/**
 * Project Member Model
 * Junction table for User-Project many-to-many relationship
 */

import { 
  Table, 
  Column, 
  Model, 
  DataType, 
  ForeignKey,
  PrimaryKey,
  CreatedAt,
  UpdatedAt,
  BelongsTo,
  Default
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';
import { Project } from './project.model';

export type ProjectRole = 'owner' | 'admin' | 'member' | 'viewer';

export interface ProjectPermissions {
  // Project management
  canUpdateProject?: boolean;
  canDeleteProject?: boolean;
  canManageMembers?: boolean;
  canManageBilling?: boolean;
  
  // Resource permissions
  canCreateJobs?: boolean;
  canViewJobs?: boolean;
  canDeleteJobs?: boolean;
  canDownloadResults?: boolean;
  
  // Integration permissions
  canManageIntegrations?: boolean;
  canManageWebhooks?: boolean;
  canManageWorkflows?: boolean;
  
  // Analytics permissions
  canViewAnalytics?: boolean;
  canExportData?: boolean;
}

@Table({
  tableName: 'project_members',
  timestamps: true
})
export class ProjectMember extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @ForeignKey(() => Project)
  @Column({
    type: DataType.UUID,
    allowNull: false
  })
  projectId!: string;

  @ForeignKey(() => User)
  @Column({
    type: DataType.UUID,
    allowNull: false
  })
  userId!: string;

  @Column({
    type: DataType.ENUM('owner', 'admin', 'member', 'viewer'),
    allowNull: false,
    defaultValue: 'member'
  })
  role!: ProjectRole;

  @Column({
    type: DataType.JSONB,
    allowNull: false,
    defaultValue: {}
  })
  permissions!: ProjectPermissions;

  @Column({
    type: DataType.DATE,
    allowNull: true
  })
  invitedAt?: Date;

  @Column({
    type: DataType.UUID,
    allowNull: true
  })
  invitedBy?: string;

  @Column({
    type: DataType.DATE,
    allowNull: true
  })
  acceptedAt?: Date;

  @Column({
    type: DataType.BOOLEAN,
    allowNull: false,
    defaultValue: true
  })
  isActive!: boolean;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  // Associations
  @BelongsTo(() => Project)
  project!: Project;

  @BelongsTo(() => User)
  user!: User;

  // Helper methods
  static getDefaultPermissions(role: ProjectRole): ProjectPermissions {
    switch (role) {
      case 'owner':
        return {
          canUpdateProject: true,
          canDeleteProject: true,
          canManageMembers: true,
          canManageBilling: true,
          canCreateJobs: true,
          canViewJobs: true,
          canDeleteJobs: true,
          canDownloadResults: true,
          canManageIntegrations: true,
          canManageWebhooks: true,
          canManageWorkflows: true,
          canViewAnalytics: true,
          canExportData: true
        };
        
      case 'admin':
        return {
          canUpdateProject: true,
          canDeleteProject: false,
          canManageMembers: true,
          canManageBilling: false,
          canCreateJobs: true,
          canViewJobs: true,
          canDeleteJobs: true,
          canDownloadResults: true,
          canManageIntegrations: true,
          canManageWebhooks: true,
          canManageWorkflows: true,
          canViewAnalytics: true,
          canExportData: true
        };
        
      case 'member':
        return {
          canUpdateProject: false,
          canDeleteProject: false,
          canManageMembers: false,
          canManageBilling: false,
          canCreateJobs: true,
          canViewJobs: true,
          canDeleteJobs: false,
          canDownloadResults: true,
          canManageIntegrations: false,
          canManageWebhooks: false,
          canManageWorkflows: true,
          canViewAnalytics: true,
          canExportData: false
        };
        
      case 'viewer':
        return {
          canUpdateProject: false,
          canDeleteProject: false,
          canManageMembers: false,
          canManageBilling: false,
          canCreateJobs: false,
          canViewJobs: true,
          canDeleteJobs: false,
          canDownloadResults: false,
          canManageIntegrations: false,
          canManageWebhooks: false,
          canManageWorkflows: false,
          canViewAnalytics: true,
          canExportData: false
        };
    }
  }

  hasPermission(permission: keyof ProjectPermissions): boolean {
    return this.permissions[permission] === true;
  }
}