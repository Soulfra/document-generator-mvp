import { promises as fs } from 'fs';
import * as path from 'path';
import { logger } from '../../utils/logger';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export interface FileInfo {
  name: string;
  path: string;
  type: 'file' | 'directory';
  size?: number;
  modified?: Date;
  permissions?: string;
}

export interface ArchiveResult {
  filename: string;
  originalPath: string;
  archivedPath: string;
  timestamp: Date;
}

export interface RestoreResult {
  filename: string;
  archivedPath: string;
  restoredPath: string;
  timestamp: Date;
}

export class FileOperationsService {
  private readonly archiveDirectory: string;
  private readonly maxFileSize = 100 * 1024 * 1024; // 100MB limit

  constructor() {
    this.archiveDirectory = path.join(process.cwd(), '.archive');
    this.ensureArchiveDirectory();
  }

  /**
   * List files in a directory
   */
  public async listFiles(directory: string = '.'): Promise<FileInfo[]> {
    try {
      // Resolve and validate directory path
      const resolvedPath = path.resolve(process.cwd(), directory);
      
      // Security check - ensure path is within project directory
      if (!resolvedPath.startsWith(process.cwd())) {
        throw new Error('Access denied: Path outside project directory');
      }

      const entries = await fs.readdir(resolvedPath, { withFileTypes: true });
      const files: FileInfo[] = [];

      for (const entry of entries) {
        const filePath = path.join(resolvedPath, entry.name);
        
        try {
          const stats = await fs.stat(filePath);
          
          files.push({
            name: entry.name,
            path: path.relative(process.cwd(), filePath),
            type: entry.isDirectory() ? 'directory' : 'file',
            size: entry.isFile() ? stats.size : undefined,
            modified: stats.mtime,
            permissions: stats.mode.toString(8),
          });
        } catch (error) {
          logger.warn('Error reading file stats', { file: entry.name, error });
        }
      }

      // Sort by type (directories first) then by name
      files.sort((a, b) => {
        if (a.type !== b.type) {
          return a.type === 'directory' ? -1 : 1;
        }
        return a.name.localeCompare(b.name);
      });

      logger.info('Listed files', { directory, count: files.length });
      return files;

    } catch (error) {
      logger.error('Error listing files', { directory, error });
      throw new Error(`Failed to list files: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Archive a file
   */
  public async archiveFile(filename: string): Promise<ArchiveResult> {
    try {
      const originalPath = path.resolve(process.cwd(), filename);
      
      // Security checks
      if (!originalPath.startsWith(process.cwd())) {
        throw new Error('Access denied: Path outside project directory');
      }

      // Check if file exists
      const stats = await fs.stat(originalPath);
      if (!stats.isFile()) {
        throw new Error('Can only archive files, not directories');
      }

      // Check file size
      if (stats.size > this.maxFileSize) {
        throw new Error(`File too large: ${stats.size} bytes (max: ${this.maxFileSize})`);
      }

      // Create archive filename with timestamp
      const timestamp = new Date();
      const basename = path.basename(filename);
      const ext = path.extname(basename);
      const nameWithoutExt = path.basename(basename, ext);
      const timestampStr = timestamp.toISOString().replace(/[:.]/g, '-');
      const archivedFilename = `${nameWithoutExt}-${timestampStr}${ext}`;
      const archivedPath = path.join(this.archiveDirectory, archivedFilename);

      // Copy file to archive
      await fs.copyFile(originalPath, archivedPath);

      // Remove original file
      await fs.unlink(originalPath);

      const result: ArchiveResult = {
        filename: basename,
        originalPath: path.relative(process.cwd(), originalPath),
        archivedPath: path.relative(process.cwd(), archivedPath),
        timestamp,
      };

      logger.info('File archived', result);
      return result;

    } catch (error) {
      logger.error('Error archiving file', { filename, error });
      throw new Error(`Failed to archive file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Restore a file from archive
   */
  public async restoreFile(filename: string): Promise<RestoreResult> {
    try {
      // Find the most recent archived version
      const archivedFiles = await this.listArchivedFiles();
      const basename = path.basename(filename);
      const nameWithoutExt = path.basename(basename, path.extname(basename));
      
      const matchingFiles = archivedFiles.filter(f => 
        f.name.startsWith(`${nameWithoutExt}-`) && 
        f.name.endsWith(path.extname(basename))
      );

      if (matchingFiles.length === 0) {
        throw new Error(`No archived version found for: ${filename}`);
      }

      // Sort by modification time (most recent first)
      matchingFiles.sort((a, b) => (b.modified || new Date(0)).getTime() - (a.modified || new Date(0)).getTime());
      
      const latestArchived = matchingFiles[0];
      const archivedPath = path.join(this.archiveDirectory, latestArchived.name);
      const restoredPath = path.resolve(process.cwd(), filename);

      // Security check for restore path
      if (!restoredPath.startsWith(process.cwd())) {
        throw new Error('Access denied: Restore path outside project directory');
      }

      // Check if target file already exists
      try {
        await fs.access(restoredPath);
        throw new Error('Target file already exists. Archive it first or choose a different name.');
      } catch (error) {
        // File doesn't exist, which is what we want
        if ((error as NodeJS.ErrnoException).code !== 'ENOENT') {
          throw error;
        }
      }

      // Ensure target directory exists
      const targetDir = path.dirname(restoredPath);
      await fs.mkdir(targetDir, { recursive: true });

      // Copy file from archive to target location
      await fs.copyFile(archivedPath, restoredPath);

      const result: RestoreResult = {
        filename: basename,
        archivedPath: path.relative(process.cwd(), archivedPath),
        restoredPath: path.relative(process.cwd(), restoredPath),
        timestamp: new Date(),
      };

      logger.info('File restored', result);
      return result;

    } catch (error) {
      logger.error('Error restoring file', { filename, error });
      throw new Error(`Failed to restore file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * List archived files
   */
  public async listArchivedFiles(): Promise<FileInfo[]> {
    try {
      return await this.listFiles(this.archiveDirectory);
    } catch (error) {
      logger.error('Error listing archived files', { error });
      return [];
    }
  }

  /**
   * Delete archived file
   */
  public async deleteArchivedFile(filename: string): Promise<void> {
    try {
      const archivedPath = path.join(this.archiveDirectory, filename);
      
      // Security check
      if (!archivedPath.startsWith(this.archiveDirectory)) {
        throw new Error('Access denied: Invalid archive path');
      }

      await fs.unlink(archivedPath);
      logger.info('Archived file deleted', { filename });

    } catch (error) {
      logger.error('Error deleting archived file', { filename, error });
      throw new Error(`Failed to delete archived file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Get archive statistics
   */
  public async getArchiveStats(): Promise<{
    totalFiles: number;
    totalSize: number;
    oldestFile?: string;
    newestFile?: string;
  }> {
    try {
      const files = await this.listArchivedFiles();
      
      if (files.length === 0) {
        return { totalFiles: 0, totalSize: 0 };
      }

      const totalSize = files.reduce((sum, file) => sum + (file.size || 0), 0);
      const sortedByDate = files
        .filter(f => f.modified)
        .sort((a, b) => (a.modified!).getTime() - (b.modified!).getTime());

      return {
        totalFiles: files.length,
        totalSize,
        oldestFile: sortedByDate[0]?.name,
        newestFile: sortedByDate[sortedByDate.length - 1]?.name,
      };

    } catch (error) {
      logger.error('Error getting archive stats', { error });
      return { totalFiles: 0, totalSize: 0 };
    }
  }

  /**
   * Clean up old archived files
   */
  public async cleanupArchive(maxAgeInDays: number = 30): Promise<number> {
    try {
      const files = await this.listArchivedFiles();
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - maxAgeInDays);

      let deletedCount = 0;

      for (const file of files) {
        if (file.modified && file.modified < cutoffDate) {
          try {
            await this.deleteArchivedFile(file.name);
            deletedCount++;
          } catch (error) {
            logger.warn('Failed to delete old archived file', { filename: file.name, error });
          }
        }
      }

      logger.info('Archive cleanup completed', { deletedCount, maxAgeInDays });
      return deletedCount;

    } catch (error) {
      logger.error('Error during archive cleanup', { error });
      throw new Error(`Archive cleanup failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Ensure archive directory exists
   */
  private async ensureArchiveDirectory(): Promise<void> {
    try {
      await fs.mkdir(this.archiveDirectory, { recursive: true });
    } catch (error) {
      logger.error('Failed to create archive directory', { error });
      throw new Error('Failed to initialize archive directory');
    }
  }

  /**
   * Get safe file operations limits
   */
  public getLimits(): {
    maxFileSize: number;
    archiveDirectory: string;
    allowedExtensions?: string[];
  } {
    return {
      maxFileSize: this.maxFileSize,
      archiveDirectory: this.archiveDirectory,
    };
  }
}

// Export singleton instance
export const fileOperations = new FileOperationsService();