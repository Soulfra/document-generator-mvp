import { TypeScriptParser } from '../../src/parsers/typescript-parser';
import { APIEndpoint, DataModel, FunctionSignature } from '../../src/types/code-analysis';
import { ParseResult } from '../../src/parsers/base-parser';

describe('TypeScriptParser', () => {
  let parser: TypeScriptParser;

  beforeEach(() => {
    parser = new TypeScriptParser();
  });

  describe('Basic Parser Properties', () => {
    it('should return correct language identifier', () => {
      expect(parser.getLanguage()).toBe('typescript');
    });

    it('should return correct supported extensions', () => {
      const extensions = parser.getSupportedExtensions();
      expect(extensions).toContain('.ts');
      expect(extensions).toContain('.tsx');
      expect(extensions).toContain('.js');
      expect(extensions).toContain('.jsx');
    });
  });

  describe('API Extraction', () => {
    describe('Express Routes', () => {
      it('should extract Express route patterns', async () => {
        const files = new Map<string, string>([
          ['server.ts', `
import express from 'express';
const app = express();
const router = express.Router();

app.get('/', (req, res) => {
  res.send('Hello World');
});

app.post('/users', async (req, res) => {
  const user = req.body;
  res.json({ id: 1, ...user });
});

router.put('/users/:id', (req, res) => {
  const { id } = req.params;
  res.json({ id, updated: true });
});

app.use('/api', router);
          `]
        ]);

        const apis = await parser.extractAPIs(files);

        expect(apis).toHaveLength(4);
        expect(apis[0]).toMatchObject({
          method: 'GET',
          path: '/',
          description: expect.stringContaining('Express')
        });
        expect(apis[1]).toMatchObject({
          method: 'POST',
          path: '/users',
          parameters: expect.arrayContaining([
            expect.objectContaining({ name: 'body' })
          ])
        });
        expect(apis[2]).toMatchObject({
          method: 'PUT',
          path: '/users/:id',
          parameters: expect.arrayContaining([
            expect.objectContaining({ name: 'id', type: 'string' })
          ])
        });
      });

      it('should detect authentication middleware', async () => {
        const files = new Map<string, string>([
          ['auth.ts', `
app.get('/protected', authenticate, (req, res) => {
  res.json({ user: req.user });
});

app.post('/login', passport.authenticate('local'), (req, res) => {
  res.json({ token: generateToken(req.user) });
});
          `]
        ]);

        const apis = await parser.extractAPIs(files);

        expect(apis[0].authentication).toBe(true);
        expect(apis[1].authentication).toBe(true);
      });
    });

    describe('Next.js Routes', () => {
      it('should extract Next.js app router API routes', async () => {
        const files = new Map<string, string>([
          ['app/api/users/route.ts', `
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  return NextResponse.json({ users: [] });
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  return NextResponse.json({ id: 1, ...body });
}
          `]
        ]);

        const apis = await parser.extractAPIs(files);

        expect(apis).toHaveLength(2);
        expect(apis[0]).toMatchObject({
          method: 'GET',
          path: '/api/users',
          description: 'Next.js API route: GET'
        });
        expect(apis[1]).toMatchObject({
          method: 'POST',
          path: '/api/users'
        });
      });

      it('should handle dynamic routes', async () => {
        const files = new Map<string, string>([
          ['app/api/posts/[id]/route.ts', `
export async function GET(request: Request, { params }: { params: { id: string } }) {
  return Response.json({ id: params.id });
}
          `]
        ]);

        const apis = await parser.extractAPIs(files);

        expect(apis[0]).toMatchObject({
          path: '/api/posts/:id'
        });
      });
    });

    describe('NestJS Routes', () => {
      it('should extract NestJS controller routes', async () => {
        const files = new Map<string, string>([
          ['users.controller.ts', `
import { Controller, Get, Post, Put, Delete, Param, Body, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Controller('users')
export class UsersController {
  @Get()
  findAll() {
    return [];
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return { id };
  }

  @Post()
  @UseGuards(AuthGuard)
  create(@Body() createUserDto: CreateUserDto) {
    return { id: 1, ...createUserDto };
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() updateUserDto: UpdateUserDto) {
    return { id, ...updateUserDto };
  }
}
          `]
        ]);

        const apis = await parser.extractAPIs(files);

        expect(apis).toHaveLength(4);
        expect(apis[0]).toMatchObject({
          method: 'GET',
          path: '/users',
          description: 'NestJS Get: findAll'
        });
        expect(apis[2]).toMatchObject({
          method: 'POST',
          path: '/users',
          authentication: true,
          parameters: expect.arrayContaining([
            expect.objectContaining({ name: 'body' })
          ])
        });
      });
    });
  });

  describe('Function Extraction', () => {
    it('should extract function declarations with type annotations', async () => {
      const files = new Map<string, string>([
        ['utils.ts', `
/**
 * Adds two numbers together
 * @param a First number
 * @param b Second number
 * @returns The sum
 */
function add(a: number, b: number): number {
  return a + b;
}

async function fetchUser(id: string): Promise<User> {
  const response = await fetch(\`/api/users/\${id}\`);
  return response.json();
}

const multiply = (x: number, y: number = 1): number => x * y;

export const divide = function(a: number, b: number): number | null {
  if (b === 0) return null;
  return a / b;
};
        `]
      ]);

      const result = await parser.parse(files);

      expect(result.functions).toHaveLength(4);
      expect(result.functions[0]).toMatchObject({
        name: 'add',
        description: expect.stringContaining('Adds two numbers'),
        parameters: [
          { name: 'a', type: 'number', required: true },
          { name: 'b', type: 'number', required: true }
        ],
        returnType: 'number'
      });
      expect(result.functions[1]).toMatchObject({
        name: 'fetchUser',
        async: true,
        returnType: expect.stringContaining('Promise')
      });
      expect(result.functions[2].parameters[1]).toMatchObject({
        name: 'y',
        defaultValue: '1',
        required: false
      });
    });

    it('should extract class methods', async () => {
      const files = new Map<string, string>([
        ['service.ts', `
export class UserService {
  constructor(private db: Database) {}

  async getUser(id: string): Promise<User | null> {
    return this.db.users.findOne({ id });
  }

  private validateEmail(email: string): boolean {
    return email.includes('@');
  }

  static createGuestUser(): User {
    return { id: 'guest', name: 'Guest User' };
  }

  get connectionString(): string {
    return this.db.connectionString;
  }
}
        `]
      ]);

      const result = await parser.parse(files);

      const methods = result.functions.filter(f => f.name.includes('UserService'));
      expect(methods.length).toBeGreaterThan(0);
      expect(methods).toContainEqual(expect.objectContaining({
        name: 'UserService.getUser',
        async: true,
        returnType: expect.stringContaining('Promise')
      }));
      expect(methods).toContainEqual(expect.objectContaining({
        name: 'UserService.validateEmail',
        visibility: 'private'
      }));
    });
  });

  describe('Data Model Extraction', () => {
    it('should extract interfaces', async () => {
      const files = new Map<string, string>([
        ['types.ts', `
export interface User {
  id: string;
  name: string;
  email: string;
  age?: number;
  roles: Role[];
  metadata: Record<string, any>;
}

interface Role extends BaseRole {
  permissions: string[];
}
        `]
      ]);

      const result = await parser.parse(files);

      expect(result.dataModels).toHaveLength(2);
      expect(result.dataModels[0]).toMatchObject({
        name: 'User',
        type: 'interface',
        properties: expect.arrayContaining([
          { name: 'id', type: 'string', required: true },
          { name: 'email', type: 'string', required: true },
          { name: 'age', type: 'number', required: false },
          { name: 'roles', type: expect.stringContaining('array'), required: true }
        ])
      });
      expect(result.dataModels[1]).toMatchObject({
        name: 'Role',
        extends: ['BaseRole']
      });
    });

    it('should extract classes with decorators', async () => {
      const files = new Map<string, string>([
        ['entities.ts', `
@Entity()
export class Product {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100 })
  name: string;

  @Column('decimal', { precision: 10, scale: 2 })
  price: number;

  @Column({ default: true })
  isActive: boolean = true;

  constructor(name: string, price: number) {
    this.name = name;
    this.price = price;
  }

  getDisplayPrice(): string {
    return \`$\${this.price.toFixed(2)}\`;
  }
}
        `]
      ]);

      const result = await parser.parse(files);

      expect(result.dataModels).toHaveLength(1);
      expect(result.dataModels[0]).toMatchObject({
        name: 'Product',
        type: 'class',
        decorators: ['@Entity()'],
        properties: expect.arrayContaining([
          { name: 'id', type: 'number', required: true },
          { name: 'name', type: 'string', required: true },
          { name: 'price', type: 'number', required: true },
          { name: 'isActive', type: 'boolean', required: false, defaultValue: 'true' }
        ]),
        methods: ['getDisplayPrice']
      });
    });

    it('should extract type aliases', async () => {
      const files = new Map<string, string>([
        ['types.ts', `
type Status = 'active' | 'inactive' | 'pending';

type UserWithPosts = User & {
  posts: Post[];
  postCount: number;
};

type ID = string | number;
        `]
      ]);

      const result = await parser.parse(files);

      // Type aliases that are object-like should be extracted
      const userWithPosts = result.dataModels.find(m => m.name === 'UserWithPosts');
      expect(userWithPosts).toBeDefined();
    });

    it('should extract enums', async () => {
      const files = new Map<string, string>([
        ['enums.ts', `
export enum UserRole {
  Admin = 'ADMIN',
  User = 'USER',
  Guest = 'GUEST'
}

enum Status {
  Active = 1,
  Inactive = 0,
  Pending = -1
}
        `]
      ]);

      const result = await parser.parse(files);

      expect(result.dataModels).toHaveLength(2);
      expect(result.dataModels[0]).toMatchObject({
        name: 'UserRole',
        type: 'enum',
        properties: expect.arrayContaining([
          { name: 'Admin', defaultValue: "'ADMIN'" },
          { name: 'User', defaultValue: "'USER'" }
        ])
      });
    });
  });

  describe('Dependency Extraction', () => {
    it('should extract dependencies from package.json', async () => {
      const files = new Map<string, string>([
        ['package.json', JSON.stringify({
          name: 'test-project',
          dependencies: {
            'express': '^4.18.0',
            'typescript': '^5.0.0'
          },
          devDependencies: {
            '@types/express': '^4.17.0',
            'jest': '^29.0.0'
          },
          peerDependencies: {
            'react': '>=16.8.0'
          },
          optionalDependencies: {
            'fsevents': '^2.3.0'
          }
        })],
        ['index.ts', 'console.log("test");']
      ]);

      const result = await parser.parse(files);

      expect(result.dependencies).toContainEqual(expect.objectContaining({
        name: 'express',
        version: '^4.18.0',
        type: 'runtime'
      }));
      expect(result.dependencies).toContainEqual(expect.objectContaining({
        name: 'jest',
        type: 'dev'
      }));
      expect(result.dependencies).toContainEqual(expect.objectContaining({
        name: 'react',
        type: 'peer'
      }));
      expect(result.dependencies).toContainEqual(expect.objectContaining({
        name: 'fsevents',
        type: 'optional'
      }));
    });
  });

  describe('Import Extraction', () => {
    it('should extract various import styles', async () => {
      const files = new Map<string, string>([
        ['imports.ts', `
import express from 'express';
import { Request, Response } from 'express';
import * as fs from 'fs';
import React, { useState, useEffect } from 'react';
import './styles.css';
import data from './data.json';
import { helper } from '../utils/helper';
        `]
      ]);

      const result = await parser.parse(files);

      expect(result.imports).toContainEqual(expect.objectContaining({
        source: 'express',
        imports: ['default'],
        alias: 'express',
        isRelative: false
      }));
      expect(result.imports).toContainEqual(expect.objectContaining({
        source: 'express',
        imports: ['Request', 'Response'],
        isRelative: false
      }));
      expect(result.imports).toContainEqual(expect.objectContaining({
        source: 'fs',
        isWildcard: true,
        alias: 'fs'
      }));
      expect(result.imports).toContainEqual(expect.objectContaining({
        source: '../utils/helper',
        isRelative: true
      }));
    });
  });

  describe('Comment Extraction', () => {
    it('should extract single-line and multi-line comments', async () => {
      const files = new Map<string, string>([
        ['comments.ts', `
// This is a single-line comment
const x = 5; // Inline comment

/*
 * This is a multi-line comment
 * with multiple lines
 */
function test() {
  /* Another multi-line comment */
  return true;
}

/**
 * This is a JSDoc comment
 * @param name The name parameter
 * @returns A greeting
 */
function greet(name: string): string {
  return \`Hello, \${name}!\`;
}
        `]
      ]);

      const result = await parser.parse(files);

      const singleComments = result.comments.filter(c => c.type === 'single');
      const multiComments = result.comments.filter(c => c.type === 'multi');
      const docComments = result.comments.filter(c => c.type === 'doc');

      expect(singleComments.length).toBeGreaterThan(0);
      expect(multiComments.length).toBeGreaterThan(0);
      expect(docComments.length).toBeGreaterThan(0);
      expect(docComments[0].content).toContain('JSDoc comment');
    });
  });

  describe('Full Parse Integration', () => {
    it('should parse a complete TypeScript file', async () => {
      const files = new Map<string, string>([
        ['app.ts', `
import express, { Request, Response, NextFunction } from 'express';
import { UserService } from './services/UserService';

interface AppConfig {
  port: number;
  debug: boolean;
}

const app = express();
const userService = new UserService();

app.use(express.json());

/**
 * Get all users
 */
app.get('/users', async (req: Request, res: Response) => {
  const users = await userService.getAllUsers();
  res.json(users);
});

/**
 * Create a new user
 */
app.post('/users', async (req: Request, res: Response) => {
  const user = await userService.createUser(req.body);
  res.status(201).json(user);
});

export default app;
        `],
        ['package.json', JSON.stringify({
          dependencies: {
            'express': '^4.18.0'
          }
        })]
      ]);

      const result = await parser.parse(files);

      expect(result.apis.length).toBeGreaterThan(0);
      expect(result.dataModels.length).toBeGreaterThan(0);
      expect(result.imports.length).toBeGreaterThan(0);
      expect(result.dependencies.length).toBeGreaterThan(0);
      expect(result.comments.length).toBeGreaterThan(0);
    });
  });

  describe('JavaScript Support', () => {
    it('should parse JavaScript files', async () => {
      const files = new Map<string, string>([
        ['app.js', `
const express = require('express');
const app = express();

// Simple route
app.get('/', (req, res) => {
  res.send('Hello from JS!');
});

function calculateSum(a, b) {
  return a + b;
}

class Calculator {
  add(x, y) {
    return x + y;
  }
}

module.exports = app;
        `]
      ]);

      const result = await parser.parse(files);

      expect(result.apis).toHaveLength(1);
      expect(result.functions.length).toBeGreaterThan(0);
      expect(result.dataModels).toHaveLength(1);
    });
  });
});