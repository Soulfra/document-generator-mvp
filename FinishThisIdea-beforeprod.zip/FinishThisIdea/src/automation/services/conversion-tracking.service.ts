import { AnalyticsIntegrationService } from './analytics-integration.service';
import { User, UserTier } from '@prisma/client';

export interface ConversionEvent {
  userId: string;
  event: string;
  properties?: Record<string, any>;
  timestamp?: Date;
}

export interface FunnelStep {
  name: string;
  event: string;
  description: string;
}

// Define conversion funnels
const CONVERSION_FUNNELS = {
  signup: [
    { name: 'Landing Page View', event: 'page_view_landing', description: 'User views landing page' },
    { name: 'Signup Started', event: 'signup_started', description: 'User clicks signup' },
    { name: 'Signup Completed', event: 'signup_completed', description: 'User completes registration' },
    { name: 'First Upload', event: 'first_file_uploaded', description: 'User uploads first file' },
    { name: 'First Job Completed', event: 'first_job_completed', description: 'First processing completed' },
  ],
  upgrade: [
    { name: 'Paywall Hit', event: 'paywall_hit', description: 'User encounters paywall' },
    { name: 'Upgrade Clicked', event: 'upgrade_clicked', description: 'User clicks upgrade button' },
    { name: 'Checkout Started', event: 'checkout_started', description: 'User starts checkout' },
    { name: 'Payment Completed', event: 'payment_completed', description: 'Payment successful' },
    { name: 'Premium Activated', event: 'premium_activated', description: 'User tier upgraded' },
  ],
  retention: [
    { name: 'User Active', event: 'user_active', description: 'User logs in' },
    { name: 'File Uploaded', event: 'file_uploaded', description: 'User uploads file' },
    { name: 'Documentation Generated', event: 'documentation_generated', description: 'Job completes' },
    { name: 'Documentation Downloaded', event: 'documentation_downloaded', description: 'User downloads result' },
    { name: 'Return Visit', event: 'return_visit', description: 'User returns after 24h' },
  ],
};

export class ConversionTrackingService {
  private analytics: AnalyticsIntegrationService;

  constructor() {
    this.analytics = new AnalyticsIntegrationService();
  }

  /**
   * Track a conversion event
   */
  public async trackConversion(
    userId: string,
    event: string,
    properties?: Record<string, any>
  ): Promise<void> {
    const timestamp = new Date();
    
    // Add funnel context if this event is part of a funnel
    const funnelContext = this.getFunnelContext(event);
    
    await this.analytics.track({
      userId,
      event,
      properties: {
        ...properties,
        ...funnelContext,
        timestamp: timestamp.toISOString(),
      },
      timestamp,
    });
  }

  /**
   * Track signup funnel progress
   */
  public async trackSignupFunnel(
    userId: string,
    step: 'landing' | 'started' | 'completed' | 'first_upload' | 'first_job',
    properties?: Record<string, any>
  ): Promise<void> {
    const eventMap = {
      landing: 'page_view_landing',
      started: 'signup_started',
      completed: 'signup_completed',
      first_upload: 'first_file_uploaded',
      first_job: 'first_job_completed',
    };

    await this.trackConversion(userId, eventMap[step], {
      funnel: 'signup',
      funnel_step: step,
      ...properties,
    });
  }

  /**
   * Track upgrade funnel progress
   */
  public async trackUpgradeFunnel(
    userId: string,
    step: 'paywall' | 'clicked' | 'checkout' | 'payment' | 'activated',
    properties?: Record<string, any>
  ): Promise<void> {
    const eventMap = {
      paywall: 'paywall_hit',
      clicked: 'upgrade_clicked',
      checkout: 'checkout_started',
      payment: 'payment_completed',
      activated: 'premium_activated',
    };

    await this.trackConversion(userId, eventMap[step], {
      funnel: 'upgrade',
      funnel_step: step,
      ...properties,
    });
  }

  /**
   * Track user retention metrics
   */
  public async trackRetention(
    userId: string,
    action: 'active' | 'upload' | 'generate' | 'download' | 'return',
    properties?: Record<string, any>
  ): Promise<void> {
    const eventMap = {
      active: 'user_active',
      upload: 'file_uploaded',
      generate: 'documentation_generated',
      download: 'documentation_downloaded',
      return: 'return_visit',
    };

    await this.trackConversion(userId, eventMap[action], {
      funnel: 'retention',
      action,
      ...properties,
    });
  }

  /**
   * Track custom conversion goals
   */
  public async trackGoal(
    userId: string,
    goalName: string,
    value?: number,
    properties?: Record<string, any>
  ): Promise<void> {
    await this.trackConversion(userId, `goal_${goalName}`, {
      goal_name: goalName,
      goal_value: value,
      ...properties,
    });
  }

  /**
   * Calculate conversion rate between funnel steps
   */
  public async calculateConversionRate(
    funnel: 'signup' | 'upgrade' | 'retention',
    startStep: string,
    endStep: string,
    timeRange: { start: Date; end: Date }
  ): Promise<number> {
    // This would typically query your analytics database
    // For now, we'll track the request
    await this.analytics.track({
      userId: 'system',
      event: 'conversion_rate_calculated',
      properties: {
        funnel,
        start_step: startStep,
        end_step: endStep,
        time_range: timeRange,
      },
      timestamp: new Date(),
    });

    // Return placeholder - implement actual calculation with your analytics DB
    return 0;
  }

  /**
   * Track A/B test conversions
   */
  public async trackABTest(
    userId: string,
    testName: string,
    variant: string,
    converted: boolean,
    properties?: Record<string, any>
  ): Promise<void> {
    await this.trackConversion(userId, 'ab_test_event', {
      test_name: testName,
      variant,
      converted,
      ...properties,
    });
  }

  /**
   * Get funnel context for an event
   */
  private getFunnelContext(event: string): Record<string, any> {
    for (const [funnelName, steps] of Object.entries(CONVERSION_FUNNELS)) {
      const stepIndex = steps.findIndex(step => step.event === event);
      if (stepIndex !== -1) {
        return {
          funnel: funnelName,
          funnel_step_index: stepIndex,
          funnel_step_name: steps[stepIndex].name,
          funnel_total_steps: steps.length,
        };
      }
    }
    return {};
  }

  /**
   * Track revenue metrics
   */
  public async trackRevenue(
    userId: string,
    amount: number,
    currency: string = 'USD',
    properties?: Record<string, any>
  ): Promise<void> {
    await this.trackConversion(userId, 'revenue_generated', {
      revenue_amount: amount,
      revenue_currency: currency,
      ...properties,
    });
  }

  /**
   * Track user lifecycle events
   */
  public async trackLifecycle(
    userId: string,
    stage: 'activated' | 'engaged' | 'retained' | 'churned' | 'reactivated',
    properties?: Record<string, any>
  ): Promise<void> {
    await this.trackConversion(userId, `lifecycle_${stage}`, {
      lifecycle_stage: stage,
      ...properties,
    });
  }
}

// Export singleton instance
export const conversionTracking = new ConversionTrackingService();