import request from 'supertest';
import { app } from '../../src/server';
import { testDb } from '../utils/test-database';
import { SampleGenerator } from '../utils/sample-generator';
import { performance } from 'perf_hooks';

describe('Load Testing E2E', () => {
  let testZipPath: string;

  beforeAll(async () => {
    await testDb.setup({ seedData: true });
    
    // Generate a small test project for load testing
    testZipPath = await SampleGenerator.generateSample('simple-js', './temp');
  });

  afterAll(async () => {
    await testDb.cleanup();
    await testDb.teardown();
  });

  describe('Concurrent Upload Load Test', () => {
    it('should handle 10 concurrent uploads', async () => {
      const concurrentRequests = 10;
      const startTime = performance.now();
      
      const promises = Array.from({ length: concurrentRequests }, (_, index) =>
        request(app)
          .post('/api/upload')
          .attach('file', testZipPath)
          .field('type', 'DOCUMENTATION')
          .field('contextProfileId', 'react-typescript')
          .expect(res => {
            expect([200, 201, 202]).toContain(res.status);
          })
      );

      const results = await Promise.allSettled(promises);
      const endTime = performance.now();
      
      const successCount = results.filter(r => r.status === 'fulfilled').length;
      const failureCount = results.filter(r => r.status === 'rejected').length;
      
      console.log(`Load Test Results:
        - Total requests: ${concurrentRequests}
        - Successful: ${successCount}
        - Failed: ${failureCount}
        - Total time: ${(endTime - startTime).toFixed(2)}ms
        - Average time per request: ${((endTime - startTime) / concurrentRequests).toFixed(2)}ms
      `);

      // At least 80% success rate
      expect(successCount / concurrentRequests).toBeGreaterThanOrEqual(0.8);
      
      // Should complete within 30 seconds
      expect(endTime - startTime).toBeLessThan(30000);
    }, 60000);

    it('should handle concurrent users across different endpoints', async () => {
      const userActions = [
        // Health checks
        () => request(app).get('/health').expect(200),
        () => request(app).get('/health/detailed').expect(200),
        
        // Profile operations
        () => request(app).get('/api/profiles').expect(200),
        
        // Upload operations
        () => request(app)
          .post('/api/upload')
          .attach('file', testZipPath)
          .field('type', 'DOCUMENTATION')
          .expect(res => expect([200, 201, 202]).toContain(res.status)),
      ];

      const startTime = performance.now();
      
      // Simulate 20 users performing random actions
      const promises = Array.from({ length: 20 }, () => {
        const randomAction = userActions[Math.floor(Math.random() * userActions.length)];
        return randomAction();
      });

      const results = await Promise.allSettled(promises);
      const endTime = performance.now();
      
      const successCount = results.filter(r => r.status === 'fulfilled').length;
      
      console.log(`Mixed Load Test Results:
        - Total requests: ${promises.length}
        - Successful: ${successCount}
        - Success rate: ${(successCount / promises.length * 100).toFixed(1)}%
        - Total time: ${(endTime - startTime).toFixed(2)}ms
      `);

      expect(successCount / promises.length).toBeGreaterThanOrEqual(0.9);
    }, 45000);
  });

  describe('Memory and Performance Tests', () => {
    it('should not have memory leaks during repeated operations', async () => {
      const initialMemory = process.memoryUsage();
      
      // Perform 50 health checks
      for (let i = 0; i < 50; i++) {
        await request(app).get('/health').expect(200);
      }
      
      // Force garbage collection if available
      if (global.gc) {
        global.gc();
      }
      
      const finalMemory = process.memoryUsage();
      const memoryIncrease = finalMemory.heapUsed - initialMemory.heapUsed;
      
      console.log(`Memory usage:
        - Initial: ${(initialMemory.heapUsed / 1024 / 1024).toFixed(2)} MB
        - Final: ${(finalMemory.heapUsed / 1024 / 1024).toFixed(2)} MB
        - Increase: ${(memoryIncrease / 1024 / 1024).toFixed(2)} MB
      `);

      // Memory increase should be reasonable (less than 50MB)
      expect(memoryIncrease).toBeLessThan(50 * 1024 * 1024);
    }, 30000);

    it('should respond to health checks within acceptable time', async () => {
      const iterations = 10;
      const times: number[] = [];
      
      for (let i = 0; i < iterations; i++) {
        const start = performance.now();
        await request(app).get('/health').expect(200);
        const end = performance.now();
        times.push(end - start);
      }
      
      const avgTime = times.reduce((a, b) => a + b, 0) / times.length;
      const maxTime = Math.max(...times);
      
      console.log(`Health check performance:
        - Average response time: ${avgTime.toFixed(2)}ms
        - Max response time: ${maxTime.toFixed(2)}ms
        - Min response time: ${Math.min(...times).toFixed(2)}ms
      `);

      // Average response time should be under 100ms
      expect(avgTime).toBeLessThan(100);
      
      // Max response time should be under 500ms
      expect(maxTime).toBeLessThan(500);
    });
  });

  describe('Rate Limiting Tests', () => {
    it('should enforce rate limits on API endpoints', async () => {
      // Test rate limiting by making many rapid requests
      const rapidRequests = 100;
      const promises = Array.from({ length: rapidRequests }, () =>
        request(app).get('/health')
      );

      const results = await Promise.allSettled(promises);
      
      const tooManyRequestsCount = results.filter(result => 
        result.status === 'fulfilled' && 
        (result.value as any).status === 429
      ).length;

      console.log(`Rate limiting test:
        - Total requests: ${rapidRequests}
        - Rate limited (429): ${tooManyRequestsCount}
        - Successful: ${results.filter(r => 
          r.status === 'fulfilled' && (r.value as any).status === 200
        ).length}
      `);

      // Should have some rate limiting in effect
      // (This depends on your actual rate limiting configuration)
    }, 15000);
  });

  describe('Error Handling Under Load', () => {
    it('should gracefully handle invalid requests under load', async () => {
      const invalidRequests = Array.from({ length: 20 }, () =>
        request(app)
          .post('/api/upload')
          .send({ invalid: 'data' })
          .expect(400)
      );

      const results = await Promise.allSettled(invalidRequests);
      const successfulErrorHandling = results.filter(r => r.status === 'fulfilled').length;
      
      console.log(`Error handling under load:
        - Invalid requests sent: ${invalidRequests.length}
        - Properly handled (400): ${successfulErrorHandling}
      `);

      // All invalid requests should be handled properly
      expect(successfulErrorHandling).toBe(invalidRequests.length);
    });

    it('should maintain system stability during mixed valid/invalid requests', async () => {
      const mixedRequests = [
        // Valid requests
        ...Array.from({ length: 5 }, () => 
          request(app).get('/health').expect(200)
        ),
        // Invalid requests
        ...Array.from({ length: 5 }, () =>
          request(app).post('/api/upload').send({}).expect(400)
        ),
        // More valid requests
        ...Array.from({ length: 5 }, () =>
          request(app).get('/api/profiles').expect(200)
        ),
      ];

      // Shuffle the requests
      const shuffled = mixedRequests.sort(() => Math.random() - 0.5);
      
      const results = await Promise.allSettled(shuffled);
      const successCount = results.filter(r => r.status === 'fulfilled').length;
      
      console.log(`Mixed request test:
        - Total requests: ${shuffled.length}
        - Successfully handled: ${successCount}
        - Success rate: ${(successCount / shuffled.length * 100).toFixed(1)}%
      `);

      // All requests should be handled (even if they return errors)
      expect(successCount).toBe(shuffled.length);
    });
  });
});