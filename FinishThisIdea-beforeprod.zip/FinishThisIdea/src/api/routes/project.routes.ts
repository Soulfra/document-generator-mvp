/**
 * Project Management Routes
 * API endpoints for project CRUD and member management
 */

import { Router, Request, Response } from 'express';
import { authenticate } from '../../middleware/auth.middleware';
import { 
  extractProjectContext, 
  requireProject, 
  requireProjectMember,
  requireProjectPermission 
} from '../../middleware/project-auth.middleware';
import { Project, ProjectSettings } from '../../models/project.model';
import { ProjectMember } from '../../models/project-member.model';
import { ProjectInvite } from '../../models/project-invite.model';
import { User } from '../../models/user.model';
import { logger } from '../../utils/logger';
import { EmailService } from '../../services/email.service';
import { Op } from 'sequelize';

const router = Router();
const emailService = new EmailService();

/**
 * Get user's projects
 */
router.get('/projects', authenticate, async (req: Request, res: Response) => {
  try {
    const memberships = await ProjectMember.findAll({
      where: {
        userId: req.user!.id,
        isActive: true
      },
      include: [{
        model: Project,
        required: true
      }]
    });
    
    const projects = memberships.map(m => ({
      ...m.project.toJSON(),
      role: m.role,
      permissions: m.permissions
    }));
    
    res.json({
      success: true,
      data: projects
    });
  } catch (error) {
    logger.error('Failed to fetch projects:', error);
    res.status(500).json({
      success: false,
      error: {
        message: 'Failed to fetch projects',
        code: 'FETCH_PROJECTS_ERROR'
      }
    });
  }
});

/**
 * Create a new project
 */
router.post('/projects', authenticate, async (req: Request, res: Response) => {
  try {
    const { name, description, slug } = req.body;
    
    if (!name || !slug) {
      return res.status(400).json({
        success: false,
        error: {
          message: 'Name and slug are required',
          code: 'VALIDATION_ERROR'
        }
      });
    }
    
    // Check if slug is unique
    const existingProject = await Project.findOne({ where: { slug } });
    if (existingProject) {
      return res.status(400).json({
        success: false,
        error: {
          message: 'Slug already in use',
          code: 'SLUG_EXISTS'
        }
      });
    }
    
    // Create project
    const project = await Project.create({
      name,
      description,
      slug,
      ownerId: req.user!.id,
      settings: {}
    });
    
    // Add creator as owner
    await ProjectMember.create({
      projectId: project.id,
      userId: req.user!.id,
      role: 'owner',
      permissions: ProjectMember.getDefaultPermissions('owner'),
      acceptedAt: new Date()
    });
    
    res.status(201).json({
      success: true,
      data: project
    });
  } catch (error) {
    logger.error('Failed to create project:', error);
    res.status(500).json({
      success: false,
      error: {
        message: 'Failed to create project',
        code: 'CREATE_PROJECT_ERROR'
      }
    });
  }
});

/**
 * Get project details
 */
router.get(
  '/projects/:projectId',
  authenticate,
  extractProjectContext,
  requireProject,
  requireProjectMember,
  async (req: Request, res: Response) => {
    try {
      const project = req.project!;
      
      // Get member count
      const memberCount = await ProjectMember.count({
        where: { projectId: project.id, isActive: true }
      });
      
      // Get usage stats if user has permission
      let usage = null;
      if (req.projectMember!.hasPermission('canViewAnalytics')) {
        const { gatewayService } = await import('../../gateway/gateway.service');
        usage = await gatewayService.getProjectUsage(project.id);
      }
      
      res.json({
        success: true,
        data: {
          ...project.toJSON(),
          memberCount,
          usage,
          currentUserRole: req.projectMember!.role,
          currentUserPermissions: req.projectMember!.permissions
        }
      });
    } catch (error) {
      logger.error('Failed to fetch project details:', error);
      res.status(500).json({
        success: false,
        error: {
          message: 'Failed to fetch project details',
          code: 'FETCH_PROJECT_ERROR'
        }
      });
    }
  }
);

/**
 * Update project settings
 */
router.patch(
  '/projects/:projectId',
  authenticate,
  extractProjectContext,
  requireProject,
  requireProjectMember,
  requireProjectPermission('canUpdateProject'),
  async (req: Request, res: Response) => {
    try {
      const { name, description, settings } = req.body;
      const project = req.project!;
      
      // Update fields
      if (name) project.name = name;
      if (description !== undefined) project.description = description;
      if (settings) {
        project.settings = {
          ...project.settings,
          ...settings
        } as ProjectSettings;
      }
      
      await project.save();
      
      res.json({
        success: true,
        data: project
      });
    } catch (error) {
      logger.error('Failed to update project:', error);
      res.status(500).json({
        success: false,
        error: {
          message: 'Failed to update project',
          code: 'UPDATE_PROJECT_ERROR'
        }
      });
    }
  }
);

/**
 * Get project members
 */
router.get(
  '/projects/:projectId/members',
  authenticate,
  extractProjectContext,
  requireProject,
  requireProjectMember,
  async (req: Request, res: Response) => {
    try {
      const members = await ProjectMember.findAll({
        where: {
          projectId: req.project!.id,
          isActive: true
        },
        include: [{
          model: User,
          attributes: ['id', 'email', 'username', 'createdAt']
        }]
      });
      
      res.json({
        success: true,
        data: members.map(m => ({
          id: m.id,
          user: m.user,
          role: m.role,
          permissions: m.permissions,
          joinedAt: m.acceptedAt || m.createdAt
        }))
      });
    } catch (error) {
      logger.error('Failed to fetch project members:', error);
      res.status(500).json({
        success: false,
        error: {
          message: 'Failed to fetch project members',
          code: 'FETCH_MEMBERS_ERROR'
        }
      });
    }
  }
);

/**
 * Invite member to project
 */
router.post(
  '/projects/:projectId/members/invite',
  authenticate,
  extractProjectContext,
  requireProject,
  requireProjectMember,
  requireProjectPermission('canManageMembers'),
  async (req: Request, res: Response) => {
    try {
      const { email, role = 'member', message } = req.body;
      const project = req.project!;
      
      if (!email) {
        return res.status(400).json({
          success: false,
          error: {
            message: 'Email is required',
            code: 'VALIDATION_ERROR'
          }
        });
      }
      
      // Check if already a member
      const existingUser = await User.findOne({ where: { email } });
      if (existingUser) {
        const existingMember = await ProjectMember.findOne({
          where: {
            projectId: project.id,
            userId: existingUser.id,
            isActive: true
          }
        });
        
        if (existingMember) {
          return res.status(400).json({
            success: false,
            error: {
              message: 'User is already a member',
              code: 'ALREADY_MEMBER'
            }
          });
        }
      }
      
      // Check for existing pending invite
      const existingInvite = await ProjectInvite.findOne({
        where: {
          projectId: project.id,
          email,
          status: 'pending'
        }
      });
      
      if (existingInvite && existingInvite.isValid()) {
        return res.status(400).json({
          success: false,
          error: {
            message: 'Invitation already sent',
            code: 'INVITE_EXISTS'
          }
        });
      }
      
      // Create invite
      const invite = await ProjectInvite.create({
        projectId: project.id,
        email,
        role,
        invitedBy: req.user!.id,
        token: ProjectInvite.generateToken(),
        message
      });
      
      // Send invitation email
      await emailService.sendEmail(email, {
        subject: `You're invited to join ${project.name}`,
        template: 'project-invite',
        data: {
          projectName: project.name,
          inviterName: req.user!.username || req.user!.email,
          role,
          message,
          inviteUrl: `${process.env.FRONTEND_URL}/invites/${invite.token}`
        }
      });
      
      res.json({
        success: true,
        data: {
          id: invite.id,
          email,
          role,
          expiresAt: invite.expiresAt
        }
      });
    } catch (error) {
      logger.error('Failed to send invite:', error);
      res.status(500).json({
        success: false,
        error: {
          message: 'Failed to send invitation',
          code: 'INVITE_ERROR'
        }
      });
    }
  }
);

/**
 * Accept project invite
 */
router.post('/invites/:token/accept', authenticate, async (req: Request, res: Response) => {
  try {
    const { token } = req.params;
    
    const invite = await ProjectInvite.findOne({
      where: { token },
      include: [Project]
    });
    
    if (!invite) {
      return res.status(404).json({
        success: false,
        error: {
          message: 'Invitation not found',
          code: 'INVITE_NOT_FOUND'
        }
      });
    }
    
    if (!invite.isValid()) {
      return res.status(400).json({
        success: false,
        error: {
          message: 'Invitation has expired or been used',
          code: 'INVITE_INVALID'
        }
      });
    }
    
    // Create membership
    const membership = await ProjectMember.create({
      projectId: invite.projectId,
      userId: req.user!.id,
      role: invite.role,
      permissions: ProjectMember.getDefaultPermissions(invite.role),
      invitedAt: invite.createdAt,
      invitedBy: invite.invitedBy,
      acceptedAt: new Date()
    });
    
    // Update invite status
    invite.status = 'accepted';
    invite.acceptedAt = new Date();
    await invite.save();
    
    res.json({
      success: true,
      data: {
        project: invite.project,
        membership
      }
    });
  } catch (error) {
    logger.error('Failed to accept invite:', error);
    res.status(500).json({
      success: false,
      error: {
        message: 'Failed to accept invitation',
        code: 'ACCEPT_INVITE_ERROR'
      }
    });
  }
});

/**
 * Switch active project
 */
router.post('/auth/switch-project', authenticate, async (req: Request, res: Response) => {
  try {
    const { projectId } = req.body;
    
    if (!projectId) {
      return res.status(400).json({
        success: false,
        error: {
          message: 'Project ID is required',
          code: 'VALIDATION_ERROR'
        }
      });
    }
    
    // Verify membership
    const membership = await ProjectMember.findOne({
      where: {
        projectId,
        userId: req.user!.id,
        isActive: true
      },
      include: [Project]
    });
    
    if (!membership) {
      return res.status(403).json({
        success: false,
        error: {
          message: 'You are not a member of this project',
          code: 'NOT_MEMBER'
        }
      });
    }
    
    // Update user's active project (would need to add this field to User model)
    // For now, return new JWT with project context
    const jwt = require('jsonwebtoken');
    const token = jwt.sign(
      {
        id: req.user!.id,
        email: req.user!.email,
        activeProjectId: projectId
      },
      process.env.JWT_SECRET!,
      { expiresIn: '7d' }
    );
    
    res.json({
      success: true,
      data: {
        token,
        project: membership.project,
        role: membership.role,
        permissions: membership.permissions
      }
    });
  } catch (error) {
    logger.error('Failed to switch project:', error);
    res.status(500).json({
      success: false,
      error: {
        message: 'Failed to switch project',
        code: 'SWITCH_PROJECT_ERROR'
      }
    });
  }
});

export default router;