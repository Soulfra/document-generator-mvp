/**
 * Base Plugin Class
 * Abstract base class that all workflow step plugins should extend
 */

import {
  WorkflowStepPlugin,
  PluginMetadata,
  PluginField,
  PluginExecutionResult
} from './interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../interfaces/workflow.interface';
import { Logger } from 'winston';
import { createLogger } from '../../utils/logger';

export abstract class BasePlugin implements WorkflowStepPlugin {
  protected logger: Logger;
  protected config: Record<string, any>;
  
  abstract metadata: PluginMetadata;
  abstract fields: PluginField[];
  
  constructor(config?: Record<string, any>) {
    this.config = config || {};
    this.logger = createLogger(`plugin:${this.constructor.name}`);
  }
  
  /**
   * Default validation implementation
   * Can be overridden by plugins for custom validation
   */
  async validate(step: WorkflowStep): Promise<{ valid: boolean; errors?: string[] }> {
    const errors: string[] = [];
    
    // Check required fields
    for (const field of this.fields) {
      if (field.required && !step[field.name]) {
        errors.push(`Required field '${field.label || field.name}' is missing`);
      }
      
      // Type validation
      const value = step[field.name];
      if (value !== undefined && value !== null) {
        switch (field.type) {
          case 'number':
            if (typeof value !== 'number') {
              errors.push(`Field '${field.label || field.name}' must be a number`);
            } else {
              if (field.validation?.min !== undefined && value < field.validation.min) {
                errors.push(`Field '${field.label || field.name}' must be at least ${field.validation.min}`);
              }
              if (field.validation?.max !== undefined && value > field.validation.max) {
                errors.push(`Field '${field.label || field.name}' must be at most ${field.validation.max}`);
              }
            }
            break;
            
          case 'text':
          case 'textarea':
            if (typeof value !== 'string') {
              errors.push(`Field '${field.label || field.name}' must be a string`);
            } else {
              if (field.validation?.minLength !== undefined && value.length < field.validation.minLength) {
                errors.push(`Field '${field.label || field.name}' must be at least ${field.validation.minLength} characters`);
              }
              if (field.validation?.maxLength !== undefined && value.length > field.validation.maxLength) {
                errors.push(`Field '${field.label || field.name}' must be at most ${field.validation.maxLength} characters`);
              }
              if (field.validation?.pattern) {
                const regex = new RegExp(field.validation.pattern);
                if (!regex.test(value)) {
                  errors.push(`Field '${field.label || field.name}' does not match required pattern`);
                }
              }
            }
            break;
            
          case 'boolean':
            if (typeof value !== 'boolean') {
              errors.push(`Field '${field.label || field.name}' must be a boolean`);
            }
            break;
            
          case 'select':
            if (field.options && !field.options.some(opt => opt.value === value)) {
              errors.push(`Field '${field.label || field.name}' must be one of: ${field.options.map(o => o.value).join(', ')}`);
            }
            break;
            
          case 'json':
            if (typeof value === 'string') {
              try {
                JSON.parse(value);
              } catch {
                errors.push(`Field '${field.label || field.name}' must be valid JSON`);
              }
            }
            break;
        }
      }
    }
    
    return {
      valid: errors.length === 0,
      errors: errors.length > 0 ? errors : undefined
    };
  }
  
  /**
   * Abstract execute method - must be implemented by plugins
   */
  abstract execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult>;
  
  /**
   * Helper method to create a successful result
   */
  protected success(data?: any, duration?: number, messages?: string[]): PluginExecutionResult {
    return {
      success: true,
      data,
      duration: duration || 0,
      messages
    };
  }
  
  /**
   * Helper method to create a failure result
   */
  protected failure(error: string, duration?: number): PluginExecutionResult {
    return {
      success: false,
      error,
      duration: duration || 0
    };
  }
  
  /**
   * Helper method to measure execution time
   */
  protected async measureExecution<T>(
    fn: () => Promise<T>
  ): Promise<{ result: T; duration: number }> {
    const start = Date.now();
    const result = await fn();
    const duration = Date.now() - start;
    return { result, duration };
  }
  
  /**
   * Optional lifecycle hooks - can be overridden by plugins
   */
  async onLoad(): Promise<void> {
    this.logger.info(`Plugin '${this.metadata.name}' loaded`);
  }
  
  async onUnload(): Promise<void> {
    this.logger.info(`Plugin '${this.metadata.name}' unloaded`);
  }
  
  async beforeWorkflowStart(context: WorkflowContext): Promise<void> {
    // Optional hook
  }
  
  async afterWorkflowComplete(context: WorkflowContext): Promise<void> {
    // Optional hook
  }
  
  /**
   * Default test connection implementation
   */
  async testConnection(config: Record<string, any>): Promise<{ success: boolean; message?: string }> {
    return {
      success: true,
      message: 'Plugin loaded successfully'
    };
  }
}