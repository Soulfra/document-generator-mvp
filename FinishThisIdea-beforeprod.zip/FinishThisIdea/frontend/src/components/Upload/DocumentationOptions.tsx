import { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Book, Code, TestTube, Users, Shield, Crown } from 'lucide-react';
import { usePremiumFeatures } from '../../hooks/usePremiumFeatures';
import { FeatureGate, PremiumBadge } from '../Premium/FeatureGate';

interface DocumentationOptionsProps {
  onOptionsChange: (options: DocumentationOptions) => void;
}

export interface DocumentationOptions {
  generateDocs: boolean;
  templates: string[];
  importChatLog: boolean;
  chatLogText?: string;
}

const TEMPLATE_OPTIONS = [
  {
    id: 'executive-summary',
    name: 'Executive Summary',
    description: 'High-level overview for stakeholders',
    icon: FileText,
    recommended: true,
    premium: false,
  },
  {
    id: 'api-contract',
    name: 'API Documentation',
    description: 'Complete API specs with OpenAPI',
    icon: Code,
    recommended: true,
    premium: false,
  },
  {
    id: 'data-models',
    name: 'Data Models',
    description: 'Database schemas and structures',
    icon: Book,
    recommended: true,
    premium: false,
  },
  {
    id: 'test-plan',
    name: 'Test Plan',
    description: 'Testing strategy and requirements',
    icon: TestTube,
    recommended: false,
    premium: true,
  },
  {
    id: 'user-stories',
    name: 'User Stories',
    description: 'User personas and requirements',
    icon: Users,
    recommended: false,
    premium: true,
  },
  {
    id: 'technical-requirements',
    name: 'Technical Requirements',
    description: 'Detailed technical specifications',
    icon: Shield,
    recommended: false,
    premium: true,
  },
  {
    id: 'enterprise-architecture',
    name: 'Enterprise Architecture',
    description: 'Advanced system architecture documentation',
    icon: Crown,
    recommended: false,
    premium: true,
  },
];

const DocumentationOptions: React.FC<DocumentationOptionsProps> = ({ onOptionsChange }) => {
  const [generateDocs, setGenerateDocs] = useState(false);
  const [selectedTemplates, setSelectedTemplates] = useState<string[]>(
    TEMPLATE_OPTIONS.filter(t => t.recommended && !t.premium).map(t => t.id)
  );
  const [importChatLog, setImportChatLog] = useState(false);
  const [chatLogText, setChatLogText] = useState('');
  const { advancedTemplates } = usePremiumFeatures();

  const handleGenerateDocsChange = (enabled: boolean) => {
    setGenerateDocs(enabled);
    onOptionsChange({
      generateDocs: enabled,
      templates: enabled ? selectedTemplates : [],
      importChatLog: enabled && importChatLog,
      chatLogText: enabled && importChatLog ? chatLogText : undefined,
    });
  };

  const handleTemplateToggle = (templateId: string) => {
    const template = TEMPLATE_OPTIONS.find(t => t.id === templateId);
    
    // Check if this is a premium template
    if (template?.premium) {
      const featureCheck = advancedTemplates();
      if (!featureCheck.isAllowed) {
        featureCheck.showPaywall();
        return;
      }
    }
    
    const newTemplates = selectedTemplates.includes(templateId)
      ? selectedTemplates.filter(id => id !== templateId)
      : [...selectedTemplates, templateId];
    
    setSelectedTemplates(newTemplates);
    
    if (generateDocs) {
      onOptionsChange({
        generateDocs,
        templates: newTemplates,
        importChatLog,
        chatLogText: importChatLog ? chatLogText : undefined,
      });
    }
  };

  const handleImportChatLogChange = (enabled: boolean) => {
    setImportChatLog(enabled);
    
    if (generateDocs) {
      onOptionsChange({
        generateDocs,
        templates: selectedTemplates,
        importChatLog: enabled,
        chatLogText: enabled ? chatLogText : undefined,
      });
    }
  };

  const handleChatLogTextChange = (text: string) => {
    setChatLogText(text);
    
    if (generateDocs && importChatLog) {
      onOptionsChange({
        generateDocs,
        templates: selectedTemplates,
        importChatLog,
        chatLogText: text,
      });
    }
  };

  const calculateDocsCost = () => {
    if (!generateDocs) return 0;
    const baseCost = 1; // $1 base for documentation
    const templateCost = selectedTemplates.length * 0.5; // $0.50 per template
    return Math.max(baseCost, templateCost);
  };

  return (
    <div className="space-y-6">
      {/* Main toggle */}
      <div className="glass-card p-6">
        <label className="flex items-center justify-between cursor-pointer">
          <div className="flex items-start space-x-4">
            <FileText className="w-6 h-6 text-purple-400 mt-0.5" />
            <div>
              <span className="text-lg font-medium">Generate Documentation</span>
              <p className="text-sm text-gray-400 mt-1">
                Auto-generate professional documentation from your code
              </p>
            </div>
          </div>
          <input
            type="checkbox"
            checked={generateDocs}
            onChange={(e) => handleGenerateDocsChange(e.target.checked)}
            className="sr-only"
          />
          <div className={`toggle ${generateDocs ? 'bg-purple-600' : 'bg-gray-700'}`}>
            <div className={`toggle-handle ${generateDocs ? 'translate-x-6' : 'translate-x-0'}`} />
          </div>
        </label>
      </div>

      {/* Template selection */}
      {generateDocs && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="space-y-4"
        >
          <h3 className="text-lg font-medium">Select Documentation Templates</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {TEMPLATE_OPTIONS.map((template) => {
              const Icon = template.icon;
              const isSelected = selectedTemplates.includes(template.id);
              const featureCheck = template.premium ? advancedTemplates() : { isAllowed: true };
              
              const templateButton = (
                <motion.button
                  key={template.id}
                  onClick={() => handleTemplateToggle(template.id)}
                  disabled={template.premium && !featureCheck.isAllowed}
                  className={`glass-card p-4 text-left transition-all ${
                    isSelected
                      ? 'border-purple-500 bg-purple-900/20'
                      : 'border-gray-700 hover:border-gray-600'
                  } ${template.premium && !featureCheck.isAllowed ? 'opacity-60' : ''}`}
                  whileHover={{ scale: featureCheck.isAllowed ? 1.02 : 1 }}
                  whileTap={{ scale: featureCheck.isAllowed ? 0.98 : 1 }}
                >
                  <div className="flex items-start space-x-3">
                    <Icon className={`w-5 h-5 ${isSelected ? 'text-purple-400' : 'text-gray-400'}`} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium flex items-center space-x-2">
                          <span>{template.name}</span>
                          {template.premium && <PremiumBadge className="text-xs" />}
                        </h4>
                        {template.recommended && (
                          <span className="text-xs text-purple-400 bg-purple-900/50 px-2 py-0.5 rounded">
                            Recommended
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-400 mt-1">{template.description}</p>
                    </div>
                  </div>
                </motion.button>
              );

              if (template.premium && !featureCheck.isAllowed) {
                return (
                  <FeatureGate key={template.id} feature="advanced-templates" fallback={templateButton}>
                    {templateButton}
                  </FeatureGate>
                );
              }

              return templateButton;
            })}
          </div>

          {/* Chat log import */}
          <div className="glass-card p-6 mt-6">
            <label className="flex items-center justify-between cursor-pointer mb-4">
              <div className="flex items-start space-x-4">
                <Book className="w-6 h-6 text-purple-400 mt-0.5" />
                <div>
                  <span className="text-lg font-medium">Import Chat Logs</span>
                  <p className="text-sm text-gray-400 mt-1">
                    Extract requirements from AI conversations
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={importChatLog}
                onChange={(e) => handleImportChatLogChange(e.target.checked)}
                className="sr-only"
              />
              <div className={`toggle ${importChatLog ? 'bg-purple-600' : 'bg-gray-700'}`}>
                <div className={`toggle-handle ${importChatLog ? 'translate-x-6' : 'translate-x-0'}`} />
              </div>
            </label>

            {importChatLog && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
              >
                <textarea
                  value={chatLogText}
                  onChange={(e) => handleChatLogTextChange(e.target.value)}
                  placeholder="Paste your ChatGPT/Claude conversation here..."
                  className="w-full h-32 px-4 py-3 bg-black/50 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 resize-none"
                />
                <p className="text-xs text-gray-500 mt-2">
                  We'll extract requirements, features, and business logic from your conversation
                </p>
              </motion.div>
            )}
          </div>

          {/* Cost preview */}
          <div className="glass-card p-4 bg-purple-900/20 border-purple-700">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Documentation cost:</span>
              <span className="text-lg font-semibold text-purple-400">
                +${calculateDocsCost().toFixed(2)}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              {selectedTemplates.length} template{selectedTemplates.length !== 1 ? 's' : ''} selected
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default DocumentationOptions;