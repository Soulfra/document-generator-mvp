/**
 * GitHub Plugin
 * GitHub integration for workflows
 */

import { BasePlugin } from '../base-plugin';
import { PluginMetadata, PluginField, PluginExecutionResult } from '../interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../../interfaces/workflow.interface';
import { GitHubIntegrationService } from '../../services/github-integration.service';

export default class GitHubPlugin extends BasePlugin {
  private githubService: GitHubIntegrationService;
  
  metadata: PluginMetadata = {
    id: 'github',
    name: 'GitHub Integration',
    version: '1.0.0',
    description: 'Create issues, PRs, and manage GitHub repositories',
    author: 'FinishThisIdea',
    icon: '🐙',
    category: 'integration',
    tags: ['github', 'git', 'issue', 'pr', 'repository'],
    requiredConfig: ['GITHUB_TOKEN']
  };
  
  fields: PluginField[] = [
    {
      name: 'action',
      label: 'Action',
      type: 'select',
      required: true,
      options: [
        { value: 'create-issue', label: 'Create Issue' },
        { value: 'create-pr', label: 'Create Pull Request' },
        { value: 'comment-issue', label: 'Comment on Issue' },
        { value: 'create-release', label: 'Create Release' }
      ],
      description: 'GitHub action to perform'
    },
    {
      name: 'repo',
      label: 'Repository',
      type: 'text',
      required: true,
      placeholder: 'owner/repo',
      description: 'Repository in owner/repo format'
    },
    {
      name: 'title',
      label: 'Title',
      type: 'text',
      required: false,
      placeholder: 'Issue or PR title',
      description: 'Title (for issues and PRs)'
    },
    {
      name: 'body',
      label: 'Body',
      type: 'textarea',
      required: false,
      placeholder: 'Description or comment body',
      description: 'Body content (markdown supported)'
    },
    {
      name: 'labels',
      label: 'Labels',
      type: 'json',
      required: false,
      placeholder: '["bug", "enhancement"]',
      description: 'Labels to apply'
    }
  ];
  
  constructor(config?: Record<string, any>) {
    super(config);
    this.githubService = GitHubIntegrationService.getInstance();
  }
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    const { action, repo, title, body, labels } = step;
    
    if (!action || !repo) {
      return this.failure('Missing required fields: action, repo');
    }
    
    try {
      await this.githubService.initialize();
      
      const { result, duration } = await this.measureExecution(async () => {
        const [owner, repoName] = repo.split('/');
        
        switch (action) {
          case 'create-issue':
            return await this.githubService.createIssue(owner, repoName, {
              title: title || 'Workflow Issue',
              body: body || 'Created by workflow',
              labels: labels || []
            });
            
          case 'create-pr':
            return await this.githubService.createPullRequest(owner, repoName, {
              title: title || 'Workflow PR',
              body: body || 'Created by workflow',
              head: step.head || 'main',
              base: step.base || 'main'
            });
            
          default:
            throw new Error(`Unsupported action: ${action}`);
        }
      });
      
      return this.success(result, duration, [`${action} completed successfully`]);
      
    } catch (error) {
      this.logger.error('GitHub action failed:', error);
      return this.failure(`GitHub action failed: ${error.message}`);
    }
  }
}