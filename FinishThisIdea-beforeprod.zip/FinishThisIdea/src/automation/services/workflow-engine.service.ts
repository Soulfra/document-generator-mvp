import { promises as fs } from 'fs';
import * as path from 'path';
import * as yaml from 'js-yaml';
import { logger } from '../../utils/logger';
import { emailService } from './email.service';
import { analyticsService } from './analytics-integration.service';
import { slackIntegration } from './slack-integration.service';
import { gitHubIntegration } from './github-integration.service';
import { discordTeamsService } from './discord-teams-integration.service';
import * as Sentry from '@sentry/node';
import { exec } from 'child_process';
import { promisify } from 'util';
import { PluginRegistryService } from '../plugins/plugin-registry.service';
import { WorkflowStepPlugin } from '../plugins/interfaces/plugin.interface';

const execAsync = promisify(exec);

export interface WorkflowStep {
  name: string;
  type: string; // Now supports any plugin type
  condition?: string; // JavaScript expression
  onError?: 'continue' | 'stop' | 'retry';
  retries?: number;
  timeout?: number; // milliseconds
  [key: string]: any; // Allow any plugin-specific fields
}

export interface WorkflowDefinition {
  name?: string;
  description?: string;
  triggers?: string[];
  variables?: Record<string, any>;
  steps: WorkflowStep[];
}

export interface WorkflowContext {
  variables: Record<string, any>;
  userId?: string;
  jobId?: string;
  projectId?: string;
  timestamp: Date;
}

export interface WorkflowResult {
  success: boolean;
  executedSteps: number;
  failedSteps: number;
  results: Array<{
    step: string;
    success: boolean;
    result?: any;
    error?: string;
    duration: number;
  }>;
  totalDuration: number;
}

export class WorkflowEngine {
  private templates: Map<string, WorkflowDefinition> = new Map();
  private isInitialized = false;
  private pluginRegistry: PluginRegistryService;

  constructor() {
    this.pluginRegistry = new PluginRegistryService();
  }

  /**
   * Initialize the workflow engine
   */
  public async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      // Initialize plugin registry
      await this.pluginRegistry.initialize();
      
      // Load workflow templates from cursor folder
      await this.loadWorkflowTemplates();
      
      this.isInitialized = true;
      logger.info('Workflow engine initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize workflow engine', { error });
      throw error;
    }
  }

  /**
   * Load workflow templates from files
   */
  private async loadWorkflowTemplates(): Promise<void> {
    const templatesPath = path.join(process.cwd(), 'cursor/launch-support-module/workflow-template-library');
    
    try {
      const files = await fs.readdir(templatesPath);
      const yamlFiles = files.filter(file => file.endsWith('.yaml') || file.endsWith('.yml'));

      for (const file of yamlFiles) {
        const filePath = path.join(templatesPath, file);
        const content = await fs.readFile(filePath, 'utf8');
        
        try {
          // Remove comment lines that start with # at the beginning
          const cleanContent = content.replace(/^#.*$/gm, '');
          const workflow = yaml.load(cleanContent) as WorkflowDefinition;
          
          if (workflow && workflow.steps) {
            const templateName = path.basename(file, path.extname(file));
            this.templates.set(templateName, workflow);
            logger.info(`Loaded workflow template: ${templateName}`);
          }
        } catch (parseError) {
          logger.warn(`Failed to parse workflow template ${file}`, { parseError });
        }
      }
    } catch (error) {
      logger.warn('Failed to load workflow templates', { error });
      // Continue without templates - engine can still execute workflows programmatically
    }
  }

  /**
   * Execute a workflow by name
   */
  public async executeWorkflow(
    templateName: string, 
    context: WorkflowContext
  ): Promise<WorkflowResult> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    const template = this.templates.get(templateName);
    if (!template) {
      throw new Error(`Workflow template '${templateName}' not found`);
    }

    return this.executeWorkflowSteps(template, context);
  }

  /**
   * Execute a workflow definition directly
   */
  public async executeWorkflowSteps(
    workflow: WorkflowDefinition,
    context: WorkflowContext
  ): Promise<WorkflowResult> {
    const startTime = Date.now();
    const results: WorkflowResult['results'] = [];
    let executedSteps = 0;
    let failedSteps = 0;

    logger.info('Starting workflow execution', {
      workflowName: workflow.name,
      stepCount: workflow.steps.length,
      userId: context.userId,
    });

    // Merge workflow variables with context
    const mergedContext = {
      ...context,
      variables: {
        ...workflow.variables,
        ...context.variables,
      },
    };

    for (const [index, step] of workflow.steps.entries()) {
      const stepStartTime = Date.now();
      let stepResult: any;
      let stepSuccess = false;
      let stepError: string | undefined;

      try {
        // Check condition if present
        if (step.condition) {
          const conditionResult = this.evaluateCondition(step.condition, mergedContext);
          if (!conditionResult) {
            logger.info(`Skipping step '${step.name}' due to condition`, { condition: step.condition });
            continue;
          }
        }

        // Execute step with retries
        const maxRetries = step.retries || 0;
        let attempt = 0;
        
        while (attempt <= maxRetries) {
          try {
            stepResult = await this.executeStep(step, mergedContext);
            stepSuccess = true;
            break;
          } catch (error) {
            attempt++;
            if (attempt > maxRetries) {
              throw error;
            }
            logger.warn(`Step '${step.name}' failed, retrying (${attempt}/${maxRetries})`, { error });
            await this.delay(1000 * attempt); // Exponential backoff
          }
        }

        executedSteps++;
        logger.info(`Step '${step.name}' completed successfully`, { 
          step: index + 1, 
          total: workflow.steps.length 
        });

      } catch (error) {
        stepError = error instanceof Error ? error.message : 'Unknown error';
        failedSteps++;
        
        logger.error(`Step '${step.name}' failed`, { 
          error, 
          step: index + 1, 
          total: workflow.steps.length 
        });

        // Handle error based on step configuration
        if (step.onError === 'stop') {
          logger.error('Workflow stopped due to step failure');
          break;
        } else if (step.onError === 'continue') {
          logger.info('Continuing workflow despite step failure');
        }

        // Report to Sentry
        Sentry.captureException(error, {
          tags: { 
            component: 'workflow-engine',
            step: step.name,
            workflowName: workflow.name,
          },
          extra: { step, context: mergedContext },
        });
      }

      results.push({
        step: step.name,
        success: stepSuccess,
        result: stepResult,
        error: stepError,
        duration: Date.now() - stepStartTime,
      });
    }

    const totalDuration = Date.now() - startTime;
    const result: WorkflowResult = {
      success: failedSteps === 0,
      executedSteps,
      failedSteps,
      results,
      totalDuration,
    };

    logger.info('Workflow execution completed', {
      workflowName: workflow.name,
      success: result.success,
      executedSteps,
      failedSteps,
      totalDuration,
    });

    // Track workflow execution
    await analyticsService.track({
      event: 'workflow_executed',
      userId: context.userId || 'system',
      properties: {
        workflow_name: workflow.name,
        success: result.success,
        executed_steps: executedSteps,
        failed_steps: failedSteps,
        duration_ms: totalDuration,
      },
    });

    return result;
  }

  /**
   * Execute a single step
   */
  private async executeStep(step: WorkflowStep, context: WorkflowContext): Promise<any> {
    const timeout = step.timeout || 30000; // 30 seconds default

    const stepPromise = this.executeStepWithoutTimeout(step, context);
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error(`Step '${step.name}' timed out after ${timeout}ms`)), timeout);
    });

    return Promise.race([stepPromise, timeoutPromise]);
  }

  /**
   * Execute step implementation
   */
  private async executeStepWithoutTimeout(step: WorkflowStep, context: WorkflowContext): Promise<any> {
    const interpolatedStep = this.interpolateVariables(step, context);

    // Try to get plugin from registry
    const plugin = this.pluginRegistry.getPlugin(step.type);
    
    if (plugin) {
      // Use plugin execution
      const validation = await plugin.validate(interpolatedStep);
      if (!validation.valid) {
        throw new Error(`Step validation failed: ${validation.errors?.join(', ')}`);
      }
      
      const result = await plugin.execute(interpolatedStep, context);
      if (!result.success) {
        throw new Error(result.error || 'Plugin execution failed');
      }
      
      return result.data;
    }
    
    // Fallback to legacy implementation for backward compatibility
    logger.warn(`No plugin found for step type '${step.type}', using legacy implementation`);
    
    switch (step.type) {
      case 'script':
        return this.executeScript(interpolatedStep);
      
      case 'email':
        return this.sendEmail(interpolatedStep);
      
      case 'slack':
        return this.sendSlackMessage(interpolatedStep);
      
      case 'github':
        return this.executeGitHubAction(interpolatedStep);
      
      case 'analytics':
        return this.trackAnalytics(interpolatedStep, context);
      
      case 'notification':
        return this.sendNotification(interpolatedStep, context);
      
      case 'delay':
        return this.delay(interpolatedStep.delay || 1000);
      
      case 'discord':
        return this.sendDiscordMessage(interpolatedStep);
      
      case 'teams':
        return this.sendTeamsMessage(interpolatedStep);
      
      default:
        throw new Error(`Unknown step type: ${step.type}`);
    }
  }

  /**
   * Execute shell script
   */
  private async executeScript(step: WorkflowStep): Promise<any> {
    if (!step.command) {
      throw new Error('Script step requires command');
    }

    logger.info(`Executing script: ${step.command}`);
    const { stdout, stderr } = await execAsync(step.command);
    
    if (stderr) {
      logger.warn(`Script stderr: ${stderr}`);
    }
    
    return { stdout, stderr };
  }

  /**
   * Send email
   */
  private async sendEmail(step: WorkflowStep): Promise<any> {
    if (!step.to || !step.subject) {
      throw new Error('Email step requires to and subject');
    }

    // Load template if specified
    let content = step.message || '';
    if (step.template) {
      try {
        const templatePath = path.join(process.cwd(), 'cursor/launch-support-module', step.template);
        content = await fs.readFile(templatePath, 'utf8');
      } catch (error) {
        logger.warn(`Failed to load email template: ${step.template}`, { error });
        content = step.message || 'No content provided';
      }
    }

    return emailService.sendEmail({
      to: step.to,
      subject: step.subject,
      html: content,
    });
  }

  /**
   * Send Slack message
   */
  private async sendSlackMessage(step: WorkflowStep): Promise<any> {
    if (!step.channel || !step.message) {
      throw new Error('Slack step requires channel and message');
    }

    if (!slackIntegration.isIntegrationEnabled()) {
      logger.warn('Slack integration not enabled, skipping message');
      return { sent: false, reason: 'integration_disabled', channel: step.channel };
    }

    try {
      // Determine message type and send accordingly
      if (step.subject) {
        // Send as notification with title
        const result = await slackIntegration.sendNotification(
          step.channel,
          step.subject,
          step.message,
          {
            color: step.properties?.color || 'good',
            fields: step.properties?.fields,
            username: step.properties?.username,
            icon_emoji: step.properties?.icon_emoji,
          }
        );
        return { sent: true, channel: step.channel, timestamp: result.ts };
      } else {
        // Send as simple message
        const result = await slackIntegration.sendMessage({
          channel: step.channel,
          text: step.message,
          username: step.properties?.username,
          icon_emoji: step.properties?.icon_emoji,
          icon_url: step.properties?.icon_url,
        });
        return { sent: true, channel: step.channel, timestamp: result.ts };
      }
    } catch (error) {
      logger.error('Failed to send Slack message', { error, channel: step.channel });
      throw error;
    }
  }

  /**
   * Execute GitHub action
   */
  private async executeGitHubAction(step: WorkflowStep): Promise<any> {
    if (!step.repo || !step.action) {
      throw new Error('GitHub step requires repo and action');
    }

    if (!gitHubIntegration.isIntegrationEnabled()) {
      logger.warn('GitHub integration not enabled, skipping action');
      return { executed: false, reason: 'integration_disabled', action: step.action };
    }

    try {
      const repository = gitHubIntegration.parseRepository(step.repo);

      switch (step.action) {
        case 'create_issue':
          if (!step.issue_title) {
            throw new Error('create_issue action requires issue_title');
          }
          const issue = await gitHubIntegration.createIssue(repository, {
            title: step.issue_title,
            body: step.message || '',
            assignees: step.assignee ? [step.assignee] : undefined,
            labels: step.properties?.labels,
          });
          return { executed: true, action: 'create_issue', issue_number: issue.number, url: issue.html_url };

        case 'create_pr':
          if (!step.properties?.head || !step.properties?.base) {
            throw new Error('create_pr action requires head and base branches in properties');
          }
          const pr = await gitHubIntegration.createPullRequest(repository, {
            title: step.issue_title || step.properties.title,
            body: step.message || '',
            head: step.properties.head,
            base: step.properties.base,
            assignees: step.assignee ? [step.assignee] : undefined,
            labels: step.properties?.labels,
          });
          return { executed: true, action: 'create_pr', pr_number: pr.number, url: pr.html_url };

        case 'create_deployment':
          if (!step.properties?.ref || !step.properties?.environment) {
            throw new Error('create_deployment action requires ref and environment in properties');
          }
          const deployment = await gitHubIntegration.createDeployment(repository, {
            ref: step.properties.ref,
            environment: step.properties.environment,
            description: step.message,
            payload: step.properties.payload,
          });
          return { executed: true, action: 'create_deployment', deployment_id: deployment.id };

        case 'update_deployment_status':
          if (!step.properties?.deployment_id || !step.properties?.state) {
            throw new Error('update_deployment_status action requires deployment_id and state in properties');
          }
          const status = await gitHubIntegration.updateDeploymentStatus(
            repository,
            step.properties.deployment_id,
            step.properties.state,
            step.message,
            step.properties.environment_url
          );
          return { executed: true, action: 'update_deployment_status', status_id: status.id };

        case 'trigger_workflow':
          if (!step.properties?.workflow_id || !step.properties?.ref) {
            throw new Error('trigger_workflow action requires workflow_id and ref in properties');
          }
          const workflow = await gitHubIntegration.triggerWorkflow(repository, {
            workflow_id: step.properties.workflow_id,
            ref: step.properties.ref,
            inputs: step.properties.inputs,
          });
          return { executed: true, action: 'trigger_workflow', triggered: workflow.triggered };

        case 'add_comment':
          if (!step.properties?.issue_number) {
            throw new Error('add_comment action requires issue_number in properties');
          }
          const comment = await gitHubIntegration.addComment(
            repository,
            step.properties.issue_number,
            step.message || ''
          );
          return { executed: true, action: 'add_comment', comment_id: comment.id, url: comment.html_url };

        default:
          throw new Error(`Unknown GitHub action: ${step.action}`);
      }
    } catch (error) {
      logger.error('Failed to execute GitHub action', { error, action: step.action, repo: step.repo });
      throw error;
    }
  }

  /**
   * Track analytics event
   */
  private async trackAnalytics(step: WorkflowStep, context: WorkflowContext): Promise<any> {
    if (!step.event) {
      throw new Error('Analytics step requires event');
    }

    return analyticsService.track({
      event: step.event,
      userId: context.userId || 'system',
      properties: {
        ...step.properties,
        workflow_triggered: true,
        timestamp: context.timestamp.toISOString(),
      },
    });
  }

  /**
   * Send notification
   */
  private async sendNotification(step: WorkflowStep, context: WorkflowContext): Promise<any> {
    logger.info(`Notification sent: ${step.message}`);
    
    // Could integrate with push notifications, SMS, etc.
    return { 
      type: 'notification',
      message: step.message,
      userId: context.userId,
    };
  }

  /**
   * Send Discord message
   */
  private async sendDiscordMessage(step: WorkflowStep): Promise<any> {
    if (!step.channel || !step.message) {
      throw new Error('Discord step requires channel and message');
    }

    if (!discordTeamsService.isAvailable()) {
      logger.warn('Discord integration not enabled, skipping message');
      return { sent: false, reason: 'integration_disabled', channel: step.channel };
    }

    try {
      const notification = {
        title: step.subject || 'Workflow Notification',
        message: step.message,
        type: (step.properties?.type as 'info' | 'success' | 'warning' | 'error') || 'info',
        url: step.properties?.url,
        fields: step.properties?.fields ? Object.entries(step.properties.fields).map(([name, value]) => ({
          name,
          value: String(value)
        })) : undefined
      };

      const result = await discordTeamsService.sendNotification(step.channel, notification);
      
      logger.info('Discord message sent successfully', { 
        channel: step.channel,
        title: notification.title 
      });
      
      return { sent: true, channel: step.channel, result };
    } catch (error) {
      logger.error('Failed to send Discord message', { error, channel: step.channel });
      throw error;
    }
  }

  /**
   * Send Teams message
   */
  private async sendTeamsMessage(step: WorkflowStep): Promise<any> {
    if (!step.channel || !step.message) {
      throw new Error('Teams step requires channel and message');
    }

    if (!discordTeamsService.isAvailable()) {
      logger.warn('Teams integration not enabled, skipping message');
      return { sent: false, reason: 'integration_disabled', channel: step.channel };
    }

    try {
      const notification = {
        title: step.subject || 'Workflow Notification',
        message: step.message,
        type: (step.properties?.type as 'info' | 'success' | 'warning' | 'error') || 'info',
        url: step.properties?.url,
        fields: step.properties?.fields ? Object.entries(step.properties.fields).map(([name, value]) => ({
          name,
          value: String(value)
        })) : undefined
      };

      const result = await discordTeamsService.sendNotification(step.channel, notification);
      
      logger.info('Teams message sent successfully', { 
        channel: step.channel,
        title: notification.title 
      });
      
      return { sent: true, channel: step.channel, result };
    } catch (error) {
      logger.error('Failed to send Teams message', { error, channel: step.channel });
      throw error;
    }
  }

  /**
   * Delay execution
   */
  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Interpolate variables in step configuration
   */
  private interpolateVariables(step: WorkflowStep, context: WorkflowContext): WorkflowStep {
    const interpolated = JSON.parse(JSON.stringify(step));
    const variables = { ...context.variables, ...context };

    const interpolateString = (str: string): string => {
      return str.replace(/\{\{\s*([^}]+)\s*\}\}/g, (match, key) => {
        const keys = key.split('.');
        let value = variables;
        
        for (const k of keys) {
          value = value?.[k];
        }
        
        return value !== undefined ? String(value) : match;
      });
    };

    const interpolateObject = (obj: any): any => {
      if (typeof obj === 'string') {
        return interpolateString(obj);
      } else if (Array.isArray(obj)) {
        return obj.map(interpolateObject);
      } else if (obj && typeof obj === 'object') {
        const result: any = {};
        for (const [key, value] of Object.entries(obj)) {
          result[key] = interpolateObject(value);
        }
        return result;
      }
      return obj;
    };

    return interpolateObject(interpolated);
  }

  /**
   * Evaluate condition
   */
  private evaluateCondition(condition: string, context: WorkflowContext): boolean {
    try {
      // Simple condition evaluation - in production, use a safer expression evaluator
      const variables = { ...context.variables, ...context };
      const func = new Function(...Object.keys(variables), `return ${condition}`);
      return Boolean(func(...Object.values(variables)));
    } catch (error) {
      logger.warn(`Failed to evaluate condition: ${condition}`, { error });
      return false;
    }
  }

  /**
   * Get available workflow templates
   */
  public getAvailableTemplates(): string[] {
    return Array.from(this.templates.keys());
  }

  /**
   * Get workflow template definition
   */
  public getTemplate(name: string): WorkflowDefinition | undefined {
    return this.templates.get(name);
  }

  /**
   * Register a new workflow template
   */
  public registerTemplate(name: string, workflow: WorkflowDefinition): void {
    this.templates.set(name, workflow);
    logger.info(`Registered workflow template: ${name}`);
  }

  /**
   * Get available step types from plugin registry
   */
  public getAvailableStepTypes(): Array<{ type: string; metadata: any }> {
    return this.pluginRegistry.getPluginMetadata();
  }

  /**
   * Reload plugins
   */
  public async reloadPlugins(): Promise<void> {
    await this.pluginRegistry.reload();
  }
}

// Export singleton instance
export const workflowEngine = new WorkflowEngine();