import { BaseParser, ParseResult, Dependency, ImportStatement, Comment, ParserOptions } from './base-parser';
import { APIEndpoint, DataModel, FunctionSignature, Parameter } from '../types/code-analysis';

export class PythonParser extends BaseParser {
  constructor(options: ParserOptions = {}) {
    super(options);
  }

  getLanguage(): string {
    return 'python';
  }

  getSupportedExtensions(): string[] {
    return ['.py', '.pyw', '.pyx', '.pyi'];
  }

  async parse(files: Map<string, string>): Promise<ParseResult> {
    const [apis, functions, dataModels, dependencies, imports, comments] = await Promise.all([
      this.extractAPIs(files),
      this.extractFunctions(files),
      this.extractDataModels(files),
      this.extractDependencies(files),
      this.extractImports(files),
      this.extractComments(files)
    ]);

    return this.mergeResults({
      apis,
      functions,
      dataModels,
      dependencies,
      imports,
      comments
    });
  }

  async extractAPIs(files: Map<string, string>): Promise<APIEndpoint[]> {
    const apis: APIEndpoint[] = [];

    for (const [filename, content] of files.entries()) {
      if (!this.shouldParseFile(filename)) continue;

      // Django URL patterns
      const djangoUrls = this.extractDjangoURLs(content, filename);
      apis.push(...djangoUrls);

      // Flask/FastAPI routes
      const flaskRoutes = this.extractFlaskRoutes(content, filename);
      apis.push(...flaskRoutes);

      // FastAPI specific patterns
      const fastapiRoutes = this.extractFastAPIRoutes(content, filename);
      apis.push(...fastapiRoutes);
    }

    return this.deduplicate(apis, api => `${api.method}:${api.path}`);
  }

  private extractDjangoURLs(content: string, _filename: string): APIEndpoint[] {
    const apis: APIEndpoint[] = [];
    
    // Django path() and re_path() patterns
    const urlPattern = /(?:path|re_path)\s*\(\s*r?['"`]([^'"`]*)['"`]\s*,\s*([\w.]+)(?:\.as_view\(\))?\s*(?:,\s*name\s*=\s*['"`]([^'"`]+)['"`])?\s*\)/g;
    
    let match;
    while ((match = urlPattern.exec(content)) !== null) {
      const [, path, viewName, name] = match;
      
      // Fix empty path and remove regex markers
      let processedPath = path?.startsWith('^') ? path.substring(1) : path || '';
      processedPath = processedPath?.replace(/\$$/, '') || ''; // Remove trailing $
      
      apis.push({
        method: 'GET', // Django doesn't specify method in URL conf
        path: processedPath,
        description: `Django view: ${viewName}${name ? ` (${name})` : ''}`,
        parameters: this.extractDjangoParams(path || ''),
        responses: {},
        authentication: content.includes('@login_required') || content.includes('LoginRequiredMixin') ? 'required' : 'optional'
      });
    }

    // Django REST Framework ViewSet routes
    const viewsetPattern = /class\s+(\w+ViewSet)\s*\([^)]*ModelViewSet[^)]*\):/g;
    while ((match = viewsetPattern.exec(content)) !== null) {
      const viewsetName = match[1];
      if (!viewsetName) continue;
      const modelName = viewsetName.replace('ViewSet', '').toLowerCase();
      
      // Standard DRF routes
      const standardRoutes = [
        { method: 'GET', path: `/${modelName}s/`, desc: 'List' },
        { method: 'POST', path: `/${modelName}s/`, desc: 'Create' },
        { method: 'GET', path: `/${modelName}s/{id}/`, desc: 'Retrieve' },
        { method: 'PUT', path: `/${modelName}s/{id}/`, desc: 'Update' },
        { method: 'DELETE', path: `/${modelName}s/{id}/`, desc: 'Delete' }
      ];

      for (const route of standardRoutes) {
        apis.push({
          method: route.method,
          path: route.path,
          description: `${route.desc} ${modelName}`,
          parameters: route.path.includes('{id}') ? [{
            name: 'id',
            type: 'integer',
            required: true,
            description: `${modelName} ID`
          }] : [],
          responses: {},
          authentication: 'required'
        });
      }
    }

    return apis;
  }

  private extractFlaskRoutes(content: string, _filename: string): APIEndpoint[] {
    const apis: APIEndpoint[] = [];
    
    // Flask @app.route and @blueprint.route decorators
    const routePattern = /@(?:app|blueprint|bp)\.route\s*\(\s*['"`]([^'"`]+)['"`](?:\s*,\s*methods\s*=\s*\[([^\]]+)\])?\s*\)/g;
    
    let match;
    while ((match = routePattern.exec(content)) !== null) {
      const [, path, methodsStr] = match;
      const methods = methodsStr 
        ? methodsStr.split(',').map(m => m.trim().replace(/['"]/g, ''))
        : ['GET'];

      // Find the function after the decorator
      const afterDecorator = content.substring(match.index + match[0].length);
      const funcMatch = afterDecorator.match(/\s*def\s+(\w+)\s*\([^)]*\)\s*:/);
      const funcName = funcMatch ? funcMatch[1] : 'unknown';

      for (const method of methods) {
        apis.push({
          method: method.toUpperCase(),
          path: path || '',
          description: `Flask route: ${funcName}`,
          parameters: this.extractFlaskParams(path || '', afterDecorator),
          responses: {},
          authentication: content.includes('@login_required') || content.includes('@jwt_required') ? 'required' : 'optional'
        });
      }
    }

    return apis;
  }

  private extractFastAPIRoutes(content: string, _filename: string): APIEndpoint[] {
    const apis: APIEndpoint[] = [];
    
    // FastAPI @app.get/post/put/delete decorators
    const routePattern = /@(?:app|router)\.(?:get|post|put|delete|patch)\s*\(\s*['"`]([^'"`]+)['"`][^)]*\)/g;
    
    let match;
    while ((match = routePattern.exec(content)) !== null) {
      const method = match[0].match(/\.(get|post|put|delete|patch)/)?.[1]?.toUpperCase() || 'GET';
      const path = match[1];

      // Find the function after the decorator
      const afterDecorator = content.substring(match.index + match[0].length);
      const funcMatch = afterDecorator.match(/\s*(?:async\s+)?def\s+([\p{L}\p{N}_]+)\s*\(([^)]*)\)\s*(?:->\s*([^:]+))?\s*:/u);
      
      if (funcMatch) {
        const [, funcName, params, returnType] = funcMatch;
        
        // Extract response model from decorator
        const responseModelMatch = match[0].match(/response_model\s*=\s*(\w+)/);
        const responseSchema = responseModelMatch ? responseModelMatch[1] : (returnType?.trim() || 'Any');
        
        apis.push({
          method,
          path: path || '',
          description: `FastAPI endpoint: ${funcName}`,
          parameters: this.extractFastAPIParams(params || '', path || ''),
          responses: {
            '200': {
              description: 'Success',
              schema: responseSchema
            }
          },
          authentication: (params?.includes('current_user') || params?.includes('token') || params?.includes('Depends')) ? 'required' : 'optional'
        });
      }
    }

    return apis;
  }

  private extractDjangoParams(path: string): Parameter[] {
    const params: Parameter[] = [];
    
    // Extract URL parameters like <int:id> or (?P<id>\d+)
    const paramPattern = /<(\w+):(\w+)>|<(\w+)>|(?:\(\?P<(\w+)>[^)]+\))/g;
    
    let match;
    while ((match = paramPattern.exec(path)) !== null) {
      const paramName = match[2] || match[3] || match[4];
      const paramType = match[1] || 'string';
      
      params.push({
        name: paramName || 'unknown',
        type: this.djangoTypeToGeneric(paramType || 'string'),
        required: true,
        description: `URL parameter: ${paramName || 'unknown'}`
      });
    }

    return params;
  }

  private extractFlaskParams(path: string, funcContent: string): Parameter[] {
    const params: Parameter[] = [];
    
    // Extract URL parameters like <id> or <int:id>
    const urlParamPattern = /<(?:(\w+):)?(\w+)>/g;
    
    let match;
    while ((match = urlParamPattern.exec(path)) !== null) {
      const [, type, name] = match;
      
      params.push({
        name: name || 'unknown',
        type: type || 'string',
        required: true,
        description: `URL parameter: ${name || 'unknown'}`
      });
    }

    // Check for request.json usage
    if (funcContent.includes('request.json') || funcContent.includes('request.get_json()')) {
      params.push({
        name: 'body',
        type: 'object',
        required: true,
        description: 'Request body (JSON)'
      });
    }

    return params;
  }

  private extractFastAPIParams(paramStr: string, path: string): Parameter[] {
    const params: Parameter[] = [];
    
    // Parse function parameters
    const paramList = paramStr.split(',').map(p => p.trim()).filter(p => p);
    
    for (const param of paramList) {
      // Skip self, request, response
      const paramName = param.split(':')[0]?.trim();
      if (paramName && ['self', 'request', 'response'].includes(paramName)) {
        continue;
      }

      // Parse parameter with type annotation
      const paramMatch = param.match(/(\w+)\s*:\s*([^=]+?)(?:\s*=\s*(.+))?$/);
      
      if (paramMatch) {
        const [, name, type, defaultValue] = paramMatch;
        
        // Check if it's a path parameter
        const isPathParam = path.includes(`{${name}}`);
        
        params.push({
          name: name || 'unknown',
          type: this.pythonTypeToGeneric(type?.trim() || 'Any'),
          required: !defaultValue,
          description: isPathParam ? `Path parameter: ${name || 'unknown'}` : `Query parameter: ${name || 'unknown'}`
        });
      }
    }

    return params;
  }

  async extractFunctions(files: Map<string, string>): Promise<FunctionSignature[]> {
    const functions: FunctionSignature[] = [];

    for (const [filename, content] of files.entries()) {
      if (!this.shouldParseFile(filename)) continue;

      // Regular function definitions - allow Unicode in function names
      // Only match functions at module level (no indentation)
      const funcPattern = /^(?:async\s+)?def\s+([\p{L}\p{N}_]+)\s*\(([^)]*)\)\s*(?:->\s*([^:]+))?\s*:/gmu;
      
      let match;
      while ((match = funcPattern.exec(content)) !== null) {
        const [, name, params, returnType] = match;
        
        // Skip private functions unless requested
        if (!this.options.includePrivate && this.isPrivate(name || '')) {
          continue;
        }

        const fullMatch = match[0];
        const functionBody = content.substring(match.index + fullMatch.length);
        const extractedDocstring = this.extractDocstringFromBody(functionBody, 0);
        
        const signature: FunctionSignature = {
          name: name || 'unknown',
          description: extractedDocstring || '',
          parameters: this.parseParameters(params || ''),
          returnType: returnType?.trim() || 'Any',
          visibility: this.isPrivate(name || '') ? 'private' : 'public',
          file: filename,
          line: this.getLineNumber(content, match.index),
          complexity: 1,
          linesOfCode: this.countFunctionLines(functionBody)
        };

        functions.push(signature);
      }

      // Class methods - only match at line start to avoid matching inline
      const classPattern = /^(\s*)class\s+([\p{L}\p{N}_]+)(?:\([^)]*\))?\s*:/gmu;
      while ((match = classPattern.exec(content)) !== null) {
        const className = match[2];  // Second capture group is the class name
        const classBody = this.extractClassBody(content, match.index);
        
        const methodPattern = /^(\s+)(?:async\s+)?def\s+([\p{L}\p{N}_]+)\s*\(([^)]*)\)\s*(?:->\s*([^:]+))?\s*:/gmu;
        let methodMatch;
        
        while ((methodMatch = methodPattern.exec(classBody)) !== null) {
          const [, , methodName, params, returnType] = methodMatch;
          
          if (!this.options.includePrivate && this.isPrivate(methodName || '')) {
            continue;
          }

          // Check for decorators
          const decorators = this.extractDecorators(classBody, methodMatch.index);
          const isStatic = decorators.includes('@staticmethod');
          const isClass = decorators.includes('@classmethod');
          // const _isProperty = decorators.includes('@property'); // Unused

          const methodFullMatch = methodMatch[0];
          const methodBody = classBody.substring(methodMatch.index + methodFullMatch.length);
          const methodDocstring = this.extractDocstringFromBody(methodBody, 0);
          
          functions.push({
            name: `${className || 'Unknown'}.${methodName || 'unknown'}`,
            description: methodDocstring || '',
            parameters: this.parseParameters(params || '', !isStatic && !isClass),
            returnType: returnType?.trim() || 'Any',
            visibility: this.isPrivate(methodName || '') ? 'private' : 'public',
            file: filename,
            line: this.getLineNumber(content, match.index + methodMatch.index),
            complexity: 1,
            linesOfCode: this.countFunctionLines(methodBody)
          });
        }
      }
    }

    return functions;
  }

  private parseParameters(paramStr: string, skipFirst: boolean = false): Parameter[] {
    const params: Parameter[] = [];
    const paramList = paramStr.split(',').map(p => p.trim()).filter(p => p);
    
    for (let i = skipFirst ? 1 : 0; i < paramList.length; i++) {
      const param = paramList[i];
      
      // Skip self, cls
      if (['self', 'cls'].includes(param || '')) continue;

      // Parse different parameter formats
      const patterns = [
        // name: Type = default
        /^(\*?\*?)(\w+)\s*:\s*([^=]+?)\s*=\s*(.+)$/,
        // name: Type
        /^(\*?\*?)(\w+)\s*:\s*(.+)$/,
        // name = default
        /^(\*?\*?)(\w+)\s*=\s*(.+)$/,
        // name
        /^(\*?\*?)(\w+)$/
      ];

      for (const pattern of patterns) {
        const match = param?.match(pattern);
        if (match) {
          let name, type, defaultValue;
          
          // Determine which pattern matched based on number of capture groups
          if (match.length === 5) {
            // name: Type = default
            [, , name, type, defaultValue] = match;
          } else if (match.length === 4 && match[3] && !match[3].includes('=')) {
            // name: Type
            [, , name, type] = match;
          } else if (match.length === 4) {
            // name = default
            [, , name, defaultValue] = match;
            type = 'Any';
          } else {
            // name
            [, , name] = match;
            type = 'Any';
          }

          const prefix = match[1];
          if (prefix === '*') {
            name = `*${name}`;
            type = `Tuple[${type || 'Any'}, ...]`;
          } else if (prefix === '**') {
            name = `**${name}`;
            type = `Dict[str, ${type || 'Any'}]`;
          }

          params.push({
            name: name || 'unknown',
            type: this.pythonTypeToGeneric(type?.trim() || 'Any'),
            required: !defaultValue,
            description: ''
          });
          break;
        }
      }
    }

    return params;
  }

  async extractDataModels(files: Map<string, string>): Promise<DataModel[]> {
    const models: DataModel[] = [];

    for (const [filename, content] of files.entries()) {
      if (!this.shouldParseFile(filename)) continue;

      // Extract classes - allow Unicode in class names
      const classPattern = /^class\s+([\p{L}\p{N}_]+)(?:\(([^)]*)\))?\s*:/gmu;
      
      let match;
      while ((match = classPattern.exec(content)) !== null) {
        const [, className, baseClasses] = match;
        
        if (!this.options.includePrivate && this.isPrivate(className || '')) {
          continue;
        }
        
        // Skip common inner classes, but not if they have decorators
        const decorators = this.extractDecorators(content, match.index);
        if (['Meta', 'Config'].includes(className || '') && decorators.length === 0) {
          continue;
        }

        const classBody = this.extractClassBody(content, match.index);
        const properties = this.extractClassProperties(classBody);
        const docstring = this.extractDocstringFromBody(classBody, 0);

        // Determine model type based on base classes
        let modelType: 'class' | 'interface' | 'enum' = 'class';
        if (baseClasses) {
          if (baseClasses.includes('Model') || baseClasses.includes('Base')) {
            modelType = 'class'; // ORM model
          } else if (baseClasses.includes('Enum')) {
            modelType = 'enum';
          } else if (baseClasses.includes('Protocol') || baseClasses.includes('ABC')) {
            modelType = 'interface';
          } else if (baseClasses.includes('TypedDict')) {
            modelType = 'interface';
          }
        }

        // Special handling for dataclasses - reuse decorators from above
        // const isDataclass = decorators.includes('@dataclass'); // Unused
        
        // Special handling for Pydantic models
        // const isPydantic = baseClasses?.includes('BaseModel') || baseClasses?.includes('BaseSettings'); // Unused

        models.push({
          name: className || 'Unknown',
          type: modelType,
          description: docstring || '',
          fields: properties?.map(p => ({
            name: p.name || 'unknown',
            type: p.type || 'Any',
            required: p.required || false,
            description: p.description
          })) || [],
          relationships: [], // Could be enhanced to detect relationships
          size: properties?.length || 0
        });
      }

      // Extract TypedDict definitions
      const typedDictPattern = /(\w+)\s*=\s*TypedDict\s*\(\s*['"`](\w+)['"`]\s*,\s*{([^}]+)}\s*\)/g;
      while ((match = typedDictPattern.exec(content)) !== null) {
        const [, varName, className, fieldsStr] = match;
        
        const properties = this.parseTypedDictFields(fieldsStr || '');
        
        models.push({
          name: className || varName || 'Unknown',
          type: 'interface',
          description: 'TypedDict definition',
          fields: properties?.map(p => ({
            name: p.name || 'unknown',
            type: p.type || 'Any',
            required: p.required || false,
            description: p.description
          })) || [],
          relationships: [],
          size: properties?.length || 0
        });
      }

      // Extract NamedTuple definitions
      const namedTuplePattern = /(\w+)\s*=\s*NamedTuple\s*\(\s*['"`](\w+)['"`]\s*,\s*\[([^\]]+)\]\s*\)/g;
      while ((match = namedTuplePattern.exec(content)) !== null) {
        const [, varName, className, fieldsStr] = match;
        
        const properties = this.parseNamedTupleFields(fieldsStr || '');
        
        models.push({
          name: className || varName || 'Unknown',
          type: 'class',
          description: 'NamedTuple definition',
          fields: properties?.map(p => ({
            name: p.name || 'unknown',
            type: p.type || 'Any',
            required: p.required || false,
            description: p.description
          })) || [],
          relationships: [],
          size: properties?.length || 0
        });
      }
    }

    return models;
  }

  private extractClassBody(content: string, classStart: number): string {
    const lines = content.substring(classStart).split('\n');
    const classIndent = lines[0]?.match(/^(\s*)/)?.[1]?.length || 0;
    
    let bodyLines: string[] = [];
    let inClass = false;
    
    for (const line of lines) {
      const currentIndent = line.match(/^(\s*)/)?.[1]?.length || 0;
      
      if (line.includes('class ') && currentIndent === classIndent) {
        if (inClass) break; // Found next class at same level
        inClass = true;
      } else if (inClass) {
        if (line.trim() && currentIndent <= classIndent) {
          break; // End of class
        }
        bodyLines.push(line);
      }
    }

    return bodyLines.join('\n');
  }

  private extractClassProperties(classBody: string): any[] {
    const properties: any[] = [];
    
    // Class variables with type annotations
    const annotationPattern = /^(\s+)(\w+)\s*:\s*([^=\n]+?)(?:\s*=\s*([^\n]+))?$/gm;
    
    let match;
    while ((match = annotationPattern.exec(classBody)) !== null) {
      const [, , name, type, defaultValue] = match;
      
      if (!this.isMethodName(name || '')) {
        properties.push({
          name,
          type: this.pythonTypeToGeneric(type?.trim() || 'any'),
          required: !defaultValue,
          defaultValue: defaultValue?.trim(),
          description: ''
        });
      }
    }

    // Django model fields
    const djangoFieldPattern = /^(\s+)(\w+)\s*=\s*models\.(\w+)\s*\(([^)]*)\)/gm;
    while ((match = djangoFieldPattern.exec(classBody)) !== null) {
      const [, , name, fieldType, args] = match;
      
      properties.push({
        name,
        type: this.djangoFieldToGeneric(fieldType || ''),
        required: !(args?.includes('null=True')) && !(args?.includes('blank=True')) && fieldType !== 'BooleanField',
        description: `Django ${fieldType} field`
      });
    }

    // SQLAlchemy columns
    const sqlalchemyPattern = /^(\s+)(\w+)\s*=\s*Column\s*\(([^)]+)\)/gm;
    while ((match = sqlalchemyPattern.exec(classBody)) !== null) {
      const [, , name, columnDef] = match;
      
      const typeMatch = columnDef?.match(/(\w+)(?:\([^)]*\))?/);
      const type = typeMatch ? this.sqlalchemyTypeToGeneric(typeMatch[1] || '') : 'Any';
      
      properties.push({
        name,
        type,
        required: !(columnDef?.includes('nullable=True')),
        description: 'SQLAlchemy column'
      });
    }

    return properties;
  }

  private isMethodName(name: string): boolean {
    return ['def', 'class', 'if', 'else', 'elif', 'for', 'while', 'try', 'except', 'finally', 'with'].includes(name);
  }

  private extractDocstringFromBody(content: string, startIndex: number): string {
    const afterDef = content.substring(startIndex);
    // Match docstring immediately after the colon and newline
    const docstringMatch = afterDef.match(/^\s*('''|""")([^]*?)\1/);
    
    if (docstringMatch) {
      return docstringMatch[2]?.trim() || '';
    }

    return '';
  }

  private extractDecorators(content: string, position: number): string[] {
    const decorators: string[] = [];
    const beforePosition = content.substring(0, position);
    const lines = beforePosition.split('\n');
    
    // Look backwards for decorators
    for (let i = lines.length - 1; i >= 0; i--) {
      const line = lines[i]?.trim() || '';
      
      if (line.startsWith('@')) {
        decorators.unshift(line.split('(')[0] || ''); // Remove parameters
      } else if (line && !line.startsWith('@')) {
        break; // Found non-decorator line
      }
    }

    return decorators;
  }

  async extractDependencies(files: Map<string, string>): Promise<Dependency[]> {
    const dependencies: Dependency[] = [];

    // Check requirements.txt (handle subdirectories)
    let requirementsTxt: string | undefined;
    let requirementsPath: string | undefined;
    
    for (const [path, content] of files.entries()) {
      if (path.endsWith('requirements.txt')) {
        requirementsTxt = content;
        requirementsPath = path;
        break;
      }
    }
    
    if (requirementsTxt) {
      const lines = requirementsTxt.split('\n');
      
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;

        // Parse different requirement formats
        const patterns = [
          /^([a-zA-Z0-9_-]+)==([0-9.]+)/,  // package==1.2.3
          /^([a-zA-Z0-9_-]+)>=([0-9.]+)/,  // package>=1.2.3
          /^([a-zA-Z0-9_-]+)~=([0-9.]+)/,  // package~=1.2.3
          /^([a-zA-Z0-9_-]+)<([0-9.]+)/,   // package<1.2.3
          /^([a-zA-Z0-9_-]+)/               // package
        ];

        for (const pattern of patterns) {
          const match = trimmed.match(pattern);
          if (match) {
            dependencies.push({
              name: match[1] || 'unknown',
              version: match[2] || 'latest',
              type: 'runtime',
              source: requirementsPath || 'requirements.txt'
            });
            break;
          }
        }
      }
    }

    // Check setup.py
    const setupPy = files.get('setup.py');
    if (setupPy) {
      const installRequiresMatch = setupPy.match(/install_requires\s*=\s*\[([^\]]+)\]/);
      if (installRequiresMatch) {
        const requires = installRequiresMatch[1];
        const packagePattern = /['"]([^'"]+)['"]/g;
        
        let match;
        while ((match = packagePattern.exec(requires || '')) !== null) {
          const [, requirement] = match;
          // Better version parsing
          const versionMatch = requirement?.match(/^([a-zA-Z0-9_-]+)([><=~]+)(.+)$/);
          if (versionMatch) {
            dependencies.push({
              name: versionMatch[1]?.trim() || 'unknown',
              version: versionMatch[3]?.trim() || 'latest',
              type: 'runtime',
              source: 'setup.py'
            });
          } else {
            dependencies.push({
              name: requirement?.trim() || 'unknown',
              version: 'latest',
              type: 'runtime',
              source: 'setup.py'
            });
          }
        }
      }
    }

    // Check pyproject.toml
    const pyprojectToml = files.get('pyproject.toml');
    if (pyprojectToml) {
      // Simple TOML parsing for dependencies
      const depsMatch = pyprojectToml.match(/\[tool\.poetry\.dependencies\]([^[]+)/);
      if (depsMatch) {
        const depsSection = depsMatch[1];
        const depPattern = /^(\w+)\s*=\s*['"]{0,1}([^'"]+)['"]{0,1}$/gm;
        
        let match;
        while ((match = depPattern.exec(depsSection || '')) !== null) {
          const [, name, version] = match;
          if (name !== 'python') {
            dependencies.push({
              name: name || 'unknown',
              version: version?.replace(/[\^~]/, '') || undefined,
              type: 'runtime',
              source: 'pyproject.toml'
            });
          }
        }
      }
    }

    // Check Pipfile
    const pipfile = files.get('Pipfile');
    if (pipfile) {
      const sections = [
        { pattern: /\[packages\]([^[]+)/, type: 'runtime' as const },
        { pattern: /\[dev-packages\]([^[]+)/, type: 'dev' as const }
      ];

      for (const { pattern, type } of sections) {
        const sectionMatch = pipfile.match(pattern);
        if (sectionMatch) {
          const depPattern = /^(\w+)\s*=\s*['"]{0,1}([^'"]+)['"]{0,1}$/gm;
          
          let match;
          while ((match = depPattern.exec(sectionMatch[1] || '')) !== null) {
            const [, name, version] = match;
            dependencies.push({
              name: name || 'unknown',
              version: version === '*' ? 'latest' : version?.replace(/[\^~]/, '') || undefined,
              type: type || 'runtime',
              source: 'Pipfile'
            });
          }
        }
      }
    }

    return this.deduplicate(dependencies, dep => `${dep.name}:${dep.type}`);
  }

  async extractImports(files: Map<string, string>): Promise<ImportStatement[]> {
    const imports: ImportStatement[] = [];

    for (const [filename, content] of files.entries()) {
      if (!this.shouldParseFile(filename)) continue;

      // Standard imports: import module
      const importPattern = /^import\s+(.+)$/gm;
      let match;
      
      while ((match = importPattern.exec(content)) !== null) {
        const [, modules] = match;
        
        // Handle multiple imports: import os, sys
        const moduleList = modules?.split(',').map(m => m.trim()) || [];
        
        for (const module of moduleList) {
          const aliasMatch = module.match(/^(.+?)\s+as\s+(.+)$/);
          
          imports.push({
            source: aliasMatch ? aliasMatch[1]?.trim() || '' : module || '',
            imports: [],
            isRelative: module.startsWith('.'),
            isWildcard: false,
            alias: aliasMatch ? aliasMatch[2] : undefined,
            line: this.getLineNumber(content, match.index),
            file: filename
          });
        }
      }

      // From imports: from module import item
      const fromImportPattern = /^from\s+([^\s]+)\s+import\s+(.+)$/gm;
      
      while ((match = fromImportPattern.exec(content)) !== null) {
        const [, source, itemsStr] = match;
        
        const isWildcard = itemsStr?.trim() === '*';
        const items = isWildcard ? [] : (itemsStr?.split(',').map(item => {
          const trimmed = item.trim();
          const aliasMatch = trimmed.match(/^(.+?)\s+as\s+(.+)$/);
          return aliasMatch ? aliasMatch[1] : trimmed;
        }) || []);

        imports.push({
          source: source || '',
          imports: items.filter((item): item is string => item != null),
          isRelative: source?.startsWith('.') || false,
          isWildcard,
          line: this.getLineNumber(content, match.index),
          file: filename
        });
      }
    }

    return imports;
  }

  async extractComments(files: Map<string, string>): Promise<Comment[]> {
    const comments: Comment[] = [];

    for (const [filename, content] of files.entries()) {
      if (!this.shouldParseFile(filename)) continue;

      // Single-line comments including end-of-line comments
      const singleLinePattern = /(^\s*|\s+)#\s*(.+)$/gm;
      let match;
      
      while ((match = singleLinePattern.exec(content)) !== null) {
        const [, , comment] = match;
        
        // Skip shebang
        if (match.index === 0 && comment?.startsWith('!')) continue;
        
        comments.push({
          type: 'single',
          content: comment || '',
          line: this.getLineNumber(content, match.index),
          file: filename
        });
      }

      // Docstrings (triple quotes)
      const docstringPattern = /('''|""")([^]*?)\1/g;
      
      while ((match = docstringPattern.exec(content)) !== null) {
        const [, _quote, docstring] = match;
        
        // Check if this is actually a docstring (follows a def, class, or at module level)
        const before = content.substring(0, match.index);
        const lines = before.split('\n');
        const previousNonEmptyLine = lines.slice().reverse().find((line: string) => line.trim().length > 0);
        
        const isDocstring = !previousNonEmptyLine || previousNonEmptyLine.match(/(def\s+[\p{L}\p{N}_]+[^:]*:|class\s+[\p{L}\p{N}_]+[^:]*:)\s*$/u);
        
        if (isDocstring) {
          comments.push({
            type: 'doc',
            content: docstring?.trim() || '',
            line: this.getLineNumber(content, match.index),
            file: filename,
            associatedWith: this.findAssociatedDefinition(before)
          });
        }
      }
    }

    return comments;
  }

  private findAssociatedDefinition(beforeContent: string): string | undefined {
    const lines = beforeContent.split('\n');
    
    // Look for the last definition in the previous lines
    for (let i = lines.length - 1; i >= 0; i--) {
      const line = lines[i];
      
      const defMatch = line?.match(/def\s+([\p{L}\p{N}_]+)/u);
      if (defMatch) return defMatch[1] || 'unknown';
      
      const classMatch = line?.match(/class\s+([\p{L}\p{N}_]+)/u);
      if (classMatch) return classMatch[1] || 'unknown';
    }
    
    return undefined;
  }

  private pythonTypeToGeneric(pythonType: string): string {
    const typeMap: Record<string, string> = {
      'int': 'integer',
      'float': 'number',
      'str': 'string',
      'bool': 'boolean',
      'list': 'array',
      'List': 'array',
      'dict': 'object',
      'Dict': 'object',
      'tuple': 'array',
      'Tuple': 'array',
      'set': 'array',
      'Set': 'array',
      'None': 'null',
      'Any': 'any',
      'Union': 'union'
    };

    // Handle generic types like List[str]
    const genericMatch = pythonType.match(/^(\w+)\[(.+)\]$/);
    if (genericMatch) {
      const [, container, inner] = genericMatch;
      const mappedContainer = typeMap[container || ''] || container?.toLowerCase() || 'unknown';
      return `${mappedContainer}<${this.pythonTypeToGeneric(inner || 'any')}>`;
    }

    // Handle Optional[T]
    if (pythonType.startsWith('Optional[')) {
      const inner = pythonType.slice(9, -1);
      return `${this.pythonTypeToGeneric(inner)} | null`;
    }
    
    // Handle optional lowercase
    if (pythonType.toLowerCase() === 'optional') {
      return 'optional';
    }

    // Handle Union[A, B]
    if (pythonType.startsWith('Union[')) {
      const types = pythonType.slice(6, -1).split(',').map(t => t.trim());
      return types.map(t => this.pythonTypeToGeneric(t)).join(' | ');
    }

    return typeMap[pythonType] || pythonType;
  }

  private djangoTypeToGeneric(djangoType: string): string {
    const typeMap: Record<string, string> = {
      'int': 'integer',
      'str': 'string',
      'slug': 'string',
      'uuid': 'string',
      'path': 'string'
    };

    return typeMap[djangoType] || djangoType;
  }

  private djangoFieldToGeneric(fieldType: string): string {
    const fieldMap: Record<string, string> = {
      'CharField': 'string',
      'TextField': 'string',
      'EmailField': 'string',
      'URLField': 'string',
      'SlugField': 'string',
      'IntegerField': 'integer',
      'BigIntegerField': 'integer',
      'SmallIntegerField': 'integer',
      'PositiveIntegerField': 'integer',
      'FloatField': 'number',
      'DecimalField': 'number',
      'BooleanField': 'boolean',
      'DateField': 'date',
      'DateTimeField': 'datetime',
      'TimeField': 'time',
      'ForeignKey': 'relation',
      'OneToOneField': 'relation',
      'ManyToManyField': 'relation[]',
      'JSONField': 'object',
      'ArrayField': 'array',
      'UUIDField': 'uuid',
      'FileField': 'file',
      'ImageField': 'image'
    };

    return fieldMap[fieldType] || 'string';
  }

  private sqlalchemyTypeToGeneric(sqlType: string): string {
    const typeMap: Record<string, string> = {
      'Integer': 'integer',
      'BigInteger': 'integer',
      'SmallInteger': 'integer',
      'String': 'string',
      'Text': 'string',
      'Unicode': 'string',
      'Float': 'number',
      'Numeric': 'number',
      'Boolean': 'boolean',
      'Date': 'date',
      'DateTime': 'datetime',
      'Time': 'time',
      'JSON': 'object',
      'ARRAY': 'array'
    };

    return typeMap[sqlType] || 'any';
  }

  private parseTypedDictFields(fieldsStr: string): any[] {
    const properties: any[] = [];
    const fieldPattern = /['"](\w+)['"]\s*:\s*([^,}]+)/g;
    
    let match;
    while ((match = fieldPattern.exec(fieldsStr)) !== null) {
      const [, name, type] = match;
      
      properties.push({
        name,
        type: this.pythonTypeToGeneric(type?.trim() || 'any'),
        required: true,
        description: ''
      });
    }

    return properties;
  }

  private parseNamedTupleFields(fieldsStr: string): any[] {
    const properties: any[] = [];
    const fieldPattern = /\(\s*['"](\w+)['"]\s*,\s*([^)]+)\s*\)/g;
    
    let match;
    while ((match = fieldPattern.exec(fieldsStr)) !== null) {
      const [, name, type] = match;
      
      properties.push({
        name,
        type: this.pythonTypeToGeneric(type?.trim() || 'any'),
        required: true,
        description: ''
      });
    }

    return properties;
  }

  /**
   * Count the number of lines in a function body
   */
  private countFunctionLines(functionBody: string): number {
    if (!functionBody) return 1;
    return functionBody.split('\n').length;
  }
}