import { Request, Response, NextFunction } from 'express';
import helmet from 'helmet';
import { logger } from '../utils/logger';

interface SecurityConfig {
  enabled: boolean;
  contentSecurityPolicy?: boolean;
  strictTransportSecurity?: boolean;
  xFrameOptions?: boolean;
  xContentTypeOptions?: boolean;
  referrerPolicy?: boolean;
  permissionsPolicy?: boolean;
}

/**
 * Enhanced security headers middleware
 * 
 * This middleware is OPTIONAL and controlled by environment variables.
 * It can be enabled/disabled without affecting existing functionality.
 */
export class SecurityHeadersMiddleware {
  private config: SecurityConfig;

  constructor() {
    this.config = {
      enabled: process.env.ENABLE_SECURITY_HEADERS === 'true',
      contentSecurityPolicy: process.env.ENABLE_CSP !== 'false',
      strictTransportSecurity: process.env.ENABLE_HSTS !== 'false',
      xFrameOptions: process.env.ENABLE_FRAME_OPTIONS !== 'false',
      xContentTypeOptions: process.env.ENABLE_CONTENT_TYPE_OPTIONS !== 'false',
      referrerPolicy: process.env.ENABLE_REFERRER_POLICY !== 'false',
      permissionsPolicy: process.env.ENABLE_PERMISSIONS_POLICY !== 'false'
    };

    if (this.config.enabled) {
      logger.info('Security headers middleware enabled', { config: this.config });
    } else {
      logger.info('Security headers middleware disabled via ENABLE_SECURITY_HEADERS=false');
    }
  }

  /**
   * Get security headers middleware
   * Returns a no-op function if security headers are disabled
   */
  getMiddleware() {
    if (!this.config.enabled) {
      return (req: Request, res: Response, next: NextFunction) => {
        // No-op middleware when security headers are disabled
        next();
      };
    }

    return helmet({
      // Content Security Policy
      contentSecurityPolicy: this.config.contentSecurityPolicy ? {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: [
            "'self'",
            "'unsafe-inline'", // Allow inline styles for Tailwind CSS
            "https://fonts.googleapis.com",
            "https://cdn.jsdelivr.net"
          ],
          scriptSrc: [
            "'self'",
            "'unsafe-inline'", // Required for inline scripts in MVP
            "https://js.stripe.com",
            "https://cdn.jsdelivr.net",
            "https://www.googletagmanager.com"
          ],
          imgSrc: [
            "'self'",
            "data:", // Allow data URLs for images
            "https:", // Allow HTTPS images
            "blob:" // Allow blob URLs for generated content
          ],
          fontSrc: [
            "'self'",
            "https://fonts.gstatic.com",
            "data:"
          ],
          connectSrc: [
            "'self'",
            "https://api.stripe.com",
            "https://api.anthropic.com",
            "https://api.mixpanel.com",
            "https://www.google-analytics.com",
            "wss:", // WebSocket connections
            process.env.FRONTEND_URL || "http://localhost:3001"
          ],
          frameSrc: [
            "'self'",
            "https://js.stripe.com",
            "https://hooks.stripe.com"
          ],
          objectSrc: ["'none'"],
          upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null
        }
      } : false,

      // Strict Transport Security (HTTPS enforcement)
      hsts: this.config.strictTransportSecurity ? {
        maxAge: 31536000, // 1 year
        includeSubDomains: true,
        preload: true
      } : false,

      // Prevent clickjacking
      frameguard: this.config.xFrameOptions ? {
        action: 'deny'
      } : false,

      // Prevent MIME type sniffing
      noSniff: this.config.xContentTypeOptions,

      // XSS Protection (legacy browsers)
      xssFilter: true,

      // Referrer Policy
      referrerPolicy: this.config.referrerPolicy ? {
        policy: 'strict-origin-when-cross-origin'
      } : false,

      // Remove X-Powered-By header
      hidePoweredBy: true,

      // DNS Prefetch Control
      dnsPrefetchControl: {
        allow: false
      },

      // Expect-CT (Certificate Transparency)
      expectCt: process.env.NODE_ENV === 'production' ? {
        maxAge: 86400,
        enforce: true
      } : false,

      // Permissions Policy (Feature Policy)
      permissionsPolicy: this.config.permissionsPolicy ? {
        camera: ['()'],
        microphone: ['()'],
        geolocation: ['()'],
        fullscreen: ['self'],
        payment: ['self', 'https://js.stripe.com']
      } : false
    });
  }

  /**
   * Custom security headers for API responses
   */
  getApiSecurityMiddleware() {
    return (req: Request, res: Response, next: NextFunction) => {
      if (!this.config.enabled) {
        return next();
      }

      // API-specific security headers
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Frame-Options', 'DENY');
      res.setHeader('X-XSS-Protection', '1; mode=block');
      
      // CORS security for API
      if (process.env.NODE_ENV === 'production') {
        res.setHeader('Access-Control-Allow-Origin', process.env.FRONTEND_URL || 'https://finishthisidea.com');
      }

      // Rate limiting headers (informational)
      const rateLimitInfo = (req as any).rateLimit;
      if (rateLimitInfo) {
        res.setHeader('X-RateLimit-Limit', rateLimitInfo.limit);
        res.setHeader('X-RateLimit-Remaining', rateLimitInfo.remaining);
        res.setHeader('X-RateLimit-Reset', new Date(Date.now() + rateLimitInfo.resetTime));
      }

      next();
    };
  }

  /**
   * Security headers for file uploads
   */
  getFileUploadSecurityMiddleware() {
    return (req: Request, res: Response, next: NextFunction) => {
      if (!this.config.enabled) {
        return next();
      }

      // Additional security for file uploads
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Download-Options', 'noopen');
      res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');

      next();
    };
  }

  /**
   * Get configuration status
   */
  getStatus() {
    return {
      enabled: this.config.enabled,
      features: this.config
    };
  }
}

// Singleton instance
const securityHeaders = new SecurityHeadersMiddleware();

// Export middleware functions
export const securityHeadersMiddleware = securityHeaders.getMiddleware();
export const apiSecurityMiddleware = securityHeaders.getApiSecurityMiddleware();
export const fileUploadSecurityMiddleware = securityHeaders.getFileUploadSecurityMiddleware();
export const getSecurityStatus = () => securityHeaders.getStatus();

// Export class for testing
export { SecurityHeadersMiddleware };