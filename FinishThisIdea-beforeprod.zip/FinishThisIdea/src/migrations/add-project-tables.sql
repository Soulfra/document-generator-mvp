-- Add Project Tables Migration
-- This migration adds support for multi-project/multi-tenant functionality

-- Create projects table
CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  owner_id UUID NOT NULL REFERENCES users(id),
  settings JSONB NOT NULL DEFAULT '{}',
  status VARCHAR(50) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'archived')),
  plan VARCHAR(50) NOT NULL DEFAULT 'free' CHECK (plan IN ('free', 'pro', 'enterprise', 'custom')),
  usage_credits INTEGER NOT NULL DEFAULT 0,
  billing_cycle_start TIMESTAMP,
  billing_cycle_end TIMESTAMP,
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create project_members table
CREATE TABLE IF NOT EXISTS project_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role VARCHAR(50) NOT NULL DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member', 'viewer')),
  permissions JSONB NOT NULL DEFAULT '{}',
  invited_at TIMESTAMP,
  invited_by UUID REFERENCES users(id),
  accepted_at TIMESTAMP,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(project_id, user_id)
);

-- Create project_invites table
CREATE TABLE IF NOT EXISTS project_invites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  email VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member', 'viewer')),
  invited_by UUID NOT NULL REFERENCES users(id),
  token VARCHAR(255) NOT NULL UNIQUE,
  status VARCHAR(50) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined', 'expired')),
  expires_at TIMESTAMP NOT NULL DEFAULT (CURRENT_TIMESTAMP + INTERVAL '7 days'),
  accepted_at TIMESTAMP,
  declined_at TIMESTAMP,
  message TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Add project_id to existing tables (with default project for backward compatibility)
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS project_id UUID;
ALTER TABLE uploads ADD COLUMN IF NOT EXISTS project_id UUID;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS project_id UUID;

-- Create default project for existing users
INSERT INTO projects (id, name, slug, owner_id, plan)
SELECT 
  gen_random_uuid(),
  COALESCE(username, split_part(email, '@', 1)) || '''s Project',
  LOWER(REGEXP_REPLACE(COALESCE(username, split_part(email, '@', 1)), '[^a-z0-9]', '-', 'g')) || '-default',
  id,
  CASE 
    WHEN tier = 'premium' THEN 'pro'
    WHEN tier = 'enterprise' THEN 'enterprise'
    ELSE 'free'
  END
FROM users
WHERE NOT EXISTS (
  SELECT 1 FROM project_members WHERE user_id = users.id
);

-- Add users as owners of their default projects
INSERT INTO project_members (project_id, user_id, role, permissions, accepted_at)
SELECT 
  p.id,
  p.owner_id,
  'owner',
  '{"canUpdateProject": true, "canDeleteProject": true, "canManageMembers": true, "canManageBilling": true, "canCreateJobs": true, "canViewJobs": true, "canDeleteJobs": true, "canDownloadResults": true, "canManageIntegrations": true, "canManageWebhooks": true, "canManageWorkflows": true, "canViewAnalytics": true, "canExportData": true}'::JSONB,
  CURRENT_TIMESTAMP
FROM projects p
WHERE NOT EXISTS (
  SELECT 1 FROM project_members WHERE project_id = p.id AND user_id = p.owner_id
);

-- Update existing records to use default project
UPDATE jobs j
SET project_id = (
  SELECT p.id 
  FROM projects p 
  JOIN project_members pm ON p.id = pm.project_id 
  WHERE pm.user_id = j.user_id 
  LIMIT 1
)
WHERE j.project_id IS NULL;

UPDATE uploads u
SET project_id = (
  SELECT p.id 
  FROM projects p 
  JOIN project_members pm ON p.id = pm.project_id 
  WHERE pm.user_id = u.user_id 
  LIMIT 1
)
WHERE u.project_id IS NULL;

UPDATE payments pay
SET project_id = (
  SELECT p.id 
  FROM projects p 
  JOIN project_members pm ON p.id = pm.project_id 
  WHERE pm.user_id = pay.user_id 
  LIMIT 1
)
WHERE pay.project_id IS NULL;

-- Make project_id required after migration
ALTER TABLE jobs ALTER COLUMN project_id SET NOT NULL;
ALTER TABLE uploads ALTER COLUMN project_id SET NOT NULL;
ALTER TABLE payments ALTER COLUMN project_id SET NOT NULL;

-- Add indexes
CREATE INDEX idx_projects_slug ON projects(slug);
CREATE INDEX idx_projects_owner ON projects(owner_id);
CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_project_members_project ON project_members(project_id);
CREATE INDEX idx_project_members_user ON project_members(user_id);
CREATE INDEX idx_project_invites_token ON project_invites(token);
CREATE INDEX idx_project_invites_email ON project_invites(email);
CREATE INDEX idx_jobs_project ON jobs(project_id);
CREATE INDEX idx_uploads_project ON uploads(project_id);
CREATE INDEX idx_payments_project ON payments(project_id);

-- Add triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_project_members_updated_at BEFORE UPDATE ON project_members
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_project_invites_updated_at BEFORE UPDATE ON project_invites
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();