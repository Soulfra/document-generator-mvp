import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { apiClient } from '../api/client';

export interface User {
  id: string;
  email: string;
  tier: 'FREE' | 'PREMIUM';
}

export interface ContextProfile {
  id: string;
  name: string;
  description?: string;
  language: string;
  framework?: string;
  isActive?: boolean;
}

interface PremiumContextState {
  user: User | null;
  activeProfile: ContextProfile | null;
  isLoading: boolean;
  setUser: (user: User | null) => void;
  setActiveProfile: (profile: ContextProfile | null) => void;
  checkPremiumFeature: (feature: string) => boolean;
  upgradeUser: (contextProfileId?: string) => Promise<void>;
  refreshUser: () => Promise<void>;
}

const PremiumContext = createContext<PremiumContextState | undefined>(undefined);

interface PremiumProviderProps {
  children: ReactNode;
}

export const PremiumProvider: React.FC<PremiumProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [activeProfile, setActiveProfile] = useState<ContextProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load user from localStorage on mount
  useEffect(() => {
    const loadStoredData = () => {
      try {
        const storedUser = localStorage.getItem('user');
        const storedProfile = localStorage.getItem('activeProfile');
        
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }
        
        if (storedProfile) {
          setActiveProfile(JSON.parse(storedProfile));
        }
      } catch (error) {
        console.error('Error loading stored data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadStoredData();
  }, []);

  // Save user to localStorage when it changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  // Save active profile to localStorage when it changes
  useEffect(() => {
    if (activeProfile) {
      localStorage.setItem('activeProfile', JSON.stringify(activeProfile));
    } else {
      localStorage.removeItem('activeProfile');
    }
  }, [activeProfile]);

  const checkPremiumFeature = (feature: string): boolean => {
    if (!user) return false;
    return user.tier === 'PREMIUM';
  };

  const upgradeUser = async (contextProfileId?: string): Promise<void> => {
    if (!user) {
      throw new Error('No user found');
    }

    try {
      // Create checkout session
      const response = await apiClient.post('/api/payment/checkout', {
        userId: user.id,
        amount: 2900, // $29.00 in cents
        contextProfileId,
      });

      const { checkoutUrl } = response.data.data;
      
      // Redirect to Stripe checkout
      window.location.href = checkoutUrl;
    } catch (error) {
      console.error('Upgrade failed:', error);
      throw error;
    }
  };

  const refreshUser = async (): Promise<void> => {
    if (!user?.id) return;

    try {
      // This would typically fetch user data from your API
      // For now, we'll simulate checking if user was upgraded
      const urlParams = new URLSearchParams(window.location.search);
      const sessionId = urlParams.get('session_id');
      
      if (sessionId) {
        // User returned from successful payment
        setUser(prev => prev ? { ...prev, tier: 'PREMIUM' } : null);
        
        // Clear the URL parameter
        const url = new URL(window.location.href);
        url.searchParams.delete('session_id');
        window.history.replaceState({}, '', url.toString());
      }
    } catch (error) {
      console.error('Error refreshing user:', error);
    }
  };

  const value: PremiumContextState = {
    user,
    activeProfile,
    isLoading,
    setUser,
    setActiveProfile,
    checkPremiumFeature,
    upgradeUser,
    refreshUser,
  };

  return (
    <PremiumContext.Provider value={value}>
      {children}
    </PremiumContext.Provider>
  );
};

export const usePremium = (): PremiumContextState => {
  const context = useContext(PremiumContext);
  if (context === undefined) {
    throw new Error('usePremium must be used within a PremiumProvider');
  }
  return context;
};