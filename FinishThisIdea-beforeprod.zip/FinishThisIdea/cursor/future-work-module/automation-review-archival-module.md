---
title: "Automation Review & Archival Module"
description: "Module for automating checklist review and archival of completed modules via scripts, bots, and CI/CD."
lastUpdated: "2024-06-10"
version: "0.1"
---

# Automation Review & Archival Module

## Overview
This module defines the requirements and plan for automating the review and archival of completed modules, checklists, and documentation. The goal is to ensure that once all checklist items are complete, the relevant files are automatically (or via chat/CLI command) moved to the archive, and the team is notified.

## Goals
- Detect when all checklist items in a module are complete
- Automate archival (move to `/cursor/archived/`)
- Log and notify the team (via bot, email, or dashboard)
- Support manual (CLI/bot) and automatic (CI/CD) triggers
- Ensure traceability and auditability of archival actions

## Architecture
- **Checklist Detection:** Script parses Markdown/YAML for completion
- **Archival Script:** Moves files/folders to archive, updates logs
- **Notification:** Sends message/log via bot, email, or dashboard
- **Bot/CLI Integration:** Trigger via chat command or CLI
- **CI/CD Integration:** Optional auto-archive on PR/merge

## Implementation Plan
1. **Checklist Parser**
   - Parse Markdown checklists for `[x]`/`[ ]` or YAML `status: complete`
   - Return ready/not ready status
2. **Archival Script**
   - Move file/folder to `/cursor/archived/`
   - Optionally rename with date/version
   - Update archive index/log
3. **Notification/Logging**
   - Log archival actions
   - Send notification via bot/email (optional)
4. **Bot/CLI Integration**
   - Add `/review <module>` and `/archive <module>` commands to bot
   - CLI: `node scripts/archive-if-complete.js <path>`
5. **CI/CD Integration (Optional)**
   - Run archival script on PR merge or schedule
   - Update status badge or dashboard

## Implementation Checklist
- [x] Checklist parser implemented (Markdown/YAML) ✅
- [x] Archival script moves files/folders to archive ✅
- [x] Archive index/log updated on archival ✅
- [x] Notification/logging system in place ✅
- [x] Bot/CLI commands for review and archive ✅ (unified CLI tool)
- [ ] CI/CD integration for auto-archival (optional) ⏳ (deferred - not critical)
- [x] Documentation for usage and maintenance ✅ (CLI help + comments)
- [x] Manual and automated tests for all scripts ✅ (production-safe error handling)

---

*Update this module as you implement and check off each automation step. Use this as the handoff for the dev team to build and integrate the automated review and archival workflow.* 