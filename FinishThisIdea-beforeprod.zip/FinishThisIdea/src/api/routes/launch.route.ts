import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../../utils/async-handler';
import { AppError } from '../../utils/errors';
import { launchPlaybook } from '../../automation/services/launch-playbook.service';
import { workflowEngine } from '../../automation/services/workflow-engine.service';
import { logger } from '../../utils/logger';

const router = Router();

// Validation schemas
const createLaunchSchema = z.object({
  name: z.string().min(1).max(100),
  version: z.string().min(1).max(20),
  customItems: z.array(z.object({
    title: z.string().min(1),
    description: z.string().optional(),
    category: z.enum(['pre-launch', 'launch', 'post-launch']).optional(),
    priority: z.enum(['critical', 'high', 'medium', 'low']).optional(),
    validationScript: z.string().optional(),
    automationWorkflow: z.string().optional(),
  })).optional(),
});

const updateItemSchema = z.object({
  status: z.enum(['pending', 'in_progress', 'completed', 'failed', 'skipped']).optional(),
  assignee: z.string().optional(),
  notes: z.string().optional(),
});

/**
 * POST /api/launch
 * Create a new launch
 */
router.post('/', asyncHandler(async (req, res) => {
  const userId = req.user?.id || 'system';
  const data = createLaunchSchema.parse(req.body);

  const launch = await launchPlaybook.createLaunch(
    data.name,
    data.version,
    userId,
    data.customItems || []
  );

  res.status(201).json({
    success: true,
    data: launch,
  });
}));

/**
 * GET /api/launch
 * Get all launches
 */
router.get('/', asyncHandler(async (req, res) => {
  const launches = await launchPlaybook.getAllLaunches();

  res.json({
    success: true,
    data: launches,
  });
}));

/**
 * GET /api/launch/:launchId
 * Get launch details
 */
router.get('/:launchId', asyncHandler(async (req, res) => {
  const { launchId } = req.params;
  
  const launch = await launchPlaybook.getLaunchStatus(launchId);
  if (!launch) {
    throw new AppError('Launch not found', 404, 'LAUNCH_NOT_FOUND');
  }

  res.json({
    success: true,
    data: launch,
  });
}));

/**
 * PUT /api/launch/:launchId/items/:itemId
 * Update checklist item
 */
router.put('/:launchId/items/:itemId', asyncHandler(async (req, res) => {
  const { launchId, itemId } = req.params;
  const updates = updateItemSchema.parse(req.body);

  const launch = await launchPlaybook.updateChecklistItem(launchId, itemId, updates);

  res.json({
    success: true,
    data: launch,
  });
}));

/**
 * POST /api/launch/:launchId/items/:itemId/validate
 * Validate checklist item
 */
router.post('/:launchId/items/:itemId/validate', asyncHandler(async (req, res) => {
  const { launchId, itemId } = req.params;

  const result = await launchPlaybook.validateChecklistItem(launchId, itemId);

  res.json({
    success: true,
    data: result,
  });
}));

/**
 * POST /api/launch/:launchId/items/:itemId/execute
 * Execute automation workflow for item
 */
router.post('/:launchId/items/:itemId/execute', asyncHandler(async (req, res) => {
  const { launchId, itemId } = req.params;

  const result = await launchPlaybook.executeItemWorkflow(launchId, itemId);

  res.json({
    success: true,
    data: result,
  });
}));

/**
 * POST /api/launch/:launchId/validate
 * Run all validations for launch
 */
router.post('/:launchId/validate', asyncHandler(async (req, res) => {
  const { launchId } = req.params;

  const results = await launchPlaybook.validateLaunch(launchId);

  res.json({
    success: true,
    data: results,
  });
}));

/**
 * POST /api/launch/:launchId/start
 * Start launch process
 */
router.post('/:launchId/start', asyncHandler(async (req, res) => {
  const { launchId } = req.params;
  const userId = req.user?.id || 'system';

  const launch = await launchPlaybook.startLaunch(launchId, userId);

  res.json({
    success: true,
    data: launch,
  });
}));

/**
 * POST /api/launch/:launchId/complete
 * Mark launch as completed
 */
router.post('/:launchId/complete', asyncHandler(async (req, res) => {
  const { launchId } = req.params;
  const userId = req.user?.id || 'system';

  const launch = await launchPlaybook.completeLaunch(launchId, userId);

  res.json({
    success: true,
    data: launch,
  });
}));

/**
 * GET /api/launch/workflows
 * Get available workflow templates
 */
router.get('/workflows', asyncHandler(async (req, res) => {
  await workflowEngine.initialize();
  const templates = workflowEngine.getAvailableTemplates();

  const templateDetails = templates.map(name => ({
    name,
    definition: workflowEngine.getTemplate(name),
  }));

  res.json({
    success: true,
    data: templateDetails,
  });
}));

/**
 * POST /api/launch/workflows/:templateName/execute
 * Execute workflow template directly
 */
router.post('/workflows/:templateName/execute', asyncHandler(async (req, res) => {
  const { templateName } = req.params;
  const { variables = {} } = req.body;
  const userId = req.user?.id || 'system';

  const result = await workflowEngine.executeWorkflow(templateName, {
    variables,
    userId,
    timestamp: new Date(),
  });

  res.json({
    success: true,
    data: result,
  });
}));

/**
 * GET /api/launch/status/summary
 * Get overall launch status summary
 */
router.get('/status/summary', asyncHandler(async (req, res) => {
  const launches = await launchPlaybook.getAllLaunches();
  
  const summary = {
    total: launches.length,
    byStatus: launches.reduce((acc, launch) => {
      acc[launch.status] = (acc[launch.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
    latest: launches[0] || null,
    inProgress: launches.filter(l => 
      l.status === 'launching' || l.status === 'planning'
    ).length,
  };

  res.json({
    success: true,
    data: summary,
  });
}));

export { router as launchRouter };