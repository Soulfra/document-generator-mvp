import { documentationService } from '../src/services/documentation.service';

describe('Chat Log Parser', () => {
  describe('parseChatlogs', () => {
    it('should extract requirements from a user management conversation', async () => {
      const chatLog = {
        messages: [
          {
            role: 'user' as const,
            content: 'I need to build a user management system for my web application. Users should be able to register, login, and manage their profiles.',
            timestamp: new Date()
          },
          {
            role: 'assistant' as const,
            content: 'I can help you build that! For a user management system, you\'ll need: 1) User registration with email verification 2) Secure login with authentication 3) Profile management where users can update their information 4) Password reset functionality. What specific features are most important to you?',
            timestamp: new Date()
          },
          {
            role: 'user' as const,
            content: 'Great! I also need user roles - admin users should be able to manage all users, and regular users should only manage their own profile. The system must be secure and we need to support 1000+ concurrent users.',
            timestamp: new Date()
          },
          {
            role: 'assistant' as const,
            content: 'Perfect! So we\'re looking at a role-based access control system. I\'ll help you implement admin privileges for user management and ensure the authentication system can handle high concurrent load. We should use JWT tokens for authentication and implement proper rate limiting.',
            timestamp: new Date()
          }
        ],
        platform: 'claude' as const,
        exportDate: new Date()
      };

      const result = await documentationService.parseChatlogs(chatLog);

      expect(result).toBeDefined();
      expect(result.features).toBeDefined();
      expect(result.userStories).toBeDefined();
      expect(result.technicalRequirements).toBeDefined();
      expect(result.businessRules).toBeDefined();
      expect(result.constraints).toBeDefined();

      // Should extract user stories
      expect(result.userStories.length).toBeGreaterThan(0);
      const userStory = result.userStories.find(story => 
        story.iWant && story.iWant.toLowerCase().includes('register')
      );
      expect(userStory).toBeDefined();

      // Should extract technical requirements
      expect(result.technicalRequirements.length).toBeGreaterThan(0);
      const jwtRequirement = result.technicalRequirements.find(req => 
        req.description && req.description.toLowerCase().includes('jwt')
      );
      expect(jwtRequirement).toBeDefined();

      // Should extract constraints
      expect(result.constraints.length).toBeGreaterThan(0);
      const performanceConstraint = result.constraints.find(constraint => 
        constraint.description && constraint.description.includes('1000')
      );
      expect(performanceConstraint).toBeDefined();
      if (performanceConstraint) {
        expect(performanceConstraint.type).toBe('performance');
        expect(performanceConstraint.impact).toBe('high');
      }
    });

    it('should extract explicit user stories with "As a..." format', async () => {
      const chatLog = {
        messages: [
          {
            role: 'user' as const,
            content: 'As a customer, I want to be able to browse products and add them to my cart so that I can purchase items easily. As an admin, I want to manage inventory so that I can keep track of stock levels.',
            timestamp: new Date()
          },
          {
            role: 'assistant' as const,
            content: 'Great user stories! I\'ll help you implement an e-commerce system with customer browsing capabilities and admin inventory management.',
            timestamp: new Date()
          }
        ],
        platform: 'chatgpt' as const,
        exportDate: new Date()
      };

      const result = await documentationService.parseChatlogs(chatLog);

      expect(result.userStories).toHaveLength(2);
      
      const customerStory = result.userStories.find(story => story.asA === 'customer');
      expect(customerStory).toBeDefined();
      expect(customerStory?.iWant).toContain('browse products');
      expect(customerStory?.soThat).toContain('purchase items easily');
      expect(customerStory?.confidence).toBeGreaterThan(0.8);

      const adminStory = result.userStories.find(story => story.asA === 'admin');
      expect(adminStory).toBeDefined();
      expect(adminStory?.iWant).toContain('manage inventory');
      expect(adminStory?.soThat).toContain('keep track of stock levels');
    });

    it('should extract constraints with different types', async () => {
      const chatLog = {
        messages: [
          {
            role: 'user' as const,
            content: 'I need this app to load in under 2 seconds, support mobile devices, and work with our existing authentication system. The budget is limited to $10,000 and we have a deadline of 3 months. Security is critical - we cannot store plain text passwords.',
            timestamp: new Date()
          }
        ],
        platform: 'claude' as const,
        exportDate: new Date()
      };

      const result = await documentationService.parseChatlogs(chatLog);

      expect(result.constraints.length).toBeGreaterThan(0);

      // Check for performance constraint
      const performanceConstraint = result.constraints.find(c => c.type === 'performance');
      expect(performanceConstraint).toBeDefined();
      expect(performanceConstraint?.description).toContain('2 seconds');

      // Check for budget constraint
      const budgetConstraint = result.constraints.find(c => c.type === 'budget');
      expect(budgetConstraint).toBeDefined();
      expect(budgetConstraint?.description).toContain('$10,000');

      // Check for timeline constraint
      const timelineConstraint = result.constraints.find(c => c.type === 'timeline');
      expect(timelineConstraint).toBeDefined();
      expect(timelineConstraint?.description).toContain('3 months');

      // Check for security constraint
      const securityConstraint = result.constraints.find(c => c.type === 'security');
      expect(securityConstraint).toBeDefined();
      expect(securityConstraint?.impact).toBe('high');
    });

    it('should handle technical discussion with framework mentions', async () => {
      const chatLog = {
        messages: [
          {
            role: 'user' as const,
            content: 'I want to build a React frontend with a Node.js Express backend. The API should use REST endpoints and connect to a PostgreSQL database. We need authentication with JWT tokens.',
            timestamp: new Date()
          },
          {
            role: 'assistant' as const,
            content: 'That\'s a solid tech stack! React + Express + PostgreSQL is a great combination. For the REST API, we\'ll need endpoints for user authentication, and JWT tokens will handle session management. I can help you set up the database schema and API routes.',
            timestamp: new Date()
          }
        ],
        platform: 'claude' as const,
        exportDate: new Date()
      };

      const result = await documentationService.parseChatlogs(chatLog);

      expect(result.technicalRequirements.length).toBeGreaterThan(0);

      // Should extract technical requirements with high confidence due to specific tech terms
      const requirements = result.technicalRequirements;
      const hasReactRequirement = requirements.some(req => 
        req.description.toLowerCase().includes('react')
      );
      const hasNodeRequirement = requirements.some(req => 
        req.description.toLowerCase().includes('node') || req.description.toLowerCase().includes('express')
      );
      const hasPostgresRequirement = requirements.some(req => 
        req.description.toLowerCase().includes('postgresql')
      );

      expect(hasReactRequirement || hasNodeRequirement || hasPostgresRequirement).toBe(true);

      // Technical terms should increase confidence
      const techRequirement = requirements.find(req => 
        req.description.toLowerCase().includes('jwt') || 
        req.description.toLowerCase().includes('api')
      );
      if (techRequirement) {
        expect(techRequirement.confidence).toBeGreaterThan(0.6);
      }
    });

    it('should extract business rules from conversation', async () => {
      const chatLog = {
        messages: [
          {
            role: 'user' as const,
            content: 'Users must verify their email before they can post content. Premium users get unlimited uploads, while free users are limited to 5 uploads per month. All content must be moderated before going live.',
            timestamp: new Date()
          },
          {
            role: 'assistant' as const,
            content: 'I understand the business rules. I\'ll implement email verification gates, user tier restrictions for uploads, and a content moderation workflow.',
            timestamp: new Date()
          }
        ],
        platform: 'claude' as const,
        exportDate: new Date()
      };

      const result = await documentationService.parseChatlogs(chatLog);

      expect(result.businessRules.length).toBeGreaterThan(0);

      const emailRule = result.businessRules.find(rule => 
        rule.description.toLowerCase().includes('email') && 
        rule.description.toLowerCase().includes('verify')
      );
      expect(emailRule).toBeDefined();

      const uploadRule = result.businessRules.find(rule => 
        rule.description.toLowerCase().includes('upload') && 
        rule.description.includes('5')
      );
      expect(uploadRule).toBeDefined();

      const moderationRule = result.businessRules.find(rule => 
        rule.description.toLowerCase().includes('moderat')
      );
      expect(moderationRule).toBeDefined();
    });

    it('should handle empty or invalid chat logs gracefully', async () => {
      const emptyChatLog = {
        messages: [],
        platform: 'claude' as const,
        exportDate: new Date()
      };

      await expect(documentationService.parseChatlogs(emptyChatLog))
        .rejects.toThrow('No messages provided in chat log');
    });

    it('should merge duplicate requirements correctly', async () => {
      const chatLog = {
        messages: [
          {
            role: 'user' as const,
            content: 'Users need to authenticate with email and password. The system should support user authentication.',
            timestamp: new Date()
          },
          {
            role: 'assistant' as const,
            content: 'I\'ll implement email/password authentication for user login.',
            timestamp: new Date()
          }
        ],
        platform: 'claude' as const,
        exportDate: new Date()
      };

      const result = await documentationService.parseChatlogs(chatLog);

      // Should merge similar authentication requirements
      const authRequirements = result.technicalRequirements.filter(req => 
        req.description.toLowerCase().includes('authenticat')
      );
      
      // Should not have many duplicate authentication requirements
      expect(authRequirements.length).toBeLessThanOrEqual(2);
    });

    it('should assign appropriate confidence scores', async () => {
      const chatLog = {
        messages: [
          {
            role: 'user' as const,
            content: 'Maybe we could add a dashboard feature. I think users might want to see analytics. The system must have secure authentication with JWT tokens.',
            timestamp: new Date()
          }
        ],
        platform: 'claude' as const,
        exportDate: new Date()
      };

      const result = await documentationService.parseChatlogs(chatLog);

      // Vague requirements ("maybe", "might") should have lower confidence
      const vagueRequirement = result.features.find(feature => 
        feature.description.toLowerCase().includes('maybe') || 
        feature.description.toLowerCase().includes('dashboard')
      );
      if (vagueRequirement) {
        expect(vagueRequirement.confidence).toBeLessThan(0.6);
      }

      // Technical requirements with specific terms should have higher confidence
      const techRequirement = result.technicalRequirements.find(req => 
        req.description.toLowerCase().includes('jwt')
      );
      if (techRequirement) {
        expect(techRequirement.confidence).toBeGreaterThan(0.7);
      }
    });

    it('should extract features with appropriate detail level', async () => {
      const chatLog = {
        messages: [
          {
            role: 'user' as const,
            content: 'I need a file upload system that supports drag and drop, progress bars, and file type validation. Users should be able to organize files into folders.',
            timestamp: new Date()
          },
          {
            role: 'assistant' as const,
            content: 'I\'ll help you build a comprehensive file management system with those features.',
            timestamp: new Date()
          }
        ],
        platform: 'claude' as const,
        exportDate: new Date()
      };

      const result = await documentationService.parseChatlogs(chatLog);

      expect(result.features.length).toBeGreaterThan(0);

      // Should extract specific features
      const uploadFeature = result.features.find(feature => 
        feature.description.toLowerCase().includes('upload') || 
        feature.description.toLowerCase().includes('drag')
      );
      expect(uploadFeature).toBeDefined();

      const folderFeature = result.features.find(feature => 
        feature.description.toLowerCase().includes('folder') || 
        feature.description.toLowerCase().includes('organiz')
      );
      expect(folderFeature).toBeDefined();
    });
  });

  describe('Direct Text Parsing', () => {
    it('should extract requirements from structured text', () => {
      const structuredText = `
## Features
- User registration and login
- Profile management
- File upload system

## Technical Requirements
- React frontend framework
- Node.js backend with Express
- PostgreSQL database
- JWT authentication

## Business Rules
- Users must verify email before posting
- Free users limited to 5 uploads per month
- All content must be moderated

## Constraints
Performance requirement: Page load under 2 seconds
Security constraint: All passwords must be hashed
Budget limitation: Development cost under $15,000
      `;

      // This tests the direct parsing without going through the full parseChatlogs method
      const service = documentationService as any;
      const result = service.parseRequirementsFromText(structuredText);

      expect(result.features).toHaveLength(3);
      expect(result.technicalRequirements).toHaveLength(4);
      expect(result.businessRules).toHaveLength(3);
      expect(result.constraints.length).toBeGreaterThan(0);

      // Check specific extractions
      expect(result.features[0].description).toContain('registration');
      expect(result.technicalRequirements[0].description).toContain('React');
      expect(result.businessRules[0].description).toContain('verify email');
    });
  });
});