#!/usr/bin/env node

/**
 * Archive Module Script - Safely move completed work to archives
 * 
 * Features:
 * - Safe file/folder archival with backup
 * - Archive index updates
 * - Completion verification
 * - Rollback capability
 * - Production-safe operations
 */

const fs = require('fs');
const path = require('path');
const ChecklistParser = require('./checklist-parser');

class ArchiveManager {
  constructor(projectRoot = null) {
    this.projectRoot = projectRoot || this.findProjectRoot();
    this.cursorDir = path.join(this.projectRoot, 'cursor');
    this.archiveDir = path.join(this.cursorDir, 'archived');
    this.indexFile = path.join(this.archiveDir, 'index.md');
    
    this.ensureDirectories();
  }

  /**
   * Find project root directory
   */
  findProjectRoot() {
    let currentDir = process.cwd();
    
    while (currentDir !== path.dirname(currentDir)) {
      if (fs.existsSync(path.join(currentDir, 'package.json')) || 
          fs.existsSync(path.join(currentDir, 'cursor'))) {
        return currentDir;
      }
      currentDir = path.dirname(currentDir);
    }
    
    return process.cwd();
  }

  /**
   * Ensure required directories exist
   */
  ensureDirectories() {
    if (!fs.existsSync(this.archiveDir)) {
      fs.mkdirSync(this.archiveDir, { recursive: true });
      console.log(`📁 Created archive directory: ${this.archiveDir}`);
    }
  }

  /**
   * Check if a module is complete
   * @param {string} modulePath - Path to module file or directory
   * @returns {Object} Completion status
   */
  async checkCompletion(modulePath) {
    const parser = new ChecklistParser();
    
    try {
      let results;
      
      if (fs.statSync(modulePath).isDirectory()) {
        results = parser.parseDirectory(modulePath);
      } else {
        results = parser.parseFile(modulePath);
      }
      
      return {
        isComplete: results.isComplete,
        completionPercentage: results.completionPercentage || results.overallCompletion,
        details: results
      };
    } catch (error) {
      return {
        isComplete: false,
        completionPercentage: 0,
        error: error.message
      };
    }
  }

  /**
   * Generate archive filename with timestamp
   * @param {string} originalName - Original filename
   * @returns {string} Timestamped filename
   */
  generateArchiveFilename(originalName) {
    const timestamp = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const baseName = path.basename(originalName, path.extname(originalName));
    const extension = path.extname(originalName);
    
    return `${baseName}-${timestamp}${extension}`;
  }

  /**
   * Create backup before archival
   * @param {string} sourcePath - Source file/directory
   * @returns {string} Backup path
   */
  createBackup(sourcePath) {
    const backupDir = path.join(this.projectRoot, '.archive-backups');
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupName = `${path.basename(sourcePath)}-backup-${timestamp}`;
    const backupPath = path.join(backupDir, backupName);

    if (fs.statSync(sourcePath).isDirectory()) {
      this.copyDirectory(sourcePath, backupPath);
    } else {
      fs.copyFileSync(sourcePath, backupPath);
    }

    return backupPath;
  }

  /**
   * Recursively copy directory
   * @param {string} src - Source directory
   * @param {string} dest - Destination directory
   */
  copyDirectory(src, dest) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }

    const entries = fs.readdirSync(src, { withFileTypes: true });

    for (const entry of entries) {
      const srcPath = path.join(src, entry.name);
      const destPath = path.join(dest, entry.name);

      if (entry.isDirectory()) {
        this.copyDirectory(srcPath, destPath);
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    }
  }

  /**
   * Archive a completed module
   * @param {string} modulePath - Path to module to archive
   * @param {Object} options - Archive options
   * @returns {Object} Archive result
   */
  async archiveModule(modulePath, options = {}) {
    const {
      force = false,
      dryRun = false,
      skipCompletion = false,
      customName = null
    } = options;

    const result = {
      success: false,
      modulePath,
      archivePath: null,
      backupPath: null,
      message: '',
      warnings: []
    };

    try {
      // Verify module exists
      if (!fs.existsSync(modulePath)) {
        throw new Error(`Module not found: ${modulePath}`);
      }

      // Check completion status unless skipped or forced
      if (!skipCompletion && !force) {
        const completion = await this.checkCompletion(modulePath);
        
        if (!completion.isComplete) {
          throw new Error(`Module is not complete (${completion.completionPercentage}%). Use --force to archive anyway.`);
        }
      }

      // Generate archive filename
      const moduleName = path.basename(modulePath);
      const archiveFilename = customName || this.generateArchiveFilename(moduleName);
      const archivePath = path.join(this.archiveDir, archiveFilename);

      // Check if archive already exists
      if (fs.existsSync(archivePath) && !force) {
        throw new Error(`Archive already exists: ${archiveFilename}. Use --force to overwrite.`);
      }

      result.archivePath = archivePath;

      if (dryRun) {
        result.success = true;
        result.message = `DRY RUN: Would archive ${modulePath} to ${archivePath}`;
        return result;
      }

      // Create backup
      console.log('📋 Creating backup...');
      result.backupPath = this.createBackup(modulePath);

      // Move to archive
      console.log(`📦 Archiving ${moduleName}...`);
      
      if (fs.statSync(modulePath).isDirectory()) {
        this.copyDirectory(modulePath, archivePath);
        fs.rmSync(modulePath, { recursive: true, force: true });
      } else {
        fs.copyFileSync(modulePath, archivePath);
        fs.unlinkSync(modulePath);
      }

      // Update archive index
      await this.updateArchiveIndex(archiveFilename, modulePath);

      result.success = true;
      result.message = `✅ Successfully archived ${moduleName} to ${archiveFilename}`;
      
      console.log(result.message);

    } catch (error) {
      result.message = `❌ Archive failed: ${error.message}`;
      console.error(result.message);
    }

    return result;
  }

  /**
   * Update the archive index file
   * @param {string} archiveFilename - Archived filename
   * @param {string} originalPath - Original module path
   */
  async updateArchiveIndex(archiveFilename, originalPath) {
    const timestamp = new Date().toISOString().split('T')[0];
    const moduleName = path.basename(originalPath);
    
    // Read existing index or create new one
    let indexContent = '';
    if (fs.existsSync(this.indexFile)) {
      indexContent = fs.readFileSync(this.indexFile, 'utf8');
    } else {
      indexContent = `# Archived Reviews Index

This file lists all completed premium/paywall feature reviews and their summaries.

---

| Review Name | Date Completed | Summary |
|-------------|---------------|---------|
`;
    }

    // Add new entry to the table
    const newEntry = `| ${moduleName} | ${timestamp} | ✅ Automatically archived completed module |`;
    
    // Insert before the detailed reports section or at the end
    if (indexContent.includes('## Detailed Implementation Reports')) {
      indexContent = indexContent.replace(
        '## Detailed Implementation Reports',
        `${newEntry}\n\n## Detailed Implementation Reports`
      );
    } else {
      indexContent += `\n${newEntry}`;
    }

    fs.writeFileSync(this.indexFile, indexContent);
    console.log(`📝 Updated archive index: ${this.indexFile}`);
  }

  /**
   * List archivable modules in cursor directory
   * @returns {Array} List of modules with completion status
   */
  async listArchivableModules() {
    const modules = [];
    
    if (!fs.existsSync(this.cursorDir)) {
      return modules;
    }

    const entries = fs.readdirSync(this.cursorDir, { withFileTypes: true });
    
    for (const entry of entries) {
      if (entry.name === 'archived' || entry.name === 'review-responses') {
        continue;
      }

      const fullPath = path.join(this.cursorDir, entry.name);
      const completion = await this.checkCompletion(fullPath);
      
      modules.push({
        name: entry.name,
        path: fullPath,
        type: entry.isDirectory() ? 'directory' : 'file',
        isComplete: completion.isComplete,
        completionPercentage: completion.completionPercentage,
        canArchive: completion.isComplete
      });
    }

    return modules;
  }

  /**
   * Restore module from backup
   * @param {string} backupPath - Path to backup
   * @param {string} restorePath - Where to restore
   */
  restoreFromBackup(backupPath, restorePath) {
    if (!fs.existsSync(backupPath)) {
      throw new Error(`Backup not found: ${backupPath}`);
    }

    if (fs.statSync(backupPath).isDirectory()) {
      this.copyDirectory(backupPath, restorePath);
    } else {
      fs.copyFileSync(backupPath, restorePath);
    }

    console.log(`🔄 Restored from backup: ${restorePath}`);
  }
}

// CLI Usage
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0 || args.includes('--help')) {
    console.log(`
Archive Module - Safely archive completed work

Usage:
  node archive-module.js <module-path> [options]
  node archive-module.js --list
  node archive-module.js --list-complete

Options:
  --force           Archive even if incomplete
  --dry-run         Show what would be archived without doing it
  --skip-completion Skip completion check
  --name <name>     Custom archive filename
  --list           List all modules with completion status
  --list-complete   List only completed modules ready for archival

Examples:
  node archive-module.js ./cursor/future-work-module/
  node archive-module.js ./cursor/automation-review-archival-module.md --dry-run
  node archive-module.js ./cursor/some-module/ --force --name "custom-name.md"
  node archive-module.js --list-complete
`);
    process.exit(0);
  }

  const manager = new ArchiveManager();

  // Handle list commands
  if (args.includes('--list') || args.includes('--list-complete')) {
    manager.listArchivableModules().then(modules => {
      const showCompleteOnly = args.includes('--list-complete');
      const filteredModules = showCompleteOnly ? modules.filter(m => m.canArchive) : modules;
      
      if (filteredModules.length === 0) {
        console.log(showCompleteOnly ? '📭 No completed modules ready for archival' : '📭 No modules found');
        return;
      }

      console.log(showCompleteOnly ? '📋 Modules ready for archival:' : '📋 All modules:');
      filteredModules.forEach(module => {
        const status = module.isComplete ? '✅' : '⏳';
        const archivable = module.canArchive ? ' (ready)' : '';
        console.log(`  ${status} ${module.name} - ${module.completionPercentage}%${archivable}`);
      });
    }).catch(console.error);
    return;
  }

  // Archive specific module
  const modulePath = args[0];
  const options = {
    force: args.includes('--force'),
    dryRun: args.includes('--dry-run'),
    skipCompletion: args.includes('--skip-completion'),
    customName: args.includes('--name') ? args[args.indexOf('--name') + 1] : null
  };

  manager.archiveModule(modulePath, options).then(result => {
    console.log(result.message);
    process.exit(result.success ? 0 : 1);
  }).catch(error => {
    console.error('❌ Archive error:', error.message);
    process.exit(1);
  });
}

module.exports = ArchiveManager;