import { promises as fs } from 'fs';
import * as path from 'path';
import { logger } from '../../utils/logger';
import { workflowEngine } from './workflow-engine.service';
import { launchPlaybook } from './launch-playbook.service';
import { analyticsService } from './analytics-integration.service';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export interface ProjectTemplate {
  id: string;
  name: string;
  description: string;
  category: 'web-app' | 'api' | 'automation' | 'documentation' | 'other';
  tags: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedTime: string;
  requirements: string[];
  files: TemplateFile[];
  workflows: string[];
  configuration: TemplateConfig[];
  integrations: Integration[];
  metadata: {
    version: string;
    author: string;
    createdAt: Date;
    updatedAt: Date;
    downloads: number;
    rating: number;
  };
}

export interface TemplateFile {
  path: string;
  content: string;
  executable?: boolean;
  binary?: boolean;
}

export interface TemplateConfig {
  key: string;
  name: string;
  description: string;
  type: 'string' | 'number' | 'boolean' | 'email' | 'url' | 'select' | 'multiselect';
  required: boolean;
  default?: any;
  options?: string[];
  validation?: string;
  placeholder?: string;
}

export interface Integration {
  id: string;
  name: string;
  description: string;
  required: boolean;
  configKeys: string[];
  testEndpoint?: string;
  documentationUrl?: string;
}

export interface WizardSession {
  id: string;
  templateId: string;
  userId: string;
  projectName: string;
  status: 'started' | 'configuring' | 'generating' | 'completed' | 'failed';
  configuration: Record<string, any>;
  selectedIntegrations: string[];
  generatedFiles: TemplateFile[];
  workflows: string[];
  outputPath?: string;
  startedAt: Date;
  completedAt?: Date;
  error?: string;
}

export interface WizardStep {
  id: string;
  title: string;
  description: string;
  component: 'project-details' | 'template-selection' | 'configuration' | 'integrations' | 'review' | 'generation';
  validation?: (data: any) => string | null;
  next?: string;
  previous?: string;
}

export class ProjectWizardService {
  private templates: Map<string, ProjectTemplate> = new Map();
  private sessions: Map<string, WizardSession> = new Map();

  /**
   * Initialize wizard with default templates
   */
  public async initialize(): Promise<void> {
    await this.loadDefaultTemplates();
    logger.info('Project wizard service initialized');
  }

  /**
   * Get all available templates
   */
  public getTemplates(category?: string): ProjectTemplate[] {
    const templates = Array.from(this.templates.values());
    return category 
      ? templates.filter(t => t.category === category)
      : templates;
  }

  /**
   * Get template by ID
   */
  public getTemplate(templateId: string): ProjectTemplate | undefined {
    return this.templates.get(templateId);
  }

  /**
   * Start a new wizard session
   */
  public async startWizardSession(
    templateId: string,
    userId: string,
    projectName: string
  ): Promise<WizardSession> {
    const template = this.templates.get(templateId);
    if (!template) {
      throw new Error(`Template ${templateId} not found`);
    }

    const sessionId = `wizard-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const session: WizardSession = {
      id: sessionId,
      templateId,
      userId,
      projectName,
      status: 'started',
      configuration: {},
      selectedIntegrations: [],
      generatedFiles: [],
      workflows: [...template.workflows],
      startedAt: new Date(),
    };

    this.sessions.set(sessionId, session);

    // Track wizard start
    await analyticsService.track({
      event: 'wizard_session_started',
      userId,
      properties: {
        session_id: sessionId,
        template_id: templateId,
        project_name: projectName,
        template_category: template.category,
      },
    });

    logger.info('Wizard session started', { sessionId, templateId, projectName, userId });
    return session;
  }

  /**
   * Update wizard session configuration
   */
  public async updateConfiguration(
    sessionId: string,
    configuration: Record<string, any>
  ): Promise<WizardSession> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new Error(`Wizard session ${sessionId} not found`);
    }

    session.configuration = { ...session.configuration, ...configuration };
    session.status = 'configuring';

    this.sessions.set(sessionId, session);
    return session;
  }

  /**
   * Set selected integrations
   */
  public async setIntegrations(
    sessionId: string,
    integrationIds: string[]
  ): Promise<WizardSession> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new Error(`Wizard session ${sessionId} not found`);
    }

    const template = this.templates.get(session.templateId);
    if (!template) {
      throw new Error(`Template ${session.templateId} not found`);
    }

    // Validate integration IDs
    const validIntegrations = template.integrations.map(i => i.id);
    const invalidIntegrations = integrationIds.filter(id => !validIntegrations.includes(id));
    
    if (invalidIntegrations.length > 0) {
      throw new Error(`Invalid integrations: ${invalidIntegrations.join(', ')}`);
    }

    session.selectedIntegrations = integrationIds;
    this.sessions.set(sessionId, session);
    
    return session;
  }

  /**
   * Generate project from wizard session
   */
  public async generateProject(sessionId: string): Promise<WizardSession> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new Error(`Wizard session ${sessionId} not found`);
    }

    const template = this.templates.get(session.templateId);
    if (!template) {
      throw new Error(`Template ${session.templateId} not found`);
    }

    try {
      session.status = 'generating';
      this.sessions.set(sessionId, session);

      logger.info('Generating project', { sessionId, templateId: template.id });

      // Generate files with interpolated variables
      const generatedFiles: TemplateFile[] = [];
      for (const file of template.files) {
        const interpolatedContent = this.interpolateTemplate(file.content, {
          project: {
            name: session.projectName,
            slug: this.slugify(session.projectName),
          },
          config: session.configuration,
          integrations: session.selectedIntegrations,
          timestamp: new Date().toISOString(),
          userId: session.userId,
        });

        generatedFiles.push({
          ...file,
          content: interpolatedContent,
        });
      }

      session.generatedFiles = generatedFiles;

      // Create output directory
      const outputPath = path.join(process.cwd(), 'generated-projects', session.id);
      await fs.mkdir(outputPath, { recursive: true });

      // Write files
      for (const file of generatedFiles) {
        const filePath = path.join(outputPath, file.path);
        const fileDir = path.dirname(filePath);
        
        await fs.mkdir(fileDir, { recursive: true });
        await fs.writeFile(filePath, file.content);

        if (file.executable) {
          await fs.chmod(filePath, '755');
        }
      }

      session.outputPath = outputPath;
      session.status = 'completed';
      session.completedAt = new Date();

      this.sessions.set(sessionId, session);

      // Track generation completion
      await analyticsService.track({
        event: 'wizard_project_generated',
        userId: session.userId,
        properties: {
          session_id: sessionId,
          template_id: template.id,
          files_generated: generatedFiles.length,
          integrations_count: session.selectedIntegrations.length,
          generation_time_ms: session.completedAt.getTime() - session.startedAt.getTime(),
        },
      });

      // Auto-create launch checklist if this is a deployable project
      if (template.category === 'web-app' || template.category === 'api') {
        try {
          await launchPlaybook.createLaunch(
            session.projectName,
            '1.0.0',
            session.userId,
            [
              {
                title: 'Review generated project',
                description: 'Review and customize the generated project files',
                category: 'pre-launch',
                priority: 'high',
              },
              {
                title: 'Test generated application',
                description: 'Run tests and verify the generated application works',
                category: 'pre-launch',
                priority: 'critical',
                validationScript: `cd ${outputPath} && npm test`,
              },
            ]
          );
          logger.info('Launch checklist created for generated project', { sessionId });
        } catch (error) {
          logger.warn('Failed to create launch checklist', { error, sessionId });
        }
      }

      logger.info('Project generated successfully', { 
        sessionId, 
        outputPath, 
        filesGenerated: generatedFiles.length 
      });

      return session;

    } catch (error) {
      session.status = 'failed';
      session.error = error instanceof Error ? error.message : 'Unknown error';
      this.sessions.set(sessionId, session);

      logger.error('Project generation failed', { error, sessionId });
      throw error;
    }
  }

  /**
   * Execute project workflows
   */
  public async executeProjectWorkflows(sessionId: string): Promise<any[]> {
    const session = this.sessions.get(sessionId);
    if (!session || session.status !== 'completed') {
      throw new Error('Project must be generated before executing workflows');
    }

    const results = [];

    for (const workflowName of session.workflows) {
      try {
        const result = await workflowEngine.executeWorkflow(workflowName, {
          variables: {
            project_name: session.projectName,
            project_path: session.outputPath,
            user_id: session.userId,
            session_id: sessionId,
            ...session.configuration,
          },
          userId: session.userId,
          timestamp: new Date(),
        });

        results.push({ workflow: workflowName, result });
        logger.info('Workflow executed', { sessionId, workflowName, success: result.success });
      } catch (error) {
        logger.error('Workflow execution failed', { error, sessionId, workflowName });
        results.push({ 
          workflow: workflowName, 
          error: error instanceof Error ? error.message : 'Unknown error' 
        });
      }
    }

    return results;
  }

  /**
   * Get wizard session
   */
  public getSession(sessionId: string): WizardSession | undefined {
    return this.sessions.get(sessionId);
  }

  /**
   * Get user's wizard sessions
   */
  public getUserSessions(userId: string): WizardSession[] {
    return Array.from(this.sessions.values())
      .filter(session => session.userId === userId)
      .sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime());
  }

  /**
   * Add custom template
   */
  public addTemplate(template: ProjectTemplate): void {
    this.templates.set(template.id, template);
    logger.info('Template added', { templateId: template.id, name: template.name });
  }

  /**
   * Load default templates
   */
  private async loadDefaultTemplates(): Promise<void> {
    // Basic web app template
    const webAppTemplate: ProjectTemplate = {
      id: 'basic-web-app',
      name: 'Basic Web Application',
      description: 'A simple web application with authentication and database',
      category: 'web-app',
      tags: ['web', 'typescript', 'react', 'express'],
      difficulty: 'intermediate',
      estimatedTime: '30 minutes',
      requirements: ['Node.js 18+', 'Database'],
      files: [
        {
          path: 'package.json',
          content: JSON.stringify({
            name: '{{ project.slug }}',
            version: '1.0.0',
            description: '{{ config.description || "Generated web application" }}',
            main: 'dist/server.js',
            scripts: {
              dev: 'tsx watch src/server.ts',
              build: 'tsc',
              start: 'node dist/server.js',
              test: 'jest',
            },
            dependencies: {
              express: '^4.18.2',
              typescript: '^5.3.3',
            },
          }, null, 2),
        },
        {
          path: 'src/server.ts',
          content: `import express from 'express';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(\`🚀 {{ project.name }} running on port \${PORT}\`);
});
`,
        },
        {
          path: 'README.md',
          content: `# {{ project.name }}

{{ config.description || "Generated web application" }}

## Getting Started

\`\`\`bash
npm install
npm run dev
\`\`\`

## Generated by FinishThisIdea

This project was generated on {{ timestamp }} using the Basic Web Application template.
`,
        },
      ],
      workflows: ['deployment-workflow'],
      configuration: [
        {
          key: 'description',
          name: 'Project Description',
          description: 'Brief description of your web application',
          type: 'string',
          required: false,
          placeholder: 'A web application for...',
        },
        {
          key: 'port',
          name: 'Server Port',
          description: 'Port for the development server',
          type: 'number',
          required: false,
          default: 3000,
        },
      ],
      integrations: [
        {
          id: 'database',
          name: 'Database',
          description: 'PostgreSQL database integration',
          required: false,
          configKeys: ['DATABASE_URL'],
          documentationUrl: 'https://docs.finishthisidea.com/integrations/database',
        },
        {
          id: 'authentication',
          name: 'Authentication',
          description: 'User authentication system',
          required: false,
          configKeys: ['JWT_SECRET'],
          documentationUrl: 'https://docs.finishthisidea.com/integrations/auth',
        },
      ],
      metadata: {
        version: '1.0.0',
        author: 'FinishThisIdea',
        createdAt: new Date(),
        updatedAt: new Date(),
        downloads: 0,
        rating: 5.0,
      },
    };

    this.templates.set(webAppTemplate.id, webAppTemplate);

    // Documentation site template
    const docsTemplate: ProjectTemplate = {
      id: 'documentation-site',
      name: 'Documentation Site',
      description: 'A documentation website with search and navigation',
      category: 'documentation',
      tags: ['docs', 'markdown', 'static-site'],
      difficulty: 'beginner',
      estimatedTime: '15 minutes',
      requirements: ['Node.js 18+'],
      files: [
        {
          path: 'docs/index.md',
          content: `# {{ project.name }}

Welcome to the documentation for {{ project.name }}.

## Getting Started

{{ config.description || "This documentation site was generated by FinishThisIdea." }}

## Navigation

- [Getting Started](#getting-started)
- [API Reference](api.md)
- [Examples](examples.md)

---

Generated on {{ timestamp }}
`,
        },
        {
          path: 'docs/api.md',
          content: `# API Reference

Documentation for {{ project.name }} API.

## Endpoints

### GET /health

Health check endpoint.

\`\`\`json
{
  "status": "ok",
  "timestamp": "2024-01-01T00:00:00.000Z"
}
\`\`\`
`,
        },
      ],
      workflows: ['user-onboarding-workflow'],
      configuration: [
        {
          key: 'description',
          name: 'Site Description',
          description: 'Description of what this documentation covers',
          type: 'string',
          required: true,
          placeholder: 'Documentation for...',
        },
      ],
      integrations: [],
      metadata: {
        version: '1.0.0',
        author: 'FinishThisIdea',
        createdAt: new Date(),
        updatedAt: new Date(),
        downloads: 0,
        rating: 4.8,
      },
    };

    this.templates.set(docsTemplate.id, docsTemplate);

    logger.info(`Loaded ${this.templates.size} default templates`);
  }

  /**
   * Interpolate template variables
   */
  private interpolateTemplate(content: string, variables: Record<string, any>): string {
    return content.replace(/\{\{\s*([^}]+)\s*\}\}/g, (match, path) => {
      const value = this.getNestedValue(variables, path.trim());
      return value !== undefined ? String(value) : match;
    });
  }

  /**
   * Get nested object value by path
   */
  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  /**
   * Slugify project name
   */
  private slugify(text: string): string {
    return text
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }
}

// Export singleton instance
export const projectWizard = new ProjectWizardService();