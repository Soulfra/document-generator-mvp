import { motion } from 'framer-motion';
import { useState } from 'react';
import { Gift, TrendingUp, Users, Zap, Star, Crown } from 'lucide-react';
import ReferralCode from './ReferralCode';
import ReferralStats from './ReferralStats';

interface ReferralDashboardProps {
  userId?: string;
}

const ReferralDashboard = ({ userId = 'demo-user' }: ReferralDashboardProps) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'performance' | 'leaderboard'>('overview');

  const leaderboardData = [
    { rank: 1, name: 'Alex Chen', referrals: 89, earnings: 44.50, badge: 'crown' },
    { rank: 2, name: 'Sarah Rodriguez', referrals: 76, earnings: 38.00, badge: 'star' },
    { rank: 3, name: 'Mike Johnson', referrals: 68, earnings: 34.00, badge: 'star' },
    { rank: 4, name: 'Emma Wilson', referrals: 45, earnings: 22.50, badge: 'none' },
    { rank: 5, name: 'David Liu', referrals: 41, earnings: 20.50, badge: 'none' },
    { rank: 6, name: 'You', referrals: 23, earnings: 9.50, badge: 'none', isUser: true },
  ];

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Gift },
    { id: 'performance', label: 'Performance', icon: TrendingUp },
    { id: 'leaderboard', label: 'Leaderboard', icon: Crown },
  ];

  const tips = [
    {
      icon: Users,
      title: 'Share with Developer Friends',
      description: 'Developers trust recommendations from other developers. Share in your coding communities!'
    },
    {
      icon: Zap,
      title: 'Show Before/After Results',
      description: 'Nothing sells better than seeing the actual transformation. Share your cleaned code examples.'
    },
    {
      icon: Star,
      title: 'Time It Right',
      description: 'Share when someone complains about messy code or during code review discussions.'
    }
  ];

  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl font-bold mb-4">
          Referral <span className="gradient-text">Dashboard</span>
        </h1>
        <p className="text-xl text-gray-400">
          Earn money by sharing the magic of clean code
        </p>
      </motion.div>

      {/* Tab Navigation */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex justify-center mb-8"
      >
        <div className="glass-card p-1 flex space-x-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`
                  flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200
                  ${activeTab === tab.id 
                    ? 'bg-primary-500 text-white' 
                    : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
                  }
                `}
              >
                <Icon className="w-4 h-4" />
                <span className="text-sm font-medium">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </motion.div>

      {/* Tab Content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Quick Stats + Referral Code */}
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ReferralStats userId={userId} />
              </div>
              <div>
                <ReferralCode userId={userId} variant="card" />
              </div>
            </div>

            {/* Tips for Success */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card p-6"
            >
              <h3 className="text-xl font-semibold text-white mb-6 flex items-center space-x-2">
                <Zap className="w-5 h-5 text-accent-400" />
                <span>Tips for Success</span>
              </h3>
              
              <div className="grid md:grid-cols-3 gap-6">
                {tips.map((tip, index) => {
                  const Icon = tip.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-gray-900/30 rounded-lg p-4 hover:bg-gray-900/50 transition-colors"
                    >
                      <div className="w-10 h-10 bg-gradient-to-br from-accent-500/20 to-primary-500/20 rounded-lg flex items-center justify-center mb-3">
                        <Icon className="w-5 h-5 text-accent-400" />
                      </div>
                      <h4 className="text-sm font-semibold text-white mb-2">{tip.title}</h4>
                      <p className="text-xs text-gray-400">{tip.description}</p>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        )}

        {activeTab === 'performance' && (
          <div className="space-y-6">
            <ReferralStats userId={userId} variant="detailed" />
            
            {/* Additional Performance Metrics */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="glass-card p-6"
            >
              <h3 className="text-xl font-semibold text-white mb-4">Detailed Analytics</h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                {/* Conversion Funnel */}
                <div className="bg-gray-900/30 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-white mb-4">Conversion Funnel</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-400">Link Clicks</span>
                      <span className="text-sm text-white">156</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div className="bg-blue-500 h-2 rounded-full w-full"></div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-400">Signups</span>
                      <span className="text-sm text-white">23</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div className="bg-yellow-500 h-2 rounded-full w-[15%]"></div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-400">First Purchase</span>
                      <span className="text-sm text-white">18</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full w-[12%]"></div>
                    </div>
                  </div>
                </div>

                {/* Top Performing Channels */}
                <div className="bg-gray-900/30 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-white mb-4">Top Channels</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-400">Twitter</span>
                      <span className="text-sm text-green-400">12 conversions</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-400">Direct Share</span>
                      <span className="text-sm text-blue-400">8 conversions</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-400">LinkedIn</span>
                      <span className="text-sm text-purple-400">3 conversions</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {activeTab === 'leaderboard' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card p-6"
          >
            <h3 className="text-xl font-semibold text-white mb-6 flex items-center space-x-2">
              <Crown className="w-5 h-5 text-yellow-400" />
              <span>Top Referrers This Month</span>
            </h3>
            
            <div className="space-y-3">
              {leaderboardData.map((user, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`
                    flex items-center justify-between p-4 rounded-lg transition-all duration-200
                    ${user.isUser 
                      ? 'bg-primary-500/10 border border-primary-500/20' 
                      : 'bg-gray-900/30 hover:bg-gray-900/50'
                    }
                  `}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`
                      w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold
                      ${user.rank === 1 
                        ? 'bg-gradient-to-br from-yellow-400 to-yellow-600 text-gray-900' 
                        : user.rank <= 3 
                          ? 'bg-gradient-to-br from-gray-400 to-gray-600 text-white'
                          : 'bg-gray-700 text-gray-300'
                      }
                    `}>
                      {user.rank}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <span className={`font-medium ${user.isUser ? 'text-primary-400' : 'text-white'}`}>
                        {user.name}
                      </span>
                      {user.badge === 'crown' && (
                        <Crown className="w-4 h-4 text-yellow-400" />
                      )}
                      {user.badge === 'star' && (
                        <Star className="w-4 h-4 text-blue-400" />
                      )}
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-sm font-semibold text-white">
                      {user.referrals} referrals
                    </div>
                    <div className="text-xs text-green-400">
                      ${user.earnings.toFixed(2)} earned
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Rewards for top performers */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="mt-6 p-4 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-lg border border-yellow-500/20"
            >
              <h4 className="text-sm font-semibold text-white mb-2">Monthly Rewards</h4>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-lg font-bold text-yellow-400">#1</div>
                  <div className="text-xs text-gray-400">$50 bonus</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-gray-400">#2</div>
                  <div className="text-xs text-gray-400">$25 bonus</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-orange-400">#3</div>
                  <div className="text-xs text-gray-400">$10 bonus</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default ReferralDashboard;