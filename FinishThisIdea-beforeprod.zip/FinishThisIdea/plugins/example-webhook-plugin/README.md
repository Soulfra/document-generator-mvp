# Webhook Workflow Plugin

A custom workflow step plugin for FinishThisIdea that enables HTTP webhook integrations.

## Installation

1. Copy this plugin to your `plugins/` directory
2. Add to your automation config:

```json
{
  "plugins": {
    "webhook": {
      "enabled": true,
      "config": {}
    }
  }
}
```

3. Restart the workflow engine

## Usage

In your workflow YAML:

```yaml
name: webhook-example
steps:
  - name: Send webhook notification
    type: webhook
    url: https://example.com/webhook
    method: POST
    headers:
      X-Custom-Header: "value"
    body:
      event: "workflow_completed"
      workflowId: "{{workflowId}}"
      status: "success"
    timeout: 30
    retryOnFailure: true
    retryCount: 3
```

## Fields

- **url** (required): The webhook endpoint URL
- **method**: HTTP method (GET, POST, PUT, PATCH, DELETE) - defaults to POST
- **headers**: Custom HTTP headers as JSON object
- **body**: Request body as JSON (for POST/PUT/PATCH)
- **timeout**: Request timeout in seconds (1-300, default: 30)
- **retryOnFailure**: Whether to retry failed requests (default: false)
- **retryCount**: Number of retry attempts (1-5, default: 3)

## Features

- Variable interpolation using `{{variable}}` syntax
- Automatic retry with exponential backoff
- Comprehensive error handling
- Connection testing support
- Supports all major HTTP methods

## Example Use Cases

1. **Notify external systems** when workflows complete
2. **Trigger CI/CD pipelines** after code processing
3. **Send data to analytics platforms**
4. **Integrate with Zapier/IFTTT/Make**
5. **Update project management tools**

## Development

To modify this plugin:

1. Edit `index.ts`
2. Compile with TypeScript: `tsc index.ts`
3. Test with the workflow engine
4. Submit a PR to share with the community!