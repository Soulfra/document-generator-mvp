import { PrismaClient } from '@prisma/client';
import { execSync } from 'child_process';
import { randomUUID } from 'crypto';

export interface TestDatabaseConfig {
  resetBetweenTests?: boolean;
  seedData?: boolean;
  isolateTransactions?: boolean;
}

export interface SeedData {
  users?: Array<{
    id?: string;
    email: string;
    name: string;
    profileId?: string;
  }>;
  jobs?: Array<{
    id?: string;
    status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
    inputFileUrl: string;
    originalFileName: string;
    fileSizeBytes: number;
    userId?: string;
  }>;
  documentation?: Array<{
    id?: string;
    jobId: string;
    userId: string;
    url: string;
    templates: string[];
    metadata?: any;
  }>;
  profiles?: Array<{
    id?: string;
    name: string;
    description: string;
    config: any;
  }>;
}

/**
 * Test database management utilities for E2E tests
 */
export class TestDatabase {
  private static instance: TestDatabase;
  private prisma: PrismaClient;
  private originalDatabaseUrl: string;
  private testDatabaseUrl: string;

  constructor() {
    this.originalDatabaseUrl = process.env.DATABASE_URL || '';
    this.testDatabaseUrl = this.generateTestDatabaseUrl();
    
    // Override DATABASE_URL for test environment
    process.env.DATABASE_URL = this.testDatabaseUrl;
    
    this.prisma = new PrismaClient({
      datasources: {
        db: {
          url: this.testDatabaseUrl,
        },
      },
    });
  }

  static getInstance(): TestDatabase {
    if (!TestDatabase.instance) {
      TestDatabase.instance = new TestDatabase();
    }
    return TestDatabase.instance;
  }

  /**
   * Generate a unique test database URL
   */
  private generateTestDatabaseUrl(): string {
    const baseUrl = this.originalDatabaseUrl || 'postgresql://postgres:password@localhost:5432/';
    const testDbName = `test_finishthisidea_${randomUUID().replace(/-/g, '').substring(0, 8)}`;
    
    // Parse the original URL and replace database name
    const url = new URL(baseUrl);
    url.pathname = `/${testDbName}`;
    
    return url.toString();
  }

  /**
   * Set up test database (create, migrate, seed)
   */
  async setup(config: TestDatabaseConfig = {}): Promise<void> {
    try {
      // Create test database
      await this.createDatabase();
      
      // Run migrations
      await this.runMigrations();
      
      // Seed data if requested
      if (config.seedData) {
        await this.seedDatabase();
      }
      
      console.log(`✅ Test database setup complete: ${this.testDatabaseUrl}`);
    } catch (error) {
      console.error('❌ Failed to setup test database:', error);
      throw error;
    }
  }

  /**
   * Tear down test database
   */
  async teardown(): Promise<void> {
    try {
      await this.prisma.$disconnect();
      await this.dropDatabase();
      
      // Restore original DATABASE_URL
      process.env.DATABASE_URL = this.originalDatabaseUrl;
      
      console.log('✅ Test database teardown complete');
    } catch (error) {
      console.error('❌ Failed to teardown test database:', error);
      throw error;
    }
  }

  /**
   * Reset database to clean state (truncate all tables)
   */
  async reset(): Promise<void> {
    try {
      // Disable foreign key checks
      await this.prisma.$executeRaw`SET FOREIGN_KEY_CHECKS = 0;`;
      
      // Get all table names
      const tables = await this.prisma.$queryRaw<Array<{ tablename: string }>>`
        SELECT tablename FROM pg_tables WHERE schemaname = 'public';
      `;
      
      // Truncate all tables
      for (const { tablename } of tables) {
        if (tablename !== '_prisma_migrations') {
          await this.prisma.$executeRawUnsafe(`TRUNCATE TABLE "${tablename}" CASCADE;`);
        }
      }
      
      // Re-enable foreign key checks
      await this.prisma.$executeRaw`SET FOREIGN_KEY_CHECKS = 1;`;
      
    } catch (error) {
      console.error('Failed to reset test database:', error);
      throw error;
    }
  }

  /**
   * Create the test database
   */
  private async createDatabase(): Promise<void> {
    const url = new URL(this.testDatabaseUrl);
    const dbName = url.pathname.substring(1);
    
    // Connect to postgres database to create test database
    const adminUrl = `${url.protocol}//${url.username}:${url.password}@${url.host}/postgres`;
    
    try {
      const adminPrisma = new PrismaClient({
        datasources: {
          db: { url: adminUrl },
        },
      });
      
      await adminPrisma.$executeRawUnsafe(`CREATE DATABASE "${dbName}";`);
      await adminPrisma.$disconnect();
    } catch (error) {
      // Database might already exist
      if (!error.message.includes('already exists')) {
        throw error;
      }
    }
  }

  /**
   * Drop the test database
   */
  private async dropDatabase(): Promise<void> {
    const url = new URL(this.testDatabaseUrl);
    const dbName = url.pathname.substring(1);
    
    // Connect to postgres database to drop test database
    const adminUrl = `${url.protocol}//${url.username}:${url.password}@${url.host}/postgres`;
    
    try {
      const adminPrisma = new PrismaClient({
        datasources: {
          db: { url: adminUrl },
        },
      });
      
      // Terminate connections to the test database
      await adminPrisma.$executeRawUnsafe(`
        SELECT pg_terminate_backend(pid)
        FROM pg_stat_activity
        WHERE datname = '${dbName}' AND pid <> pg_backend_pid();
      `);
      
      await adminPrisma.$executeRawUnsafe(`DROP DATABASE IF EXISTS "${dbName}";`);
      await adminPrisma.$disconnect();
    } catch (error) {
      console.warn('Warning: Could not drop test database:', error.message);
    }
  }

  /**
   * Run database migrations
   */
  private async runMigrations(): Promise<void> {
    try {
      // Use Prisma CLI to deploy migrations
      execSync('npx prisma migrate deploy', {
        env: { ...process.env, DATABASE_URL: this.testDatabaseUrl },
        stdio: 'pipe',
      });
    } catch (error) {
      console.error('Migration failed:', error.toString());
      throw new Error(`Failed to run migrations: ${error.message}`);
    }
  }

  /**
   * Seed database with test data
   */
  async seedDatabase(customData?: SeedData): Promise<SeedData> {
    const seedData: SeedData = customData || this.getDefaultSeedData();
    
    try {
      // Seed profiles first (no dependencies)
      if (seedData.profiles) {
        for (const profile of seedData.profiles) {
          await this.prisma.profile.create({
            data: {
              id: profile.id || randomUUID(),
              name: profile.name,
              description: profile.description,
              config: profile.config,
            },
          });
        }
      }

      // Seed users
      if (seedData.users) {
        for (const user of seedData.users) {
          await this.prisma.user.create({
            data: {
              id: user.id || randomUUID(),
              email: user.email,
              name: user.name,
              profileId: user.profileId,
            },
          });
        }
      }

      // Seed jobs
      if (seedData.jobs) {
        for (const job of seedData.jobs) {
          await this.prisma.job.create({
            data: {
              id: job.id || randomUUID(),
              status: job.status,
              inputFileUrl: job.inputFileUrl,
              originalFileName: job.originalFileName,
              fileSizeBytes: job.fileSizeBytes,
              userId: job.userId,
              createdAt: new Date(),
              updatedAt: new Date(),
            },
          });
        }
      }

      // Seed documentation
      if (seedData.documentation) {
        for (const doc of seedData.documentation) {
          await this.prisma.documentation.create({
            data: {
              id: doc.id || randomUUID(),
              jobId: doc.jobId,
              userId: doc.userId,
              url: doc.url,
              templates: doc.templates,
              metadata: doc.metadata || {},
              createdAt: new Date(),
              updatedAt: new Date(),
            },
          });
        }
      }

      return seedData;
    } catch (error) {
      console.error('Failed to seed database:', error);
      throw error;
    }
  }

  /**
   * Get default seed data for tests
   */
  private getDefaultSeedData(): SeedData {
    const profileId = randomUUID();
    const userId = randomUUID();
    const jobId = randomUUID();

    return {
      profiles: [
        {
          id: profileId,
          name: 'React TypeScript',
          description: 'Modern React with TypeScript',
          config: {
            language: 'typescript',
            framework: 'react',
            patterns: ['hooks', 'functional-components'],
          },
        },
        {
          id: randomUUID(),
          name: 'Node.js Express',
          description: 'Node.js API with Express',
          config: {
            language: 'javascript',
            framework: 'express',
            patterns: ['rest-api', 'middleware'],
          },
        },
      ],
      users: [
        {
          id: userId,
          email: 'test@example.com',
          name: 'Test User',
          profileId,
        },
        {
          id: randomUUID(),
          email: 'admin@example.com',
          name: 'Admin User',
        },
      ],
      jobs: [
        {
          id: jobId,
          status: 'COMPLETED',
          inputFileUrl: 'https://test-bucket.s3.amazonaws.com/input.zip',
          originalFileName: 'test-project.zip',
          fileSizeBytes: 1024000,
          userId,
        },
        {
          id: randomUUID(),
          status: 'PENDING',
          inputFileUrl: 'https://test-bucket.s3.amazonaws.com/pending.zip',
          originalFileName: 'pending-project.zip',
          fileSizeBytes: 512000,
          userId,
        },
      ],
      documentation: [
        {
          id: randomUUID(),
          jobId,
          userId,
          url: 'https://test-bucket.s3.amazonaws.com/docs.zip',
          templates: ['executive-summary', 'api-contract'],
          metadata: {
            quality: { overall: 85, completeness: 90, accuracy: 80 },
            generatedAt: new Date().toISOString(),
            tokensUsed: 1500,
          },
        },
      ],
    };
  }

  /**
   * Get Prisma client instance
   */
  getPrisma(): PrismaClient {
    return this.prisma;
  }

  /**
   * Execute within a transaction
   */
  async withTransaction<T>(
    fn: (prisma: PrismaClient) => Promise<T>
  ): Promise<T> {
    return this.prisma.$transaction(fn);
  }

  /**
   * Get database statistics for verification
   */
  async getStats(): Promise<{
    userCount: number;
    jobCount: number;
    documentationCount: number;
    profileCount: number;
  }> {
    const [userCount, jobCount, documentationCount, profileCount] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.job.count(),
      this.prisma.documentation.count(),
      this.prisma.profile.count(),
    ]);

    return {
      userCount,
      jobCount,
      documentationCount,
      profileCount,
    };
  }

  /**
   * Wait for database connection to be ready
   */
  async waitForConnection(maxAttempts = 10, delayMs = 1000): Promise<void> {
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        await this.prisma.$queryRaw`SELECT 1`;
        return;
      } catch (error) {
        if (attempt === maxAttempts) {
          throw new Error(`Database not ready after ${maxAttempts} attempts: ${error.message}`);
        }
        
        console.log(`Database connection attempt ${attempt}/${maxAttempts} failed, retrying in ${delayMs}ms...`);
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
    }
  }

  /**
   * Clean up test artifacts
   */
  async cleanup(): Promise<void> {
    try {
      // Delete test files from database records
      await this.prisma.documentation.deleteMany({
        where: {
          url: {
            contains: 'test-bucket',
          },
        },
      });

      await this.prisma.job.deleteMany({
        where: {
          originalFileName: {
            contains: 'test',
          },
        },
      });

      await this.prisma.user.deleteMany({
        where: {
          email: {
            contains: 'test',
          },
        },
      });

      await this.prisma.profile.deleteMany({
        where: {
          name: {
            contains: 'Test',
          },
        },
      });
    } catch (error) {
      console.warn('Warning: Could not clean up test artifacts:', error.message);
    }
  }
}

/**
 * Global test database instance for use in tests
 */
export const testDb = TestDatabase.getInstance();