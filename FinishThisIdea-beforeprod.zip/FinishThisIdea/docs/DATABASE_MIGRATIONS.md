---
title: "Database Migrations Guide"
description: "Production-ready database migration workflow using Prisma for safe schema changes and rollbacks"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Database Migrations Guide

This document outlines the production-ready database migration workflow for FinishThisIdea using Prisma migrations.

## Overview

We use **Prisma migrations** instead of `db push` for production-ready database management. This ensures:
- Version-controlled schema changes
- Safe rollback capabilities  
- Consistent database state across environments
- Audit trail of all schema modifications

## Migration Commands

### Development Workflow

```bash
# Create a new migration after schema changes
npm run db:migrate:dev

# Apply pending migrations
npm run db:migrate

# Reset database (WARNING: destroys all data)
npm run db:migrate:reset

# Check migration status
npm run db:migrate:status
```

### Production Workflow

```bash
# Apply migrations in production (safe)
npm run db:migrate

# Seed production data
npm run db:seed

# Full setup (migrate + seed)
npm run db:setup
```

## Schema Change Process

### 1. Development Changes

1. **Modify** `prisma/schema.prisma`
2. **Create migration**:
   ```bash
   npm run db:migrate:dev
   ```
3. **Review** generated SQL in `prisma/migrations/`
4. **Test** migration locally
5. **Commit** migration files to version control

### 2. Production Deployment

1. **Build** application with new schema
2. **Deploy** application code
3. **Run migrations**:
   ```bash
   npm run db:migrate
   ```
4. **Verify** database state

## Migration Structure

```
prisma/
├── migrations/
│   ├── migration_lock.toml          # Provider lock file
│   ├── 20240628000000_initial/
│   │   └── migration.sql           # Initial schema
│   └── 20240628100000_add_feature/
│       └── migration.sql           # Feature addition
└── schema.prisma                   # Current schema
```

## Safety Guidelines

### ✅ Safe Migrations
- Adding new tables
- Adding new optional columns
- Adding indexes
- Creating new enums with new values
- Renaming columns (with proper migration)

### ⚠️ Risky Migrations
- Dropping columns with data
- Changing column types
- Adding NOT NULL constraints to existing columns
- Removing enum values

### 🚨 Dangerous Operations
- Dropping tables with data
- Removing foreign key constraints
- Major schema restructuring

## Rollback Strategy

### Automatic Rollback
Prisma doesn't support automatic rollbacks. Plan rollbacks manually:

1. **Create reverse migration**:
   ```sql
   -- If you added a column, remove it
   ALTER TABLE users DROP COLUMN new_column;
   ```

2. **Apply via direct SQL** (emergency only):
   ```bash
   psql $DATABASE_URL -f rollback.sql
   ```

### Application-Level Rollback
1. **Deploy** previous application version
2. **Ensure** schema compatibility
3. **Monitor** for issues

## Environment Configuration

### Development
```env
DATABASE_URL="postgresql://user:password@localhost:5432/finishthisidea_dev"
```

### Testing
```env
DATABASE_URL="postgresql://user:password@localhost:5432/finishthisidea_test"
```

### Production
```env
DATABASE_URL="postgresql://user:password@prod-host:5432/finishthisidea_prod?connection_limit=20"
```

## Seeding Strategy

### Development Seeds
- Default context profiles
- Test users and data
- Sample jobs and payments

### Production Seeds
- Default context profiles only
- System configuration
- No test data

### Custom Seeding
```javascript
// scripts/seed.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function customSeed() {
  // Your seeding logic
}
```

## CI/CD Integration

### GitHub Actions
```yaml
- name: Setup database
  run: |
    npx prisma generate
    npx prisma migrate deploy
    npm run db:seed
```

### Docker Setup
```dockerfile
# Run migrations on container start
CMD ["sh", "-c", "npm run db:migrate && npm start"]
```

## Monitoring & Alerts

### Migration Monitoring
- Track migration execution time
- Alert on migration failures
- Monitor database performance post-migration

### Health Checks
```bash
# Verify database connectivity
npm run db:migrate:status

# Check schema consistency
npx prisma validate
```

## Troubleshooting

### Migration Fails
```bash
# Check current state
npm run db:migrate:status

# Reset and retry (development only)
npm run db:migrate:reset
```

### Schema Drift
```bash
# Compare schema with database
npx prisma db pull
npx prisma format
```

### Recovery
```bash
# Restore from backup
pg_restore -d $DATABASE_URL backup.sql

# Re-run migrations
npm run db:migrate
```

## Best Practices

1. **Always backup** before major migrations
2. **Test migrations** in staging environment
3. **Review generated SQL** before applying
4. **Plan rollback strategy** for risky changes
5. **Monitor performance** after schema changes
6. **Version control** all migration files
7. **Use descriptive** migration names
8. **Coordinate** with team on schema changes

## Migration Checklist

### Pre-Migration
- [ ] Schema changes reviewed
- [ ] Migration tested locally
- [ ] Rollback plan documented
- [ ] Team notified of changes
- [ ] Backup created

### Migration
- [ ] Application deployment paused
- [ ] Migration applied successfully
- [ ] Database state verified
- [ ] Application deployment resumed
- [ ] Health checks passing

### Post-Migration
- [ ] Performance monitoring active
- [ ] Error rates normal
- [ ] Rollback plan updated
- [ ] Documentation updated