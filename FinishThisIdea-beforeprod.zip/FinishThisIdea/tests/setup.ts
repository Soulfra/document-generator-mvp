// Jest setup file for FinishThisIdea tests

// Set test environment variables
process.env.NODE_ENV = 'test';
process.env.DATABASE_URL = 'postgresql://postgres:password@localhost:5432/finishthisidea_test';
process.env.JWT_SECRET = 'test-secret-key-for-testing-only';
process.env.ENCRYPTION_KEY = 'test-encryption-key-32-chars-long';
process.env.ENABLE_DOCUMENTATION_GENERATION = 'true';
process.env.REDIS_URL = 'redis://localhost:6379/15'; // Use different Redis DB for tests

// Mock external services for testing
jest.mock('../src/utils/logger', () => ({
  logger: {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    debug: jest.fn(),
  },
}));

// Mock S3 uploads
jest.mock('../src/utils/storage', () => ({
  uploadToS3: jest.fn().mockResolvedValue('https://test-bucket.s3.amazonaws.com/test-file.zip'),
  downloadFromS3: jest.fn().mockResolvedValue(Buffer.from('test file content')),
}));

// Mock LLM router
jest.mock('../src/llm/router', () => ({
  llmRouter: {
    initialize: jest.fn().mockResolvedValue(undefined),
    route: jest.fn().mockResolvedValue({
      success: true,
      data: 'Mock AI response',
      provider: 'ollama',
      confidence: 0.8,
      cost: 0.01,
      duration: 100,
    }),
  },
}));

// Mock Redis for tests
jest.mock('ioredis', () => {
  return jest.fn().mockImplementation(() => ({
    get: jest.fn().mockResolvedValue(null),
    set: jest.fn().mockResolvedValue('OK'),
    del: jest.fn().mockResolvedValue(1),
    incr: jest.fn().mockResolvedValue(1),
    expire: jest.fn().mockResolvedValue(1),
    disconnect: jest.fn().mockResolvedValue(undefined),
    on: jest.fn(),
    status: 'ready',
  }));
});

// Mock Bull queues for tests
jest.mock('bull', () => {
  return jest.fn().mockImplementation(() => ({
    add: jest.fn().mockResolvedValue({ id: 'test-job-id' }),
    process: jest.fn(),
    close: jest.fn().mockResolvedValue(undefined),
    on: jest.fn(),
  }));
});

// Mock cleanup queue specifically
jest.mock('../src/jobs/cleanup.queue', () => ({
  cleanupQueue: {
    add: jest.fn().mockResolvedValue({ id: 'cleanup-job-id' }),
    process: jest.fn(),
    close: jest.fn().mockResolvedValue(undefined),
    on: jest.fn(),
  },
}));

// Increase timeout for integration tests
jest.setTimeout(30000);