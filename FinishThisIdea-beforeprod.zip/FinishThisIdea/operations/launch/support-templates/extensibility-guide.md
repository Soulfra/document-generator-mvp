# Platform Extensibility Guide: Adding New Templates

This guide explains how to add a new template project to the FinishThisIdea platform.

---

## 1. Create Your Project Template
- Fork or copy an existing template repo
- Update project name, description, and branding
- Add required features (automation, onboarding, docs)

## 2. Integrate with Shared Services
- Set up shared authentication (SSO/JWT)
- Configure analytics and monitoring
- Connect to payment and notification services
- Use the design system and component library

## 3. Add Automation & Workflows
- Include onboarding, deployment, and notification scripts
- Add workflow templates to the library (YAML/JSON/Markdown)
- Document how to customize automations for your template

## 4. Document Everything
- Write onboarding and support guides
- Add API docs (OpenAPI/Swagger)
- Update the integration plan and launch playbook

## 5. Submit for Review
- Follow the template contribution guide
- Complete the review checklist
- Open a pull request or submit via the platform UI

---

*Update this guide as the platform and template system evolve.* 