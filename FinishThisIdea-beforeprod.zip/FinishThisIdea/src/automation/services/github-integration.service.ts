import { Octokit } from '@octokit/rest';
import { logger } from '../../utils/logger';

export interface GitHubRepository {
  owner: string;
  repo: string;
}

export interface GitHubIssue {
  title: string;
  body?: string;
  assignees?: string[];
  labels?: string[];
  milestone?: number;
}

export interface GitHubPullRequest {
  title: string;
  body?: string;
  head: string;
  base: string;
  assignees?: string[];
  reviewers?: string[];
  labels?: string[];
}

export interface GitHubDeployment {
  ref: string;
  environment: string;
  description?: string;
  payload?: Record<string, any>;
}

export interface GitHubWorkflowDispatch {
  workflow_id: string;
  ref: string;
  inputs?: Record<string, any>;
}

export class GitHubIntegrationService {
  private octokit: Octokit | null = null;
  private isEnabled = false;
  private token: string | null = null;

  constructor() {
    this.initialize();
  }

  /**
   * Initialize GitHub integration
   */
  private initialize(): void {
    this.token = process.env.GITHUB_TOKEN;
    if (!this.token) {
      logger.warn('GITHUB_TOKEN not found in environment variables');
      return;
    }

    try {
      this.octokit = new Octokit({
        auth: this.token,
        userAgent: 'FinishThisIdea/1.0.0',
      });
      this.isEnabled = true;
      logger.info('GitHub integration initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize GitHub client', { error });
    }
  }

  /**
   * Create an issue
   */
  public async createIssue(
    repository: GitHubRepository,
    issue: GitHubIssue
  ): Promise<any> {
    if (!this.isEnabled || !this.octokit) {
      throw new Error('GitHub integration not enabled or configured');
    }

    try {
      const result = await this.octokit.rest.issues.create({
        owner: repository.owner,
        repo: repository.repo,
        title: issue.title,
        body: issue.body,
        assignees: issue.assignees,
        labels: issue.labels,
        milestone: issue.milestone,
      });

      logger.info('GitHub issue created successfully', {
        repository: `${repository.owner}/${repository.repo}`,
        issueNumber: result.data.number,
        title: issue.title,
      });

      return result.data;
    } catch (error) {
      logger.error('Failed to create GitHub issue', { error, repository, issue });
      throw error;
    }
  }

  /**
   * Create a pull request
   */
  public async createPullRequest(
    repository: GitHubRepository,
    pullRequest: GitHubPullRequest
  ): Promise<any> {
    if (!this.isEnabled || !this.octokit) {
      throw new Error('GitHub integration not enabled or configured');
    }

    try {
      const result = await this.octokit.rest.pulls.create({
        owner: repository.owner,
        repo: repository.repo,
        title: pullRequest.title,
        body: pullRequest.body,
        head: pullRequest.head,
        base: pullRequest.base,
      });

      // Add assignees if specified
      if (pullRequest.assignees && pullRequest.assignees.length > 0) {
        await this.octokit.rest.issues.addAssignees({
          owner: repository.owner,
          repo: repository.repo,
          issue_number: result.data.number,
          assignees: pullRequest.assignees,
        });
      }

      // Request reviews if specified
      if (pullRequest.reviewers && pullRequest.reviewers.length > 0) {
        await this.octokit.rest.pulls.requestReviewers({
          owner: repository.owner,
          repo: repository.repo,
          pull_number: result.data.number,
          reviewers: pullRequest.reviewers,
        });
      }

      // Add labels if specified
      if (pullRequest.labels && pullRequest.labels.length > 0) {
        await this.octokit.rest.issues.addLabels({
          owner: repository.owner,
          repo: repository.repo,
          issue_number: result.data.number,
          labels: pullRequest.labels,
        });
      }

      logger.info('GitHub pull request created successfully', {
        repository: `${repository.owner}/${repository.repo}`,
        pullNumber: result.data.number,
        title: pullRequest.title,
      });

      return result.data;
    } catch (error) {
      logger.error('Failed to create GitHub pull request', { error, repository, pullRequest });
      throw error;
    }
  }

  /**
   * Create a deployment
   */
  public async createDeployment(
    repository: GitHubRepository,
    deployment: GitHubDeployment
  ): Promise<any> {
    if (!this.isEnabled || !this.octokit) {
      throw new Error('GitHub integration not enabled or configured');
    }

    try {
      const result = await this.octokit.rest.repos.createDeployment({
        owner: repository.owner,
        repo: repository.repo,
        ref: deployment.ref,
        environment: deployment.environment,
        description: deployment.description,
        payload: deployment.payload ? JSON.stringify(deployment.payload) : undefined,
        auto_merge: false,
        required_contexts: [],
      });

      logger.info('GitHub deployment created successfully', {
        repository: `${repository.owner}/${repository.repo}`,
        deploymentId: result.data.id,
        environment: deployment.environment,
      });

      return result.data;
    } catch (error) {
      logger.error('Failed to create GitHub deployment', { error, repository, deployment });
      throw error;
    }
  }

  /**
   * Update deployment status
   */
  public async updateDeploymentStatus(
    repository: GitHubRepository,
    deploymentId: number,
    state: 'pending' | 'success' | 'error' | 'failure' | 'inactive',
    description?: string,
    environmentUrl?: string
  ): Promise<any> {
    if (!this.isEnabled || !this.octokit) {
      throw new Error('GitHub integration not enabled or configured');
    }

    try {
      const result = await this.octokit.rest.repos.createDeploymentStatus({
        owner: repository.owner,
        repo: repository.repo,
        deployment_id: deploymentId,
        state,
        description,
        environment_url: environmentUrl,
      });

      logger.info('GitHub deployment status updated', {
        repository: `${repository.owner}/${repository.repo}`,
        deploymentId,
        state,
      });

      return result.data;
    } catch (error) {
      logger.error('Failed to update GitHub deployment status', { 
        error, 
        repository, 
        deploymentId, 
        state 
      });
      throw error;
    }
  }

  /**
   * Trigger workflow dispatch
   */
  public async triggerWorkflow(
    repository: GitHubRepository,
    workflow: GitHubWorkflowDispatch
  ): Promise<any> {
    if (!this.isEnabled || !this.octokit) {
      throw new Error('GitHub integration not enabled or configured');
    }

    try {
      const result = await this.octokit.rest.actions.createWorkflowDispatch({
        owner: repository.owner,
        repo: repository.repo,
        workflow_id: workflow.workflow_id,
        ref: workflow.ref,
        inputs: workflow.inputs,
      });

      logger.info('GitHub workflow triggered successfully', {
        repository: `${repository.owner}/${repository.repo}`,
        workflowId: workflow.workflow_id,
        ref: workflow.ref,
      });

      return { triggered: true, workflow_id: workflow.workflow_id };
    } catch (error) {
      logger.error('Failed to trigger GitHub workflow', { error, repository, workflow });
      throw error;
    }
  }

  /**
   * Get repository information
   */
  public async getRepository(repository: GitHubRepository): Promise<any> {
    if (!this.isEnabled || !this.octokit) {
      throw new Error('GitHub integration not enabled or configured');
    }

    try {
      const result = await this.octokit.rest.repos.get({
        owner: repository.owner,
        repo: repository.repo,
      });

      return result.data;
    } catch (error) {
      logger.error('Failed to get GitHub repository', { error, repository });
      throw error;
    }
  }

  /**
   * Get workflow runs
   */
  public async getWorkflowRuns(
    repository: GitHubRepository,
    workflowId?: string,
    status?: 'queued' | 'in_progress' | 'completed'
  ): Promise<any> {
    if (!this.isEnabled || !this.octokit) {
      throw new Error('GitHub integration not enabled or configured');
    }

    try {
      if (workflowId) {
        const result = await this.octokit.rest.actions.listWorkflowRuns({
          owner: repository.owner,
          repo: repository.repo,
          workflow_id: workflowId,
          status,
        });
        return result.data;
      } else {
        const result = await this.octokit.rest.actions.listWorkflowRunsForRepo({
          owner: repository.owner,
          repo: repository.repo,
          status,
        });
        return result.data;
      }
    } catch (error) {
      logger.error('Failed to get GitHub workflow runs', { error, repository, workflowId });
      throw error;
    }
  }

  /**
   * Add comment to issue or PR
   */
  public async addComment(
    repository: GitHubRepository,
    issueNumber: number,
    body: string
  ): Promise<any> {
    if (!this.isEnabled || !this.octokit) {
      throw new Error('GitHub integration not enabled or configured');
    }

    try {
      const result = await this.octokit.rest.issues.createComment({
        owner: repository.owner,
        repo: repository.repo,
        issue_number: issueNumber,
        body,
      });

      logger.info('GitHub comment added successfully', {
        repository: `${repository.owner}/${repository.repo}`,
        issueNumber,
      });

      return result.data;
    } catch (error) {
      logger.error('Failed to add GitHub comment', { error, repository, issueNumber });
      throw error;
    }
  }

  /**
   * Test GitHub connection
   */
  public async testConnection(): Promise<boolean> {
    if (!this.isEnabled || !this.octokit) {
      return false;
    }

    try {
      const result = await this.octokit.rest.users.getAuthenticated();
      logger.info('GitHub connection test successful', {
        user: result.data.login,
        name: result.data.name,
      });
      return true;
    } catch (error) {
      logger.error('GitHub connection test failed', { error });
      return false;
    }
  }

  /**
   * Check if GitHub integration is enabled
   */
  public isIntegrationEnabled(): boolean {
    return this.isEnabled;
  }

  /**
   * Get integration status
   */
  public getStatus(): {
    enabled: boolean;
    configured: boolean;
    token: boolean;
  } {
    return {
      enabled: this.isEnabled,
      configured: this.isEnabled,
      token: !!this.token,
    };
  }

  /**
   * Parse repository string (owner/repo) into GitHubRepository
   */
  public parseRepository(repoString: string): GitHubRepository {
    const parts = repoString.split('/');
    if (parts.length !== 2) {
      throw new Error(`Invalid repository format: ${repoString}. Expected: owner/repo`);
    }
    return { owner: parts[0], repo: parts[1] };
  }
}

// Export singleton instance
export const gitHubIntegration = new GitHubIntegrationService();