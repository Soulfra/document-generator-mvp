---
title: "Plugin Development Guide"
description: "Comprehensive guide for creating custom workflow step plugins and extending FinishThisIdea functionality"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Plugin Development Guide

This guide explains how to create custom workflow step plugins for FinishThisIdea.

## Overview

The plugin system allows you to extend the workflow engine with custom step types without modifying the core codebase. Plugins are loaded dynamically and can be distributed as npm packages or local modules.

## Plugin Architecture

### Base Classes and Interfaces

All plugins must extend the `BasePlugin` class and implement the `WorkflowStepPlugin` interface:

```typescript
import { BasePlugin } from '@finishthisidea/plugin-sdk';
import { PluginMetadata, PluginField, PluginExecutionResult } from '@finishthisidea/plugin-sdk';

export class MyPlugin extends BasePlugin {
  metadata: PluginMetadata = { /* ... */ };
  fields: PluginField[] = [ /* ... */ ];
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    // Implementation
  }
}
```

## Creating a Plugin

### 1. Set Up Your Project

```bash
mkdir my-workflow-plugin
cd my-workflow-plugin
npm init -y
npm install --save-dev typescript @types/node
```

### 2. Define Plugin Metadata

```typescript
metadata: PluginMetadata = {
  id: 'my-plugin',              // Unique identifier
  name: 'My Custom Plugin',      // Display name
  version: '1.0.0',             // Semver version
  description: 'Description',    // Brief description
  author: 'Your Name',          // Author/organization
  icon: '🔧',                   // Emoji or icon class
  category: 'utility',          // Category for organization
  tags: ['custom', 'example'],  // Searchable tags
  requiredConfig: ['API_KEY'],  // Required env vars
  experimental: false,          // Mark as experimental
  minEngineVersion: '1.0.0'     // Minimum engine version
};
```

### 3. Define Plugin Fields

Fields define the configuration options for your plugin:

```typescript
fields: PluginField[] = [
  {
    name: 'apiUrl',
    label: 'API URL',
    type: 'text',
    required: true,
    placeholder: 'https://api.example.com',
    description: 'The API endpoint',
    validation: {
      pattern: '^https?://.+'
    }
  },
  {
    name: 'retries',
    label: 'Retry Count',
    type: 'number',
    required: false,
    default: 3,
    validation: {
      min: 1,
      max: 10
    }
  }
];
```

### Field Types

- **text**: Single line text input
- **textarea**: Multi-line text input
- **number**: Numeric input
- **select**: Dropdown selection
- **boolean**: Checkbox/toggle
- **json**: JSON object input
- **file**: File path input

### 4. Implement Execute Method

The `execute` method is called when your step runs:

```typescript
async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
  // Extract configuration from step
  const { apiUrl, retries = 3 } = step;
  
  try {
    // Use measureExecution helper for timing
    const { result, duration } = await this.measureExecution(async () => {
      // Your plugin logic here
      const response = await fetch(apiUrl);
      return await response.json();
    });
    
    // Log success
    this.logger.info(`Plugin executed successfully in ${duration}ms`);
    
    // Return success result
    return this.success(
      result,           // Data to store in context
      duration,         // Execution time
      ['Success message'] // Messages for UI
    );
    
  } catch (error) {
    // Log and return failure
    this.logger.error('Plugin execution failed:', error);
    return this.failure(`Error: ${error.message}`);
  }
}
```

### 5. Optional Methods

#### Validation

Override the `validate` method for custom validation:

```typescript
async validate(step: WorkflowStep): Promise<{ valid: boolean; errors?: string[] }> {
  const baseValidation = await super.validate(step);
  if (!baseValidation.valid) return baseValidation;
  
  // Custom validation
  const errors: string[] = [];
  
  if (step.apiUrl && !step.apiUrl.startsWith('https://')) {
    errors.push('API URL must use HTTPS');
  }
  
  return {
    valid: errors.length === 0,
    errors: errors.length > 0 ? errors : undefined
  };
}
```

#### Test Connection

Implement connection testing:

```typescript
async testConnection(config: Record<string, any>): Promise<{ success: boolean; message?: string }> {
  try {
    const response = await fetch(config.apiUrl + '/health');
    return {
      success: response.ok,
      message: response.ok ? 'Connection successful' : `API returned ${response.status}`
    };
  } catch (error) {
    return {
      success: false,
      message: `Connection failed: ${error.message}`
    };
  }
}
```

#### Lifecycle Hooks

```typescript
async onLoad(): Promise<void> {
  // Called when plugin is loaded
  await this.initializeConnections();
}

async onUnload(): Promise<void> {
  // Called when plugin is unloaded
  await this.cleanupResources();
}

async beforeWorkflowStart(context: WorkflowContext): Promise<void> {
  // Called before workflow execution
}

async afterWorkflowComplete(context: WorkflowContext): Promise<void> {
  // Called after workflow execution
}
```

## Best Practices

### 1. Error Handling

Always handle errors gracefully:

```typescript
try {
  // Plugin logic
} catch (error) {
  if (error.code === 'ECONNREFUSED') {
    return this.failure('Cannot connect to service');
  }
  return this.failure(`Unexpected error: ${error.message}`);
}
```

### 2. Logging

Use the built-in logger:

```typescript
this.logger.info('Processing started');
this.logger.warn('Rate limit approaching');
this.logger.error('Operation failed', { error });
```

### 3. Variable Interpolation

Support workflow variables:

```typescript
const url = step.url.replace(/\{\{(\w+)\}\}/g, (match, key) => {
  return context.variables[key] || match;
});
```

### 4. Performance

- Use `measureExecution` for timing
- Implement timeouts for external calls
- Consider caching for expensive operations

### 5. Security

- Validate all inputs
- Sanitize data before external calls
- Never log sensitive information
- Use environment variables for secrets

## Testing Your Plugin

### Unit Tests

```typescript
import { MyPlugin } from './index';

describe('MyPlugin', () => {
  let plugin: MyPlugin;
  
  beforeEach(() => {
    plugin = new MyPlugin();
  });
  
  test('should validate required fields', async () => {
    const result = await plugin.validate({
      name: 'test',
      type: 'my-plugin'
      // Missing required field
    });
    
    expect(result.valid).toBe(false);
    expect(result.errors).toContain("Required field 'apiUrl' is missing");
  });
  
  test('should execute successfully', async () => {
    const result = await plugin.execute(
      { name: 'test', type: 'my-plugin', apiUrl: 'https://api.example.com' },
      { variables: {}, workflowId: 'test-123' }
    );
    
    expect(result.success).toBe(true);
    expect(result.duration).toBeGreaterThan(0);
  });
});
```

### Integration Testing

Test with the workflow engine:

```yaml
name: test-my-plugin
steps:
  - name: Test my plugin
    type: my-plugin
    apiUrl: https://api.example.com
    retries: 3
```

## Distribution

### As NPM Package

1. Create `package.json`:

```json
{
  "name": "@myorg/workflow-plugin-example",
  "version": "1.0.0",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "keywords": ["finishthisidea", "workflow", "plugin"],
  "peerDependencies": {
    "@finishthisidea/plugin-sdk": "^1.0.0"
  }
}
```

2. Publish to npm:

```bash
npm publish
```

3. Users install and configure:

```bash
npm install @myorg/workflow-plugin-example
```

### As Local Plugin

1. Place in `plugins/` directory
2. Add to automation config:

```json
{
  "plugins": {
    "my-plugin": {
      "enabled": true,
      "config": {
        "defaultApiUrl": "https://api.example.com"
      }
    }
  }
}
```

## Advanced Topics

### Dynamic Fields

Implement `getDynamicFields` for conditional fields:

```typescript
async getDynamicFields(config: Record<string, any>): Promise<PluginField[]> {
  if (config.authType === 'oauth') {
    return [
      {
        name: 'clientId',
        label: 'Client ID',
        type: 'text',
        required: true
      }
    ];
  }
  return [];
}
```

### Custom UI Components

For the workflow builder UI, provide field hints:

```typescript
fields: PluginField[] = [
  {
    name: 'query',
    label: 'SQL Query',
    type: 'textarea',
    required: true,
    placeholder: 'SELECT * FROM users',
    description: 'SQL query to execute',
    // Custom UI hints
    uiHints: {
      syntax: 'sql',
      height: '200px'
    }
  }
];
```

### Plugin Dependencies

Handle plugin dependencies:

```typescript
constructor(config?: Record<string, any>) {
  super(config);
  
  // Load dependencies conditionally
  if (config?.enableCache) {
    this.cache = new CacheService(config.cacheConfig);
  }
}
```

## Examples

See the `plugins/example-webhook-plugin/` directory for a complete example implementation.

## Support

- Create issues for bugs or feature requests
- Join our Discord for plugin development discussions
- Check existing plugins for inspiration
- Contribute your plugins back to the community!

## Plugin Ideas

- **Database Query**: Execute SQL queries
- **API Transformer**: Transform data between APIs  
- **File Operations**: Advanced file manipulation
- **Cloud Services**: AWS, Azure, GCP integrations
- **ML/AI**: Integrate AI services
- **Monitoring**: Send metrics to monitoring platforms
- **Custom Notifications**: SMS, WhatsApp, etc.
- **Data Validation**: Complex validation rules
- **ETL Operations**: Extract, transform, load data
- **Security Scanning**: Run security checks