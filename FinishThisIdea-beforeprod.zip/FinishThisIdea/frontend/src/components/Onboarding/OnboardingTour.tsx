import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, ChevronLeft, Upload, FileText, Zap, Check } from 'lucide-react';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface TourStep {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  selector?: string;
  position?: 'top' | 'bottom' | 'left' | 'right';
}

const TOUR_STEPS: TourStep[] = [
  {
    id: 'welcome',
    title: 'Welcome to FinishThisIdea!',
    description: 'Let me show you how to transform your messy code into professional documentation in just a few clicks.',
    icon: Zap,
  },
  {
    id: 'upload',
    title: 'Upload Your Code',
    description: 'Drag and drop your project files or ZIP archive here. We support all major programming languages.',
    icon: Upload,
    selector: '.drop-zone',
    position: 'bottom',
  },
  {
    id: 'profile',
    title: 'Choose Your Profile',
    description: 'Select a context profile that matches your project type for better documentation results.',
    icon: FileText,
    selector: '.profile-selector',
    position: 'bottom',
  },
  {
    id: 'templates',
    title: 'Select Documentation',
    description: 'Choose which types of documentation you want generated. Premium users get access to advanced templates!',
    icon: FileText,
    selector: '.documentation-options',
    position: 'top',
  },
  {
    id: 'complete',
    title: "You're All Set!",
    description: 'Upload your first project and watch the magic happen. Your documentation will be ready in minutes!',
    icon: Check,
  },
];

interface OnboardingTourProps {
  onComplete?: () => void;
}

export const OnboardingTour: React.FC<OnboardingTourProps> = ({ onComplete }) => {
  const [hasSeenTour, setHasSeenTour] = useLocalStorage('hasSeenOnboarding', false);
  const [isVisible, setIsVisible] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [highlightElement, setHighlightElement] = useState<HTMLElement | null>(null);

  useEffect(() => {
    // Show tour for new users
    if (!hasSeenTour) {
      setTimeout(() => setIsVisible(true), 1000);
    }
  }, [hasSeenTour]);

  useEffect(() => {
    // Highlight current step element
    const step = TOUR_STEPS[currentStep];
    if (step.selector) {
      const element = document.querySelector(step.selector) as HTMLElement;
      setHighlightElement(element);
    } else {
      setHighlightElement(null);
    }
  }, [currentStep]);

  const handleNext = () => {
    if (currentStep < TOUR_STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSkip = () => {
    setIsVisible(false);
    setHasSeenTour(true);
    onComplete?.();
  };

  const handleComplete = () => {
    setIsVisible(false);
    setHasSeenTour(true);
    onComplete?.();
    
    // Show success message
    const event = new CustomEvent('showNotification', {
      detail: {
        type: 'success',
        message: 'Welcome aboard! Ready to transform your code?',
      },
    });
    window.dispatchEvent(event);
  };

  if (!isVisible) return null;

  const currentStepData = TOUR_STEPS[currentStep];
  const Icon = currentStepData.icon;

  return (
    <>
      {/* Backdrop */}
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-75 z-[9998]"
          onClick={handleSkip}
        />
      </AnimatePresence>

      {/* Highlight Box */}
      {highlightElement && (
        <motion.div
          className="fixed z-[9999] pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          style={{
            top: highlightElement.offsetTop - 8,
            left: highlightElement.offsetLeft - 8,
            width: highlightElement.offsetWidth + 16,
            height: highlightElement.offsetHeight + 16,
            border: '3px solid #6366f1',
            borderRadius: '12px',
            boxShadow: '0 0 0 4px rgba(99, 102, 241, 0.3)',
          }}
        />
      )}

      {/* Tour Modal */}
      <motion.div
        className="fixed z-[10000]"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        style={{
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          ...(highlightElement && currentStepData.position && {
            top: currentStepData.position === 'bottom' 
              ? highlightElement.offsetTop + highlightElement.offsetHeight + 20
              : currentStepData.position === 'top'
              ? highlightElement.offsetTop - 200
              : '50%',
            left: currentStepData.position === 'right'
              ? highlightElement.offsetLeft + highlightElement.offsetWidth + 20
              : currentStepData.position === 'left'
              ? highlightElement.offsetLeft - 400
              : '50%',
            transform: highlightElement ? 'none' : 'translate(-50%, -50%)',
          }),
        }}
      >
        <div className="bg-gray-900 rounded-xl shadow-2xl p-6 max-w-md w-full">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary-500 rounded-full flex items-center justify-center">
                <Icon className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white">{currentStepData.title}</h3>
            </div>
            <button
              onClick={handleSkip}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <p className="text-gray-300 mb-6">{currentStepData.description}</p>

          {/* Progress */}
          <div className="flex items-center justify-center space-x-2 mb-6">
            {TOUR_STEPS.map((_, index) => (
              <div
                key={index}
                className={`h-2 rounded-full transition-all ${
                  index === currentStep
                    ? 'w-8 bg-primary-500'
                    : index < currentStep
                    ? 'w-2 bg-primary-600'
                    : 'w-2 bg-gray-600'
                }`}
              />
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between">
            <button
              onClick={handleSkip}
              className="text-sm text-gray-400 hover:text-white transition-colors"
            >
              Skip tour
            </button>
            
            <div className="flex items-center space-x-3">
              {currentStep > 0 && (
                <button
                  onClick={handlePrevious}
                  className="flex items-center space-x-1 px-4 py-2 text-gray-300 hover:text-white transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>
              )}
              
              <button
                onClick={handleNext}
                className="flex items-center space-x-1 px-4 py-2 bg-primary-600 hover:bg-primary-700 
                         text-white rounded-lg transition-colors"
              >
                <span>{currentStep === TOUR_STEPS.length - 1 ? 'Get Started' : 'Next'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
};

// Onboarding Checklist Component
interface OnboardingChecklistProps {
  userId: string;
}

export const OnboardingChecklist: React.FC<OnboardingChecklistProps> = ({ userId }) => {
  const [checklist, setChecklist] = useLocalStorage(`onboarding-checklist-${userId}`, {
    hasUploadedFile: false,
    hasSelectedProfile: false,
    hasGeneratedDocs: false,
    hasUpgraded: false,
  });

  const [isExpanded, setIsExpanded] = useState(!checklist.hasGeneratedDocs);

  const tasks = [
    {
      id: 'upload',
      label: 'Upload your first project',
      completed: checklist.hasUploadedFile,
      icon: Upload,
    },
    {
      id: 'profile',
      label: 'Select a context profile',
      completed: checklist.hasSelectedProfile,
      icon: FileText,
    },
    {
      id: 'generate',
      label: 'Generate documentation',
      completed: checklist.hasGeneratedDocs,
      icon: Zap,
    },
    {
      id: 'upgrade',
      label: 'Unlock premium features',
      completed: checklist.hasUpgraded,
      icon: Check,
      optional: true,
    },
  ];

  const completedCount = tasks.filter(t => t.completed && !t.optional).length;
  const totalRequired = tasks.filter(t => !t.optional).length;
  const progress = (completedCount / totalRequired) * 100;

  if (progress === 100 && !isExpanded) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-4 right-4 bg-gray-900 rounded-lg shadow-xl p-4 max-w-sm z-50"
    >
      <div 
        className="flex items-center justify-between cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <h4 className="text-white font-medium">Getting Started</h4>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-400">{completedCount}/{totalRequired}</span>
          <ChevronRight 
            className={`w-4 h-4 text-gray-400 transform transition-transform ${
              isExpanded ? 'rotate-90' : ''
            }`} 
          />
        </div>
      </div>

      {isExpanded && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className="mt-4 space-y-3"
        >
          {/* Progress Bar */}
          <div className="w-full bg-gray-800 rounded-full h-2">
            <motion.div
              className="bg-gradient-to-r from-primary-500 to-primary-600 h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>

          {/* Tasks */}
          <div className="space-y-2">
            {tasks.map((task) => {
              const TaskIcon = task.icon;
              return (
                <div
                  key={task.id}
                  className={`flex items-center space-x-3 p-2 rounded-lg transition-colors ${
                    task.completed 
                      ? 'bg-green-900/20 text-green-400' 
                      : 'bg-gray-800/50 text-gray-400'
                  }`}
                >
                  <TaskIcon className="w-4 h-4" />
                  <span className="text-sm flex-1">{task.label}</span>
                  {task.optional && (
                    <span className="text-xs bg-amber-900/50 text-amber-400 px-2 py-0.5 rounded">
                      Optional
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {progress === 100 && (
            <div className="text-center pt-2">
              <p className="text-sm text-green-400 mb-2">🎉 You're all set!</p>
              <button
                onClick={() => setIsExpanded(false)}
                className="text-xs text-gray-400 hover:text-white transition-colors"
              >
                Dismiss
              </button>
            </div>
          )}
        </motion.div>
      )}
    </motion.div>
  );
};