import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../../utils/database';
import { cleanupQueue } from '../../jobs/cleanup.queue';
import { logger } from '../../utils/logger';
import { asyncHandler } from '../../utils/async-handler';
import { AppError } from '../../utils/errors';
import { calculateCost } from '../../utils/pricing';
import { getJobPriority, validateExportFormat, validateBatchSize } from '../../utils/premium-features';

const router = Router();

// Job creation schema
const createJobSchema = z.object({
  uploadId: z.string().uuid(),
  type: z.enum(['cleanup', 'refactor', 'format', 'full']).default('cleanup'),
  profileId: z.string().optional(),
  customProfile: z.any().optional(), // Allow inline custom profile
  options: z.object({
    removeComments: z.boolean().default(false),
    removeConsoleLog: z.boolean().default(true),
    formatCode: z.boolean().default(true),
    optimizeImports: z.boolean().default(true),
    removeDeadCode: z.boolean().default(true),
    convertToTypeScript: z.boolean().default(false),
    addTests: z.boolean().default(false),
    llmProvider: z.enum(['ollama', 'openai', 'anthropic', 'auto']).default('auto'),
  }).default({}),
});

// Batch job creation schema
const createBatchJobSchema = z.object({
  uploadIds: z.array(z.string().uuid()).min(1).max(10),
  type: z.enum(['cleanup', 'refactor', 'format', 'full']).default('cleanup'),
  profileId: z.string().optional(),
  customProfile: z.any().optional(),
  options: z.object({
    removeComments: z.boolean().default(false),
    removeConsoleLog: z.boolean().default(true),
    formatCode: z.boolean().default(true),
    optimizeImports: z.boolean().default(true),
    removeDeadCode: z.boolean().default(true),
    convertToTypeScript: z.boolean().default(false),
    addTests: z.boolean().default(false),
    llmProvider: z.enum(['ollama', 'openai', 'anthropic', 'auto']).default('auto'),
  }).default({}),
});

// Swipe decision schema
const swipeDecisionSchema = z.object({
  changeId: z.string(),
  decision: z.enum(['accept', 'reject', 'modify']),
  modifiedCode: z.string().optional(),
});

// Job update schema
const updateJobSchema = z.object({
  decisions: z.array(swipeDecisionSchema),
});

/**
 * POST /api/jobs
 * Create a new cleanup job
 */
router.post(
  '/',
  asyncHandler(async (req, res) => {
    const userId = req.user!.id;
    const data = createJobSchema.parse(req.body);

    // Verify upload exists and belongs to user
    const upload = await prisma.upload.findFirst({
      where: {
        id: data.uploadId,
        userId,
        status: 'UPLOADED',
      },
    });

    if (!upload) {
      throw new AppError('Upload not found or not accessible', 404, 'UPLOAD_NOT_FOUND');
    }

    // Check for existing pending jobs
    const existingJob = await prisma.job.findFirst({
      where: {
        uploadId: data.uploadId,
        status: { in: ['PENDING', 'PROCESSING', 'REVIEW'] },
      },
    });

    if (existingJob) {
      throw new AppError(
        'A job is already in progress for this upload',
        400,
        'JOB_ALREADY_EXISTS'
      );
    }

    // Calculate estimated cost
    const estimatedCost = calculateCost({
      fileSize: upload.size,
      type: data.type,
      options: data.options,
    });

    // Create job record
    const job = await prisma.job.create({
      data: {
        userId,
        uploadId: data.uploadId,
        type: data.type,
        status: 'PENDING',
        inputFileUrl: upload.url || upload.path, // Use URL or fallback to path
        originalFileName: upload.originalName,
        fileSizeBytes: upload.size,
        input: {
          options: data.options,
          profileId: data.profileId,
          customProfile: data.customProfile,
          uploadInfo: {
            filename: upload.originalName,
            size: upload.size,
            mimeType: upload.mimeType,
          },
        },
        cost: estimatedCost,
        metadata: {
          createdFrom: 'web',
          userAgent: req.headers['user-agent'],
        },
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
      },
    });

    // Get user for priority calculation
    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    // Add to processing queue with tier-based priority
    const priority = getJobPriority(user);
    await cleanupQueue.add('process-cleanup', {
      jobId: job.id,
      userId,
      uploadId: data.uploadId,
      options: data.options,
      type: data.type,
    }, {
      priority,
      attempts: 3,
      backoff: {
        type: 'exponential',
        delay: 2000,
      },
    });

    logger.info('Job created and queued', {
      jobId: job.id,
      userId,
      uploadId: data.uploadId,
      type: data.type,
    });

    res.status(201).json({
      success: true,
      data: {
        id: job.id,
        type: job.type,
        status: job.status,
        estimatedCost,
        createdAt: job.createdAt,
        expiresAt: job.expiresAt,
      },
    });
  })
);

/**
 * POST /api/jobs/batch
 * Create multiple jobs for batch processing (Premium feature)
 */
router.post(
  '/batch',
  asyncHandler(async (req, res) => {
    const userId = req.user!.id;
    const data = createBatchJobSchema.parse(req.body);

    // Get user for tier validation
    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    // Validate batch size against user tier
    try {
      validateBatchSize(user, data.uploadIds.length);
    } catch (error) {
      throw new AppError(
        error instanceof Error ? error.message : 'Batch size validation failed',
        403,
        'BATCH_SIZE_EXCEEDED'
      );
    }

    // Verify all uploads exist and belong to user
    const uploads = await prisma.upload.findMany({
      where: {
        id: { in: data.uploadIds },
        userId,
        status: 'UPLOADED',
      },
    });

    if (uploads.length !== data.uploadIds.length) {
      throw new AppError('Some uploads not found or not accessible', 404, 'UPLOADS_NOT_FOUND');
    }

    // Check for existing pending jobs for any of these uploads
    const existingJobs = await prisma.job.findMany({
      where: {
        uploadId: { in: data.uploadIds },
        status: { in: ['PENDING', 'PROCESSING', 'REVIEW'] },
      },
    });

    if (existingJobs.length > 0) {
      throw new AppError(
        `Jobs already in progress for uploads: ${existingJobs.map(j => j.uploadId).join(', ')}`,
        400,
        'BATCH_JOBS_ALREADY_EXISTS'
      );
    }

    // Create jobs for each upload
    const jobs = [];
    const priority = getJobPriority(user);
    
    for (const upload of uploads) {
      const estimatedCost = calculateCost({
        fileSize: upload.size,
        type: data.type,
        options: data.options,
      });

      const job = await prisma.job.create({
        data: {
          userId,
          uploadId: upload.id,
          type: data.type,
          status: 'PENDING',
          inputFileUrl: upload.url || upload.path,
          originalFileName: upload.originalName,
          fileSizeBytes: upload.size,
          input: {
            options: data.options,
            profileId: data.profileId,
            customProfile: data.customProfile,
            uploadInfo: {
              filename: upload.originalName,
              size: upload.size,
              mimeType: upload.mimeType,
            },
          },
          cost: estimatedCost,
          metadata: {
            createdFrom: 'batch',
            userAgent: req.headers['user-agent'],
            batchId: `batch-${Date.now()}`,
          },
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
        },
      });

      // Add to processing queue
      await cleanupQueue.add('process-cleanup', {
        jobId: job.id,
        userId,
        uploadId: upload.id,
        options: data.options,
        type: data.type,
      }, {
        priority,
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 2000,
        },
        delay: jobs.length * 1000, // Stagger batch jobs by 1 second
      });

      jobs.push(job);
    }

    logger.info('Batch jobs created and queued', {
      batchId: jobs[0]?.metadata || `batch-${Date.now()}`,
      userId,
      userTier: user?.tier || 'FREE',
      jobCount: jobs.length,
      type: data.type,
    });

    res.status(201).json({
      success: true,
      data: {
        batchId: `batch-${Date.now()}`,
        jobs: jobs.map(job => ({
          id: job.id,
          uploadId: job.uploadId,
          type: job.type,
          status: job.status,
          estimatedCost: job.cost,
          createdAt: job.createdAt,
          expiresAt: job.expiresAt,
        })),
        totalEstimatedCost: jobs.reduce((sum, job) => sum + job.cost, 0),
      },
    });
  })
);

/**
 * GET /api/jobs
 * List user's jobs
 */
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const userId = req.user!.id;
    const { status, limit = 20, offset = 0 } = req.query;

    const where: any = { userId };
    
    if (status) {
      where.status = status as string;
    }

    const [jobs, total] = await Promise.all([
      prisma.job.findMany({
        where,
        include: {
          upload: {
            select: {
              originalName: true,
              size: true,
            },
          },
          payment: {
            select: {
              status: true,
              amount: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: Number(limit),
        skip: Number(offset),
      }),
      prisma.job.count({ where }),
    ]);

    res.json({
      success: true,
      data: jobs.map(job => ({
        id: job.id,
        type: job.type,
        status: job.status,
        progress: job.progress,
        cost: job.cost,
        filename: job.upload?.originalName,
        fileSize: job.upload?.size,
        paymentStatus: job.payment?.status,
        createdAt: job.createdAt,
        completedAt: job.completedAt,
      })),
      pagination: {
        total,
        limit: Number(limit),
        offset: Number(offset),
        hasMore: Number(offset) + Number(limit) < total,
      },
    });
  })
);

/**
 * GET /api/jobs/:id
 * Get job details
 */
router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const userId = req.user!.id;

    const job = await prisma.job.findFirst({
      where: { id, userId },
      include: {
        upload: true,
        payment: true,
      },
    });

    if (!job) {
      throw new AppError('Job not found', 404, 'JOB_NOT_FOUND');
    }

    // Get real-time progress from queue if processing
    let queueProgress = null;
    if (job.status === 'PROCESSING') {
      const queueJob = await cleanupQueue.getJob(id as string);
      if (queueJob) {
        queueProgress = await queueJob.progress();
      }
    }

    res.json({
      success: true,
      data: {
        id: job.id,
        type: job.type,
        status: job.status,
        progress: queueProgress || job.progress,
        currentStep: job.currentStep,
        input: job.input,
        changes: job.changes,
        decisions: job.decisions,
        cost: job.cost,
        tokensUsed: job.tokensUsed,
        llmProvider: job.llmProvider,
        outputUrl: job.outputUrl,
        downloadUrl: job.downloadUrl,
        error: job.error,
        upload: job.upload ? {
          id: job.upload.id,
          filename: job.upload.originalName,
          size: job.upload.size,
        } : null,
        payment: job.payment ? {
          id: job.payment.id,
          status: job.payment.status,
          amount: job.payment.amount,
        } : null,
        createdAt: job.createdAt,
        startedAt: job.startedAt,
        completedAt: job.completedAt,
        expiresAt: job.expiresAt,
      },
    });
  })
);

/**
 * PUT /api/jobs/:id
 * Update job with swipe decisions
 */
router.put(
  '/:id',
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const userId = req.user!.id;
    const data = updateJobSchema.parse(req.body);

    const job = await prisma.job.findFirst({
      where: { id, userId, status: 'REVIEW' },
    });

    if (!job) {
      throw new AppError(
        'Job not found or not in review status',
        404,
        'JOB_NOT_REVIEWABLE'
      );
    }

    // Update job with decisions
    const updatedJob = await prisma.job.update({
      where: { id },
      data: {
        decisions: data.decisions,
        status: 'APPLYING',
      },
    });

    // Queue application of changes
    await cleanupQueue.add('apply-changes', {
      jobId: id,
      userId,
      decisions: data.decisions,
    }, {
      priority: 2,
      attempts: 3,
    });

    // Store swipe patterns for future learning
    for (const decision of data.decisions) {
      const change = (job.changes as any[]).find((c: any) => c.id === decision.changeId);
      if (change) {
        await prisma.swipePattern.upsert({
          where: {
            userId_changeType_pattern: {
              userId,
              changeType: change.type,
              pattern: change.pattern || change.type,
            },
          },
          update: {
            action: decision.decision === 'accept' ? 'ACCEPT' : 'REJECT',
            usageCount: { increment: 1 },
            lastUsedAt: new Date(),
          },
          create: {
            userId,
            changeType: change.type,
            pattern: change.pattern || change.type,
            filePattern: change.filePattern,
            action: decision.decision === 'accept' ? 'ACCEPT' : 'REJECT',
          },
        });
      }
    }

    logger.info('Job decisions submitted', {
      jobId: id,
      userId,
      decisionCount: data.decisions.length,
    });

    res.json({
      success: true,
      data: {
        id: updatedJob.id,
        status: updatedJob.status,
        message: 'Applying your decisions...',
      },
    });
  })
);

/**
 * DELETE /api/jobs/:id
 * Cancel a job
 */
router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const userId = req.user!.id;

    const job = await prisma.job.findFirst({
      where: {
        id,
        userId,
        status: { in: ['PENDING', 'PROCESSING', 'REVIEW'] },
      },
    });

    if (!job) {
      throw new AppError('Job not found or cannot be cancelled', 404, 'JOB_NOT_CANCELLABLE');
    }

    // Remove from queue if pending/processing
    if (job.status === 'PENDING' || job.status === 'PROCESSING') {
      const queueJob = await cleanupQueue.getJob(id as string);
      if (queueJob) {
        await queueJob.remove();
      }
    }

    // Update job status
    await prisma.job.update({
      where: { id },
      data: { status: 'CANCELLED' },
    });

    logger.info('Job cancelled', { jobId: id, userId });

    res.json({
      success: true,
      message: 'Job cancelled successfully',
    });
  })
);

/**
 * POST /api/jobs/:id/retry
 * Retry a failed job
 */
router.post(
  '/:id/retry',
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const userId = req.user!.id;

    const job = await prisma.job.findFirst({
      where: {
        id,
        userId,
        status: 'FAILED',
      },
    });

    if (!job) {
      throw new AppError('Job not found or not retryable', 404, 'JOB_NOT_RETRYABLE');
    }

    // Reset job status
    const updatedJob = await prisma.job.update({
      where: { id },
      data: {
        status: 'PENDING',
        error: null,
        attempts: { increment: 1 },
      },
    });

    // Re-queue the job
    await cleanupQueue.add('process-cleanup', {
      jobId: id,
      userId,
      uploadId: job.uploadId!,
      options: (job.input as any).options,
      type: job.type,
      isRetry: true,
    }, {
      priority: 1,
      attempts: 3,
      backoff: {
        type: 'exponential',
        delay: 2000,
      },
    });

    logger.info('Job retry initiated', {
      jobId: id,
      userId,
      attempt: updatedJob.attempts,
    });

    res.json({
      success: true,
      data: {
        id: updatedJob.id,
        status: updatedJob.status,
        message: 'Job requeued for processing',
      },
    });
  })
);

/**
 * GET /api/jobs/:id/export
 * Export job results in specified format
 */
router.get(
  '/:id/export',
  asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { format = 'zip' } = req.query;
    const userId = req.user!.id;

    // Get user for tier validation
    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    // Validate export format against user tier
    try {
      validateExportFormat(user, format as string);
    } catch (error) {
      throw new AppError(
        error instanceof Error ? error.message : 'Export format validation failed',
        403,
        'EXPORT_FORMAT_RESTRICTED'
      );
    }

    const job = await prisma.job.findFirst({
      where: { 
        id, 
        userId,
        status: 'COMPLETED',
      },
    });

    if (!job) {
      throw new AppError('Job not found or not completed', 404, 'JOB_NOT_FOUND');
    }

    if (!job.downloadUrl) {
      throw new AppError('No download available for this job', 404, 'NO_DOWNLOAD_AVAILABLE');
    }

    logger.info('Job export requested', {
      jobId: id,
      userId,
      userTier: user?.tier || 'FREE',
      format,
    });

    // For now, redirect to the existing download URL
    // In the future, this could handle format conversion
    res.redirect(job.downloadUrl);
  })
);

export { router as jobRouter };