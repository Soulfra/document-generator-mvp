import { ParserIntegrationService } from '../src/services/parser-integration.service';
import { PythonParser } from '../src/parsers/python-parser';
import { BaseParser } from '../src/parsers/base-parser';

// Mock logger
jest.mock('../src/utils/logger', () => ({
  logger: {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    debug: jest.fn()
  }
}));

// Mock the language detection service
jest.mock('../src/services/language-detection.service');

describe('ParserIntegrationService', () => {
  let service: ParserIntegrationService;
  let mockLanguageDetection: any;

  beforeEach(() => {
    // Clear singleton instance
    (ParserIntegrationService as any).instance = undefined;
    
    // Setup mocks
    const { LanguageDetectionService } = require('../src/services/language-detection.service');
    mockLanguageDetection = {
      detectLanguage: jest.fn()
    };
    LanguageDetectionService.getInstance = jest.fn(() => mockLanguageDetection);
    
    // Create service instance
    service = ParserIntegrationService.getInstance();
    
    // Clear mock calls
    jest.clearAllMocks();
  });

  describe('Parser Registration', () => {
    it('should register Python parser by default', () => {
      const pythonParser = service.getParser('python');
      expect(pythonParser).toBeInstanceOf(PythonParser);
    });

    it('should register custom parsers', () => {
      const mockParser = {
        getLanguage: () => 'custom',
        getSupportedExtensions: () => ['.custom'],
        parse: jest.fn()
      } as any;

      service.registerParser('custom', mockParser);
      
      expect(service.getParser('custom')).toBe(mockParser);
      expect(service.getSupportedLanguages()).toContain('custom');
    });

    it('should handle case-insensitive language lookup', () => {
      const parser = service.getParser('PYTHON');
      expect(parser).toBeInstanceOf(PythonParser);
    });
  });

  describe('analyzeCodebase', () => {
    it('should analyze Python codebase', async () => {
      const files = new Map<string, string>([
        ['main.py', `
def hello():
    """Say hello"""
    return "Hello, World!"
        `],
        ['models.py', `
class User:
    name: str
    email: str
        `],
        ['requirements.txt', 'flask==2.0.0\nrequests==2.28.0']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 95,
        framework: 'flask',
        secondary: [],
        configFiles: ['requirements.txt']
      });

      const result = await service.analyzeCodebase(files);

      expect(result.projectInfo.language).toBe('python');
      expect(result.projectInfo.framework).toBe('flask');
      expect(result.functions).toHaveLength(1);
      expect(result.dataModels).toHaveLength(1);
      expect(result.dependencies).toHaveLength(2);
    });

    it('should handle unknown language gracefully', async () => {
      const files = new Map<string, string>([
        ['unknown.xyz', 'some content']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'unknown',
        confidence: 0,
        secondary: [],
        configFiles: []
      });

      await expect(service.analyzeCodebase(files))
        .rejects.toThrow('Unable to detect programming language');
    });

    it('should handle missing parser gracefully', async () => {
      const files = new Map<string, string>([
        ['file.go', 'package main']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'go',
        confidence: 100,
        secondary: [],
        configFiles: []
      });

      await expect(service.analyzeCodebase(files))
        .rejects.toThrow('No parser available for language: go');
    });

    it('should analyze multi-language codebase', async () => {
      const files = new Map<string, string>([
        ['backend/main.py', 'def main(): pass'],
        ['frontend/app.ts', 'const app = {};'],
        ['package.json', '{"name": "fullstack-app"}'],
        ['requirements.txt', 'django==4.0.0']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 60,
        secondary: ['typescript'],
        framework: 'django',
        configFiles: ['requirements.txt', 'package.json']
      });

      // Mock TypeScript parser
      const mockTsParser = {
        getLanguage: () => 'typescript',
        getSupportedExtensions: () => ['.ts', '.tsx'],
        parse: jest.fn().mockResolvedValue({
          apis: [],
          functions: [{ name: 'tsFunction', file: 'frontend/app.ts' }],
          dataModels: [],
          dependencies: [],
          imports: [],
          comments: [],
          errors: []
        })
      } as any;

      service.registerParser('typescript', mockTsParser);

      const result = await service.analyzeCodebase(files);

      expect(result.projectInfo.language).toBe('python');
      expect(result.functions.length).toBeGreaterThan(0);
      expect(mockTsParser.parse).toHaveBeenCalled();
    });

    it('should respect primaryLanguageOnly option', async () => {
      const files = new Map<string, string>([
        ['main.py', 'def main(): pass'],
        ['app.js', 'function app() {}']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 70,
        secondary: ['javascript'],
        configFiles: []
      });

      const mockJsParser = {
        getLanguage: () => 'javascript',
        getSupportedExtensions: () => ['.js'],
        parse: jest.fn()
      } as any;

      service.registerParser('javascript', mockJsParser);

      await service.analyzeCodebase(files, { primaryLanguageOnly: true });

      expect(mockJsParser.parse).not.toHaveBeenCalled();
    });
  });

  describe('Project Type Detection', () => {
    it('should detect API project', async () => {
      const files = new Map<string, string>([
        ['api.py', `
from flask import Flask
app = Flask(__name__)

@app.route('/users')
def get_users():
    return []
        `]
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        framework: 'flask',
        secondary: [],
        configFiles: []
      });

      const result = await service.analyzeCodebase(files);
      expect(result.projectInfo.type).toBe('api');
    });

    it('should detect web application', async () => {
      const files = new Map<string, string>([
        ['app.py', 'from django.shortcuts import render'],
        ['manage.py', '']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        framework: 'django',
        secondary: [],
        configFiles: []
      });

      const result = await service.analyzeCodebase(files);
      expect(result.projectInfo.type).toBe('webapp');
    });

    it('should detect CLI application', async () => {
      const files = new Map<string, string>([
        ['cli.py', 'import click'],
        ['requirements.txt', 'click==8.0.0']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: ['requirements.txt']
      });

      const result = await service.analyzeCodebase(files);
      expect(result.projectInfo.type).toBe('cli');
    });

    it('should detect library project', async () => {
      const files = new Map<string, string>([
        ['lib.py', `
def func1(): pass
def func2(): pass
def func3(): pass
def func4(): pass
def func5(): pass
        `],
        ['__init__.py', '']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: []
      });

      const result = await service.analyzeCodebase(files);
      expect(result.projectInfo.type).toBe('library');
    });
  });

  describe('Architecture Analysis', () => {
    it('should detect layered architecture', async () => {
      const files = new Map<string, string>([
        ['controllers/user_controller.py', 'class UserController: pass'],
        ['services/user_service.py', 'class UserService: pass'],
        ['models/user.py', 'class User: pass'],
        ['repositories/user_repository.py', 'class UserRepository: pass']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: []
      });

      const result = await service.analyzeCodebase(files);
      expect(result.architecture.style).toBe('layered');
      expect(result.architecture.layers.presentation).toBeGreaterThan(0);
      expect(result.architecture.layers.business).toBeGreaterThan(0);
      expect(result.architecture.layers.data).toBeGreaterThan(0);
    });

    it('should detect microservices architecture', async () => {
      const files = new Map<string, string>([
        ['service1/app.py', 'from flask import Flask'],
        ['service2/app.py', 'from flask import Flask'],
        ['docker-compose.yml', 'version: "3"']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: []
      });

      const result = await service.analyzeCodebase(files);
      expect(result.architecture.style).toBe('microservices');
    });

    it('should detect common patterns', async () => {
      const files = new Map<string, string>([
        ['models.py', `
class UserModel:
    pass

class UserRepository:
    def create_user(self): pass

class UserFactory:
    def create(self): pass
        `]
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: []
      });

      const result = await service.analyzeCodebase(files);
      expect(result.architecture.patterns).toContain('Repository');
      expect(result.architecture.patterns).toContain('Factory');
    });
  });

  describe('Test Metrics', () => {
    it('should calculate test coverage metrics', async () => {
      const files = new Map<string, string>([
        ['app.py', `
def func1(): pass
def func2(): pass
def func3(): pass
        `],
        ['test_app.py', `
def test_func1(): pass
def test_func2(): pass
        `]
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: []
      });

      const result = await service.analyzeCodebase(files);
      expect(result.testCoverage.totalFunctions).toBe(3);
      expect(result.testCoverage.testFunctions).toBe(2);
      expect(result.testCoverage.testFiles).toBe(1);
    });
  });

  describe('Business Rules Extraction', () => {
    it('should extract validation rules', async () => {
      const files = new Map<string, string>([
        ['validators.py', `
def validate_email(email):
    """Validate email format"""
    return "@" in email

def check_age(age):
    """Check if age is valid"""
    return age >= 18
        `]
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: []
      });

      const result = await service.analyzeCodebase(files);
      expect(result.businessLogic).toHaveLength(2);
      expect(result.businessLogic[0].type).toBe('validation');
      expect(result.businessLogic[0].name).toContain('validate');
    });

    it('should extract documented business rules', async () => {
      const files = new Map<string, string>([
        ['business.py', `
# Business Rule: Users must be 18 or older
def create_user(age):
    if age < 18:
        raise ValueError("Too young")
        `]
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: []
      });

      const result = await service.analyzeCodebase(files);
      const docRule = result.businessLogic.find(r => r.type === 'documented');
      expect(docRule).toBeDefined();
      expect(docRule.description).toContain('18 or older');
    });
  });

  describe('File Structure Analysis', () => {
    it('should analyze file structure', async () => {
      const files = new Map<string, string>([
        ['src/main.py', 'print("main")'],
        ['src/utils/helper.py', 'def help(): pass'],
        ['tests/test_main.py', 'def test(): pass'],
        ['README.md', '# Project'],
        ['requirements.txt', 'flask']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: ['requirements.txt']
      });

      const result = await service.analyzeCodebase(files);
      expect(result.fileStructure.totalFiles).toBe(5);
      expect(result.fileStructure.directories).toContain('src');
      expect(result.fileStructure.directories).toContain('src/utils');
      expect(result.fileStructure.directories).toContain('tests');
      expect(result.fileStructure.fileTypes['.py']).toBe(3);
      expect(result.fileStructure.fileTypes['.md']).toBe(1);
    });
  });

  describe('Project Metadata Extraction', () => {
    it('should extract project name from package.json', async () => {
      const files = new Map<string, string>([
        ['package.json', '{"name": "my-awesome-project", "description": "An awesome project"}'],
        ['index.js', 'console.log("hello")']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'javascript',
        confidence: 100,
        secondary: [],
        configFiles: ['package.json']
      });

      // Register mock JS parser
      service.registerParser('javascript', {
        getLanguage: () => 'javascript',
        getSupportedExtensions: () => ['.js'],
        parse: jest.fn().mockResolvedValue({
          apis: [], functions: [], dataModels: [],
          dependencies: [], imports: [], comments: [], errors: []
        })
      } as any);

      const result = await service.analyzeCodebase(files);
      expect(result.projectInfo.name).toBe('my-awesome-project');
      expect(result.projectInfo.description).toBe('An awesome project');
    });

    it('should extract project name from setup.py', async () => {
      const files = new Map<string, string>([
        ['setup.py', `
from setuptools import setup
setup(
    name='python-project',
    description='A Python project'
)
        `],
        ['main.py', 'print("hello")']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: ['setup.py']
      });

      const result = await service.analyzeCodebase(files);
      expect(result.projectInfo.name).toBe('python-project');
    });

    it('should extract description from README', async () => {
      const files = new Map<string, string>([
        ['README.md', `# My Project\n\nThis is an amazing project that does wonderful things.\nIt has many features.`],
        ['main.py', 'print("hello")']
      ]);

      mockLanguageDetection.detectLanguage.mockResolvedValue({
        primary: 'python',
        confidence: 100,
        secondary: [],
        configFiles: []
      });

      const result = await service.analyzeCodebase(files);
      expect(result.projectInfo.description).toContain('amazing project');
    });
  });
});