import path from 'path';
import fs from 'fs/promises';
import unzipper from 'unzipper';
import archiver from 'archiver';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger';
import { llmRouter } from '../llm/router';
import { prisma } from '../utils/database';
import { uploadToS3, downloadFromS3 } from '../utils/storage';
import { ProcessingError } from '../utils/errors';

export interface CleanupResult {
  outputFileUrl: string;
  metadata: {
    originalFiles: number;
    cleanedFiles: number;
    linesOfCode: number;
    languages: Record<string, number>;
    improvements: string[];
    processingCost: number;
  };
}

export async function processCleanupJob(
  jobId: string,
  progressCallback?: (progress: number) => void
): Promise<CleanupResult> {
  const updateProgress = (progress: number) => {
    progressCallback?.(progress);
  };

  updateProgress(5);

  try {
    // Get job details
    const job = await prisma.job.findUnique({
      where: { id: jobId },
    });

    if (!job) {
      throw new ProcessingError('Job not found');
    }

    logger.info('Starting cleanup process', { jobId, inputUrl: job.inputFileUrl });

    // Download and extract files
    updateProgress(10);
    const extractedDir = await downloadAndExtract(job.inputFileUrl, jobId);
    
    updateProgress(20);
    
    // Analyze project structure
    const projectAnalysis = await analyzeProject(extractedDir);
    updateProgress(30);
    
    // Clean up files
    const cleanupResults = await cleanupFiles(extractedDir, projectAnalysis);
    updateProgress(70);
    
    // Reorganize structure
    const reorganizedDir = await reorganizeStructure(extractedDir, projectAnalysis);
    updateProgress(85);
    
    // Package results
    const outputUrl = await packageResults(reorganizedDir, jobId);
    updateProgress(95);
    
    // Cleanup temporary files
    await cleanup(extractedDir, reorganizedDir);
    updateProgress(100);

    // Store analysis results
    await prisma.analysisResult.create({
      data: {
        jobId,
        totalFiles: projectAnalysis.totalFiles,
        linesOfCode: projectAnalysis.linesOfCode,
        languages: projectAnalysis.languages,
        issues: cleanupResults.issues,
        improvements: cleanupResults.improvements,
        ollamaConfidence: cleanupResults.ollamaConfidence,
        claudeUsed: cleanupResults.claudeUsed,
        processingCostUsd: cleanupResults.cost,
      },
    });

    return {
      outputFileUrl: outputUrl,
      metadata: {
        originalFiles: projectAnalysis.totalFiles,
        cleanedFiles: cleanupResults.cleanedFiles,
        linesOfCode: projectAnalysis.linesOfCode,
        languages: projectAnalysis.languages,
        improvements: cleanupResults.improvements,
        processingCost: cleanupResults.cost,
      },
    };

  } catch (error) {
    logger.error('Cleanup job failed', { jobId, error });
    throw error;
  }
}

async function downloadAndExtract(fileUrl: string, jobId: string): Promise<string> {
  const tempDir = path.join('/tmp', `cleanup-${jobId}`);
  const extractDir = path.join(tempDir, 'extracted');
  
  await fs.mkdir(extractDir, { recursive: true });
  
  // Download file from S3
  const fileBuffer = await downloadFromS3(fileUrl);
  const zipPath = path.join(tempDir, 'input.zip');
  
  await fs.writeFile(zipPath, fileBuffer);
  
  // Extract zip file
  await fs.createReadStream(zipPath)
    .pipe(unzipper.Extract({ path: extractDir }))
    .promise();
  
  logger.info('Files extracted', { extractDir, jobId });
  return extractDir;
}

async function analyzeProject(projectDir: string): Promise<{
  totalFiles: number;
  linesOfCode: number;
  languages: Record<string, number>;
  fileTypes: Record<string, number>;
  structure: string[];
}> {
  const files = await getAllFiles(projectDir);
  const languages: Record<string, number> = {};
  const fileTypes: Record<string, number> = {};
  let totalLines = 0;

  for (const file of files) {
    const ext = path.extname(file).toLowerCase();
    fileTypes[ext] = (fileTypes[ext] || 0) + 1;

    // Detect language
    const language = detectLanguage(ext);
    if (language) {
      languages[language] = (languages[language] || 0) + 1;
    }

    // Count lines (for text files only)
    if (isTextFile(ext)) {
      try {
        const content = await fs.readFile(file, 'utf-8');
        totalLines += content.split('\n').length;
      } catch (error) {
        // Skip binary or problematic files
      }
    }
  }

  return {
    totalFiles: files.length,
    linesOfCode: totalLines,
    languages,
    fileTypes,
    structure: files.map(f => path.relative(projectDir, f)),
  };
}

async function cleanupFiles(projectDir: string, analysis: any): Promise<{
  cleanedFiles: number;
  issues: string[];
  improvements: string[];
  ollamaConfidence: number;
  claudeUsed: boolean;
  cost: number;
}> {
  const files = await getAllFiles(projectDir);
  let cleanedFiles = 0;
  let totalCost = 0;
  let claudeUsed = false;
  let minConfidence = 1.0;
  const allIssues: string[] = [];
  const allImprovements: string[] = [];

  for (const file of files) {
    const ext = path.extname(file).toLowerCase();
    
    // Only process code files
    if (!isCodeFile(ext)) continue;

    try {
      const content = await fs.readFile(file, 'utf-8');
      
      // Skip empty files
      if (content.trim().length === 0) continue;

      // Analyze file
      const analysisResult = await llmRouter.route({
        type: 'analyze',
        input: { code: content },
        options: { preferLocal: true, maxCost: 0.05 }
      });

      allIssues.push(...(analysisResult.data.issues || []));
      minConfidence = Math.min(minConfidence, analysisResult.confidence);
      totalCost += analysisResult.cost;
      
      if (analysisResult.provider === 'claude') {
        claudeUsed = true;
      }

      // Clean up file if issues found
      if (analysisResult.data.issues?.length > 0) {
        const cleanupResult = await llmRouter.route({
          type: 'cleanup',
          input: { 
            code: content, 
            language: detectLanguage(ext) || 'text' 
          },
          options: { preferLocal: true, maxCost: 0.1 }
        });

        // Write cleaned file
        await fs.writeFile(file, cleanupResult.data);
        cleanedFiles++;
        totalCost += cleanupResult.cost;
        
        if (cleanupResult.provider === 'claude') {
          claudeUsed = true;
        }

        allImprovements.push(`Cleaned ${path.basename(file)}`);
      }

    } catch (error) {
      logger.error('Failed to clean file', { file, error });
      allIssues.push(`Failed to process ${path.basename(file)}`);
    }
  }

  return {
    cleanedFiles,
    issues: allIssues,
    improvements: allImprovements,
    ollamaConfidence: minConfidence,
    claudeUsed,
    cost: totalCost,
  };
}

async function reorganizeStructure(projectDir: string, analysis: any): Promise<string> {
  const files = analysis.structure;
  
  // Get structure suggestion from LLM
  const structureResult = await llmRouter.route({
    type: 'structure',
    input: { files },
    options: { preferLocal: true, maxCost: 0.05 }
  });

  const suggestion = structureResult.data;
  const reorganizedDir = path.join(path.dirname(projectDir), 'reorganized');
  
  await fs.mkdir(reorganizedDir, { recursive: true });

  // Apply suggested structure
  for (const [folder, folderFiles] of Object.entries(suggestion.structure)) {
    const folderPath = path.join(reorganizedDir, folder);
    await fs.mkdir(folderPath, { recursive: true });

    for (const file of folderFiles as string[]) {
      const sourcePath = path.join(projectDir, file);
      const destPath = path.join(folderPath, path.basename(file));
      
      try {
        await fs.copyFile(sourcePath, destPath);
      } catch (error) {
        logger.warn('Failed to copy file during reorganization', { 
          source: sourcePath, 
          dest: destPath, 
          error 
        });
      }
    }
  }

  // Generate README with improvements
  const readmePath = path.join(reorganizedDir, 'README.md');
  const readmeContent = generateReadme(analysis, suggestion);
  await fs.writeFile(readmePath, readmeContent);

  return reorganizedDir;
}

async function packageResults(projectDir: string, jobId: string): Promise<string> {
  const zipPath = path.join('/tmp', `cleaned-${jobId}.zip`);
  
  const output = fs.createWriteStream(zipPath);
  const archive = archiver('zip', { zlib: { level: 9 } });
  
  archive.pipe(output);
  archive.directory(projectDir, false);
  await archive.finalize();
  
  // Upload to S3
  const fileBuffer = await fs.readFile(zipPath);
  const s3Key = `results/${jobId}/cleaned-codebase.zip`;
  const uploadUrl = await uploadToS3(fileBuffer, s3Key);
  
  // Cleanup local zip
  await fs.unlink(zipPath);
  
  return uploadUrl;
}

async function cleanup(...dirs: string[]) {
  for (const dir of dirs) {
    try {
      await fs.rm(dir, { recursive: true, force: true });
    } catch (error) {
      logger.warn('Failed to cleanup temp directory', { dir, error });
    }
  }
}

// Helper functions
async function getAllFiles(dir: string): Promise<string[]> {
  const files: string[] = [];
  
  async function scan(currentDir: string) {
    const entries = await fs.readdir(currentDir, { withFileTypes: true });
    
    for (const entry of entries) {
      const fullPath = path.join(currentDir, entry.name);
      
      if (entry.isDirectory()) {
        // Skip common ignore directories
        if (!shouldIgnoreDir(entry.name)) {
          await scan(fullPath);
        }
      } else {
        files.push(fullPath);
      }
    }
  }
  
  await scan(dir);
  return files;
}

function shouldIgnoreDir(dirName: string): boolean {
  const ignoreDirs = [
    'node_modules', '.git', '.svn', '.hg', 'dist', 'build', 
    'coverage', '.nyc_output', 'logs', 'tmp', 'temp', '.cache'
  ];
  return ignoreDirs.includes(dirName) || dirName.startsWith('.');
}

function detectLanguage(ext: string): string | null {
  const languageMap: Record<string, string> = {
    '.js': 'javascript',
    '.jsx': 'javascript',
    '.ts': 'typescript',
    '.tsx': 'typescript',
    '.py': 'python',
    '.java': 'java',
    '.cpp': 'cpp',
    '.c': 'c',
    '.cs': 'csharp',
    '.php': 'php',
    '.rb': 'ruby',
    '.go': 'go',
    '.rs': 'rust',
    '.swift': 'swift',
    '.kt': 'kotlin',
    '.scala': 'scala',
    '.html': 'html',
    '.css': 'css',
    '.scss': 'scss',
    '.sass': 'sass',
    '.json': 'json',
    '.xml': 'xml',
    '.yaml': 'yaml',
    '.yml': 'yaml',
  };
  
  return languageMap[ext] || null;
}

function isTextFile(ext: string): boolean {
  const textExts = [
    '.js', '.jsx', '.ts', '.tsx', '.py', '.java', '.cpp', '.c', '.cs',
    '.php', '.rb', '.go', '.rs', '.swift', '.kt', '.scala', '.html',
    '.css', '.scss', '.sass', '.json', '.xml', '.yaml', '.yml', '.md',
    '.txt', '.csv', '.sql', '.sh', '.bat', '.ps1', '.dockerfile',
  ];
  
  return textExts.includes(ext.toLowerCase());
}

function isCodeFile(ext: string): boolean {
  const codeExts = [
    '.js', '.jsx', '.ts', '.tsx', '.py', '.java', '.cpp', '.c', '.cs',
    '.php', '.rb', '.go', '.rs', '.swift', '.kt', '.scala', '.css', 
    '.scss', '.sass', '.json', '.sql',
  ];
  
  return codeExts.includes(ext.toLowerCase());
}

function generateReadme(analysis: any, structure: any): string {
  return `# Cleaned Codebase

This codebase has been automatically cleaned and organized by FinishThisIdea.

## Project Statistics

- **Total Files**: ${analysis.totalFiles}
- **Lines of Code**: ${analysis.linesOfCode.toLocaleString()}
- **Languages**: ${Object.keys(analysis.languages).join(', ')}

## Improvements Made

- Organized files into logical folder structure
- Removed unused imports and dead code
- Fixed indentation and formatting
- Applied language-specific best practices

## Project Structure

\`\`\`
${Object.entries(structure.structure)
  .map(([folder, files]) => `${folder}\n${(files as string[]).map(f => `  ├── ${f}`).join('\n')}`)
  .join('\n\n')}
\`\`\`

## Notes

${structure.reasoning || 'Files have been organized following best practices for the detected languages.'}

---

*Cleaned by [FinishThisIdea](https://finishthisidea.com) - AI-powered codebase cleanup*
`;
}