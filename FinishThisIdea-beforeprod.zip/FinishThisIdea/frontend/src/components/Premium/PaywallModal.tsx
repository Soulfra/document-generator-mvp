import React, { useState } from 'react';
import { X, Lock, Check, Zap } from 'lucide-react';

interface PaywallModalProps {
  isOpen: boolean;
  onClose: () => void;
  feature: string;
  featureName: string;
  contextProfileId?: string;
  onUpgrade: (contextProfileId?: string) => Promise<void>;
}

interface PremiumFeature {
  name: string;
  free: string;
  premium: string;
  icon: React.ReactNode;
}

const PREMIUM_FEATURES: PremiumFeature[] = [
  {
    name: 'File Size Limit',
    free: '50MB',
    premium: '500MB',
    icon: <Lock className="w-4 h-4" />,
  },
  {
    name: 'Batch Processing',
    free: '1 file',
    premium: '10 files',
    icon: <Zap className="w-4 h-4" />,
  },
  {
    name: 'Custom Profiles',
    free: '2 profiles',
    premium: '10 profiles',
    icon: <Check className="w-4 h-4" />,
  },
  {
    name: 'Export Formats',
    free: 'ZIP only',
    premium: 'ZIP, PDF, HTML, MD',
    icon: <Check className="w-4 h-4" />,
  },
  {
    name: 'Processing Priority',
    free: 'Standard',
    premium: 'Priority Queue',
    icon: <Zap className="w-4 h-4" />,
  },
  {
    name: 'Advanced Templates',
    free: 'Basic',
    premium: 'Enterprise Templates',
    icon: <Check className="w-4 h-4" />,
  },
];

export const PaywallModal: React.FC<PaywallModalProps> = ({
  isOpen,
  onClose,
  feature,
  featureName,
  contextProfileId,
  onUpgrade,
}) => {
  const [isUpgrading, setIsUpgrading] = useState(false);

  if (!isOpen) return null;

  const handleUpgrade = async () => {
    setIsUpgrading(true);
    try {
      await onUpgrade(contextProfileId);
    } catch (error) {
      console.error('Upgrade failed:', error);
    } finally {
      setIsUpgrading(false);
    }
  };

  const getPersonalizedMessage = () => {
    if (contextProfileId) {
      return `Upgrade to Premium to unlock ${featureName.toLowerCase()} for your projects.`;
    }
    return `${featureName} is a Premium feature. Upgrade to unlock this functionality.`;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <Lock className="w-5 h-5 text-amber-500" />
            <h3 className="text-lg font-semibold text-gray-900">
              Premium Feature Required
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Main Message */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-amber-600" />
            </div>
            <p className="text-gray-600 text-sm leading-relaxed">
              {getPersonalizedMessage()}
            </p>
          </div>

          {/* Feature Comparison */}
          <div className="mb-6">
            <h4 className="text-sm font-medium text-gray-900 mb-3">
              Free vs Premium Features
            </h4>
            <div className="space-y-3">
              {PREMIUM_FEATURES.map((item, index) => (
                <div key={index} className="flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-2">
                    {item.icon}
                    <span className="text-gray-700">{item.name}</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-gray-500 w-16 text-right">{item.free}</span>
                    <span className="text-amber-600 font-medium w-20 text-right">
                      {item.premium}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upgrade Button */}
          <button
            onClick={handleUpgrade}
            disabled={isUpgrading}
            className="w-full bg-amber-600 hover:bg-amber-700 disabled:bg-amber-400 
                     text-white font-medium py-3 px-4 rounded-lg transition-colors
                     flex items-center justify-center space-x-2"
          >
            {isUpgrading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                <span>Upgrade to Premium</span>
              </>
            )}
          </button>

          {/* Additional Info */}
          <div className="mt-4 text-center">
            <p className="text-xs text-gray-500">
              Secure payment powered by Stripe
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};