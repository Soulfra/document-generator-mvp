/**
 * CSRF Protection Middleware
 * 
 * Implements CSRF protection for state-mutating operations using double-submit cookie pattern
 * for stateless API design while maintaining security against CSRF attacks.
 */

import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { logger } from '../utils/logger';
import { AppError } from '../utils/errors';

const CSRF_TOKEN_LENGTH = 32;
const CSRF_COOKIE_NAME = 'csrf-token';
const CSRF_HEADER_NAME = 'x-csrf-token';

/**
 * Generate a cryptographically secure CSRF token
 */
function generateCSRFToken(): string {
  return crypto.randomBytes(CSRF_TOKEN_LENGTH).toString('hex');
}

/**
 * CSRF token provider middleware
 * Sets a CSRF token in a cookie and provides it for client consumption
 */
export function csrfTokenProvider(req: Request, res: Response, next: NextFunction): void {
  try {
    // Generate new token if none exists
    let token = req.cookies?.[CSRF_COOKIE_NAME];
    
    if (!token) {
      token = generateCSRFToken();
      
      // Set secure HTTP-only cookie
      res.cookie(CSRF_COOKIE_NAME, token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      });
    }

    // Provide token in response for client to include in headers
    res.locals.csrfToken = token;
    
    next();
  } catch (error) {
    logger.error('CSRF token generation failed', { error });
    next(new AppError('Security token generation failed', 500, 'CSRF_TOKEN_ERROR'));
  }
}

/**
 * CSRF protection middleware for state-mutating operations
 * Validates the CSRF token from header against the cookie value
 */
export function csrfProtection(req: Request, res: Response, next: NextFunction): void {
  try {
    // Skip CSRF for safe methods
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
      return next();
    }

    // Skip CSRF for webhook routes (they use signature verification)
    if (req.path.includes('/webhook/')) {
      return next();
    }

    const cookieToken = req.cookies?.[CSRF_COOKIE_NAME];
    const headerToken = req.headers[CSRF_HEADER_NAME] as string;

    // Check if tokens exist
    if (!cookieToken) {
      logger.warn('CSRF protection: missing cookie token', {
        method: req.method,
        path: req.path,
        ip: req.ip,
      });
      
      return next(new AppError('CSRF token missing - please refresh and try again', 403, 'CSRF_MISSING_COOKIE'));
    }

    if (!headerToken) {
      logger.warn('CSRF protection: missing header token', {
        method: req.method,
        path: req.path,
        ip: req.ip,
      });
      
      return next(new AppError('CSRF token required in headers', 403, 'CSRF_MISSING_HEADER'));
    }

    // Validate tokens match using constant-time comparison
    if (!crypto.timingSafeEqual(Buffer.from(cookieToken), Buffer.from(headerToken))) {
      logger.warn('CSRF protection: token mismatch', {
        method: req.method,
        path: req.path,
        ip: req.ip,
        userAgent: req.headers['user-agent'],
      });
      
      return next(new AppError('Invalid CSRF token', 403, 'CSRF_TOKEN_MISMATCH'));
    }

    // CSRF validation passed
    logger.debug('CSRF protection: validation successful', {
      method: req.method,
      path: req.path,
    });

    next();
  } catch (error) {
    logger.error('CSRF protection error', { error, path: req.path });
    next(new AppError('CSRF validation error', 500, 'CSRF_VALIDATION_ERROR'));
  }
}

/**
 * Get CSRF token endpoint for client-side consumption
 */
export function getCSRFToken(req: Request, res: Response): void {
  const token = res.locals.csrfToken;
  
  if (!token) {
    logger.error('CSRF token not available in response locals');
    res.status(500).json({
      success: false,
      error: 'CSRF token not available',
    });
    return;
  }

  res.json({
    success: true,
    data: {
      csrfToken: token,
    },
  });
}

/**
 * Development-only CSRF bypass (for testing)
 * Should be removed in production
 */
export function bypassCSRFInDevelopment(req: Request, res: Response, next: NextFunction): void {
  if (process.env.NODE_ENV === 'development' && req.headers['x-bypass-csrf'] === 'true') {
    logger.warn('CSRF protection bypassed for development', {
      path: req.path,
      method: req.method,
    });
    return next();
  }
  
  csrfProtection(req, res, next);
}