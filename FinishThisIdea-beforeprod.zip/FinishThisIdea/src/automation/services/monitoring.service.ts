import * as Sentry from '@sentry/node';
import { ProfilingIntegration } from '@sentry/profiling-node';
import { logger } from '../../utils/logger';
import automationConfig from '../config/automation-config.json';

export class MonitoringService {
  private isEnabled: boolean = false;

  constructor() {
    this.initialize();
  }

  private initialize(): void {
    if (automationConfig.monitoring.sentry.enabled && process.env.SENTRY_DSN) {
      try {
        Sentry.init({
          dsn: process.env.SENTRY_DSN,
          environment: automationConfig.monitoring.sentry.environment || 'development',
          integrations: [
            // Enable HTTP calls tracing
            new Sentry.Integrations.Http({ tracing: true }),
            // Enable Express.js middleware tracing
            new Sentry.Integrations.Express({ app: undefined }),
            // Enable Profiling (optional)
            new ProfilingIntegration(),
          ],
          // Performance Monitoring
          tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
          // Profiling
          profilesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
          // Release tracking
          release: process.env.SENTRY_RELEASE || 'finishthisidea@1.0.0',
          // Filtering
          beforeSend(event, hint) {
            // Filter out sensitive data
            if (event.request?.cookies) {
              delete event.request.cookies;
            }
            if (event.request?.headers) {
              delete event.request.headers.authorization;
              delete event.request.headers.cookie;
            }
            
            // Don't send events in development unless specified
            if (process.env.NODE_ENV === 'development' && !process.env.SENTRY_FORCE_SEND) {
              return null;
            }
            
            return event;
          },
        });

        this.isEnabled = true;
        logger.info('Sentry monitoring initialized');
      } catch (error) {
        logger.error('Failed to initialize Sentry', { error });
      }
    }
  }

  /**
   * Capture an exception
   */
  public captureException(error: Error, context?: any): void {
    if (!this.isEnabled) {
      logger.error('Exception captured (Sentry disabled)', { error, context });
      return;
    }

    Sentry.captureException(error, {
      extra: context,
    });
  }

  /**
   * Capture a message
   */
  public captureMessage(message: string, level: 'info' | 'warning' | 'error' = 'info'): void {
    if (!this.isEnabled) {
      logger.log(level, `Message captured (Sentry disabled): ${message}`);
      return;
    }

    Sentry.captureMessage(message, level);
  }

  /**
   * Set user context
   */
  public setUserContext(user: { id: string; email?: string; tier?: string }): void {
    if (!this.isEnabled) return;

    Sentry.setUser({
      id: user.id,
      email: user.email,
      segment: user.tier,
    });
  }

  /**
   * Clear user context
   */
  public clearUserContext(): void {
    if (!this.isEnabled) return;
    Sentry.setUser(null);
  }

  /**
   * Add breadcrumb
   */
  public addBreadcrumb(breadcrumb: {
    message: string;
    category?: string;
    level?: 'debug' | 'info' | 'warning' | 'error';
    data?: any;
  }): void {
    if (!this.isEnabled) return;

    Sentry.addBreadcrumb({
      message: breadcrumb.message,
      category: breadcrumb.category || 'custom',
      level: breadcrumb.level || 'info',
      data: breadcrumb.data,
      timestamp: Date.now() / 1000,
    });
  }

  /**
   * Start a transaction for performance monitoring
   */
  public startTransaction(name: string, op: string): any {
    if (!this.isEnabled) return null;

    return Sentry.startTransaction({
      name,
      op,
    });
  }

  /**
   * Create Express error handler middleware
   */
  public getErrorHandler() {
    if (!this.isEnabled) {
      // Return a no-op middleware
      return (_err: any, _req: any, _res: any, next: any) => next();
    }

    return Sentry.Handlers.errorHandler();
  }

  /**
   * Create Express request handler middleware
   */
  public getRequestHandler() {
    if (!this.isEnabled) {
      // Return a no-op middleware
      return (_req: any, _res: any, next: any) => next();
    }

    return Sentry.Handlers.requestHandler();
  }

  /**
   * Create Express tracing handler middleware
   */
  public getTracingHandler() {
    if (!this.isEnabled) {
      // Return a no-op middleware
      return (_req: any, _res: any, next: any) => next();
    }

    return Sentry.Handlers.tracingHandler();
  }

  /**
   * Flush all pending events (call before shutdown)
   */
  public async flush(timeout?: number): Promise<boolean> {
    if (!this.isEnabled) return true;

    try {
      return await Sentry.flush(timeout || 2000);
    } catch (error) {
      logger.error('Failed to flush Sentry events', { error });
      return false;
    }
  }

  /**
   * Close Sentry client
   */
  public async close(timeout?: number): Promise<boolean> {
    if (!this.isEnabled) return true;

    try {
      return await Sentry.close(timeout || 2000);
    } catch (error) {
      logger.error('Failed to close Sentry', { error });
      return false;
    }
  }
}

// Export singleton instance
export const monitoringService = new MonitoringService();