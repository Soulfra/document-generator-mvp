/**
 * Coverage Validation Script
 * 
 * Validates test coverage against defined thresholds and provides detailed reporting
 * for CI/CD pipeline quality gates.
 */

const fs = require('fs');
const path = require('path');

const COVERAGE_FILE = path.join(__dirname, '../coverage/coverage-summary.json');
const REQUIRED_THRESHOLDS = {
  lines: 80,
  functions: 80,
  branches: 75,
  statements: 80
};

// Critical modules requiring higher coverage
const CRITICAL_MODULES = {
  'src/services/payment.service.ts': { lines: 90, functions: 90, branches: 85, statements: 90 },
  'src/middleware/csrf.middleware.ts': { lines: 85, functions: 85, branches: 80, statements: 85 },
  'src/middleware/auth.middleware.ts': { lines: 85, functions: 85, branches: 80, statements: 85 },
  'src/utils/telemetry.ts': { lines: 80, functions: 80, branches: 75, statements: 80 }
};

async function main() {
  console.log('🔍 Validating test coverage...\n');

  try {
    // Check if coverage file exists
    if (!fs.existsSync(COVERAGE_FILE)) {
      console.error('❌ Coverage file not found. Run tests with coverage first.');
      process.exit(1);
    }

    // Load coverage data
    const coverageData = JSON.parse(fs.readFileSync(COVERAGE_FILE, 'utf8'));
    
    // Validate overall coverage
    const overallPassed = validateOverallCoverage(coverageData.total);
    
    // Validate critical modules
    const criticalPassed = validateCriticalModules(coverageData);
    
    // Generate coverage report
    generateCoverageReport(coverageData);
    
    if (overallPassed && criticalPassed) {
      console.log('\n✅ All coverage thresholds met!');
      process.exit(0);
    } else {
      console.log('\n❌ Coverage validation failed');
      process.exit(1);
    }
    
  } catch (error) {
    console.error('❌ Coverage validation error:', error.message);
    process.exit(1);
  }
}

function validateOverallCoverage(totalCoverage) {
  console.log('📊 Overall Coverage:');
  console.log('─'.repeat(50));
  
  let allPassed = true;
  
  for (const [metric, threshold] of Object.entries(REQUIRED_THRESHOLDS)) {
    const coverage = totalCoverage[metric];
    const passed = coverage.pct >= threshold;
    const status = passed ? '✅' : '❌';
    
    console.log(`${status} ${metric.padEnd(12)}: ${coverage.pct.toFixed(1)}% (required: ${threshold}%)`);
    
    if (!passed) {
      allPassed = false;
    }
  }
  
  return allPassed;
}

function validateCriticalModules(coverageData) {
  console.log('\n🚨 Critical Modules:');
  console.log('─'.repeat(50));
  
  let allPassed = true;
  
  for (const [module, thresholds] of Object.entries(CRITICAL_MODULES)) {
    const moduleCoverage = coverageData[module];
    
    if (!moduleCoverage) {
      console.log(`⚠️  ${module}: Not found in coverage report`);
      continue;
    }
    
    console.log(`\n📁 ${module}:`);
    
    for (const [metric, threshold] of Object.entries(thresholds)) {
      const coverage = moduleCoverage[metric];
      const passed = coverage.pct >= threshold;
      const status = passed ? '✅' : '❌';
      
      console.log(`   ${status} ${metric.padEnd(10)}: ${coverage.pct.toFixed(1)}% (required: ${threshold}%)`);
      
      if (!passed) {
        allPassed = false;
      }
    }
  }
  
  return allPassed;
}

function generateCoverageReport(coverageData) {
  console.log('\n📈 Coverage Summary:');
  console.log('─'.repeat(50));
  
  const total = coverageData.total;
  const covered = {
    lines: total.lines.covered,
    functions: total.functions.covered,
    branches: total.branches.covered,
    statements: total.statements.covered
  };
  
  const totalItems = {
    lines: total.lines.total,
    functions: total.functions.total,
    branches: total.branches.total,
    statements: total.statements.total
  };
  
  console.log(`Lines:      ${covered.lines}/${totalItems.lines} (${total.lines.pct.toFixed(1)}%)`);
  console.log(`Functions:  ${covered.functions}/${totalItems.functions} (${total.functions.pct.toFixed(1)}%)`);
  console.log(`Branches:   ${covered.branches}/${totalItems.branches} (${total.branches.pct.toFixed(1)}%)`);
  console.log(`Statements: ${covered.statements}/${totalItems.statements} (${total.statements.pct.toFixed(1)}%)`);
  
  // Calculate coverage trends (if previous data exists)
  const previousCoverageFile = path.join(__dirname, '../coverage/previous-coverage.json');
  if (fs.existsSync(previousCoverageFile)) {
    try {
      const previousData = JSON.parse(fs.readFileSync(previousCoverageFile, 'utf8'));
      console.log('\n📊 Coverage Trends:');
      console.log('─'.repeat(50));
      
      for (const metric of ['lines', 'functions', 'branches', 'statements']) {
        const current = total[metric].pct;
        const previous = previousData.total[metric].pct;
        const diff = current - previous;
        const trend = diff > 0 ? '📈' : diff < 0 ? '📉' : '➖';
        const diffStr = diff > 0 ? `+${diff.toFixed(1)}%` : `${diff.toFixed(1)}%`;
        
        console.log(`${trend} ${metric.padEnd(10)}: ${current.toFixed(1)}% (${diffStr})`);
      }
    } catch (error) {
      console.log('⚠️  Could not load previous coverage data for trends');
    }
  }
  
  // Save current coverage for next comparison
  fs.writeFileSync(previousCoverageFile, JSON.stringify(coverageData, null, 2));
}

// Handle script execution
if (require.main === module) {
  main().catch(error => {
    console.error('❌ Coverage check failed:', error);
    process.exit(1);
  });
}

module.exports = { 
  main, 
  validateOverallCoverage, 
  validateCriticalModules,
  REQUIRED_THRESHOLDS,
  CRITICAL_MODULES 
};