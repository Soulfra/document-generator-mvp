#!/usr/bin/env node

/**
 * Archive CLI - Unified command-line interface for archive automation
 * 
 * Combines all automation tools into a single, easy-to-use CLI
 * Production-safe with comprehensive error handling and validation
 */

const path = require('path');
const ChecklistParser = require('./checklist-parser');
const ArchiveManager = require('./archive-module');
const ArchiveIndexUpdater = require('./archive-index-updater');

class ArchiveCLI {
  constructor() {
    this.parser = new ChecklistParser();
    this.archiveManager = new ArchiveManager();
    this.indexUpdater = new ArchiveIndexUpdater();
  }

  /**
   * Check completion status of modules
   */
  async checkCommand(args) {
    const target = args[0];
    if (!target) {
      console.error('❌ Target path required for check command');
      process.exit(1);
    }

    const options = {
      json: args.includes('--json'),
      quiet: args.includes('--quiet')
    };

    try {
      let results;
      const fs = require('fs');
      
      if (fs.statSync(target).isDirectory()) {
        results = this.parser.parseDirectory(target);
      } else {
        results = this.parser.parseFile(target);
      }

      if (options.json) {
        console.log(JSON.stringify(results, null, 2));
      } else if (options.quiet) {
        console.log(results.isComplete ? 'COMPLETE' : 'INCOMPLETE');
      } else {
        console.log(this.parser.generateReport(results));
      }

      process.exit(results.isComplete ? 0 : 1);

    } catch (error) {
      console.error('❌ Check failed:', error.message);
      process.exit(2);
    }
  }

  /**
   * List modules with completion status
   */
  async listCommand(args) {
    const showCompleteOnly = args.includes('--complete-only');
    
    try {
      const modules = await this.archiveManager.listArchivableModules();
      const filteredModules = showCompleteOnly ? modules.filter(m => m.canArchive) : modules;
      
      if (filteredModules.length === 0) {
        console.log(showCompleteOnly ? '📭 No completed modules ready for archival' : '📭 No modules found');
        return;
      }

      console.log(showCompleteOnly ? '📋 Modules ready for archival:' : '📋 All modules:');
      console.log('');
      
      filteredModules.forEach(module => {
        const status = module.isComplete ? '✅' : '⏳';
        const percentage = `${module.completionPercentage}%`.padStart(4);
        const archivable = module.canArchive ? ' (ready for archive)' : '';
        console.log(`  ${status} ${percentage} ${module.name}${archivable}`);
      });

      if (!showCompleteOnly) {
        const readyCount = modules.filter(m => m.canArchive).length;
        console.log('');
        console.log(`📊 Summary: ${readyCount}/${modules.length} modules ready for archival`);
      }

    } catch (error) {
      console.error('❌ List failed:', error.message);
      process.exit(1);
    }
  }

  /**
   * Archive completed modules
   */
  async archiveCommand(args) {
    const target = args[0];
    if (!target) {
      console.error('❌ Target path required for archive command');
      process.exit(1);
    }

    const options = {
      force: args.includes('--force'),
      dryRun: args.includes('--dry-run'),
      skipCompletion: args.includes('--skip-completion'),
      customName: args.includes('--name') ? args[args.indexOf('--name') + 1] : null
    };

    try {
      const result = await this.archiveManager.archiveModule(target, options);
      
      if (result.success) {
        console.log(result.message);
        
        if (!options.dryRun) {
          // Update index automatically
          const moduleName = path.basename(target);
          await this.indexUpdater.addEntry({
            name: moduleName,
            summary: '✅ Archived via CLI',
            type: 'main'
          });
        }
      } else {
        console.error(result.message);
        process.exit(1);
      }

    } catch (error) {
      console.error('❌ Archive failed:', error.message);
      process.exit(1);
    }
  }

  /**
   * Archive all completed modules
   */
  async archiveAllCommand(args) {
    const options = {
      dryRun: args.includes('--dry-run'),
      force: args.includes('--force')
    };

    try {
      const modules = await this.archiveManager.listArchivableModules();
      const readyModules = modules.filter(m => m.canArchive);

      if (readyModules.length === 0) {
        console.log('📭 No modules ready for archival');
        return;
      }

      console.log(`📦 Found ${readyModules.length} modules ready for archival:`);
      readyModules.forEach(module => {
        console.log(`  ✅ ${module.name}`);
      });
      console.log('');

      if (options.dryRun) {
        console.log('🔍 DRY RUN - No files will be moved');
      }

      const results = [];
      for (const module of readyModules) {
        console.log(`📋 Processing: ${module.name}`);
        
        const result = await this.archiveManager.archiveModule(module.path, {
          dryRun: options.dryRun,
          force: options.force
        });
        
        results.push({ module: module.name, result });
        
        if (result.success && !options.dryRun) {
          // Update index
          await this.indexUpdater.addEntry({
            name: module.name,
            summary: '✅ Bulk archived via CLI',
            type: 'main'
          });
        }
      }

      // Summary
      const successful = results.filter(r => r.result.success).length;
      console.log('');
      console.log(`📊 Archive Summary: ${successful}/${results.length} successful`);
      
      if (successful < results.length) {
        console.log('❌ Failed modules:');
        results.filter(r => !r.result.success).forEach(r => {
          console.log(`  • ${r.module}: ${r.result.message}`);
        });
      }

    } catch (error) {
      console.error('❌ Bulk archive failed:', error.message);
      process.exit(1);
    }
  }

  /**
   * Index management commands
   */
  async indexCommand(args) {
    const subcommand = args[0];
    
    try {
      switch (subcommand) {
        case 'update':
          if (args.length < 2) {
            console.error('❌ Module name required for index update');
            process.exit(1);
          }
          
          const entry = {
            name: args[1],
            summary: args[2] || '✅ Manual index update',
            type: args.includes('--detailed') ? 'detailed' : 'main',
            details: {
              focusArea: args.includes('--focus-area') ? args[args.indexOf('--focus-area') + 1] : null,
              status: args.includes('--status') ? args[args.indexOf('--status') + 1] : null
            }
          };
          
          this.indexUpdater.addEntry(entry);
          break;

        case 'regenerate':
          this.indexUpdater.regenerateIndex();
          break;

        case 'validate':
          const validation = this.indexUpdater.validateArchive();
          console.log(validation.valid ? '✅ Archive index is valid' : '❌ Archive index has issues');
          if (!validation.valid) {
            validation.issues.forEach(issue => console.log(`  • ${issue}`));
            process.exit(1);
          }
          break;

        case 'report':
          console.log(this.indexUpdater.generateReport());
          break;

        default:
          console.error(`❌ Unknown index subcommand: ${subcommand}`);
          console.log('Available: update, regenerate, validate, report');
          process.exit(1);
      }
    } catch (error) {
      console.error('❌ Index command failed:', error.message);
      process.exit(1);
    }
  }

  /**
   * Status overview
   */
  async statusCommand() {
    try {
      console.log('📊 Archive System Status');
      console.log('========================\n');

      // Module completion status
      const modules = await this.archiveManager.listArchivableModules();
      const readyCount = modules.filter(m => m.canArchive).length;
      
      console.log(`📋 Modules: ${readyCount}/${modules.length} ready for archival`);
      
      // Index validation
      const validation = this.indexUpdater.validateArchive();
      console.log(`📄 Index: ${validation.valid ? 'Valid' : 'Issues found'}`);
      
      // Recent activity
      const archiveFiles = this.indexUpdater.scanArchiveFiles();
      console.log(`📁 Archive: ${archiveFiles.length} files total`);
      
      if (archiveFiles.length > 0) {
        const latest = archiveFiles[0];
        const latestDate = latest.modified.toISOString().split('T')[0];
        console.log(`📅 Latest: ${latest.name} (${latestDate})`);
      }

      console.log('');
      
      if (readyCount > 0) {
        console.log('💡 Ready modules:');
        modules.filter(m => m.canArchive).forEach(module => {
          console.log(`  ✅ ${module.name}`);
        });
        console.log('\n💻 Run: archive-cli archive-all --dry-run');
      }

      if (!validation.valid) {
        console.log('⚠️  Index issues found. Run: archive-cli index validate');
      }

    } catch (error) {
      console.error('❌ Status check failed:', error.message);
      process.exit(1);
    }
  }

  /**
   * Show help
   */
  showHelp() {
    console.log(`
Archive CLI - Automated module archival system

Usage: node archive-cli.js <command> [options]

Commands:
  check <path>              Check completion status of module
  list [--complete-only]    List modules with completion status
  archive <path> [opts]     Archive a specific module
  archive-all [--dry-run]   Archive all completed modules
  index <subcommand>        Manage archive index
  status                    Show overall system status
  help                      Show this help

Archive Options:
  --force                   Archive even if incomplete
  --dry-run                 Show what would happen without doing it
  --name <name>             Custom archive filename
  --skip-completion         Skip completion check

Index Subcommands:
  update <name> [summary]   Add entry to index
  regenerate               Rebuild index from files
  validate                 Check index integrity
  report                   Generate detailed report

Examples:
  # Check if module is complete
  archive-cli check ./cursor/future-work-module/

  # List all modules
  archive-cli list

  # List only completed modules
  archive-cli list --complete-only

  # Archive specific module (dry run)
  archive-cli archive ./cursor/some-module/ --dry-run

  # Archive all completed modules
  archive-cli archive-all

  # Get system status
  archive-cli status

  # Validate archive integrity
  archive-cli index validate

Production Safe:
  • All operations have --dry-run support
  • Automatic backups before archival
  • Comprehensive validation
  • No modifications to existing functionality
`);
  }

  /**
   * Main CLI entry point
   */
  async run() {
    const args = process.argv.slice(2);
    
    if (args.length === 0 || args.includes('--help') || args.includes('help')) {
      this.showHelp();
      return;
    }

    const command = args[0];
    const commandArgs = args.slice(1);

    try {
      switch (command) {
        case 'check':
          await this.checkCommand(commandArgs);
          break;
        case 'list':
          await this.listCommand(commandArgs);
          break;
        case 'archive':
          await this.archiveCommand(commandArgs);
          break;
        case 'archive-all':
          await this.archiveAllCommand(commandArgs);
          break;
        case 'index':
          await this.indexCommand(commandArgs);
          break;
        case 'status':
          await this.statusCommand();
          break;
        default:
          console.error(`❌ Unknown command: ${command}`);
          console.log('Run "archive-cli help" for usage information');
          process.exit(1);
      }
    } catch (error) {
      console.error('❌ Command failed:', error.message);
      process.exit(1);
    }
  }
}

// Run CLI if called directly
if (require.main === module) {
  const cli = new ArchiveCLI();
  cli.run().catch(error => {
    console.error('❌ Unexpected error:', error.message);
    process.exit(1);
  });
}

module.exports = ArchiveCLI;