import { logger } from '../utils/logger';
import { withErrorHandling, CodeAnalysisError } from '../utils/error-handler';
import { BaseParser, ParseResult } from '../parsers/base-parser';
import { PythonParser } from '../parsers/python-parser';
import { TypeScriptParser } from '../parsers/typescript-parser';
import { LanguageDetectionService } from './language-detection.service';
import { CodeAnalysis } from '../types/code-analysis';

export interface ParserIntegrationOptions {
  includePrivate?: boolean;
  includeTests?: boolean;
  maxDepth?: number;
  followImports?: boolean;
  primaryLanguageOnly?: boolean;
}

export class ParserIntegrationService {
  private static instance: ParserIntegrationService;
  private parsers: Map<string, BaseParser> = new Map();
  private languageDetectionService: LanguageDetectionService;

  private constructor() {
    this.languageDetectionService = LanguageDetectionService.getInstance();
    this.registerParsers();
  }

  static getInstance(): ParserIntegrationService {
    if (!ParserIntegrationService.instance) {
      ParserIntegrationService.instance = new ParserIntegrationService();
    }
    return ParserIntegrationService.instance;
  }

  private registerParsers(): void {
    // Register available parsers
    this.registerParser('python', new PythonParser());
    this.registerParser('typescript', new TypeScriptParser());
    this.registerParser('javascript', new TypeScriptParser()); // JS uses same parser
    // Future parsers will be registered here
  }

  registerParser(language: string, parser: BaseParser): void {
    this.parsers.set(language.toLowerCase(), parser);
    logger.info(`Registered parser for language: ${language}`);
  }

  getParser(language: string): BaseParser | undefined {
    return this.parsers.get(language.toLowerCase());
  }

  getSupportedLanguages(): string[] {
    return Array.from(this.parsers.keys());
  }

  /**
   * Analyze a codebase and extract comprehensive information
   */
  analyzeCodebase = withErrorHandling(
    async (
      files: Map<string, string>,
      options: ParserIntegrationOptions = {}
    ): Promise<CodeAnalysis> => {
      // Detect primary language and framework
      const languageResult = await this.languageDetectionService.detectLanguage(files);
      logger.info('🔍 Language detection completed', {
        primary: languageResult.primary,
        secondary: languageResult.secondary,
        confidence: languageResult.confidence,
        framework: languageResult.framework,
        fileCount: files.size,
        fileTypes: Array.from(files.keys()).map(f => this.getFileExtension(f)).filter((ext, i, arr) => arr.indexOf(ext) === i)
      });

      if (languageResult.primary === 'unknown') {
        throw new CodeAnalysisError('Unable to detect programming language');
      }

      // Get parser for primary language
      const primaryParser = this.getParser(languageResult.primary);
      if (!primaryParser) {
        throw new CodeAnalysisError(`No parser available for language: ${languageResult.primary}`);
      }

      // Configure parser with options (currently unused but may be needed for future parser configurations)
      // const _parserOptions = {
      //   includePrivate: options.includePrivate,
      //   includeTests: options.includeTests,
      //   maxDepth: options.maxDepth,
      //   followImports: options.followImports
      // };

      // Parse primary language files
      const primaryFiles = this.filterFilesByLanguage(files, languageResult.primary, primaryParser);
      logger.info('📝 Parsing primary language', {
        language: languageResult.primary,
        filteredFiles: primaryFiles.size,
        fileList: Array.from(primaryFiles.keys()).slice(0, 10) // Log first 10 files
      });
      
      const primaryResult = await primaryParser.parse(primaryFiles);
      logger.info('✅ Primary language parsing completed', {
        language: languageResult.primary,
        apis: primaryResult.apis.length,
        functions: primaryResult.functions.length,
        models: primaryResult.dataModels.length,
        dependencies: primaryResult.dependencies.length
      });

      // Initialize combined results
      let combinedResult: ParseResult = primaryResult;
      const languagesAnalyzed = [languageResult.primary];

      // Parse secondary languages if requested
      if (!options.primaryLanguageOnly && languageResult.secondary && languageResult.secondary.length > 0) {
        logger.info('🔄 Processing secondary languages', {
          secondaryLanguages: languageResult.secondary,
          primaryLanguageOnly: options.primaryLanguageOnly
        });
        
        for (const secondaryLang of languageResult.secondary) {
          const secondaryParser = this.getParser(secondaryLang);
          if (secondaryParser) {
            const secondaryFiles = this.filterFilesByLanguage(files, secondaryLang, secondaryParser);
            logger.info('📝 Parsing secondary language', {
              language: secondaryLang,
              filteredFiles: secondaryFiles.size,
              fileList: Array.from(secondaryFiles.keys()).slice(0, 5)
            });
            
            if (secondaryFiles.size > 0) {
              try {
                const secondaryResult = await secondaryParser.parse(secondaryFiles);
                logger.info('✅ Secondary language parsing completed', {
                  language: secondaryLang,
                  apis: secondaryResult.apis.length,
                  functions: secondaryResult.functions.length,
                  models: secondaryResult.dataModels.length,
                  dependencies: secondaryResult.dependencies.length
                });
                
                combinedResult = this.mergeParseResults(combinedResult, secondaryResult);
                languagesAnalyzed.push(secondaryLang);
              } catch (error) {
                logger.warn('⚠️ Failed to parse secondary language', {
                  language: secondaryLang,
                  error: error instanceof Error ? error.message : String(error),
                  fileCount: secondaryFiles.size
                });
              }
            } else {
              logger.info('ℹ️ No files found for secondary language', {
                language: secondaryLang
              });
            }
          } else {
            logger.warn('⚠️ No parser available for secondary language', {
              language: secondaryLang
            });
          }
        }
      }

      // Build code analysis result
      const analysis: CodeAnalysis = {
        projectInfo: {
          name: this.extractProjectName(files, languageResult.primary),
          description: this.extractProjectDescription(files, languageResult.primary),
          type: this.determineProjectType(combinedResult, languageResult),
          language: languageResult.primary,
          framework: languageResult.framework
        },
        apis: combinedResult.apis,
        dataModels: combinedResult.dataModels,
        functions: combinedResult.functions,
        dependencies: combinedResult.dependencies,
        testCoverage: this.calculateTestMetrics(combinedResult),
        architecture: this.analyzeArchitecture(combinedResult, files),
        businessLogic: this.extractBusinessRules(combinedResult),
        fileStructure: this.analyzeFileStructure(files, languagesAnalyzed)
      };

      // Log comprehensive analysis summary
      logger.info('🎉 Code analysis completed successfully', {
        projectName: analysis.projectInfo.name,
        projectType: analysis.projectInfo.type,
        primaryLanguage: analysis.projectInfo.language,
        framework: analysis.projectInfo.framework,
        languagesAnalyzed,
        summary: {
          apis: analysis.apis.length,
          functions: analysis.functions.length,
          dataModels: analysis.dataModels.length,
          dependencies: analysis.dependencies.length,
          testCoverage: analysis.testCoverage.coverage
        },
        architecture: {
          style: analysis.architecture.style,
          pattern: analysis.architecture.pattern
        },
        performance: {
          totalFiles: analysis.fileStructure.totalFiles,
          analysisTime: Date.now() - (performance.now() || 0) // Approximate
        }
      });

      return analysis;
    },
    'Failed to analyze codebase'
  );

  /**
   * Filter files by language based on parser's supported extensions
   */
  private filterFilesByLanguage(
    files: Map<string, string>,
    language: string,
    parser: BaseParser
  ): Map<string, string> {
    const supportedExtensions = parser.getSupportedExtensions();
    const filtered = new Map<string, string>();

    // Define config files that each language parser should handle
    const configFiles = {
      python: ['requirements.txt', 'setup.py', 'pyproject.toml', 'Pipfile', 'environment.yml'],
      typescript: ['package.json', 'tsconfig.json', 'package-lock.json', 'yarn.lock'],
      javascript: ['package.json', 'package-lock.json', 'yarn.lock'],
      java: ['pom.xml', 'build.gradle', 'gradle.properties'],
      go: ['go.mod', 'go.sum'],
      csharp: ['*.csproj', '*.sln', 'packages.config'],
      php: ['composer.json', 'composer.lock'],
      ruby: ['Gemfile', 'Gemfile.lock', '*.gemspec']
    };

    const languageConfigFiles = (configFiles as any)[language.toLowerCase()] || [];

    const debugInfo = {
      totalFiles: files.size,
      supportedExtensions,
      configFiles: languageConfigFiles,
      included: [] as string[],
      excluded: [] as string[]
    };

    for (const [filename, content] of files.entries()) {
      const ext = this.getFileExtension(filename);
      const basename = filename.split('/').pop() || filename;
      
      // Include files with supported extensions
      if (supportedExtensions.includes(ext)) {
        filtered.set(filename, content);
        debugInfo.included.push(`${filename} (ext: ${ext})`);
      }
      // Include relevant config files
      else if (languageConfigFiles.some((pattern: string) => {
        if (pattern.includes('*')) {
          // Handle wildcard patterns like *.csproj
          const regex = new RegExp(pattern.replace('*', '.*'));
          return regex.test(basename);
        }
        return basename === pattern || filename.endsWith('/' + pattern);
      })) {
        filtered.set(filename, content);
        debugInfo.included.push(`${filename} (config)`);
      } else {
        debugInfo.excluded.push(`${filename} (ext: ${ext})`);
      }
    }

    logger.info('🗂️ File filtering completed', {
      language,
      ...debugInfo,
      filteredCount: filtered.size,
      // Only log first few files to avoid spam
      includedSample: debugInfo.included.slice(0, 10),
      excludedSample: debugInfo.excluded.slice(0, 5)
    });

    return filtered;
  }

  /**
   * Merge parse results from multiple languages
   */
  private mergeParseResults(result1: ParseResult, result2: ParseResult): ParseResult {
    return {
      apis: [...result1.apis, ...result2.apis],
      functions: [...result1.functions, ...result2.functions],
      dataModels: [...result1.dataModels, ...result2.dataModels],
      dependencies: [...result1.dependencies, ...result2.dependencies],
      imports: [...result1.imports, ...result2.imports],
      comments: [...result1.comments, ...result2.comments],
      errors: [...result1.errors, ...result2.errors]
    };
  }

  /**
   * Extract project name from package files
   */
  private extractProjectName(files: Map<string, string>, _language: string): string {
    // Check package.json for JavaScript/TypeScript
    const packageJson = files.get('package.json');
    if (packageJson) {
      try {
        const pkg = JSON.parse(packageJson);
        if (pkg.name) return pkg.name;
      } catch {}
    }

    // Check setup.py for Python
    const setupPy = files.get('setup.py');
    if (setupPy) {
      const nameMatch = setupPy.match(/name\s*=\s*['"]([^'"]+)['"]/);
      if (nameMatch) return nameMatch[1] || 'unknown-project';
    }

    // Check pom.xml for Java
    const pomXml = files.get('pom.xml');
    if (pomXml) {
      const nameMatch = pomXml.match(/<artifactId>([^<]+)<\/artifactId>/);
      if (nameMatch) return nameMatch[1] || 'unknown-project';
    }

    // Default to directory name or unknown
    return 'unknown-project';
  }

  /**
   * Extract project description from various sources
   */
  private extractProjectDescription(files: Map<string, string>, _language: string): string {
    // Check README files
    const readmeFiles = ['README.md', 'README.rst', 'README.txt', 'README'];
    for (const readmeFile of readmeFiles) {
      const readme = files.get(readmeFile);
      if (readme) {
        // Extract first paragraph or first few lines
        const lines = readme.split('\n').filter(line => line.trim());
        if (lines.length > 0) {
          // Skip title if it's a markdown header
          const startIndex = lines[0]?.startsWith('#') ? 1 : 0;
          return lines.slice(startIndex, startIndex + 3).join(' ').trim();
        }
      }
    }

    // Check package.json description
    const packageJson = files.get('package.json');
    if (packageJson) {
      try {
        const pkg = JSON.parse(packageJson);
        if (pkg.description) return pkg.description;
      } catch {}
    }

    return 'No description available';
  }

  /**
   * Determine project type based on analysis results
   */
  private determineProjectType(
    result: ParseResult,
    languageResult: any
  ): string {
    // Check for web frameworks first (more specific than just having APIs)
    if (languageResult.framework) {
      const webFrameworks = ['react', 'angular', 'vue', 'django', 'flask', 'express', 'spring', 'rails'];
      if (webFrameworks.includes(languageResult.framework.toLowerCase())) {
        return 'webapp';
      }
    }

    // Check for pure API services (has APIs but no frontend frameworks)
    if (result.apis.length > 0) {
      if (result.apis.some(api => api.method)) {
        // If no frontend framework detected but has APIs, it's likely a pure API service
        return 'api';
      }
    }

    // Check for CLI indicators
    if (result.dependencies.some(dep => 
      ['click', 'argparse', 'commander', 'yargs'].includes(dep.name.toLowerCase())
    )) {
      return 'cli';
    }

    // Check for library indicators
    if (result.functions.length > result.apis.length * 2) {
      return 'library';
    }

    return 'application';
  }

  /**
   * Calculate test coverage metrics
   */
  private calculateTestMetrics(result: ParseResult): any {
    const testFiles = result.functions.filter(f => 
      f.file?.includes('test') || f.file?.includes('spec')
    );

    const testFunctions = testFiles.length;
    const totalFunctions = result.functions.filter(f => 
      !f.file?.includes('test') && !f.file?.includes('spec')
    ).length;

    return {
      testFiles: new Set(testFiles.map(f => f.file).filter(f => f !== undefined)).size,
      testFunctions,
      totalFunctions,
      coverage: totalFunctions > 0 ? Math.round((testFunctions / totalFunctions) * 100) : 0
    };
  }

  /**
   * Analyze code architecture
   */
  private analyzeArchitecture(result: ParseResult, files: Map<string, string>): any {
    const layers = {
      presentation: 0,
      business: 0,
      data: 0,
      infrastructure: 0
    };

    // Analyze based on file paths and content
    for (const [filename] of files) {
      const lowerFile = filename.toLowerCase();
      
      if (lowerFile.includes('controller') || lowerFile.includes('route') || 
          lowerFile.includes('view') || lowerFile.includes('component')) {
        layers.presentation++;
      } else if (lowerFile.includes('service') || lowerFile.includes('business') ||
                 lowerFile.includes('logic') || lowerFile.includes('usecase')) {
        layers.business++;
      } else if (lowerFile.includes('model') || lowerFile.includes('entity') ||
                 lowerFile.includes('repository') || lowerFile.includes('dao')) {
        layers.data++;
      } else if (lowerFile.includes('config') || lowerFile.includes('middleware') ||
                 lowerFile.includes('util') || lowerFile.includes('helper')) {
        layers.infrastructure++;
      }
    }

    // Determine architecture style
    let style = 'monolithic';
    if (layers.presentation > 0 && layers.business > 0 && layers.data > 0) {
      style = 'layered';
    }
    if (files.has('docker-compose.yml') || files.has('kubernetes.yaml')) {
      style = 'microservices';
    }

    return {
      style,
      layers,
      patterns: this.detectArchitecturePatterns(result)
    };
  }

  /**
   * Detect common architecture patterns
   */
  private detectArchitecturePatterns(result: ParseResult): string[] {
    const patterns: string[] = [];

    // MVC pattern
    if (result.dataModels.some(m => m.name.includes('Model')) &&
        result.functions.some(f => f.name.includes('Controller'))) {
      patterns.push('MVC');
    }

    // Repository pattern
    if (result.dataModels.some(m => m.name.includes('Repository'))) {
      patterns.push('Repository');
    }

    // Factory pattern
    if (result.functions.some(f => f.name.includes('Factory') || f.name.includes('create'))) {
      patterns.push('Factory');
    }

    // Observer pattern
    if (result.functions.some(f => f.name.includes('subscribe') || f.name.includes('notify'))) {
      patterns.push('Observer');
    }

    return patterns;
  }

  /**
   * Extract business rules from code
   */
  private extractBusinessRules(result: ParseResult): any[] {
    const rules: any[] = [];

    // Look for validation functions
    const validationFunctions = result.functions.filter(f => 
      f.name.toLowerCase().includes('validate') ||
      f.name.toLowerCase().includes('check') ||
      f.name.toLowerCase().includes('verify')
    );

    for (const func of validationFunctions) {
      rules.push({
        type: 'validation',
        name: func.name,
        description: func.description || `Validation rule: ${func.name}`,
        location: `${func.file}:${func.line}`
      });
    }

    // Look for business logic in comments
    const businessComments = result.comments.filter(c => 
      c.content.toLowerCase().includes('business rule') ||
      c.content.toLowerCase().includes('requirement') ||
      c.content.toLowerCase().includes('constraint')
    );

    for (const comment of businessComments) {
      rules.push({
        type: 'documented',
        name: 'Business Rule',
        description: comment.content,
        location: `${comment.file}:${comment.line}`
      });
    }

    return rules;
  }

  /**
   * Analyze file structure
   */
  private analyzeFileStructure(files: Map<string, string>, languages: string[]): any {
    const structure: any = {
      totalFiles: files.size,
      languages,
      directories: new Set<string>(),
      fileTypes: new Map<string, number>()
    };

    for (const [filename] of files) {
      // Extract directory
      const dir = filename.substring(0, filename.lastIndexOf('/'));
      if (dir) structure.directories.add(dir);

      // Count file types
      const ext = this.getFileExtension(filename);
      structure.fileTypes.set(ext, (structure.fileTypes.get(ext) || 0) + 1);
    }

    structure.directories = Array.from(structure.directories).sort();
    structure.fileTypes = Object.fromEntries(structure.fileTypes);

    return structure;
  }

  private getFileExtension(filename: string): string {
    const lastDot = filename.lastIndexOf('.');
    return lastDot >= 0 ? filename.slice(lastDot) : '';
  }
}

export const parserIntegrationService = ParserIntegrationService.getInstance();