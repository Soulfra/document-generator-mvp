/**
 * Microsoft Teams Plugin
 * Send messages to Teams channels
 */

import { BasePlugin } from '../base-plugin';
import { PluginMetadata, PluginField, PluginExecutionResult } from '../interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../../interfaces/workflow.interface';
import { DiscordTeamsIntegrationService } from '../../services/discord-teams-integration.service';

export default class TeamsPlugin extends BasePlugin {
  private teamsService: DiscordTeamsIntegrationService;
  
  metadata: PluginMetadata = {
    id: 'teams',
    name: 'Microsoft Teams',
    version: '1.0.0',
    description: 'Send messages to Microsoft Teams channels',
    author: 'FinishThisIdea',
    icon: '💼',
    category: 'notification',
    tags: ['teams', 'microsoft', 'chat', 'webhook']
  };
  
  fields: PluginField[] = [
    {
      name: 'channel',
      label: 'Channel Name',
      type: 'text',
      required: true,
      placeholder: 'general',
      description: 'Teams channel name (configured in automation config)'
    },
    {
      name: 'title',
      label: 'Card Title',
      type: 'text',
      required: true,
      placeholder: 'Workflow Notification',
      description: 'Title of the Teams card'
    },
    {
      name: 'text',
      label: 'Message Text',
      type: 'textarea',
      required: true,
      placeholder: 'Your message here...',
      description: 'Message body text'
    },
    {
      name: 'themeColor',
      label: 'Theme Color',
      type: 'text',
      required: false,
      default: '0076D7',
      placeholder: '0076D7',
      description: 'Card accent color (hex)'
    },
    {
      name: 'sections',
      label: 'Card Sections',
      type: 'json',
      required: false,
      placeholder: '[{"activityTitle": "Status", "activitySubtitle": "Complete"}]',
      description: 'Additional card sections'
    },
    {
      name: 'potentialAction',
      label: 'Actions',
      type: 'json',
      required: false,
      placeholder: '[{"@type": "OpenUri", "name": "View", "targets": [{"os": "default", "uri": "https://example.com"}]}]',
      description: 'Card action buttons'
    }
  ];
  
  constructor(config?: Record<string, any>) {
    super(config);
    this.teamsService = DiscordTeamsIntegrationService.getInstance();
  }
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    const { channel, title, text, themeColor, sections, potentialAction } = step;
    
    if (!channel || !title || !text) {
      return this.failure('Missing required fields: channel, title, text');
    }
    
    try {
      await this.teamsService.initialize();
      
      const { result, duration } = await this.measureExecution(async () => {
        return await this.teamsService.sendTeamsMessage(channel, {
          '@type': 'MessageCard',
          '@context': 'http://schema.org/extensions',
          themeColor: themeColor || '0076D7',
          summary: title,
          sections: [
            {
              activityTitle: title,
              text: text
            },
            ...(sections || [])
          ],
          potentialAction: potentialAction || []
        });
      });
      
      return this.success(result, duration, [`Message sent to Teams channel: ${channel}`]);
    } catch (error) {
      return this.failure(`Teams message failed: ${error.message}`);
    }
  }
}