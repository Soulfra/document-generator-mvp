/**
 * Email Plugin
 * Sends emails as workflow steps
 */

import { BasePlugin } from '../base-plugin';
import { PluginMetadata, PluginField, PluginExecutionResult } from '../interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../../interfaces/workflow.interface';
import { container } from '../../../inversify.config';
import { EmailService } from '../../../services/email.service';
import { TYPES } from '../../../types';

export default class EmailPlugin extends BasePlugin {
  private emailService: EmailService;
  
  metadata: PluginMetadata = {
    id: 'email',
    name: 'Send Email',
    version: '1.0.0',
    description: 'Send emails with templates and attachments',
    author: 'FinishThisIdea',
    icon: '📧',
    category: 'notification',
    tags: ['email', 'notification', 'smtp'],
    requiredConfig: ['SMTP_HOST', 'SMTP_USER', 'SMTP_PASS']
  };
  
  fields: PluginField[] = [
    {
      name: 'to',
      label: 'To',
      type: 'text',
      required: true,
      placeholder: 'user@example.com',
      description: 'Recipient email address (supports multiple comma-separated)',
      validation: {
        pattern: '^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$'
      }
    },
    {
      name: 'subject',
      label: 'Subject',
      type: 'text',
      required: true,
      placeholder: 'Workflow Notification',
      description: 'Email subject line'
    },
    {
      name: 'template',
      label: 'Template',
      type: 'select',
      required: false,
      options: [
        { value: 'workflow-complete', label: 'Workflow Complete' },
        { value: 'workflow-failed', label: 'Workflow Failed' },
        { value: 'custom', label: 'Custom HTML' }
      ],
      description: 'Email template to use'
    },
    {
      name: 'body',
      label: 'Body',
      type: 'textarea',
      required: false,
      placeholder: 'Email body content',
      description: 'Email body (HTML supported)'
    },
    {
      name: 'data',
      label: 'Template Data',
      type: 'json',
      required: false,
      placeholder: '{"name": "John", "status": "completed"}',
      description: 'Data for template variables'
    },
    {
      name: 'attachments',
      label: 'Attachments',
      type: 'json',
      required: false,
      placeholder: '[{"filename": "report.pdf", "path": "/tmp/report.pdf"}]',
      description: 'File attachments'
    },
    {
      name: 'cc',
      label: 'CC',
      type: 'text',
      required: false,
      placeholder: 'cc@example.com',
      description: 'CC recipients (comma-separated)'
    },
    {
      name: 'bcc',
      label: 'BCC',
      type: 'text',
      required: false,
      placeholder: 'bcc@example.com',
      description: 'BCC recipients (comma-separated)'
    }
  ];
  
  constructor(config?: Record<string, any>) {
    super(config);
    this.emailService = container.get<EmailService>(TYPES.EmailService);
  }
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    const { to, subject, template, body, data = {}, attachments = [], cc, bcc } = step;
    
    if (!to || !subject) {
      return this.failure('Missing required fields: to, subject');
    }
    
    try {
      const { result, duration } = await this.measureExecution(async () => {
        // Parse multiple recipients
        const recipients = to.split(',').map((email: string) => email.trim());
        
        // Prepare email options
        const emailData: any = {
          subject,
          data: { ...context.variables, ...data }
        };
        
        // Handle template vs custom body
        if (template && template !== 'custom') {
          emailData.template = template;
        } else if (body) {
          emailData.html = body;
        } else {
          throw new Error('Either template or body must be provided');
        }
        
        // Add optional fields
        if (cc) emailData.cc = cc.split(',').map((email: string) => email.trim());
        if (bcc) emailData.bcc = bcc.split(',').map((email: string) => email.trim());
        if (attachments && attachments.length > 0) {
          emailData.attachments = attachments;
        }
        
        // Send emails
        const results = await Promise.all(
          recipients.map(recipient => 
            this.emailService.sendEmail(recipient, emailData)
          )
        );
        
        return {
          sent: recipients.length,
          messageIds: results.map(r => r.messageId).filter(Boolean)
        };
      });
      
      this.logger.info(`Sent ${result.sent} emails in ${duration}ms`);
      
      return this.success(result, duration, [
        `Sent to ${result.sent} recipient(s)`,
        template ? `Using template: ${template}` : 'Custom email body'
      ]);
      
    } catch (error) {
      this.logger.error('Email sending failed:', error);
      return this.failure(`Failed to send email: ${error.message}`);
    }
  }
  
  async testConnection(): Promise<{ success: boolean; message?: string }> {
    try {
      const testResult = await this.emailService.verifyConnection();
      return {
        success: testResult,
        message: testResult ? 'Email service is configured correctly' : 'Email service configuration error'
      };
    } catch (error) {
      return {
        success: false,
        message: `Email service test failed: ${error.message}`
      };
    }
  }
}