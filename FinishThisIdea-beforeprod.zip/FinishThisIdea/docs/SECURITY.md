---
title: "Security Guidelines"
description: "Comprehensive security guidelines and best practices for the Document Generator project"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Security Guidelines

Comprehensive security guidelines and best practices for the Document Generator project.

## 🛡️ Security Overview

The Document Generator handles sensitive data including user code, payment information, and generated documentation. This document outlines security measures, best practices, and incident response procedures.

## 🔐 Authentication & Authorization

### Current Implementation (MVP)
- **No authentication required** for MVP phase
- All operations are anonymous
- Session-based job tracking

### Planned Authentication (Future)
```typescript
// JWT-based authentication
interface AuthToken {
  userId: string;
  email: string;
  role: 'user' | 'admin';
  iat: number;
  exp: number;
}

// Example middleware
const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as AuthToken;
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid token' });
  }
};
```

### API Key Management
```typescript
// Secure API key storage
interface APIKey {
  id: string;
  userId: string;
  name: string;
  keyHash: string;  // Never store plain text
  permissions: string[];
  lastUsed: Date;
  expiresAt: Date;
}

// Key validation
const validateAPIKey = async (key: string): Promise<APIKey | null> => {
  const hash = crypto.createHash('sha256').update(key).digest('hex');
  return await prisma.apiKey.findFirst({
    where: { 
      keyHash: hash,
      expiresAt: { gt: new Date() }
    }
  });
};
```

## 🔒 Data Protection

### Data Classification
1. **Public**: Documentation templates, language parsers
2. **Internal**: System logs, analytics data
3. **Confidential**: User code, payment data
4. **Restricted**: API keys, encryption keys

### Encryption at Rest
```typescript
// Sensitive data encryption
import crypto from 'crypto';

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY!; // 32 bytes
const ALGORITHM = 'aes-256-gcm';

export function encrypt(text: string): string {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipher(ALGORITHM, ENCRYPTION_KEY);
  cipher.setAAD(Buffer.from('finishthisidea'));
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const authTag = cipher.getAuthTag();
  
  return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
}

export function decrypt(encryptedData: string): string {
  const [ivHex, authTagHex, encrypted] = encryptedData.split(':');
  
  const iv = Buffer.from(ivHex, 'hex');
  const authTag = Buffer.from(authTagHex, 'hex');
  
  const decipher = crypto.createDecipher(ALGORITHM, ENCRYPTION_KEY);
  decipher.setAAD(Buffer.from('finishthisidea'));
  decipher.setAuthTag(authTag);
  
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
}
```

### Encryption in Transit
```nginx
# Nginx SSL configuration
server {
    listen 443 ssl http2;
    
    ssl_certificate /etc/ssl/certs/fullchain.pem;
    ssl_certificate_key /etc/ssl/private/privkey.pem;
    
    # Modern SSL configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    
    # HSTS
    add_header Strict-Transport-Security "max-age=63072000" always;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
```

## 🛡️ Input Validation & Sanitization

### File Upload Security
```typescript
// Secure file upload validation
const ALLOWED_MIME_TYPES = [
  'application/zip',
  'application/x-tar',
  'application/gzip'
];

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

export function validateUpload(file: Express.Multer.File): ValidationResult {
  // Check file size
  if (file.size > MAX_FILE_SIZE) {
    return { valid: false, error: 'File too large' };
  }
  
  // Check MIME type
  if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
    return { valid: false, error: 'Invalid file type' };
  }
  
  // Check file signature (magic bytes)
  const buffer = file.buffer.slice(0, 10);
  if (!isValidArchive(buffer)) {
    return { valid: false, error: 'Invalid file format' };
  }
  
  // Scan for malicious content
  if (containsMaliciousContent(file.buffer)) {
    return { valid: false, error: 'Malicious content detected' };
  }
  
  return { valid: true };
}

function isValidArchive(buffer: Buffer): boolean {
  // ZIP signature: 50 4B (PK)
  if (buffer[0] === 0x50 && buffer[1] === 0x4B) return true;
  
  // TAR signature: ustar (at offset 257)
  // GZIP signature: 1F 8B
  if (buffer[0] === 0x1F && buffer[1] === 0x8B) return true;
  
  return false;
}
```

### API Input Validation
```typescript
// Zod schemas for API validation
import { z } from 'zod';

export const JobCreateSchema = z.object({
  contextProfileId: z.string().uuid().optional(),
  options: z.object({
    generateDocs: z.boolean().default(true),
    maxFiles: z.number().min(1).max(1000).default(100),
    timeout: z.number().min(60).max(1800).default(300)
  }).optional()
});

export const PaymentSchema = z.object({
  jobId: z.string().uuid(),
  successUrl: z.string().url(),
  cancelUrl: z.string().url()
});

// Middleware for validation
export const validateInput = (schema: z.ZodSchema) => {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      req.body = schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          error: 'Validation failed',
          details: error.errors
        });
      }
      next(error);
    }
  };
};
```

### SQL Injection Prevention
```typescript
// Safe database queries with Prisma
export async function getUserJobs(userId: string, status?: JobStatus) {
  // Prisma automatically parameterizes queries
  return await prisma.job.findMany({
    where: {
      userId, // Safe parameter binding
      ...(status && { status }) // Conditional filtering
    },
    select: {
      id: true,
      status: true,
      createdAt: true,
      // Never select sensitive fields directly
    }
  });
}

// For raw queries, use parameterization
export async function getJobStats(startDate: Date) {
  return await prisma.$queryRaw`
    SELECT status, COUNT(*) as count
    FROM jobs 
    WHERE created_at >= ${startDate}
    GROUP BY status
  `;
}
```

## 🚦 Rate Limiting & DDoS Protection

### Application-Level Rate Limiting
```typescript
import rateLimit from 'express-rate-limit';
import RedisStore from 'rate-limit-redis';

// Global rate limit
export const globalLimiter = rateLimit({
  store: new RedisStore({
    client: redisClient,
    prefix: 'rl:global:'
  }),
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per window
  message: 'Too many requests from this IP',
  standardHeaders: true,
  legacyHeaders: false
});

// API-specific rate limits
export const uploadLimiter = rateLimit({
  store: new RedisStore({
    client: redisClient,
    prefix: 'rl:upload:'
  }),
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 5, // 5 uploads per hour
  message: 'Upload limit exceeded'
});

// Payment rate limiting
export const paymentLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 3, // 3 payment attempts per minute
  message: 'Too many payment attempts'
});
```

### Infrastructure-Level Protection
```nginx
# Nginx rate limiting
http {
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=upload:10m rate=1r/s;
    
    server {
        location /api/ {
            limit_req zone=api burst=20 nodelay;
            limit_req_status 429;
        }
        
        location /api/upload {
            limit_req zone=upload burst=3 nodelay;
            client_max_body_size 50m;
        }
    }
}
```

## 🔍 Security Headers

### Express Security Middleware
```typescript
import helmet from 'helmet';

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://js.stripe.com"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://api.stripe.com"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["https://js.stripe.com"]
    }
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
}));

// Additional security headers
app.use((req, res, next) => {
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  next();
});
```

## 🔐 Secrets Management

### Environment Security
```typescript
// Secure environment validation
function validateSecrets() {
  const requiredSecrets = [
    'JWT_SECRET',
    'ENCRYPTION_KEY',
    'STRIPE_SECRET_KEY',
    'DATABASE_URL'
  ];

  const missing = requiredSecrets.filter(key => !process.env[key]);
  if (missing.length > 0) {
    throw new Error(`Missing critical secrets: ${missing.join(', ')}`);
  }

  // Validate secret strength
  if (process.env.JWT_SECRET!.length < 32) {
    throw new Error('JWT_SECRET must be at least 32 characters');
  }

  if (process.env.ENCRYPTION_KEY!.length !== 32) {
    throw new Error('ENCRYPTION_KEY must be exactly 32 characters');
  }
}
```

### Secret Rotation
```bash
#!/bin/bash
# rotate-secrets.sh

# Generate new secrets
NEW_JWT_SECRET=$(openssl rand -base64 32)
NEW_ENCRYPTION_KEY=$(openssl rand -base64 32)

# Update environment
kubectl create secret generic app-secrets-new \
  --from-literal=JWT_SECRET="$NEW_JWT_SECRET" \
  --from-literal=ENCRYPTION_KEY="$NEW_ENCRYPTION_KEY"

# Rolling update
kubectl patch deployment api -p '{"spec":{"template":{"spec":{"containers":[{"name":"api","env":[{"name":"SECRET_VERSION","value":"'$(date +%s)'"}]}]}}}}'

# Cleanup old secrets after validation
kubectl delete secret app-secrets-old
```

## 🔒 Payment Security

### Stripe Integration Security
```typescript
// Secure payment processing
export async function createPaymentIntent(jobId: string, amount: number) {
  // Validate amount server-side
  if (amount !== 100) { // $1.00 in cents
    throw new Error('Invalid payment amount');
  }

  // Create payment intent with metadata
  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency: 'usd',
    metadata: {
      jobId,
      service: 'document-generator'
    },
    automatic_payment_methods: {
      enabled: true
    }
  });

  // Log payment creation (without sensitive data)
  logger.info('Payment intent created', {
    paymentIntentId: paymentIntent.id,
    jobId,
    amount
  });

  return paymentIntent;
}

// Webhook signature verification
export function verifyWebhookSignature(payload: string, signature: string): boolean {
  try {
    stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
    return true;
  } catch (error) {
    logger.error('Webhook signature verification failed', { error });
    return false;
  }
}
```

### PCI Compliance
- **No card data storage** - All payment processing through Stripe
- **HTTPS everywhere** - All payment-related communications encrypted
- **Webhook validation** - All payment webhooks cryptographically verified
- **Audit logging** - All payment events logged securely

## 🔍 Monitoring & Logging

### Security Event Logging
```typescript
// Security event logger
export class SecurityLogger {
  static logAuthAttempt(ip: string, success: boolean, userId?: string) {
    logger.info('Authentication attempt', {
      type: 'auth_attempt',
      ip,
      success,
      userId,
      timestamp: new Date().toISOString()
    });
  }

  static logSuspiciousActivity(ip: string, activity: string, details: any) {
    logger.warn('Suspicious activity detected', {
      type: 'suspicious_activity',
      ip,
      activity,
      details,
      timestamp: new Date().toISOString()
    });
    
    // Alert security team for critical events
    if (activity === 'multiple_failed_logins' || activity === 'malicious_upload') {
      this.alertSecurityTeam(ip, activity, details);
    }
  }

  static logDataAccess(userId: string, resource: string, action: string) {
    logger.info('Data access', {
      type: 'data_access',
      userId,
      resource,
      action,
      timestamp: new Date().toISOString()
    });
  }

  private static async alertSecurityTeam(ip: string, activity: string, details: any) {
    // Implement alerting mechanism (email, Slack, PagerDuty, etc.)
  }
}
```

### Intrusion Detection
```typescript
// Simple intrusion detection
export class IntrusionDetection {
  private static suspiciousIPs = new Map<string, number>();

  static checkSuspiciousActivity(req: Request): boolean {
    const ip = req.ip;
    const userAgent = req.get('User-Agent') || '';
    
    // Check for suspicious patterns
    if (this.isMaliciousUserAgent(userAgent)) {
      this.flagIP(ip, 'malicious_user_agent');
      return true;
    }

    // Check for rapid requests
    if (this.isRapidRequests(ip)) {
      this.flagIP(ip, 'rapid_requests');
      return true;
    }

    return false;
  }

  private static isMaliciousUserAgent(userAgent: string): boolean {
    const suspiciousPatterns = [
      /sqlmap/i,
      /nmap/i,
      /nikto/i,
      /dirb/i,
      /acunetix/i
    ];
    
    return suspiciousPatterns.some(pattern => pattern.test(userAgent));
  }

  private static flagIP(ip: string, reason: string) {
    const count = this.suspiciousIPs.get(ip) || 0;
    this.suspiciousIPs.set(ip, count + 1);
    
    SecurityLogger.logSuspiciousActivity(ip, reason, { count: count + 1 });
    
    // Block IP after multiple incidents
    if (count >= 3) {
      this.blockIP(ip);
    }
  }

  private static blockIP(ip: string) {
    // Implement IP blocking (firewall rules, fail2ban, etc.)
    logger.error('IP blocked due to suspicious activity', { ip });
  }
}
```

## 🚨 Incident Response

### Security Incident Procedures

1. **Detection**
   - Automated monitoring alerts
   - Manual security reviews
   - User reports

2. **Assessment**
   - Determine severity level
   - Identify affected systems
   - Estimate impact scope

3. **Containment**
   - Isolate affected systems
   - Block malicious traffic
   - Preserve evidence

4. **Eradication**
   - Remove malicious content
   - Patch vulnerabilities
   - Update security rules

5. **Recovery**
   - Restore from clean backups
   - Monitor for reoccurrence
   - Update documentation

6. **Lessons Learned**
   - Post-incident review
   - Update procedures
   - Improve monitoring

### Emergency Contacts
```typescript
// Emergency response contacts
const SECURITY_CONTACTS = {
  lead: 'security-lead@finishthisidea.com',
  team: 'security-team@finishthisidea.com',
  legal: 'legal@finishthisidea.com',
  pr: 'pr@finishthisidea.com'
};

// Incident severity levels
enum IncidentSeverity {
  LOW = 'low',           // Minor security concern
  MEDIUM = 'medium',     // Potential security risk
  HIGH = 'high',         // Active security threat
  CRITICAL = 'critical'  // Data breach or system compromise
}
```

## 🔒 Vulnerability Management

### Security Scanning
```bash
# Automated security scanning
npm audit --audit-level moderate
npm audit fix

# Docker image scanning
docker scan finishthisidea/api:latest

# OWASP ZAP scanning
docker run -v $(pwd):/zap/wrk/:rw -t owasp/zap2docker-stable zap-baseline.py \
  -t http://localhost:3001 -g gen.conf -r testreport.html
```

### Dependency Management
```json
{
  "scripts": {
    "security:audit": "npm audit --audit-level moderate",
    "security:update": "npm update && npm audit fix",
    "security:check": "snyk test",
    "security:monitor": "snyk monitor"
  }
}
```

### Regular Security Tasks
- **Daily**: Automated vulnerability scans
- **Weekly**: Dependency updates and audits
- **Monthly**: Security code reviews
- **Quarterly**: Penetration testing
- **Annually**: Full security audit

## 📋 Security Checklist

### Development Security
- [ ] Input validation on all endpoints
- [ ] Output encoding/sanitization
- [ ] Parameterized database queries
- [ ] Error handling without information disclosure
- [ ] Secure file upload handling
- [ ] Rate limiting implementation
- [ ] Security headers configuration
- [ ] Dependency vulnerability scanning

### Infrastructure Security
- [ ] HTTPS/TLS encryption
- [ ] Firewall configuration
- [ ] Database access controls
- [ ] Container security scanning
- [ ] Network segmentation
- [ ] Log aggregation and monitoring
- [ ] Backup encryption
- [ ] Disaster recovery testing

### Operational Security
- [ ] Access control reviews
- [ ] Secret rotation procedures
- [ ] Incident response plan
- [ ] Security training for team
- [ ] Compliance documentation
- [ ] Third-party security assessments
- [ ] Bug bounty program consideration

## 📞 Reporting Vulnerabilities

### Responsible Disclosure
If you discover a security vulnerability, please report it responsibly:

**Email**: security@finishthisidea.com  
**PGP Key**: [Download public key](./security-pgp-key.asc)

### What to Include
- Description of the vulnerability
- Steps to reproduce
- Potential impact assessment
- Suggested remediation (if any)

### Our Commitment
- **Acknowledgment**: Within 24 hours
- **Initial assessment**: Within 72 hours
- **Regular updates**: Every 5 business days
- **Resolution**: Based on severity (1-90 days)

We appreciate security researchers who help keep our platform secure!

---

**Last Updated**: 2024-01-15  
**Security Version**: 1.0.0