import axios, { AxiosResponse } from 'axios';
import { logger } from '../../utils/logger';

export interface DiscordMessage {
  content?: string;
  embeds?: DiscordEmbed[];
  username?: string;
  avatar_url?: string;
  tts?: boolean;
}

export interface DiscordEmbed {
  title?: string;
  description?: string;
  url?: string;
  timestamp?: string;
  color?: number;
  footer?: {
    text: string;
    icon_url?: string;
  };
  image?: {
    url: string;
  };
  thumbnail?: {
    url: string;
  };
  author?: {
    name: string;
    url?: string;
    icon_url?: string;
  };
  fields?: Array<{
    name: string;
    value: string;
    inline?: boolean;
  }>;
}

export interface TeamsMessage {
  '@type': string;
  '@context': string;
  summary: string;
  themeColor?: string;
  title?: string;
  text?: string;
  sections?: TeamsSection[];
  potentialAction?: TeamsAction[];
}

export interface TeamsSection {
  activityTitle?: string;
  activitySubtitle?: string;
  activityImage?: string;
  facts?: Array<{
    name: string;
    value: string;
  }>;
  markdown?: boolean;
}

export interface TeamsAction {
  '@type': string;
  name: string;
  targets: Array<{
    os: string;
    uri: string;
  }>;
}

export interface NotificationChannel {
  type: 'discord' | 'teams';
  webhook: string;
  name?: string;
}

export class DiscordTeamsIntegrationService {
  private channels: Map<string, NotificationChannel> = new Map();
  private isEnabled = false;

  constructor() {
    this.loadConfiguration();
  }

  private loadConfiguration(): void {
    try {
      // Load Discord webhooks
      const discordWebhooks = process.env.DISCORD_WEBHOOKS;
      if (discordWebhooks) {
        const webhooks = JSON.parse(discordWebhooks);
        Object.entries(webhooks).forEach(([name, webhook]) => {
          this.channels.set(name, {
            type: 'discord',
            webhook: webhook as string,
            name
          });
        });
      }

      // Load Teams webhooks
      const teamsWebhooks = process.env.TEAMS_WEBHOOKS;
      if (teamsWebhooks) {
        const webhooks = JSON.parse(teamsWebhooks);
        Object.entries(webhooks).forEach(([name, webhook]) => {
          this.channels.set(name, {
            type: 'teams',
            webhook: webhook as string,
            name
          });
        });
      }

      this.isEnabled = this.channels.size > 0;
      
      if (this.isEnabled) {
        logger.info('Discord/Teams integration enabled', { 
          channels: Array.from(this.channels.keys()),
          discord: Array.from(this.channels.values()).filter(c => c.type === 'discord').length,
          teams: Array.from(this.channels.values()).filter(c => c.type === 'teams').length
        });
      } else {
        logger.warn('Discord/Teams integration disabled - no webhooks configured');
      }
    } catch (error) {
      logger.error('Failed to load Discord/Teams configuration', { error });
      this.isEnabled = false;
    }
  }

  public isAvailable(): boolean {
    return this.isEnabled;
  }

  public getAvailableChannels(): string[] {
    return Array.from(this.channels.keys());
  }

  public async sendDiscordMessage(channelName: string, message: DiscordMessage): Promise<any> {
    if (!this.isEnabled) {
      logger.warn('Discord integration not enabled');
      return null;
    }

    const channel = this.channels.get(channelName);
    if (!channel || channel.type !== 'discord') {
      throw new Error(`Discord channel '${channelName}' not found`);
    }

    try {
      const response: AxiosResponse = await axios.post(channel.webhook, message, {
        headers: {
          'Content-Type': 'application/json',
        },
        timeout: 10000,
      });

      logger.info('Discord message sent successfully', {
        channel: channelName,
        status: response.status,
        messageLength: message.content?.length || 0,
        embedCount: message.embeds?.length || 0
      });

      return response.data;
    } catch (error) {
      logger.error('Failed to send Discord message', {
        channel: channelName,
        error: error instanceof Error ? error.message : String(error),
        webhook: channel.webhook.substring(0, 50) + '...'
      });
      throw error;
    }
  }

  public async sendTeamsMessage(channelName: string, message: TeamsMessage): Promise<any> {
    if (!this.isEnabled) {
      logger.warn('Teams integration not enabled');
      return null;
    }

    const channel = this.channels.get(channelName);
    if (!channel || channel.type !== 'teams') {
      throw new Error(`Teams channel '${channelName}' not found`);
    }

    try {
      const response: AxiosResponse = await axios.post(channel.webhook, message, {
        headers: {
          'Content-Type': 'application/json',
        },
        timeout: 10000,
      });

      logger.info('Teams message sent successfully', {
        channel: channelName,
        status: response.status,
        title: message.title,
        sections: message.sections?.length || 0
      });

      return response.data;
    } catch (error) {
      logger.error('Failed to send Teams message', {
        channel: channelName,
        error: error instanceof Error ? error.message : String(error),
        webhook: channel.webhook.substring(0, 50) + '...'
      });
      throw error;
    }
  }

  public async sendNotification(channelName: string, notification: {
    title: string;
    message: string;
    type?: 'info' | 'success' | 'warning' | 'error';
    url?: string;
    fields?: Array<{ name: string; value: string }>;
  }): Promise<any> {
    const channel = this.channels.get(channelName);
    if (!channel) {
      throw new Error(`Channel '${channelName}' not found`);
    }

    if (channel.type === 'discord') {
      return this.sendDiscordNotification(channelName, notification);
    } else {
      return this.sendTeamsNotification(channelName, notification);
    }
  }

  private async sendDiscordNotification(channelName: string, notification: {
    title: string;
    message: string;
    type?: 'info' | 'success' | 'warning' | 'error';
    url?: string;
    fields?: Array<{ name: string; value: string }>;
  }): Promise<any> {
    const colors = {
      info: 0x3b82f6,    // Blue
      success: 0x10b981, // Green
      warning: 0xf59e0b, // Yellow
      error: 0xef4444    // Red
    };

    const embed: DiscordEmbed = {
      title: notification.title,
      description: notification.message,
      color: colors[notification.type || 'info'],
      timestamp: new Date().toISOString(),
      footer: {
        text: 'FinishThisIdea Automation'
      }
    };

    if (notification.url) {
      embed.url = notification.url;
    }

    if (notification.fields && notification.fields.length > 0) {
      embed.fields = notification.fields.map(field => ({
        name: field.name,
        value: field.value,
        inline: true
      }));
    }

    const message: DiscordMessage = {
      embeds: [embed],
      username: 'FinishThisIdea Bot'
    };

    return this.sendDiscordMessage(channelName, message);
  }

  private async sendTeamsNotification(channelName: string, notification: {
    title: string;
    message: string;
    type?: 'info' | 'success' | 'warning' | 'error';
    url?: string;
    fields?: Array<{ name: string; value: string }>;
  }): Promise<any> {
    const colors = {
      info: '0078D4',    // Microsoft Blue
      success: '107C10', // Green
      warning: 'FF8C00', // Orange
      error: 'D13438'    // Red
    };

    const message: TeamsMessage = {
      '@type': 'MessageCard',
      '@context': 'http://schema.org/extensions',
      summary: notification.title,
      themeColor: colors[notification.type || 'info'],
      title: notification.title,
      text: notification.message
    };

    if (notification.fields && notification.fields.length > 0) {
      message.sections = [{
        facts: notification.fields.map(field => ({
          name: field.name,
          value: field.value
        }))
      }];
    }

    if (notification.url) {
      message.potentialAction = [{
        '@type': 'OpenUri',
        name: 'View Details',
        targets: [{
          os: 'default',
          uri: notification.url
        }]
      }];
    }

    return this.sendTeamsMessage(channelName, message);
  }

  public async sendDeploymentNotification(environment: string, status: 'started' | 'success' | 'failure', details?: {
    version?: string;
    duration?: number;
    url?: string;
    error?: string;
  }): Promise<void> {
    if (!this.isEnabled) return;

    const emoji = {
      started: '🚀',
      success: '✅',
      failure: '❌'
    };

    const type = status === 'success' ? 'success' : status === 'failure' ? 'error' : 'info';
    
    const fields: Array<{ name: string; value: string }> = [
      { name: 'Environment', value: environment },
      { name: 'Status', value: status.toUpperCase() }
    ];

    if (details?.version) {
      fields.push({ name: 'Version', value: details.version });
    }

    if (details?.duration) {
      fields.push({ name: 'Duration', value: `${details.duration}ms` });
    }

    if (details?.error) {
      fields.push({ name: 'Error', value: details.error });
    }

    const notification = {
      title: `${emoji[status]} Deployment ${status.charAt(0).toUpperCase() + status.slice(1)}`,
      message: `Deployment to ${environment} has ${status}`,
      type,
      url: details?.url,
      fields
    };

    // Send to all available channels
    const promises = Array.from(this.channels.keys()).map(async (channelName) => {
      try {
        await this.sendNotification(channelName, notification);
      } catch (error) {
        logger.error('Failed to send deployment notification', { 
          channel: channelName, 
          error: error instanceof Error ? error.message : String(error) 
        });
      }
    });

    await Promise.allSettled(promises);
  }

  public async sendWorkflowNotification(workflowName: string, status: 'started' | 'completed' | 'failed', details?: {
    duration?: number;
    stepCount?: number;
    errorStep?: string;
    error?: string;
  }): Promise<void> {
    if (!this.isEnabled) return;

    const emoji = {
      started: '▶️',
      completed: '✅',
      failed: '❌'
    };

    const type = status === 'completed' ? 'success' : status === 'failed' ? 'error' : 'info';
    
    const fields: Array<{ name: string; value: string }> = [
      { name: 'Workflow', value: workflowName },
      { name: 'Status', value: status.toUpperCase() }
    ];

    if (details?.stepCount) {
      fields.push({ name: 'Steps', value: details.stepCount.toString() });
    }

    if (details?.duration) {
      fields.push({ name: 'Duration', value: `${details.duration}ms` });
    }

    if (details?.errorStep) {
      fields.push({ name: 'Failed Step', value: details.errorStep });
    }

    if (details?.error) {
      fields.push({ name: 'Error', value: details.error });
    }

    const notification = {
      title: `${emoji[status]} Workflow ${status.charAt(0).toUpperCase() + status.slice(1)}`,
      message: `Workflow "${workflowName}" has ${status}`,
      type,
      fields
    };

    // Send to workflow channels only
    const workflowChannels = Array.from(this.channels.keys()).filter(name => 
      name.includes('workflow') || name.includes('automation')
    );

    if (workflowChannels.length === 0) {
      // Fallback to first available channel
      workflowChannels.push(Array.from(this.channels.keys())[0]);
    }

    const promises = workflowChannels.map(async (channelName) => {
      try {
        await this.sendNotification(channelName, notification);
      } catch (error) {
        logger.error('Failed to send workflow notification', { 
          channel: channelName, 
          error: error instanceof Error ? error.message : String(error) 
        });
      }
    });

    await Promise.allSettled(promises);
  }
}

export const discordTeamsService = new DiscordTeamsIntegrationService();