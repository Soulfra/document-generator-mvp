/**
 * Project Invite Model
 * Manages invitations to join projects
 */

import { 
  Table, 
  Column, 
  Model, 
  DataType, 
  PrimaryKey,
  Default,
  CreatedAt,
  UpdatedAt,
  ForeignKey,
  BelongsTo
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { Project } from './project.model';
import { User } from './user.model';
import { ProjectRole } from './project-member.model';

@Table({
  tableName: 'project_invites',
  timestamps: true
})
export class ProjectInvite extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @ForeignKey(() => Project)
  @Column({
    type: DataType.UUID,
    allowNull: false
  })
  projectId!: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
    validate: {
      isEmail: true
    }
  })
  email!: string;

  @Column({
    type: DataType.ENUM('owner', 'admin', 'member', 'viewer'),
    allowNull: false,
    defaultValue: 'member'
  })
  role!: ProjectRole;

  @ForeignKey(() => User)
  @Column({
    type: DataType.UUID,
    allowNull: false
  })
  invitedBy!: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
    unique: true
  })
  token!: string;

  @Column({
    type: DataType.ENUM('pending', 'accepted', 'declined', 'expired'),
    allowNull: false,
    defaultValue: 'pending'
  })
  status!: 'pending' | 'accepted' | 'declined' | 'expired';

  @Column({
    type: DataType.DATE,
    allowNull: false,
    defaultValue: () => new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
  })
  expiresAt!: Date;

  @Column({
    type: DataType.DATE,
    allowNull: true
  })
  acceptedAt?: Date;

  @Column({
    type: DataType.DATE,
    allowNull: true
  })
  declinedAt?: Date;

  @Column({
    type: DataType.TEXT,
    allowNull: true
  })
  message?: string;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  // Associations
  @BelongsTo(() => Project)
  project!: Project;

  @BelongsTo(() => User)
  inviter!: User;

  // Helper methods
  isExpired(): boolean {
    return new Date() > this.expiresAt || this.status === 'expired';
  }

  isValid(): boolean {
    return this.status === 'pending' && !this.isExpired();
  }

  static generateToken(): string {
    return Buffer.from(`${uuidv4()}-${Date.now()}`).toString('base64url');
  }
}