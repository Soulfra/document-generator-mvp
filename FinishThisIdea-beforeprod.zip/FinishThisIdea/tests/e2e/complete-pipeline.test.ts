import request from 'supertest';
import { app } from '../../src/server';
import { testDb } from '../utils/test-database';
import { SampleGenerator } from '../utils/sample-generator';
import { ZipManager } from '../utils/zip-manager';
import { promises as fs } from 'fs';
import * as path from 'path';
import * as os from 'os';

describe('Complete Pipeline E2E Tests', () => {
  let tempDir: string;
  let sampleZips: string[] = [];

  beforeAll(async () => {
    // Set up test database
    await testDb.setup({ seedData: true });
    
    // Create temporary directory for test files
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'finishthisidea-e2e-'));
    
    // Generate sample projects for testing
    console.log('Generating sample projects for E2E testing...');
    
    const samples = [
      'react-ecommerce',
      'nextjs-blog', 
      'django-webapp',
      'spring-boot-api'
    ];
    
    for (const sampleName of samples) {
      try {
        const zipPath = await SampleGenerator.generateSample(sampleName, tempDir);
        sampleZips.push(zipPath);
        console.log(`✅ Generated ${sampleName}: ${zipPath}`);
      } catch (error) {
        console.warn(`⚠️ Failed to generate ${sampleName}:`, error.message);
      }
    }
  });

  afterAll(async () => {
    // Clean up test files
    await ZipManager.cleanupZips(sampleZips);
    await fs.rm(tempDir, { recursive: true, force: true });
    
    // Clean up test database
    await testDb.cleanup();
    await testDb.teardown();
  });

  afterEach(async () => {
    // Reset database between tests
    await testDb.reset();
    await testDb.seedDatabase();
  });

  describe('Upload → Extract → Analyze → Generate → Package', () => {
    it('should process React E-commerce project end-to-end', async () => {
      const reactZipPath = sampleZips.find(zip => zip.includes('react-ecommerce'));
      
      if (!reactZipPath) {
        console.warn('React e-commerce sample not available, skipping test');
        return;
      }

      // Step 1: Upload project file
      console.log('Step 1: Uploading React project...');
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', reactZipPath)
        .field('profileId', 'react-typescript')
        .expect(200);

      expect(uploadResponse.body.success).toBe(true);
      expect(uploadResponse.body.data.jobId).toBeDefined();

      const jobId = uploadResponse.body.data.jobId;
      console.log(`✅ Upload successful, Job ID: ${jobId}`);

      // Step 2: Wait for job processing (simulate)
      console.log('Step 2: Simulating job processing...');
      
      // In a real test, we would wait for actual processing
      // For now, we'll update the job status manually
      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: 'https://test-bucket.s3.amazonaws.com/processed-' + jobId + '.zip'
        }
      });

      // Step 3: Generate documentation
      console.log('Step 3: Generating documentation...');
      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId,
          templates: ['executive-summary', 'api-contract', 'data-models'],
          includeInOutput: true
        })
        .expect(200);

      expect(docResponse.body.success).toBe(true);
      expect(docResponse.body.data.documentationId).toBeDefined();
      expect(docResponse.body.data.url).toBeDefined();
      expect(docResponse.body.data.templates).toEqual(['executive-summary', 'api-contract', 'data-models']);
      expect(docResponse.body.data.quality).toBeDefined();

      console.log(`✅ Documentation generated: ${docResponse.body.data.documentationId}`);

      // Step 4: Verify documentation exists in database
      console.log('Step 4: Verifying documentation in database...');
      const documentation = await prisma.documentation.findFirst({
        where: { jobId }
      });

      expect(documentation).toBeDefined();
      expect(documentation!.templates).toEqual(['executive-summary', 'api-contract', 'data-models']);
      expect(documentation!.metadata).toBeDefined();

      // Step 5: Retrieve documentation
      console.log('Step 5: Retrieving documentation...');
      const getDocResponse = await request(app)
        .get(`/api/documentation/${jobId}`)
        .expect(200);

      expect(getDocResponse.body.success).toBe(true);
      expect(getDocResponse.body.data.id).toBe(documentation!.id);

      console.log('✅ Complete React E-commerce pipeline test passed');
    });

    it('should process Django webapp project end-to-end', async () => {
      const djangoZipPath = sampleZips.find(zip => zip.includes('django-webapp'));
      
      if (!djangoZipPath) {
        console.warn('Django webapp sample not available, skipping test');
        return;
      }

      // Step 1: Upload Django project
      console.log('Step 1: Uploading Django project...');
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', djangoZipPath)
        .field('profileId', 'python-pep8')
        .expect(200);

      const jobId = uploadResponse.body.data.jobId;
      console.log(`✅ Django upload successful, Job ID: ${jobId}`);

      // Step 2: Simulate processing completion
      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: 'https://test-bucket.s3.amazonaws.com/processed-django-' + jobId + '.zip'
        }
      });

      // Step 3: Generate comprehensive documentation
      console.log('Step 3: Generating comprehensive Django documentation...');
      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId,
          templates: ['executive-summary', 'api-contract', 'data-models', 'user-stories'],
          includeInOutput: true
        })
        .expect(200);

      expect(docResponse.body.success).toBe(true);
      expect(docResponse.body.data.quality).toBeDefined();
      expect(docResponse.body.data.quality.overall).toBeGreaterThan(50);

      console.log('✅ Complete Django webapp pipeline test passed');
    });

    it('should process Spring Boot API project end-to-end', async () => {
      const springZipPath = sampleZips.find(zip => zip.includes('spring-boot'));
      
      if (!springZipPath) {
        console.warn('Spring Boot sample not available, skipping test');
        return;
      }

      // Test Java/Spring Boot processing
      console.log('Step 1: Uploading Spring Boot project...');
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', springZipPath)
        .field('profileId', 'java-spring')
        .expect(200);

      const jobId = uploadResponse.body.data.jobId;

      // Simulate processing
      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: 'https://test-bucket.s3.amazonaws.com/processed-spring-' + jobId + '.zip'
        }
      });

      // Generate API-focused documentation
      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId,
          templates: ['api-contract', 'data-models', 'technical-requirements'],
          includeInOutput: true
        })
        .expect(200);

      expect(docResponse.body.success).toBe(true);
      expect(docResponse.body.data.templates).toEqual(['api-contract', 'data-models', 'technical-requirements']);

      console.log('✅ Complete Spring Boot API pipeline test passed');
    });
  });

  describe('Chat Log → Requirements → Documentation', () => {
    it('should generate documentation from chat logs end-to-end', async () => {
      console.log('Testing chat log to documentation pipeline...');

      // Step 1: Import chat logs and extract requirements
      const chatLog = {
        messages: [
          {
            role: 'user' as const,
            content: 'I want to build a modern e-commerce platform with React and Node.js. Users should be able to browse products, add them to cart, and checkout with payment processing.',
            timestamp: new Date().toISOString()
          },
          {
            role: 'assistant' as const,
            content: 'I\'ll help you build a comprehensive e-commerce platform. We\'ll need: 1) React frontend with product catalog and cart functionality 2) Node.js Express API for backend 3) PostgreSQL database for products and orders 4) Stripe integration for payments 5) User authentication with JWT tokens.',
            timestamp: new Date().toISOString()
          },
          {
            role: 'user' as const,
            content: 'Perfect! I also need admin features - admins should be able to manage products and view orders. The system must handle 1000+ concurrent users and load pages in under 2 seconds.',
            timestamp: new Date().toISOString()
          },
          {
            role: 'assistant' as const,
            content: 'Great requirements! I\'ll implement role-based access control for admin features, optimize for high performance with caching and CDN, and ensure fast page loads with code splitting and image optimization.',
            timestamp: new Date().toISOString()
          }
        ],
        platform: 'claude' as const
      };

      console.log('Step 1: Importing chat logs...');
      const chatImportResponse = await request(app)
        .post('/api/documentation/chat-import')
        .send(chatLog)
        .expect(200);

      expect(chatImportResponse.body.success).toBe(true);
      expect(chatImportResponse.body.data.requirements).toBeDefined();
      expect(chatImportResponse.body.data.documentation).toBeDefined();

      const requirements = chatImportResponse.body.data.requirements;
      
      // Verify extracted requirements
      expect(requirements.features.length).toBeGreaterThan(0);
      expect(requirements.technicalRequirements.length).toBeGreaterThan(0);
      expect(requirements.constraints.length).toBeGreaterThan(0);

      // Should extract e-commerce features
      const hasEcommerceFeature = requirements.features.some((f: any) => 
        f.description.toLowerCase().includes('ecommerce') || 
        f.description.toLowerCase().includes('cart') ||
        f.description.toLowerCase().includes('checkout')
      );
      expect(hasEcommerceFeature).toBe(true);

      // Should extract technical requirements
      const hasReactRequirement = requirements.technicalRequirements.some((r: any) => 
        r.description.toLowerCase().includes('react')
      );
      const hasNodeRequirement = requirements.technicalRequirements.some((r: any) => 
        r.description.toLowerCase().includes('node') || r.description.toLowerCase().includes('express')
      );
      expect(hasReactRequirement || hasNodeRequirement).toBe(true);

      // Should extract performance constraints
      const hasPerformanceConstraint = requirements.constraints.some((c: any) => 
        c.type === 'performance' && c.description.includes('2 seconds')
      );
      expect(hasPerformanceConstraint).toBe(true);

      console.log('✅ Chat log requirements extraction successful');
      console.log(`   - Features: ${requirements.features.length}`);
      console.log(`   - Technical Requirements: ${requirements.technicalRequirements.length}`);
      console.log(`   - Constraints: ${requirements.constraints.length}`);

      // Step 2: Verify generated documentation content
      const documentation = chatImportResponse.body.data.documentation;
      expect(documentation).toContain('# Project Requirements');
      expect(documentation).toContain('## Features');
      expect(documentation).toContain('## Technical Requirements');
      expect(documentation).toContain('## Constraints');

      console.log('✅ Complete chat log to documentation pipeline test passed');
    });
  });

  describe('Error Handling and Edge Cases', () => {
    it('should handle malformed ZIP files gracefully', async () => {
      console.log('Testing malformed ZIP file handling...');

      // Create a malformed ZIP file
      const malformedZipPath = await ZipManager.createTestZip({
        type: 'malformed',
        outputPath: path.join(tempDir, 'malformed.zip')
      });

      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', malformedZipPath)
        .expect(400);

      expect(uploadResponse.body.success).toBe(false);
      expect(uploadResponse.body.error).toBeDefined();

      console.log('✅ Malformed ZIP handling test passed');
    });

    it('should handle oversized files', async () => {
      console.log('Testing oversized file handling...');

      // Create a large ZIP file
      const largeZipPath = await ZipManager.createTestZip({
        type: 'large',
        outputPath: path.join(tempDir, 'large.zip'),
        options: {
          fileCount: 100,
          fileSize: 1024 * 1024 // 1MB per file = 100MB total
        }
      });

      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', largeZipPath)
        .expect(400);

      expect(uploadResponse.body.success).toBe(false);
      expect(uploadResponse.body.error.message).toContain('too large');

      console.log('✅ Oversized file handling test passed');
    });

    it('should handle job not found scenarios', async () => {
      console.log('Testing job not found handling...');

      const nonExistentJobId = 'non-existent-job-id';

      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId: nonExistentJobId,
          templates: ['executive-summary']
        })
        .expect(404);

      expect(docResponse.body.success).toBe(false);
      expect(docResponse.body.error).toContain('not found');

      console.log('✅ Job not found handling test passed');
    });

    it('should handle empty chat logs gracefully', async () => {
      console.log('Testing empty chat log handling...');

      const emptyChatLog = {
        messages: [],
        platform: 'claude' as const
      };

      const chatResponse = await request(app)
        .post('/api/documentation/chat-import')
        .send(emptyChatLog)
        .expect(400);

      expect(chatResponse.body.success).toBe(false);

      console.log('✅ Empty chat log handling test passed');
    });
  });

  describe('Performance and Scale Testing', () => {
    it('should handle multiple concurrent uploads', async () => {
      console.log('Testing concurrent upload handling...');

      const sampleZipPath = sampleZips[0];
      if (!sampleZipPath) {
        console.warn('No sample ZIP available for concurrent test');
        return;
      }

      // Create multiple concurrent upload requests
      const uploadPromises = Array.from({ length: 3 }, (_, i) => 
        request(app)
          .post('/api/upload')
          .attach('file', sampleZipPath)
          .field('profileId', 'test-profile')
      );

      const results = await Promise.allSettled(uploadPromises);
      
      // At least some uploads should succeed
      const successfulUploads = results.filter(r => 
        r.status === 'fulfilled' && r.value.status === 200
      );
      
      expect(successfulUploads.length).toBeGreaterThan(0);

      console.log(`✅ Concurrent uploads test passed: ${successfulUploads.length}/3 succeeded`);
    });

    it('should process documentation generation within time limits', async () => {
      console.log('Testing documentation generation performance...');

      // Use a simpler project for faster processing
      const testZipPath = await ZipManager.createTestZip({
        type: 'mixed-content',
        outputPath: path.join(tempDir, 'performance-test.zip')
      });

      // Upload and process
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', testZipPath)
        .expect(200);

      const jobId = uploadResponse.body.data.jobId;

      // Simulate completed processing
      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: 'https://test-bucket.s3.amazonaws.com/perf-test-' + jobId + '.zip'
        }
      });

      // Time the documentation generation
      const startTime = Date.now();
      
      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId,
          templates: ['executive-summary']
        })
        .expect(200);

      const endTime = Date.now();
      const duration = endTime - startTime;

      expect(docResponse.body.success).toBe(true);
      expect(duration).toBeLessThan(10000); // Should complete within 10 seconds

      console.log(`✅ Documentation generation completed in ${duration}ms`);
    });
  });

  describe('Data Consistency and Quality', () => {
    it('should maintain data consistency across the pipeline', async () => {
      console.log('Testing data consistency...');

      const testZipPath = sampleZips[0];
      if (!testZipPath) {
        console.warn('No sample ZIP available for consistency test');
        return;
      }

      // Upload file
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', testZipPath)
        .expect(200);

      const jobId = uploadResponse.body.data.jobId;
      const originalFileName = uploadResponse.body.data.originalFileName;

      // Verify job was created correctly
      const prisma = testDb.getPrisma();
      const job = await prisma.job.findUnique({ where: { id: jobId } });
      
      expect(job).toBeDefined();
      expect(job!.originalFileName).toBe(originalFileName);
      expect(job!.status).toBe('PENDING');

      // Simulate processing completion
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: 'https://test-bucket.s3.amazonaws.com/consistency-test-' + jobId + '.zip'
        }
      });

      // Generate documentation
      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId,
          templates: ['executive-summary', 'api-contract']
        })
        .expect(200);

      // Verify documentation was created with correct relationships
      const documentation = await prisma.documentation.findFirst({
        where: { jobId },
        include: { job: true }
      });

      expect(documentation).toBeDefined();
      expect(documentation!.jobId).toBe(jobId);
      expect(documentation!.job.id).toBe(jobId);
      expect(documentation!.templates).toEqual(['executive-summary', 'api-contract']);

      console.log('✅ Data consistency test passed');
    });

    it('should generate quality documentation with proper metadata', async () => {
      console.log('Testing documentation quality...');

      const reactZipPath = sampleZips.find(zip => zip.includes('react'));
      if (!reactZipPath) {
        console.warn('React sample not available for quality test');
        return;
      }

      // Process React project
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', reactZipPath)
        .expect(200);

      const jobId = uploadResponse.body.data.jobId;

      // Simulate processing
      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: 'https://test-bucket.s3.amazonaws.com/quality-test-' + jobId + '.zip'
        }
      });

      // Generate documentation
      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId,
          templates: ['executive-summary', 'api-contract', 'data-models']
        })
        .expect(200);

      // Verify quality metrics
      const quality = docResponse.body.data.quality;
      expect(quality).toBeDefined();
      expect(quality.overall).toBeGreaterThan(50);
      expect(quality.completeness).toBeGreaterThan(0);
      expect(quality.accuracy).toBeGreaterThan(0);
      expect(quality.readability).toBeGreaterThan(0);

      // Verify metadata completeness
      const documentation = await prisma.documentation.findFirst({
        where: { jobId }
      });

      expect(documentation!.metadata).toBeDefined();
      expect(documentation!.metadata.generatedAt).toBeDefined();
      expect(documentation!.metadata.tokensUsed).toBeGreaterThan(0);

      console.log(`✅ Documentation quality test passed - Overall quality: ${quality.overall}%`);
    });
  });
});