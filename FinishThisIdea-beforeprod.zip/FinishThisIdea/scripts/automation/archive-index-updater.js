#!/usr/bin/env node

/**
 * Archive Index Updater - Maintain archive tracking and logs
 * 
 * Features:
 * - Update archive index with new entries
 * - Regenerate index from existing archives
 * - Validate archive integrity
 * - Generate completion reports
 */

const fs = require('fs');
const path = require('path');

class ArchiveIndexUpdater {
  constructor(projectRoot = null) {
    this.projectRoot = projectRoot || this.findProjectRoot();
    this.archiveDir = path.join(this.projectRoot, 'cursor', 'archived');
    this.indexFile = path.join(this.archiveDir, 'index.md');
    
    this.ensureArchiveDirectory();
  }

  /**
   * Find project root directory
   */
  findProjectRoot() {
    let currentDir = process.cwd();
    
    while (currentDir !== path.dirname(currentDir)) {
      if (fs.existsSync(path.join(currentDir, 'package.json')) || 
          fs.existsSync(path.join(currentDir, 'cursor'))) {
        return currentDir;
      }
      currentDir = path.dirname(currentDir);
    }
    
    return process.cwd();
  }

  /**
   * Ensure archive directory exists
   */
  ensureArchiveDirectory() {
    if (!fs.existsSync(this.archiveDir)) {
      fs.mkdirSync(this.archiveDir, { recursive: true });
      console.log(`📁 Created archive directory: ${this.archiveDir}`);
    }
  }

  /**
   * Read current archive index
   * @returns {Object} Parsed index data
   */
  readCurrentIndex() {
    if (!fs.existsSync(this.indexFile)) {
      return {
        content: '',
        entries: [],
        detailedReports: []
      };
    }

    const content = fs.readFileSync(this.indexFile, 'utf8');
    const entries = this.parseIndexEntries(content);
    const detailedReports = this.parseDetailedReports(content);

    return {
      content,
      entries,
      detailedReports
    };
  }

  /**
   * Parse index table entries
   * @param {string} content - Index file content
   * @returns {Array} Parsed entries
   */
  parseIndexEntries(content) {
    const entries = [];
    const lines = content.split('\n');
    
    let inTable = false;
    for (const line of lines) {
      if (line.includes('Review Name') && line.includes('Date Completed')) {
        inTable = true;
        continue;
      }
      if (inTable && line.startsWith('|') && !line.includes('---')) {
        const parts = line.split('|').map(p => p.trim()).filter(p => p);
        if (parts.length >= 3) {
          entries.push({
            name: parts[0],
            date: parts[1],
            summary: parts[2]
          });
        }
      }
      if (inTable && (line.includes('## ') || line.trim() === '')) {
        if (line.includes('## ')) break;
      }
    }

    return entries;
  }

  /**
   * Parse detailed reports section
   * @param {string} content - Index file content
   * @returns {Array} Detailed reports
   */
  parseDetailedReports(content) {
    const reports = [];
    const lines = content.split('\n');
    
    let inDetailedSection = false;
    for (const line of lines) {
      if (line.includes('## Detailed Implementation Reports')) {
        inDetailedSection = true;
        continue;
      }
      if (inDetailedSection && line.startsWith('|') && !line.includes('---')) {
        const parts = line.split('|').map(p => p.trim()).filter(p => p);
        if (parts.length >= 4) {
          reports.push({
            implementation: parts[0],
            date: parts[1],
            focusArea: parts[2],
            status: parts[3]
          });
        }
      }
    }

    return reports;
  }

  /**
   * Get all files in archive directory
   * @returns {Array} Archive files with metadata
   */
  scanArchiveFiles() {
    const files = [];
    
    if (!fs.existsSync(this.archiveDir)) {
      return files;
    }

    const entries = fs.readdirSync(this.archiveDir, { withFileTypes: true });
    
    for (const entry of entries) {
      if (entry.name === 'index.md' || entry.name === 'README.md') {
        continue;
      }

      const filePath = path.join(this.archiveDir, entry.name);
      const stats = fs.statSync(filePath);
      
      files.push({
        name: entry.name,
        path: filePath,
        isDirectory: entry.isDirectory(),
        size: stats.size,
        modified: stats.mtime,
        created: stats.birthtime
      });
    }

    return files.sort((a, b) => b.modified - a.modified);
  }

  /**
   * Add new entry to archive index
   * @param {Object} entry - Entry to add
   * @param {string} entry.name - Module name
   * @param {string} entry.summary - Summary description
   * @param {string} entry.type - Entry type (main or detailed)
   * @param {Object} entry.details - Additional details for detailed reports
   */
  addEntry(entry) {
    const { name, summary, type = 'main', details = {} } = entry;
    const timestamp = new Date().toISOString().split('T')[0];
    
    const currentIndex = this.readCurrentIndex();
    
    // Check if entry already exists
    const existingEntry = currentIndex.entries.find(e => e.name === name);
    if (existingEntry) {
      console.log(`⚠️  Entry already exists: ${name}. Updating...`);
    }

    if (type === 'main') {
      // Add to main table
      const newEntry = {
        name,
        date: timestamp,
        summary: summary || '✅ Archived completed module'
      };
      
      if (existingEntry) {
        Object.assign(existingEntry, newEntry);
      } else {
        currentIndex.entries.push(newEntry);
      }
    }

    if (type === 'detailed' || details.focusArea) {
      // Add to detailed reports
      const detailedEntry = {
        implementation: name,
        date: timestamp,
        focusArea: details.focusArea || 'Module Implementation',
        status: details.status || '✅ Complete'
      };
      
      const existingDetailed = currentIndex.detailedReports.find(r => r.implementation === name);
      if (existingDetailed) {
        Object.assign(existingDetailed, detailedEntry);
      } else {
        currentIndex.detailedReports.push(detailedEntry);
      }
    }

    this.writeIndex(currentIndex);
    console.log(`✅ Added index entry: ${name}`);
  }

  /**
   * Regenerate entire index from archive files
   */
  regenerateIndex() {
    console.log('🔄 Regenerating archive index...');
    
    const archiveFiles = this.scanArchiveFiles();
    const newIndex = {
      content: '',
      entries: [],
      detailedReports: []
    };

    // Generate entries from file names and dates
    for (const file of archiveFiles) {
      const name = file.name.replace(/-\d{4}-\d{2}-\d{2}(\.\w+)?$/, ''); // Remove timestamp
      const date = file.modified.toISOString().split('T')[0];
      
      newIndex.entries.push({
        name: this.formatName(name),
        date,
        summary: '✅ Archived module'
      });

      // Add to detailed reports if it looks like an implementation
      if (name.includes('implementation') || name.includes('completion') || name.includes('report')) {
        newIndex.detailedReports.push({
          implementation: this.formatName(name),
          date,
          focusArea: this.inferFocusArea(name),
          status: '✅ Complete'
        });
      }
    }

    this.writeIndex(newIndex);
    console.log(`✅ Regenerated index with ${newIndex.entries.length} entries`);
  }

  /**
   * Format file name for display
   * @param {string} fileName - Raw file name
   * @returns {string} Formatted name
   */
  formatName(fileName) {
    return fileName
      .replace(/[-_]/g, ' ')
      .replace(/\b\w/g, l => l.toUpperCase())
      .replace(/\.(md|yaml|yml)$/, '');
  }

  /**
   * Infer focus area from file name
   * @param {string} fileName - File name
   * @returns {string} Focus area
   */
  inferFocusArea(fileName) {
    const name = fileName.toLowerCase();
    
    if (name.includes('plugin')) return 'Extensibility Framework';
    if (name.includes('multi-project') || name.includes('gateway')) return 'Multi-Tenancy & Enterprise';
    if (name.includes('analytics')) return 'Business Intelligence';
    if (name.includes('workflow')) return 'Visual Workflow Creation';
    if (name.includes('template') || name.includes('marketplace')) return 'Template Distribution';
    if (name.includes('accessibility')) return 'WCAG 2.1 Compliance';
    if (name.includes('premium')) return 'Premium Features';
    if (name.includes('automation')) return 'Process Automation';
    
    return 'Module Implementation';
  }

  /**
   * Write index file
   * @param {Object} indexData - Index data to write
   */
  writeIndex(indexData) {
    let content = `# Archived Reviews Index

This file lists all completed premium/paywall feature reviews and their summaries.

---

| Review Name | Date Completed | Summary |
|-------------|---------------|---------|
`;

    // Add main entries
    for (const entry of indexData.entries) {
      content += `| ${entry.name} | ${entry.date} | ${entry.summary} |\n`;
    }

    // Add detailed reports section if there are any
    if (indexData.detailedReports.length > 0) {
      content += `\n## Detailed Implementation Reports\n\n`;
      content += `| Implementation | Date | Focus Area | Status |\n`;
      content += `|----------------|------|------------|--------|\n`;
      
      for (const report of indexData.detailedReports) {
        content += `| ${report.implementation} | ${report.date} | ${report.focusArea} | ${report.status} |\n`;
      }
    }

    content += `\n---\n\n*This index helps future devs quickly find and reference past audits.*\n`;

    fs.writeFileSync(this.indexFile, content);
  }

  /**
   * Validate archive integrity
   * @returns {Object} Validation results
   */
  validateArchive() {
    const results = {
      valid: true,
      issues: [],
      stats: {
        totalFiles: 0,
        indexedFiles: 0,
        missingFromIndex: [],
        deadIndexEntries: []
      }
    };

    const archiveFiles = this.scanArchiveFiles();
    const currentIndex = this.readCurrentIndex();

    results.stats.totalFiles = archiveFiles.length;
    results.stats.indexedFiles = currentIndex.entries.length;

    // Check for files not in index
    for (const file of archiveFiles) {
      const fileName = this.formatName(file.name);
      const inIndex = currentIndex.entries.some(e => e.name.includes(fileName) || fileName.includes(e.name));
      
      if (!inIndex) {
        results.stats.missingFromIndex.push(file.name);
      }
    }

    // Check for index entries without files
    for (const entry of currentIndex.entries) {
      const hasFile = archiveFiles.some(f => {
        const fileName = this.formatName(f.name);
        return fileName.includes(entry.name) || entry.name.includes(fileName);
      });
      
      if (!hasFile) {
        results.stats.deadIndexEntries.push(entry.name);
      }
    }

    // Determine if validation passed
    if (results.stats.missingFromIndex.length > 0) {
      results.valid = false;
      results.issues.push(`${results.stats.missingFromIndex.length} files not indexed`);
    }

    if (results.stats.deadIndexEntries.length > 0) {
      results.valid = false;
      results.issues.push(`${results.stats.deadIndexEntries.length} dead index entries`);
    }

    return results;
  }

  /**
   * Generate completion report
   * @returns {string} Formatted report
   */
  generateReport() {
    const validation = this.validateArchive();
    const archiveFiles = this.scanArchiveFiles();
    const currentIndex = this.readCurrentIndex();

    let report = `📊 Archive Status Report\n`;
    report += `=======================\n\n`;
    report += `📁 Archive Directory: ${this.archiveDir}\n`;
    report += `📄 Index File: ${path.basename(this.indexFile)}\n\n`;
    
    report += `📈 Statistics:\n`;
    report += `  • Total archived files: ${validation.stats.totalFiles}\n`;
    report += `  • Indexed entries: ${validation.stats.indexedFiles}\n`;
    report += `  • Detailed reports: ${currentIndex.detailedReports.length}\n\n`;

    if (validation.valid) {
      report += `✅ Archive integrity: VALID\n`;
    } else {
      report += `❌ Archive integrity: ISSUES FOUND\n`;
      for (const issue of validation.issues) {
        report += `  • ${issue}\n`;
      }
    }

    if (validation.stats.missingFromIndex.length > 0) {
      report += `\n⚠️  Files not in index:\n`;
      for (const file of validation.stats.missingFromIndex) {
        report += `  • ${file}\n`;
      }
    }

    if (validation.stats.deadIndexEntries.length > 0) {
      report += `\n⚠️  Dead index entries:\n`;
      for (const entry of validation.stats.deadIndexEntries) {
        report += `  • ${entry}\n`;
      }
    }

    report += `\n📋 Recent Archives:\n`;
    const recentFiles = archiveFiles.slice(0, 5);
    for (const file of recentFiles) {
      const date = file.modified.toISOString().split('T')[0];
      report += `  • ${file.name} (${date})\n`;
    }

    return report;
  }
}

// CLI Usage
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0 || args.includes('--help')) {
    console.log(`
Archive Index Updater - Maintain archive tracking

Usage:
  node archive-index-updater.js <command> [options]

Commands:
  add <name> [summary]     Add entry to index
  regenerate              Regenerate entire index from files
  validate                Check archive integrity
  report                  Generate status report

Options:
  --type <main|detailed>  Entry type for add command
  --focus-area <area>     Focus area for detailed entries
  --status <status>       Status for detailed entries

Examples:
  node archive-index-updater.js add "New Module" "Completed implementation"
  node archive-index-updater.js add "Plugin System" --type detailed --focus-area "Extensibility"
  node archive-index-updater.js regenerate
  node archive-index-updater.js report
`);
    process.exit(0);
  }

  const updater = new ArchiveIndexUpdater();
  const command = args[0];

  try {
    switch (command) {
      case 'add':
        if (args.length < 2) {
          console.error('❌ Name required for add command');
          process.exit(1);
        }
        
        const entry = {
          name: args[1],
          summary: args[2] || null,
          type: args.includes('--type') ? args[args.indexOf('--type') + 1] : 'main',
          details: {
            focusArea: args.includes('--focus-area') ? args[args.indexOf('--focus-area') + 1] : null,
            status: args.includes('--status') ? args[args.indexOf('--status') + 1] : null
          }
        };
        
        updater.addEntry(entry);
        break;

      case 'regenerate':
        updater.regenerateIndex();
        break;

      case 'validate':
        const validation = updater.validateArchive();
        console.log(validation.valid ? '✅ Archive is valid' : '❌ Archive has issues');
        if (!validation.valid) {
          for (const issue of validation.issues) {
            console.log(`  • ${issue}`);
          }
          process.exit(1);
        }
        break;

      case 'report':
        console.log(updater.generateReport());
        break;

      default:
        console.error(`❌ Unknown command: ${command}`);
        process.exit(1);
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

module.exports = ArchiveIndexUpdater;