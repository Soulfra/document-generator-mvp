import request from 'supertest';
import { app } from '../../src/server';
import { testDb } from '../utils/test-database';
import { performance, PerformanceObserver } from 'perf_hooks';
import * as os from 'os';

interface PerformanceMetrics {
  endpoint: string;
  responseTime: number;
  statusCode: number;
  memoryUsage: NodeJS.MemoryUsage;
  cpuLoad: number[];
  timestamp: number;
}

describe('Performance Monitoring', () => {
  let performanceData: PerformanceMetrics[] = [];
  let observer: PerformanceObserver;

  beforeAll(async () => {
    await testDb.setup({ seedData: true });
    
    // Set up performance observer
    observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry) => {
        console.log(`${entry.name}: ${entry.duration.toFixed(2)}ms`);
      });
    });
    observer.observe({ entryTypes: ['measure'] });
  });

  afterAll(async () => {
    observer.disconnect();
    await testDb.cleanup();
    await testDb.teardown();
    
    // Generate performance report
    generatePerformanceReport(performanceData);
  });

  const measureEndpoint = async (endpoint: string, method: 'GET' | 'POST' = 'GET', data?: any) => {
    const startTime = performance.now();
    const initialMemory = process.memoryUsage();
    const initialCpu = os.loadavg();
    
    let response;
    try {
      if (method === 'GET') {
        response = await request(app).get(endpoint);
      } else {
        response = await request(app).post(endpoint).send(data);
      }
    } catch (error) {
      response = { status: 500 };
    }
    
    const endTime = performance.now();
    const finalMemory = process.memoryUsage();
    const finalCpu = os.loadavg();
    
    performance.mark(`${endpoint}-start`);
    performance.mark(`${endpoint}-end`);
    performance.measure(`${endpoint}`, `${endpoint}-start`, `${endpoint}-end`);
    
    const metrics: PerformanceMetrics = {
      endpoint,
      responseTime: endTime - startTime,
      statusCode: response.status,
      memoryUsage: {
        rss: finalMemory.rss - initialMemory.rss,
        heapTotal: finalMemory.heapTotal - initialMemory.heapTotal,
        heapUsed: finalMemory.heapUsed - initialMemory.heapUsed,
        external: finalMemory.external - initialMemory.external,
        arrayBuffers: finalMemory.arrayBuffers - initialMemory.arrayBuffers,
      },
      cpuLoad: finalCpu,
      timestamp: Date.now(),
    };
    
    performanceData.push(metrics);
    return response;
  };

  describe('Endpoint Performance Benchmarks', () => {
    it('should measure health endpoint performance', async () => {
      const iterations = 100;
      const times: number[] = [];
      
      for (let i = 0; i < iterations; i++) {
        const response = await measureEndpoint('/health');
        times.push(performanceData[performanceData.length - 1].responseTime);
        expect(response.status).toBe(200);
      }
      
      const stats = calculateStats(times);
      console.log(`Health endpoint performance (${iterations} requests):
        - Average: ${stats.avg.toFixed(2)}ms
        - Median: ${stats.median.toFixed(2)}ms
        - 95th percentile: ${stats.p95.toFixed(2)}ms
        - Min: ${stats.min.toFixed(2)}ms
        - Max: ${stats.max.toFixed(2)}ms
      `);
      
      // Performance requirements
      expect(stats.avg).toBeLessThan(50); // Average under 50ms
      expect(stats.p95).toBeLessThan(100); // 95th percentile under 100ms
    });

    it('should measure detailed health endpoint performance', async () => {
      const iterations = 50;
      const times: number[] = [];
      
      for (let i = 0; i < iterations; i++) {
        const response = await measureEndpoint('/health/detailed');
        times.push(performanceData[performanceData.length - 1].responseTime);
        expect(response.status).toBe(200);
      }
      
      const stats = calculateStats(times);
      console.log(`Detailed health endpoint performance (${iterations} requests):
        - Average: ${stats.avg.toFixed(2)}ms
        - 95th percentile: ${stats.p95.toFixed(2)}ms
      `);
      
      // Detailed health check can be slower but should still be reasonable
      expect(stats.avg).toBeLessThan(500); // Average under 500ms
      expect(stats.p95).toBeLessThan(1000); // 95th percentile under 1s
    });

    it('should measure profiles endpoint performance', async () => {
      const iterations = 30;
      const times: number[] = [];
      
      for (let i = 0; i < iterations; i++) {
        const response = await measureEndpoint('/api/profiles');
        times.push(performanceData[performanceData.length - 1].responseTime);
        expect(response.status).toBe(200);
      }
      
      const stats = calculateStats(times);
      console.log(`Profiles endpoint performance (${iterations} requests):
        - Average: ${stats.avg.toFixed(2)}ms
        - 95th percentile: ${stats.p95.toFixed(2)}ms
      `);
      
      expect(stats.avg).toBeLessThan(200); // Average under 200ms
    });
  });

  describe('Memory Usage Patterns', () => {
    it('should monitor memory usage during sustained load', async () => {
      const initialMemory = process.memoryUsage();
      const memorySnapshots: NodeJS.MemoryUsage[] = [initialMemory];
      
      // Perform 200 requests while monitoring memory
      for (let i = 0; i < 200; i++) {
        await measureEndpoint('/health');
        
        if (i % 50 === 0) {
          memorySnapshots.push(process.memoryUsage());
        }
      }
      
      const finalMemory = process.memoryUsage();
      memorySnapshots.push(finalMemory);
      
      console.log('Memory usage during sustained load:');
      memorySnapshots.forEach((snapshot, index) => {
        console.log(`  Snapshot ${index}: ${(snapshot.heapUsed / 1024 / 1024).toFixed(2)} MB`);
      });
      
      const memoryIncrease = finalMemory.heapUsed - initialMemory.heapUsed;
      console.log(`Total memory increase: ${(memoryIncrease / 1024 / 1024).toFixed(2)} MB`);
      
      // Memory increase should be reasonable
      expect(memoryIncrease).toBeLessThan(100 * 1024 * 1024); // Less than 100MB increase
    });
  });

  describe('Concurrency Performance', () => {
    it('should maintain performance under concurrent load', async () => {
      const concurrentUsers = 20;
      const requestsPerUser = 10;
      
      const userPromises = Array.from({ length: concurrentUsers }, async (_, userIndex) => {
        const userTimes: number[] = [];
        
        for (let i = 0; i < requestsPerUser; i++) {
          const startTime = performance.now();
          await request(app).get('/health').expect(200);
          const endTime = performance.now();
          userTimes.push(endTime - startTime);
        }
        
        return userTimes;
      });
      
      const allUserTimes = await Promise.all(userPromises);
      const allTimes = allUserTimes.flat();
      const stats = calculateStats(allTimes);
      
      console.log(`Concurrent load performance (${concurrentUsers} users, ${requestsPerUser} requests each):
        - Total requests: ${allTimes.length}
        - Average response time: ${stats.avg.toFixed(2)}ms
        - 95th percentile: ${stats.p95.toFixed(2)}ms
        - Max response time: ${stats.max.toFixed(2)}ms
      `);
      
      // Under concurrent load, response times may be higher but should still be reasonable
      expect(stats.avg).toBeLessThan(200); // Average under 200ms
      expect(stats.p95).toBeLessThan(500); // 95th percentile under 500ms
    });
  });
});

function calculateStats(times: number[]) {
  const sorted = times.sort((a, b) => a - b);
  const avg = times.reduce((a, b) => a + b, 0) / times.length;
  const median = sorted[Math.floor(sorted.length / 2)];
  const p95 = sorted[Math.floor(sorted.length * 0.95)];
  const min = Math.min(...times);
  const max = Math.max(...times);
  
  return { avg, median, p95, min, max };
}

function generatePerformanceReport(data: PerformanceMetrics[]) {
  if (data.length === 0) return;
  
  console.log('\n=== PERFORMANCE REPORT ===');
  
  // Group by endpoint
  const endpointGroups = data.reduce((groups, metric) => {
    if (!groups[metric.endpoint]) {
      groups[metric.endpoint] = [];
    }
    groups[metric.endpoint].push(metric);
    return groups;
  }, {} as Record<string, PerformanceMetrics[]>);
  
  Object.entries(endpointGroups).forEach(([endpoint, metrics]) => {
    const times = metrics.map(m => m.responseTime);
    const stats = calculateStats(times);
    
    console.log(`\n${endpoint}:`);
    console.log(`  Requests: ${metrics.length}`);
    console.log(`  Avg Response Time: ${stats.avg.toFixed(2)}ms`);
    console.log(`  95th Percentile: ${stats.p95.toFixed(2)}ms`);
    console.log(`  Success Rate: ${(metrics.filter(m => m.statusCode < 400).length / metrics.length * 100).toFixed(1)}%`);
  });
  
  // Overall memory usage
  const memoryChanges = data.map(m => m.memoryUsage.heapUsed);
  const totalMemoryChange = memoryChanges.reduce((a, b) => a + b, 0);
  
  console.log(`\nOverall Memory Impact: ${(totalMemoryChange / 1024 / 1024).toFixed(2)} MB`);
  console.log(`Total Test Requests: ${data.length}`);
  console.log('=========================\n');
}