# Premium Feature Integration Guide

This document explains how to add easy-to-implement premium features to the FinishThisIdea codebase, including paywall logic and integration points. These features are designed to be added quickly and safely, without breaking existing functionality.

---

## 1. Priority Processing

**What:** Paid users get their jobs processed faster by assigning higher queue priority.

**How to Integrate:**
- In `src/jobs/cleanup.queue.ts` and job creation routes, set the `priority` option based on user tier.

```typescript
// Example in job creation
const jobPriority = user.tier === 'premium' ? 2 : 1;
await cleanupQueue.add('process-cleanup', jobData, { priority: jobPriority });
```

**Frontend:**
- Show a paywall modal if a free user tries to select "Priority Processing".

---

## 2. Advanced Templates

**What:** Premium users unlock additional documentation templates.

**How to Integrate:**
- In `src/services/documentation.service.ts`, filter available templates by user tier.

```typescript
const availableTemplates = templates.filter(t => t.tier === 'free' || user.tier === 'premium');
```

**Frontend:**
- Lock premium templates with an upgrade prompt for free users.

---

## 3. File Size Limits

**What:** Premium users can upload much larger files.

**How to Integrate:**
- In `src/api/routes/upload.route.ts`, check file size against user tier.

```typescript
const maxSize = user.tier === 'premium' ? 500 * 1024 * 1024 : 50 * 1024 * 1024;
if (file.size > maxSize) throw new AppError('Upgrade required for larger files');
```

**Frontend:**
- Show a paywall modal if a free user tries to upload a file over the free limit.

---

## 4. Custom Context Profiles

**What:** Premium users can create more custom profiles.

**How to Integrate:**
- In `src/services/profile.service.ts`, enforce a limit based on user tier.

```typescript
const profileLimit = user.tier === 'premium' ? 10 : 2;
if (userProfiles.length >= profileLimit) throw new AppError('Profile limit reached. Upgrade for more.');
```

---

## 5. Export Formats

**What:** Premium users can export documentation in more formats (PDF, HTML, etc).

**How to Integrate:**
- In documentation export logic, check allowed formats by user tier.

```typescript
const allowedFormats = user.tier === 'premium' ? ['zip', 'pdf', 'html', 'md'] : ['zip'];
if (!allowedFormats.includes(requestedFormat)) throw new AppError('Upgrade for more export formats.');
```

---

## 6. Batch Processing

**What:** Premium users can process multiple files at once.

**How to Integrate:**
- In upload logic, check batch size by user tier.

```typescript
const batchLimit = user.tier === 'premium' ? 10 : 1;
if (files.length > batchLimit) throw new AppError('Upgrade for batch processing.');
```

---

## 7. Feature Flag Utility

**What:** Centralize feature checks for easy paywall logic.

**How to Integrate:**
- Add a utility function:

```typescript
function hasPremium(user) {
  return user.tier === 'premium';
}
```
- Use this in all paywall checks.

---

## 8. Paywall Modal (Frontend)

**What:** Show upgrade prompts when a user hits a premium feature.

**How to Integrate:**
- Use your existing modal system to trigger an upgrade prompt when a paywall check fails.

---

## 9. Subscription/Upgrade Flow

**What:** Allow users to upgrade via Stripe or your payment provider.

**How to Integrate:**
- Add a "Go Premium" button that triggers the payment flow.
- On success, update the user's `tier` in the database.

---

## 10. Testing

- Add unit and integration tests for all new paywall logic.
- Ensure free users are blocked from premium features and premium users have access.

---

## Handoff Notes
- All changes are additive and should not break existing functionality.
- Use feature flags and tier checks to keep logic clean.
- Coordinate frontend and backend changes for a smooth user experience.

---

**Contact:** For questions, reach out to the product or platform team. 