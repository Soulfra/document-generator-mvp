#!/usr/bin/env node
/**
 * Accessibility Test Script
 * Runs basic accessibility checks on the application
 */

const puppeteer = require('puppeteer');
const axe = require('axe-core');
const chalk = require('chalk');

const pages = [
  { name: 'Home Page', url: 'http://localhost:3001/' },
  { name: 'Analytics Dashboard', url: 'http://localhost:3001/admin/analytics.html' },
  { name: 'Workflow Builder', url: 'http://localhost:3001/admin/workflow-builder.html' },
  { name: 'Template Marketplace', url: 'http://localhost:3001/admin/template-marketplace.html' }
];

async function testAccessibility() {
  console.log(chalk.blue('🔍 Running Accessibility Tests...\n'));
  
  const browser = await puppeteer.launch({ headless: true });
  const results = [];
  
  for (const pageInfo of pages) {
    console.log(chalk.yellow(`Testing: ${pageInfo.name}`));
    console.log(`URL: ${pageInfo.url}`);
    
    const page = await browser.newPage();
    
    try {
      await page.goto(pageInfo.url, { waitUntil: 'networkidle2' });
      
      // Inject axe-core
      await page.addScriptTag({ path: require.resolve('axe-core') });
      
      // Run accessibility tests
      const violations = await page.evaluate(async () => {
        const results = await axe.run();
        return results.violations;
      });
      
      results.push({
        page: pageInfo.name,
        url: pageInfo.url,
        violations: violations,
        violationCount: violations.length
      });
      
      if (violations.length === 0) {
        console.log(chalk.green('✅ No accessibility violations found!\n'));
      } else {
        console.log(chalk.red(`❌ Found ${violations.length} violations:`));
        violations.forEach((violation, index) => {
          console.log(`\n  ${index + 1}. ${violation.description}`);
          console.log(`     Impact: ${violation.impact}`);
          console.log(`     Help: ${violation.helpUrl}`);
          console.log(`     Elements affected: ${violation.nodes.length}`);
        });
        console.log('');
      }
      
    } catch (error) {
      console.log(chalk.red(`❌ Error testing page: ${error.message}\n`));
      results.push({
        page: pageInfo.name,
        url: pageInfo.url,
        error: error.message
      });
    }
    
    await page.close();
  }
  
  await browser.close();
  
  // Summary
  console.log(chalk.blue('\n📊 Summary:'));
  console.log(chalk.blue('═'.repeat(50)));
  
  let totalViolations = 0;
  results.forEach(result => {
    if (result.error) {
      console.log(`${result.page}: ${chalk.red('Error - ' + result.error)}`);
    } else {
      totalViolations += result.violationCount;
      const status = result.violationCount === 0 ? chalk.green('✅ PASS') : chalk.red(`❌ ${result.violationCount} violations`);
      console.log(`${result.page}: ${status}`);
    }
  });
  
  console.log(chalk.blue('═'.repeat(50)));
  console.log(`Total violations: ${totalViolations === 0 ? chalk.green('0') : chalk.red(totalViolations)}`);
  
  // Exit with appropriate code
  process.exit(totalViolations === 0 ? 0 : 1);
}

// Check if required dependencies are installed
try {
  require.resolve('puppeteer');
  require.resolve('axe-core');
  require.resolve('chalk');
} catch (error) {
  console.log(chalk.red('Missing dependencies. Please install:'));
  console.log('npm install --save-dev puppeteer axe-core chalk');
  process.exit(1);
}

// Run tests
testAccessibility().catch(error => {
  console.error(chalk.red('Fatal error:'), error);
  process.exit(1);
});