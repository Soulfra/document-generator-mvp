/**
 * Slack Plugin
 * Sends messages to Slack channels
 */

import { BasePlugin } from '../base-plugin';
import { PluginMetadata, PluginField, PluginExecutionResult } from '../interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../../interfaces/workflow.interface';
import { SlackIntegrationService } from '../../services/slack-integration.service';

export default class SlackPlugin extends BasePlugin {
  private slackService: SlackIntegrationService;
  
  metadata: PluginMetadata = {
    id: 'slack',
    name: 'Slack Message',
    version: '1.0.0',
    description: 'Send messages to Slack channels',
    author: 'FinishThisIdea',
    icon: '💬',
    category: 'notification',
    tags: ['slack', 'notification', 'chat'],
    requiredConfig: ['SLACK_BOT_TOKEN', 'SLACK_WEBHOOK_URL']
  };
  
  fields: PluginField[] = [
    {
      name: 'channel',
      label: 'Channel',
      type: 'text',
      required: true,
      placeholder: '#general or @username',
      description: 'Slack channel or user to send to'
    },
    {
      name: 'message',
      label: 'Message',
      type: 'textarea',
      required: true,
      placeholder: 'Your message here...',
      description: 'Message text (supports Slack markdown)'
    },
    {
      name: 'blocks',
      label: 'Blocks',
      type: 'json',
      required: false,
      placeholder: '[{"type": "section", "text": {"type": "mrkdwn", "text": "Hello"}}]',
      description: 'Slack Block Kit blocks for rich formatting'
    },
    {
      name: 'attachments',
      label: 'Attachments',
      type: 'json',
      required: false,
      placeholder: '[{"color": "good", "text": "Success!"}]',
      description: 'Legacy attachments format'
    },
    {
      name: 'username',
      label: 'Bot Username',
      type: 'text',
      required: false,
      placeholder: 'Workflow Bot',
      description: 'Override bot username'
    },
    {
      name: 'icon_emoji',
      label: 'Bot Icon',
      type: 'text',
      required: false,
      placeholder: ':robot_face:',
      description: 'Override bot icon emoji'
    },
    {
      name: 'thread_ts',
      label: 'Thread Timestamp',
      type: 'text',
      required: false,
      placeholder: '1234567890.123456',
      description: 'Reply in thread (timestamp)'
    }
  ];
  
  constructor(config?: Record<string, any>) {
    super(config);
    this.slackService = SlackIntegrationService.getInstance();
  }
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    const { channel, message, blocks, attachments, username, icon_emoji, thread_ts } = step;
    
    if (!channel || !message) {
      return this.failure('Missing required fields: channel, message');
    }
    
    try {
      await this.slackService.initialize();
      
      const { result, duration } = await this.measureExecution(async () => {
        const messageData: any = {
          channel,
          text: message
        };
        
        // Add optional fields
        if (blocks) messageData.blocks = blocks;
        if (attachments) messageData.attachments = attachments;
        if (username) messageData.username = username;
        if (icon_emoji) messageData.icon_emoji = icon_emoji;
        if (thread_ts) messageData.thread_ts = thread_ts;
        
        return await this.slackService.sendMessage(channel, message, {
          blocks,
          attachments,
          username,
          icon_emoji,
          thread_ts
        });
      });
      
      this.logger.info(`Slack message sent to ${channel} in ${duration}ms`);
      
      return this.success(
        { 
          channel, 
          timestamp: result.ts,
          permalink: result.permalink
        }, 
        duration, 
        [`Message sent to ${channel}`]
      );
      
    } catch (error) {
      this.logger.error('Slack message failed:', error);
      return this.failure(`Failed to send Slack message: ${error.message}`);
    }
  }
  
  async testConnection(): Promise<{ success: boolean; message?: string }> {
    try {
      await this.slackService.initialize();
      const channels = await this.slackService.listChannels();
      return {
        success: true,
        message: `Connected to Slack workspace with ${channels.length} channels`
      };
    } catch (error) {
      return {
        success: false,
        message: `Slack connection test failed: ${error.message}`
      };
    }
  }
}