import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { 
  Users, 
  DollarSign, 
  TrendingUp, 
  Gift, 
  Calendar,
  Star,
  Target,
  Clock
} from 'lucide-react';

interface ReferralData {
  totalReferrals: number;
  successfulReferrals: number;
  totalEarnings: number;
  pendingEarnings: number;
  thisMonth: number;
  conversionRate: number;
  recentReferrals: Array<{
    id: string;
    name: string;
    date: string;
    status: 'pending' | 'completed' | 'used_service';
    earning: number;
  }>;
}

interface ReferralStatsProps {
  userId?: string;
  variant?: 'detailed' | 'compact';
}

const ReferralStats = ({ userId = 'demo-user', variant = 'detailed' }: ReferralStatsProps) => {
  const [data, setData] = useState<ReferralData>({
    totalReferrals: 23,
    successfulReferrals: 18,
    totalEarnings: 9.50,
    pendingEarnings: 2.50,
    thisMonth: 7,
    conversionRate: 78.3,
    recentReferrals: [
      { id: '1', name: 'Alex M.', date: '2 hours ago', status: 'completed', earning: 0.50 },
      { id: '2', name: 'Sarah K.', date: '1 day ago', status: 'used_service', earning: 0.50 },
      { id: '3', name: 'Mike D.', date: '2 days ago', status: 'pending', earning: 0.00 },
      { id: '4', name: 'Emma L.', date: '3 days ago', status: 'completed', earning: 0.50 },
    ]
  });

  const [isAnimating, setIsAnimating] = useState(false);

  // Simulate data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setData(prev => ({
          ...prev,
          totalReferrals: prev.totalReferrals + (Math.random() > 0.8 ? 1 : 0),
          thisMonth: prev.thisMonth + (Math.random() > 0.9 ? 1 : 0)
        }));
        setIsAnimating(false);
      }, 500);
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const formatCurrency = (amount: number) => `$${amount.toFixed(2)}`;
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-400';
      case 'used_service': return 'text-blue-400';
      case 'pending': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Earned';
      case 'used_service': return 'Used Service';
      case 'pending': return 'Signed Up';
      default: return 'Unknown';
    }
  };

  if (variant === 'compact') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-4"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-blue-500 rounded-full flex items-center justify-center">
              <DollarSign className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="text-lg font-bold text-white">
                {formatCurrency(data.totalEarnings)}
              </div>
              <div className="text-xs text-gray-400">earned from referrals</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm font-medium text-white">{data.successfulReferrals}</div>
            <div className="text-xs text-gray-400">successful</div>
          </div>
        </div>
      </motion.div>
    );
  }

  const stats = [
    {
      icon: Users,
      label: 'Total Referrals',
      value: data.totalReferrals,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20'
    },
    {
      icon: Star,
      label: 'Successful',
      value: data.successfulReferrals,
      color: 'text-green-400',
      bgColor: 'bg-green-500/20'
    },
    {
      icon: DollarSign,
      label: 'Total Earned',
      value: formatCurrency(data.totalEarnings),
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-500/20'
    },
    {
      icon: TrendingUp,
      label: 'This Month',
      value: data.thisMonth,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card p-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-blue-500 rounded-full flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Referral Performance</h3>
            <p className="text-sm text-gray-400">Your earnings and impact</p>
          </div>
        </div>

        {/* Conversion rate badge */}
        <div className="bg-green-500/10 text-green-400 px-3 py-1 rounded-full text-sm font-medium">
          {data.conversionRate}% conversion
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ 
                opacity: 1, 
                scale: 1,
                y: isAnimating && index === 0 ? [-2, 0] : 0
              }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-900/30 rounded-lg p-4 hover:bg-gray-900/50 transition-colors"
            >
              <div className={`${stat.bgColor} w-8 h-8 rounded-lg flex items-center justify-center mb-3`}>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </div>
              <div className="text-xl font-bold text-white">
                <motion.span
                  key={stat.value}
                  initial={{ opacity: 0.8 }}
                  animate={{ opacity: 1 }}
                >
                  {stat.value}
                </motion.span>
              </div>
              <div className="text-xs text-gray-500">{stat.label}</div>
            </motion.div>
          );
        })}
      </div>

      {/* Earnings Summary */}
      <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-lg p-4 mb-6 border border-green-500/20">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold text-white">
              {formatCurrency(data.totalEarnings + data.pendingEarnings)}
            </div>
            <div className="text-sm text-gray-400">
              {formatCurrency(data.totalEarnings)} available • {formatCurrency(data.pendingEarnings)} pending
            </div>
          </div>
          <button className="btn-primary text-sm px-4 py-2">
            Withdraw
          </button>
        </div>
      </div>

      {/* Recent Referrals */}
      <div>
        <h4 className="text-sm font-medium text-white mb-4 flex items-center space-x-2">
          <Clock className="w-4 h-4 text-gray-400" />
          <span>Recent Referrals</span>
        </h4>
        
        <div className="space-y-3">
          {data.recentReferrals.map((referral, index) => (
            <motion.div
              key={referral.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center justify-between p-3 bg-gray-900/30 rounded-lg hover:bg-gray-900/50 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center text-xs font-semibold text-white">
                  {referral.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <div className="text-sm font-medium text-white">{referral.name}</div>
                  <div className="text-xs text-gray-500">{referral.date}</div>
                </div>
              </div>
              
              <div className="text-right">
                <div className={`text-sm font-medium ${getStatusColor(referral.status)}`}>
                  {getStatusText(referral.status)}
                </div>
                {referral.earning > 0 && (
                  <div className="text-xs text-green-400">
                    +{formatCurrency(referral.earning)}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Next milestone */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-6 p-4 bg-accent-500/10 rounded-lg border border-accent-500/20"
      >
        <div className="flex items-center space-x-3">
          <Target className="w-5 h-5 text-accent-400" />
          <div>
            <div className="text-sm font-medium text-white">
              Next Milestone: {25 - data.totalReferrals} more referrals
            </div>
            <div className="text-xs text-gray-400">
              Unlock bonus rewards at 25 successful referrals!
            </div>
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="mt-3 w-full bg-gray-800 rounded-full h-2">
          <motion.div
            className="bg-gradient-to-r from-accent-500 to-primary-500 h-2 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${(data.totalReferrals / 25) * 100}%` }}
            transition={{ duration: 1, delay: 0.7 }}
          />
        </div>
      </motion.div>
    </motion.div>
  );
};

export default ReferralStats;