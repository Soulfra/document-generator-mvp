import express from 'express';
import { asyncHandler } from '../middleware/async-handler';
import { authentication } from '../../middleware/auth.middleware';
import { projectWizard } from '../../automation/services/project-wizard.service';
import { analyticsService } from '../../automation/services/analytics-integration.service';
import { logger } from '../../utils/logger';
import { prisma } from '../../utils/database';

const router = express.Router();

interface TemplateRating {
  id: string;
  templateId: string;
  userId: string;
  rating: number; // 1-5 stars
  review?: string;
  createdAt: Date;
}

interface TemplateDownload {
  id: string;
  templateId: string;
  userId: string;
  downloadedAt: Date;
  projectName?: string;
}

/**
 * Get all available templates from marketplace
 */
router.get('/templates', asyncHandler(async (req, res) => {
  try {
    const { category, search, sortBy = 'downloads', limit = 20, offset = 0 } = req.query;

    // Get templates from project wizard
    let templates = projectWizard.getTemplates(category as string);

    // Filter by search term
    if (search && typeof search === 'string') {
      const searchLower = search.toLowerCase();
      templates = templates.filter(template => 
        template.name.toLowerCase().includes(searchLower) ||
        template.description.toLowerCase().includes(searchLower) ||
        template.tags.some(tag => tag.toLowerCase().includes(searchLower))
      );
    }

    // Sort templates
    templates.sort((a, b) => {
      switch (sortBy) {
        case 'rating':
          return b.metadata.rating - a.metadata.rating;
        case 'downloads':
          return b.metadata.downloads - a.metadata.downloads;
        case 'name':
          return a.name.localeCompare(b.name);
        case 'newest':
          return b.metadata.updatedAt.getTime() - a.metadata.updatedAt.getTime();
        default:
          return b.metadata.downloads - a.metadata.downloads;
      }
    });

    // Paginate
    const startIndex = Number(offset);
    const endIndex = startIndex + Number(limit);
    const paginatedTemplates = templates.slice(startIndex, endIndex);

    // Enhance with marketplace data
    const enhancedTemplates = await Promise.all(
      paginatedTemplates.map(async (template) => {
        // Get download count (mock for now, would use real database)
        const downloadCount = template.metadata.downloads;
        
        // Get average rating (mock for now, would use real database)
        const avgRating = template.metadata.rating;
        const ratingCount = Math.floor(downloadCount / 10); // Mock rating count
        
        return {
          ...template,
          marketplace: {
            downloadCount,
            avgRating,
            ratingCount,
            isPopular: downloadCount > 50,
            isFeatured: template.metadata.rating >= 4.5,
            tags: template.tags,
            category: template.category,
            difficulty: template.difficulty,
            estimatedTime: template.estimatedTime
          }
        };
      })
    );

    res.json({
      success: true,
      data: {
        templates: enhancedTemplates,
        pagination: {
          total: templates.length,
          limit: Number(limit),
          offset: Number(offset),
          hasMore: endIndex < templates.length
        },
        filters: {
          categories: ['web-app', 'api', 'automation', 'documentation', 'other'],
          difficulties: ['beginner', 'intermediate', 'advanced'],
          sortOptions: ['downloads', 'rating', 'name', 'newest']
        }
      }
    });

  } catch (error) {
    logger.error('Failed to get marketplace templates', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'MARKETPLACE_ERROR',
        message: 'Failed to retrieve templates'
      }
    });
  }
}));

/**
 * Get template details
 */
router.get('/templates/:id', asyncHandler(async (req, res) => {
  try {
    const { id } = req.params;
    const template = projectWizard.getTemplate(id);

    if (!template) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'TEMPLATE_NOT_FOUND',
          message: 'Template not found'
        }
      });
    }

    // Get additional marketplace data
    const downloadCount = template.metadata.downloads;
    const avgRating = template.metadata.rating;
    const ratingCount = Math.floor(downloadCount / 10);

    // Get recent downloads (mock data for now)
    const recentDownloads = Array.from({ length: Math.min(5, downloadCount) }, (_, i) => ({
      id: `download-${i}`,
      projectName: `Project ${i + 1}`,
      downloadedAt: new Date(Date.now() - i * 24 * 60 * 60 * 1000),
      userName: `User ${i + 1}`
    }));

    // Get reviews (mock data for now)
    const reviews = Array.from({ length: Math.min(10, ratingCount) }, (_, i) => ({
      id: `review-${i}`,
      userName: `User ${i + 1}`,
      rating: Math.floor(Math.random() * 2) + 4, // 4-5 stars
      review: `Great template! Very helpful for getting started.`,
      createdAt: new Date(Date.now() - i * 7 * 24 * 60 * 60 * 1000)
    }));

    res.json({
      success: true,
      data: {
        ...template,
        marketplace: {
          downloadCount,
          avgRating,
          ratingCount,
          recentDownloads,
          reviews,
          isPopular: downloadCount > 50,
          isFeatured: avgRating >= 4.5,
          relatedTemplates: projectWizard.getTemplates(template.category)
            .filter(t => t.id !== id)
            .slice(0, 3)
            .map(t => ({
              id: t.id,
              name: t.name,
              description: t.description,
              rating: t.metadata.rating,
              downloads: t.metadata.downloads
            }))
        }
      }
    });

  } catch (error) {
    logger.error('Failed to get template details', { error, templateId: req.params.id });
    res.status(500).json({
      success: false,
      error: {
        code: 'TEMPLATE_ERROR',
        message: 'Failed to retrieve template details'
      }
    });
  }
}));

/**
 * Download/use a template
 */
router.post('/templates/:id/download', authentication(), asyncHandler(async (req, res) => {
  try {
    const { id } = req.params;
    const { projectName, configuration = {} } = req.body;

    if (!projectName) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'MISSING_PROJECT_NAME',
          message: 'Project name is required'
        }
      });
    }

    const template = projectWizard.getTemplate(id);
    if (!template) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'TEMPLATE_NOT_FOUND',
          message: 'Template not found'
        }
      });
    }

    // Start wizard session for the template
    const session = await projectWizard.startWizardSession(
      id,
      req.user?.id || 'anonymous',
      projectName
    );

    // Apply configuration if provided
    if (Object.keys(configuration).length > 0) {
      await projectWizard.updateConfiguration(session.id, configuration);
    }

    // Track download
    await analyticsService.track({
      event: 'template_downloaded',
      userId: req.user?.id,
      properties: {
        templateId: id,
        templateName: template.name,
        templateCategory: template.category,
        projectName,
        sessionId: session.id
      }
    });

    // Update download count (in real implementation, would update database)
    template.metadata.downloads += 1;

    logger.info('Template downloaded from marketplace', {
      templateId: id,
      templateName: template.name,
      projectName,
      userId: req.user?.id,
      sessionId: session.id
    });

    res.json({
      success: true,
      data: {
        sessionId: session.id,
        projectName,
        template: {
          id: template.id,
          name: template.name,
          description: template.description
        },
        nextStep: 'configuration',
        configurationUrl: `/api/wizard/sessions/${session.id}`
      }
    });

  } catch (error) {
    logger.error('Failed to download template', { error, templateId: req.params.id });
    res.status(500).json({
      success: false,
      error: {
        code: 'DOWNLOAD_ERROR',
        message: 'Failed to download template'
      }
    });
  }
}));

/**
 * Rate a template
 */
router.post('/templates/:id/rate', authentication(), asyncHandler(async (req, res) => {
  try {
    const { id } = req.params;
    const { rating, review } = req.body;

    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_RATING',
          message: 'Rating must be between 1 and 5'
        }
      });
    }

    const template = projectWizard.getTemplate(id);
    if (!template) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'TEMPLATE_NOT_FOUND',
          message: 'Template not found'
        }
      });
    }

    // In a real implementation, save rating to database
    // For now, just track the event
    await analyticsService.track({
      event: 'template_rated',
      userId: req.user?.id,
      properties: {
        templateId: id,
        templateName: template.name,
        rating,
        hasReview: !!review,
        reviewLength: review?.length || 0
      }
    });

    logger.info('Template rated', {
      templateId: id,
      templateName: template.name,
      rating,
      userId: req.user?.id,
      hasReview: !!review
    });

    res.json({
      success: true,
      message: 'Rating submitted successfully',
      data: {
        templateId: id,
        rating,
        review: review || null
      }
    });

  } catch (error) {
    logger.error('Failed to rate template', { error, templateId: req.params.id });
    res.status(500).json({
      success: false,
      error: {
        code: 'RATING_ERROR',
        message: 'Failed to submit rating'
      }
    });
  }
}));

/**
 * Get popular/featured templates
 */
router.get('/featured', asyncHandler(async (req, res) => {
  try {
    const allTemplates = projectWizard.getTemplates();
    
    const featured = allTemplates
      .filter(t => t.metadata.rating >= 4.5)
      .sort((a, b) => b.metadata.downloads - a.metadata.downloads)
      .slice(0, 6)
      .map(template => ({
        id: template.id,
        name: template.name,
        description: template.description,
        category: template.category,
        difficulty: template.difficulty,
        estimatedTime: template.estimatedTime,
        rating: template.metadata.rating,
        downloads: template.metadata.downloads,
        tags: template.tags,
        author: template.metadata.author
      }));

    const popular = allTemplates
      .sort((a, b) => b.metadata.downloads - a.metadata.downloads)
      .slice(0, 6)
      .map(template => ({
        id: template.id,
        name: template.name,
        description: template.description,
        category: template.category,
        difficulty: template.difficulty,
        estimatedTime: template.estimatedTime,
        rating: template.metadata.rating,
        downloads: template.metadata.downloads,
        tags: template.tags,
        author: template.metadata.author
      }));

    const recent = allTemplates
      .sort((a, b) => b.metadata.updatedAt.getTime() - a.metadata.updatedAt.getTime())
      .slice(0, 6)
      .map(template => ({
        id: template.id,
        name: template.name,
        description: template.description,
        category: template.category,
        difficulty: template.difficulty,
        estimatedTime: template.estimatedTime,
        rating: template.metadata.rating,
        downloads: template.metadata.downloads,
        tags: template.tags,
        author: template.metadata.author
      }));

    res.json({
      success: true,
      data: {
        featured,
        popular,
        recent,
        stats: {
          totalTemplates: allTemplates.length,
          totalDownloads: allTemplates.reduce((sum, t) => sum + t.metadata.downloads, 0),
          avgRating: allTemplates.reduce((sum, t) => sum + t.metadata.rating, 0) / allTemplates.length,
          categories: [...new Set(allTemplates.map(t => t.category))]
        }
      }
    });

  } catch (error) {
    logger.error('Failed to get featured templates', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'FEATURED_ERROR',
        message: 'Failed to retrieve featured templates'
      }
    });
  }
}));

/**
 * Search templates
 */
router.get('/search', asyncHandler(async (req, res) => {
  try {
    const { q, category, difficulty, tags } = req.query;

    if (!q || typeof q !== 'string') {
      return res.status(400).json({
        success: false,
        error: {
          code: 'MISSING_QUERY',
          message: 'Search query is required'
        }
      });
    }

    let templates = projectWizard.getTemplates();
    const searchLower = q.toLowerCase();

    // Text search
    templates = templates.filter(template =>
      template.name.toLowerCase().includes(searchLower) ||
      template.description.toLowerCase().includes(searchLower) ||
      template.tags.some(tag => tag.toLowerCase().includes(searchLower)) ||
      template.metadata.author.toLowerCase().includes(searchLower)
    );

    // Filter by category
    if (category && typeof category === 'string') {
      templates = templates.filter(t => t.category === category);
    }

    // Filter by difficulty
    if (difficulty && typeof difficulty === 'string') {
      templates = templates.filter(t => t.difficulty === difficulty);
    }

    // Filter by tags
    if (tags && typeof tags === 'string') {
      const tagList = tags.split(',').map(tag => tag.trim().toLowerCase());
      templates = templates.filter(t =>
        tagList.some(tag => t.tags.some(templateTag => templateTag.toLowerCase().includes(tag)))
      );
    }

    // Track search
    await analyticsService.track({
      event: 'template_search',
      properties: {
        query: q,
        category,
        difficulty,
        tags,
        resultCount: templates.length
      }
    });

    const results = templates.map(template => ({
      id: template.id,
      name: template.name,
      description: template.description,
      category: template.category,
      difficulty: template.difficulty,
      estimatedTime: template.estimatedTime,
      rating: template.metadata.rating,
      downloads: template.metadata.downloads,
      tags: template.tags,
      author: template.metadata.author
    }));

    res.json({
      success: true,
      data: {
        query: q,
        results,
        resultCount: results.length,
        filters: {
          category,
          difficulty,
          tags
        }
      }
    });

  } catch (error) {
    logger.error('Failed to search templates', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'SEARCH_ERROR',
        message: 'Failed to search templates'
      }
    });
  }
}));

/**
 * Get marketplace statistics
 */
router.get('/stats', authentication({ role: 'admin' }), asyncHandler(async (req, res) => {
  try {
    const templates = projectWizard.getTemplates();
    
    const stats = {
      overview: {
        totalTemplates: templates.length,
        totalDownloads: templates.reduce((sum, t) => sum + t.metadata.downloads, 0),
        avgRating: templates.reduce((sum, t) => sum + t.metadata.rating, 0) / templates.length,
        totalAuthors: new Set(templates.map(t => t.metadata.author)).size
      },
      byCategory: templates.reduce((acc, template) => {
        if (!acc[template.category]) {
          acc[template.category] = { count: 0, downloads: 0 };
        }
        acc[template.category].count++;
        acc[template.category].downloads += template.metadata.downloads;
        return acc;
      }, {} as Record<string, { count: number; downloads: number }>),
      byDifficulty: templates.reduce((acc, template) => {
        if (!acc[template.difficulty]) {
          acc[template.difficulty] = { count: 0, downloads: 0 };
        }
        acc[template.difficulty].count++;
        acc[template.difficulty].downloads += template.metadata.downloads;
        return acc;
      }, {} as Record<string, { count: number; downloads: number }>),
      topTemplates: templates
        .sort((a, b) => b.metadata.downloads - a.metadata.downloads)
        .slice(0, 10)
        .map(t => ({
          id: t.id,
          name: t.name,
          downloads: t.metadata.downloads,
          rating: t.metadata.rating,
          category: t.category
        })),
      recentActivity: [] // Would come from database in real implementation
    };

    res.json({
      success: true,
      data: stats
    });

  } catch (error) {
    logger.error('Failed to get marketplace stats', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'STATS_ERROR',
        message: 'Failed to retrieve marketplace statistics'
      }
    });
  }
}));

export { router as templateMarketplaceRouter };