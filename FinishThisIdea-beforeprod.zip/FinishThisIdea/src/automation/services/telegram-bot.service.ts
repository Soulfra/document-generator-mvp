import TelegramBot from 'node-telegram-bot-api';
import { logger } from '../../utils/logger';
import { workflowEngine } from './workflow-engine.service';
import { launchPlaybook } from './launch-playbook.service';
import { queueHealthMonitor } from './queue-health-monitor.service';
import { analyticsService } from './analytics-integration.service';
import { fileOperations } from './file-operations.service';
import { gitOperations } from './git-operations.service';
import automationConfig from '../config/automation-config.json';
import * as fs from 'fs';
import * as path from 'path';

export interface BotCommand {
  command: string;
  description: string;
  handler: (msg: TelegramBot.Message, match: RegExpExecArray | null) => Promise<void>;
  adminOnly?: boolean;
  pattern?: RegExp;
}

export interface BotUser {
  id: number;
  username?: string;
  firstName?: string;
  lastName?: string;
  isAdmin: boolean;
  lastSeen: Date;
}

export class TelegramBotService {
  private bot: TelegramBot | null = null;
  private isInitialized = false;
  private authorizedUsers: Map<number, BotUser> = new Map();
  private commands: Map<string, BotCommand> = new Map();

  /**
   * Initialize the Telegram bot
   */
  public async initialize(): Promise<void> {
    if (this.isInitialized) {
      logger.warn('Telegram bot already initialized');
      return;
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      logger.warn('TELEGRAM_BOT_TOKEN not configured, skipping bot initialization');
      return;
    }

    if (!automationConfig.features.telegramBot) {
      logger.info('Telegram bot disabled in configuration');
      return;
    }

    try {
      // Initialize bot
      this.bot = new TelegramBot(botToken, { 
        polling: {
          interval: 1000,
          autoStart: false,
        }
      });

      // Load authorized users
      await this.loadAuthorizedUsers();

      // Register commands
      this.registerCommands();

      // Set up message handlers
      this.setupMessageHandlers();

      // Start polling
      await this.bot.startPolling();

      this.isInitialized = true;
      logger.info('Telegram bot initialized successfully');

      // Send startup notification to admin
      await this.notifyAdmins('🤖 FinishThisIdea bot is now online and ready for commands!');

    } catch (error) {
      logger.error('Failed to initialize Telegram bot', { error });
      throw error;
    }
  }

  /**
   * Register bot commands
   */
  private registerCommands(): void {
    // Basic commands
    this.addCommand({
      command: 'start',
      description: 'Start the bot and show welcome message',
      handler: this.handleStart.bind(this),
    });

    this.addCommand({
      command: 'help',
      description: 'Show available commands',
      handler: this.handleHelp.bind(this),
    });

    this.addCommand({
      command: 'status',
      description: 'Check system health and status',
      handler: this.handleStatus.bind(this),
    });

    // File operations
    this.addCommand({
      command: 'list',
      description: 'List files in current directory',
      handler: this.handleList.bind(this),
      pattern: /^\/list(?:\s+(.+))?$/,
    });

    this.addCommand({
      command: 'archive',
      description: 'Archive a file - Usage: /archive <filename>',
      handler: this.handleArchive.bind(this),
      pattern: /^\/archive\s+(.+)$/,
    });

    this.addCommand({
      command: 'restore',
      description: 'Restore a file from archive - Usage: /restore <filename>',
      handler: this.handleRestore.bind(this),
      pattern: /^\/restore\s+(.+)$/,
    });

    // Workflow operations
    this.addCommand({
      command: 'workflows',
      description: 'List available workflows',
      handler: this.handleWorkflows.bind(this),
    });

    this.addCommand({
      command: 'execute',
      description: 'Execute a workflow - Usage: /execute <workflow-name>',
      handler: this.handleExecuteWorkflow.bind(this),
      pattern: /^\/execute\s+(.+)$/,
    });

    // Launch management
    this.addCommand({
      command: 'launches',
      description: 'List recent launches',
      handler: this.handleLaunches.bind(this),
    });

    this.addCommand({
      command: 'launch',
      description: 'Create or manage launch - Usage: /launch <action> [name]',
      handler: this.handleLaunch.bind(this),
      pattern: /^\/launch\s+(\w+)(?:\s+(.+))?$/,
    });

    // Git operations
    this.addCommand({
      command: 'git',
      description: 'Git operations - Usage: /git <status|add|commit|push>',
      handler: this.handleGit.bind(this),
      pattern: /^\/git\s+(.+)$/,
    });

    // Admin commands
    this.addCommand({
      command: 'logs',
      description: 'Get recent logs',
      handler: this.handleLogs.bind(this),
      adminOnly: true,
      pattern: /^\/logs(?:\s+(\d+))?$/,
    });

    this.addCommand({
      command: 'restart',
      description: 'Restart automation services',
      handler: this.handleRestart.bind(this),
      adminOnly: true,
    });
  }

  /**
   * Set up message handlers
   */
  private setupMessageHandlers(): void {
    if (!this.bot) return;

    // Handle all messages
    this.bot.on('message', async (msg) => {
      try {
        if (!this.isAuthorizedUser(msg.from?.id)) {
          await this.sendMessage(msg.chat.id, '❌ Unauthorized. Contact the administrator for access.');
          logger.warn('Unauthorized bot access attempt', { 
            userId: msg.from?.id, 
            username: msg.from?.username 
          });
          return;
        }

        // Update user activity
        this.updateUserActivity(msg.from!);

        // Handle commands
        if (msg.text?.startsWith('/')) {
          await this.handleCommand(msg);
        } else {
          // Handle non-command messages
          await this.sendMessage(msg.chat.id, 'Send /help to see available commands.');
        }

      } catch (error) {
        logger.error('Error handling bot message', { error, messageId: msg.message_id });
        await this.sendMessage(msg.chat.id, '❌ An error occurred while processing your request.');
      }
    });

    // Handle callback queries (inline keyboards)
    this.bot.on('callback_query', async (query) => {
      try {
        if (!this.isAuthorizedUser(query.from.id)) {
          await this.bot?.answerCallbackQuery(query.id, { text: 'Unauthorized' });
          return;
        }

        await this.handleCallbackQuery(query);
      } catch (error) {
        logger.error('Error handling callback query', { error, queryId: query.id });
        await this.bot?.answerCallbackQuery(query.id, { text: 'Error occurred' });
      }
    });
  }

  /**
   * Handle command messages
   */
  private async handleCommand(msg: TelegramBot.Message): Promise<void> {
    const text = msg.text || '';
    
    // Find matching command
    for (const [name, cmd] of this.commands) {
      if (cmd.pattern) {
        const match = cmd.pattern.exec(text);
        if (match) {
          // Check admin permissions
          if (cmd.adminOnly && !this.isAdmin(msg.from?.id)) {
            await this.sendMessage(msg.chat.id, '❌ Admin access required for this command.');
            return;
          }

          await cmd.handler(msg, match);
          return;
        }
      } else if (text === `/${name}`) {
        // Check admin permissions
        if (cmd.adminOnly && !this.isAdmin(msg.from?.id)) {
          await this.sendMessage(msg.chat.id, '❌ Admin access required for this command.');
          return;
        }

        await cmd.handler(msg, null);
        return;
      }
    }

    // Unknown command
    await this.sendMessage(msg.chat.id, `❌ Unknown command: ${text}\nSend /help to see available commands.`);
  }

  /**
   * Command handlers
   */
  private async handleStart(msg: TelegramBot.Message): Promise<void> {
    const user = msg.from;
    const welcomeMessage = `
🤖 **Welcome to FinishThisIdea Bot!**

Hello ${user?.first_name || 'there'}! I can help you manage your project files and workflows remotely.

🔧 **Available Features:**
• File operations (archive, restore, list)
• Workflow execution
• Launch management  
• System health monitoring
• Git operations

Send /help to see all available commands.

**System Status:** ✅ Online and ready
    `;

    await this.sendMessage(msg.chat.id, welcomeMessage, { parse_mode: 'Markdown' });
  }

  private async handleHelp(msg: TelegramBot.Message): Promise<void> {
    const isUserAdmin = this.isAdmin(msg.from?.id);
    
    let helpText = '🤖 **FinishThisIdea Bot Commands**\n\n';
    
    // Group commands by category
    const categories = {
      'Basic Commands': ['start', 'help', 'status'],
      'File Operations': ['list', 'archive', 'restore'],
      'Workflows': ['workflows', 'execute'],
      'Launch Management': ['launches', 'launch'],
      'Git Operations': ['git'],
    };

    if (isUserAdmin) {
      categories['Admin Commands'] = ['logs', 'restart'];
    }

    for (const [category, commandNames] of Object.entries(categories)) {
      helpText += `**${category}:**\n`;
      for (const commandName of commandNames) {
        const command = this.commands.get(commandName);
        if (command) {
          helpText += `• /${commandName} - ${command.description}\n`;
        }
      }
      helpText += '\n';
    }

    helpText += '💡 **Tips:**\n';
    helpText += '• Commands are case-sensitive\n';
    helpText += '• Use /status to check system health\n';
    helpText += '• File paths are relative to project root\n';

    await this.sendMessage(msg.chat.id, helpText, { parse_mode: 'Markdown' });
  }

  private async handleStatus(msg: TelegramBot.Message): Promise<void> {
    try {
      const queueStats = await queueHealthMonitor.getQueueStats();
      const launches = await launchPlaybook.getAllLaunches();
      const activeLaunches = launches.filter(l => l.status === 'launching' || l.status === 'planning').length;

      const statusMessage = `
📊 **System Status**

🔄 **Queue Health:**
${Object.entries(queueStats).map(([name, stats]) => 
  `• ${name}: ${stats.waiting} waiting, ${stats.active} active, ${stats.failed} failed`
).join('\n')}

🚀 **Launches:**
• Total: ${launches.length}
• Active: ${activeLaunches}
• Latest: ${launches[0]?.name || 'None'} (${launches[0]?.status || 'N/A'})

⚡ **Automation:**
• Workflows: ${workflowEngine.getAvailableTemplates().length} available
• Bot: ✅ Online
• Services: ✅ Running

🕐 **Last Updated:** ${new Date().toLocaleString()}
      `;

      await this.sendMessage(msg.chat.id, statusMessage, { parse_mode: 'Markdown' });

    } catch (error) {
      logger.error('Error getting system status', { error });
      await this.sendMessage(msg.chat.id, '❌ Error retrieving system status.');
    }
  }

  private async handleList(msg: TelegramBot.Message, match: RegExpExecArray | null): Promise<void> {
    try {
      const directory = match?.[1] || '.';
      const files = await fileOperations.listFiles(directory);
      
      if (files.length === 0) {
        await this.sendMessage(msg.chat.id, `📁 No files found in: ${directory}`);
        return;
      }

      const filesList = files.slice(0, 20).map(file => 
        `${file.type === 'directory' ? '📁' : '📄'} ${file.name}`
      ).join('\n');

      const message = `📁 **Files in ${directory}:**\n\n${filesList}`;
      
      if (files.length > 20) {
        message + `\n\n... and ${files.length - 20} more files`;
      }

      await this.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });

    } catch (error) {
      logger.error('Error listing files', { error });
      await this.sendMessage(msg.chat.id, '❌ Error listing files.');
    }
  }

  private async handleArchive(msg: TelegramBot.Message, match: RegExpExecArray | null): Promise<void> {
    if (!match?.[1]) {
      await this.sendMessage(msg.chat.id, '❌ Please specify a filename: /archive <filename>');
      return;
    }

    try {
      const filename = match[1];
      const result = await fileOperations.archiveFile(filename);
      
      await this.sendMessage(msg.chat.id, `✅ Archived: ${filename} → ${result.archivedPath}`);
      
      // Track action
      await analyticsService.track({
        event: 'bot_file_archived',
        userId: msg.from?.id?.toString() || 'unknown',
        properties: {
          filename,
          archived_path: result.archivedPath,
        },
      });

    } catch (error) {
      logger.error('Error archiving file', { error, filename: match[1] });
      await this.sendMessage(msg.chat.id, `❌ Error archiving file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async handleRestore(msg: TelegramBot.Message, match: RegExpExecArray | null): Promise<void> {
    if (!match?.[1]) {
      await this.sendMessage(msg.chat.id, '❌ Please specify a filename: /restore <filename>');
      return;
    }

    try {
      const filename = match[1];
      const result = await fileOperations.restoreFile(filename);
      
      await this.sendMessage(msg.chat.id, `✅ Restored: ${filename} → ${result.restoredPath}`);

    } catch (error) {
      logger.error('Error restoring file', { error, filename: match[1] });
      await this.sendMessage(msg.chat.id, `❌ Error restoring file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async handleWorkflows(msg: TelegramBot.Message): Promise<void> {
    try {
      const workflows = workflowEngine.getAvailableTemplates();
      
      if (workflows.length === 0) {
        await this.sendMessage(msg.chat.id, '📋 No workflows available.');
        return;
      }

      const workflowsList = workflows.map(name => `• ${name}`).join('\n');
      const message = `📋 **Available Workflows:**\n\n${workflowsList}\n\nUse /execute <workflow-name> to run a workflow.`;
      
      await this.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });

    } catch (error) {
      logger.error('Error listing workflows', { error });
      await this.sendMessage(msg.chat.id, '❌ Error listing workflows.');
    }
  }

  private async handleExecuteWorkflow(msg: TelegramBot.Message, match: RegExpExecArray | null): Promise<void> {
    if (!match?.[1]) {
      await this.sendMessage(msg.chat.id, '❌ Please specify a workflow: /execute <workflow-name>');
      return;
    }

    try {
      const workflowName = match[1];
      await this.sendMessage(msg.chat.id, `🔄 Executing workflow: ${workflowName}...`);

      const result = await workflowEngine.executeWorkflow(workflowName, {
        variables: {
          triggered_by: 'telegram_bot',
          user_id: msg.from?.id?.toString(),
          chat_id: msg.chat.id,
        },
        userId: msg.from?.id?.toString() || 'bot',
        timestamp: new Date(),
      });

      const statusIcon = result.success ? '✅' : '❌';
      const message = `${statusIcon} **Workflow: ${workflowName}**\n\n` +
        `• Executed: ${result.executedSteps} steps\n` +
        `• Failed: ${result.failedSteps} steps\n` +
        `• Duration: ${result.totalDuration}ms\n` +
        `• Status: ${result.success ? 'Success' : 'Failed'}`;

      await this.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });

    } catch (error) {
      logger.error('Error executing workflow', { error, workflow: match[1] });
      await this.sendMessage(msg.chat.id, `❌ Error executing workflow: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async handleLaunches(msg: TelegramBot.Message): Promise<void> {
    try {
      const launches = await launchPlaybook.getAllLaunches();
      
      if (launches.length === 0) {
        await this.sendMessage(msg.chat.id, '🚀 No launches found.');
        return;
      }

      const launchList = launches.slice(0, 10).map(launch => {
        const statusIcon = launch.status === 'live' ? '✅' : 
                          launch.status === 'launching' ? '🔄' : 
                          launch.status === 'ready' ? '⚡' : '⏳';
        return `${statusIcon} ${launch.name} v${launch.version} (${launch.status})`;
      }).join('\n');

      const message = `🚀 **Recent Launches:**\n\n${launchList}\n\nUse /launch <action> to manage launches.`;
      
      await this.sendMessage(msg.chat.id, message, { parse_mode: 'Markdown' });

    } catch (error) {
      logger.error('Error listing launches', { error });
      await this.sendMessage(msg.chat.id, '❌ Error listing launches.');
    }
  }

  private async handleLaunch(msg: TelegramBot.Message, match: RegExpExecArray | null): Promise<void> {
    if (!match?.[1]) {
      await this.sendMessage(msg.chat.id, '❌ Usage: /launch <list|create|start|status> [name]');
      return;
    }

    const action = match[1].toLowerCase();
    const name = match[2];

    try {
      switch (action) {
        case 'list':
          await this.handleLaunches(msg);
          break;
          
        case 'create':
          if (!name) {
            await this.sendMessage(msg.chat.id, '❌ Please provide a launch name: /launch create <name>');
            return;
          }
          
          const launch = await launchPlaybook.createLaunch(
            name,
            '1.0.0',
            msg.from?.id?.toString() || 'bot'
          );
          
          await this.sendMessage(msg.chat.id, `✅ Created launch: ${launch.name} (${launch.id})`);
          break;
          
        default:
          await this.sendMessage(msg.chat.id, '❌ Unknown launch action. Use: list, create, start, or status');
      }

    } catch (error) {
      logger.error('Error handling launch command', { error, action, name });
      await this.sendMessage(msg.chat.id, `❌ Error with launch command: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async handleGit(msg: TelegramBot.Message, match: RegExpExecArray | null): Promise<void> {
    if (!match?.[1]) {
      await this.sendMessage(msg.chat.id, '❌ Usage: /git <status|add|commit|push>');
      return;
    }

    try {
      const action = match[1].toLowerCase();
      let result: any;

      switch (action) {
        case 'status':
          result = await gitOperations.getStatus();
          await this.sendMessage(msg.chat.id, `📊 **Git Status:**\n\n${result.output}`, { parse_mode: 'Markdown' });
          break;
          
        case 'add':
          result = await gitOperations.addAll();
          await this.sendMessage(msg.chat.id, `✅ Added all changes to git staging area.`);
          break;
          
        case 'commit':
          const commitMessage = `Bot commit: ${new Date().toISOString()}`;
          result = await gitOperations.commit(commitMessage);
          await this.sendMessage(msg.chat.id, `✅ Committed changes: ${commitMessage}`);
          break;
          
        case 'push':
          result = await gitOperations.push();
          await this.sendMessage(msg.chat.id, `✅ Pushed changes to remote repository.`);
          break;
          
        default:
          await this.sendMessage(msg.chat.id, '❌ Unknown git action. Use: status, add, commit, or push');
      }

    } catch (error) {
      logger.error('Error with git operation', { error, action: match[1] });
      await this.sendMessage(msg.chat.id, `❌ Git error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async handleLogs(msg: TelegramBot.Message, match: RegExpExecArray | null): Promise<void> {
    try {
      const lines = parseInt(match?.[1] || '20');
      // This would read from your log files
      const logs = `Recent logs would be shown here (last ${lines} lines)`;
      
      await this.sendMessage(msg.chat.id, `📋 **Recent Logs (${lines} lines):**\n\n\`\`\`\n${logs}\n\`\`\``, { parse_mode: 'Markdown' });

    } catch (error) {
      logger.error('Error getting logs', { error });
      await this.sendMessage(msg.chat.id, '❌ Error retrieving logs.');
    }
  }

  private async handleRestart(msg: TelegramBot.Message): Promise<void> {
    try {
      await this.sendMessage(msg.chat.id, '🔄 Restarting automation services...');
      
      // This would restart your services
      // For now, just simulate
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      await this.sendMessage(msg.chat.id, '✅ Automation services restarted successfully.');

    } catch (error) {
      logger.error('Error restarting services', { error });
      await this.sendMessage(msg.chat.id, '❌ Error restarting services.');
    }
  }

  /**
   * Utility methods
   */
  private addCommand(command: BotCommand): void {
    this.commands.set(command.command, command);
  }

  private async handleCallbackQuery(query: TelegramBot.CallbackQuery): Promise<void> {
    // Handle inline keyboard callbacks
    await this.bot?.answerCallbackQuery(query.id, { text: 'Feature coming soon!' });
  }

  private async sendMessage(chatId: number, text: string, options?: TelegramBot.SendMessageOptions): Promise<void> {
    if (!this.bot) return;
    
    try {
      await this.bot.sendMessage(chatId, text, options);
    } catch (error) {
      logger.error('Error sending telegram message', { error, chatId });
    }
  }

  private async notifyAdmins(message: string): Promise<void> {
    const admins = Array.from(this.authorizedUsers.values()).filter(user => user.isAdmin);
    
    for (const admin of admins) {
      try {
        await this.sendMessage(admin.id, message);
      } catch (error) {
        logger.error('Error notifying admin', { error, adminId: admin.id });
      }
    }
  }

  private isAuthorizedUser(userId?: number): boolean {
    if (!userId) return false;
    return this.authorizedUsers.has(userId);
  }

  private isAdmin(userId?: number): boolean {
    if (!userId) return false;
    const user = this.authorizedUsers.get(userId);
    return user?.isAdmin || false;
  }

  private updateUserActivity(user: TelegramBot.User): void {
    const existingUser = this.authorizedUsers.get(user.id);
    if (existingUser) {
      existingUser.lastSeen = new Date();
      this.authorizedUsers.set(user.id, existingUser);
    }
  }

  private async loadAuthorizedUsers(): Promise<void> {
    // Load from environment or config
    const adminUserIds = (process.env.TELEGRAM_ADMIN_USER_IDS || '').split(',').filter(Boolean);
    
    for (const userId of adminUserIds) {
      const id = parseInt(userId.trim());
      if (!isNaN(id)) {
        this.authorizedUsers.set(id, {
          id,
          isAdmin: true,
          lastSeen: new Date(),
        });
      }
    }

    logger.info(`Loaded ${this.authorizedUsers.size} authorized bot users`);
  }

  /**
   * Public methods
   */
  public async shutdown(): Promise<void> {
    if (this.bot && this.isInitialized) {
      await this.notifyAdmins('🤖 Bot is shutting down...');
      await this.bot.stopPolling();
      this.isInitialized = false;
      logger.info('Telegram bot shut down');
    }
  }

  public isRunning(): boolean {
    return this.isInitialized && this.bot !== null;
  }

  public async sendNotification(message: string): Promise<void> {
    await this.notifyAdmins(message);
  }

  public getStats(): { authorizedUsers: number; commandsRegistered: number; isRunning: boolean } {
    return {
      authorizedUsers: this.authorizedUsers.size,
      commandsRegistered: this.commands.size,
      isRunning: this.isRunning(),
    };
  }
}

// Export singleton instance
export const telegramBot = new TelegramBotService();