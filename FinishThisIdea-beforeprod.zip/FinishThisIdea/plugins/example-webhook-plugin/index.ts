/**
 * Example Webhook Plugin
 * Demonstrates how to create a custom workflow step plugin
 */

import { BasePlugin } from '../../src/automation/plugins/base-plugin';
import { PluginMetadata, PluginField, PluginExecutionResult } from '../../src/automation/plugins/interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../../src/automation/interfaces/workflow.interface';
import axios from 'axios';

export class WebhookPlugin extends BasePlugin {
  metadata: PluginMetadata = {
    id: 'webhook',
    name: 'HTTP Webhook',
    version: '1.0.0',
    description: 'Send HTTP requests to external webhooks',
    author: 'FinishThisIdea Community',
    icon: '🌐',
    category: 'integration',
    tags: ['webhook', 'http', 'api', 'integration']
  };
  
  fields: PluginField[] = [
    {
      name: 'url',
      label: 'Webhook URL',
      type: 'text',
      required: true,
      placeholder: 'https://example.com/webhook',
      description: 'The URL to send the request to',
      validation: {
        pattern: '^https?://.+'
      }
    },
    {
      name: 'method',
      label: 'HTTP Method',
      type: 'select',
      required: false,
      default: 'POST',
      options: [
        { value: 'GET', label: 'GET' },
        { value: 'POST', label: 'POST' },
        { value: 'PUT', label: 'PUT' },
        { value: 'PATCH', label: 'PATCH' },
        { value: 'DELETE', label: 'DELETE' }
      ],
      description: 'HTTP method to use'
    },
    {
      name: 'headers',
      label: 'Headers',
      type: 'json',
      required: false,
      placeholder: '{"Content-Type": "application/json"}',
      description: 'HTTP headers to include'
    },
    {
      name: 'body',
      label: 'Request Body',
      type: 'json',
      required: false,
      placeholder: '{"event": "workflow_completed"}',
      description: 'JSON body to send (for POST/PUT/PATCH)'
    },
    {
      name: 'timeout',
      label: 'Timeout (seconds)',
      type: 'number',
      required: false,
      default: 30,
      validation: {
        min: 1,
        max: 300
      },
      description: 'Request timeout in seconds'
    },
    {
      name: 'retryOnFailure',
      label: 'Retry on Failure',
      type: 'boolean',
      required: false,
      default: false,
      description: 'Whether to retry failed requests'
    },
    {
      name: 'retryCount',
      label: 'Retry Count',
      type: 'number',
      required: false,
      default: 3,
      validation: {
        min: 1,
        max: 5
      },
      description: 'Number of retry attempts'
    }
  ];
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    const { 
      url, 
      method = 'POST', 
      headers = {}, 
      body = {}, 
      timeout = 30,
      retryOnFailure = false,
      retryCount = 3
    } = step;
    
    if (!url) {
      return this.failure('Webhook URL is required');
    }
    
    // Interpolate context variables into body
    const interpolatedBody = this.interpolateObject(body, context);
    
    let attempts = 0;
    let lastError: Error | null = null;
    
    while (attempts < (retryOnFailure ? retryCount : 1)) {
      attempts++;
      
      try {
        const { result, duration } = await this.measureExecution(async () => {
          const response = await axios({
            url,
            method,
            headers: {
              'Content-Type': 'application/json',
              ...headers
            },
            data: ['POST', 'PUT', 'PATCH'].includes(method.toUpperCase()) ? interpolatedBody : undefined,
            timeout: timeout * 1000,
            validateStatus: (status) => status < 500 // Don't throw on 4xx errors
          });
          
          return {
            status: response.status,
            statusText: response.statusText,
            data: response.data,
            headers: response.headers
          };
        });
        
        this.logger.info(`Webhook request to ${url} completed with status ${result.status}`);
        
        // Check if response indicates success
        if (result.status >= 200 && result.status < 300) {
          return this.success(
            {
              status: result.status,
              response: result.data
            },
            duration,
            [
              `${method} request to ${url}`,
              `Status: ${result.status} ${result.statusText}`,
              attempts > 1 ? `Succeeded after ${attempts} attempts` : null
            ].filter(Boolean)
          );
        } else {
          // 4xx errors - don't retry
          return this.failure(`Webhook returned error: ${result.status} ${result.statusText}`);
        }
        
      } catch (error) {
        lastError = error as Error;
        this.logger.warn(`Webhook request attempt ${attempts} failed:`, error);
        
        if (attempts < (retryOnFailure ? retryCount : 1)) {
          // Wait before retry (exponential backoff)
          await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempts - 1) * 1000));
        }
      }
    }
    
    // All attempts failed
    return this.failure(
      `Webhook request failed after ${attempts} attempts: ${lastError?.message || 'Unknown error'}`
    );
  }
  
  /**
   * Interpolate context variables into an object
   */
  private interpolateObject(obj: any, context: WorkflowContext): any {
    if (typeof obj === 'string') {
      // Replace {{variable}} patterns
      return obj.replace(/\{\{(\w+)\}\}/g, (match, key) => {
        return context.variables[key] || match;
      });
    } else if (Array.isArray(obj)) {
      return obj.map(item => this.interpolateObject(item, context));
    } else if (obj && typeof obj === 'object') {
      const result: any = {};
      for (const [key, value] of Object.entries(obj)) {
        result[key] = this.interpolateObject(value, context);
      }
      return result;
    }
    return obj;
  }
  
  async testConnection(config: Record<string, any>): Promise<{ success: boolean; message?: string }> {
    if (!config.url) {
      return {
        success: false,
        message: 'Test URL is required for connection test'
      };
    }
    
    try {
      const response = await axios.head(config.url, { timeout: 5000 });
      return {
        success: true,
        message: `Webhook endpoint is reachable (Status: ${response.status})`
      };
    } catch (error) {
      return {
        success: false,
        message: `Cannot reach webhook endpoint: ${(error as Error).message}`
      };
    }
  }
}

// Export the plugin
export default WebhookPlugin;