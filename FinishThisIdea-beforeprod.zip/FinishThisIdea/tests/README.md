# FinishThisIdea Test Suite

Comprehensive test suite ensuring the FinishThisIdea documentation generation pipeline works reliably for any codebase input.

## Test Structure

### Unit Tests
- `documentation-service.test.ts` - Core documentation generation logic
- `file-processing.test.ts` - File extraction and processing
- `chat-parser.test.ts` - Requirements extraction from conversations  
- `error-handling.test.ts` - Error handling and resilience
- `function-extraction.test.ts` - AST-based code analysis
- `template-transformations.test.ts` - Documentation template processing

### API Tests
- `documentation-api.test.ts` - REST API endpoint testing with mocks

### End-to-End Tests
- `complete-pipeline.test.ts` - Full upload → documentation pipeline
- `self-testing.test.ts` - Dogfooding with our own codebase

### Test Utilities
- `sample-generator.ts` - Generate realistic test projects
- `zip-manager.ts` - ZIP file creation and management  
- `test-database.ts` - Database setup and cleanup

## Sample Projects

The test suite includes realistic sample projects covering:

### Languages & Frameworks
- **React E-commerce** (TypeScript) - Complex frontend with multiple components
- **Next.js Blog** (TypeScript) - Static site generation and file-based routing
- **Django Webapp** (Python) - Full-stack web application with ORM
- **Spring Boot API** (Java) - Enterprise REST API with JPA

### Project Types
- **Web Applications** - Frontend projects with routing and state management
- **APIs** - Backend services with database integration
- **Full-Stack** - Combined frontend/backend applications

### Complexity Levels
- **Standard** - Typical startup-sized projects (10-50 files)
- **Enterprise** - Complex applications (100-500 files) with advanced patterns

## Running Tests

### Install Dependencies
```bash
npm install
```

### Run All Tests
```bash
npm run test:all
```

### Run Unit Tests Only
```bash
npm run test:unit
```

### Run End-to-End Tests Only
```bash
npm run test:e2e
```

### Run with Coverage
```bash
npm run test:coverage
```

### Run in Watch Mode
```bash
npm run test:watch
```

## Test Categories

### 🚀 Complete Pipeline Tests
Test the entire workflow from file upload to documentation generation:

1. **Upload Processing** - File validation, ZIP extraction, metadata extraction
2. **Code Analysis** - Language detection, framework identification, code parsing
3. **Documentation Generation** - Template processing, AI content generation
4. **Quality Validation** - Completeness, accuracy, readability scoring
5. **Packaging & Storage** - ZIP creation, S3 upload, database storage

### 🔄 Self-Testing (Dogfooding)
Process our own FinishThisIdea codebase to validate:

- **Real-world Complexity** - Handle our actual project structure
- **Quality Standards** - Generate high-quality docs for our own code
- **Performance Benchmarks** - Meet processing time requirements
- **Consistency** - Produce repeatable results across runs

### 🧠 Chat Log Processing
Test requirements extraction from AI conversations:

- **User Story Extraction** - Parse "As a... I want... so that..." patterns
- **Technical Requirements** - Identify frameworks, languages, architectures
- **Business Rules** - Extract validation rules and constraints
- **Confidence Scoring** - Rate extraction accuracy

### ⚡ Performance & Scale
Validate system performance under load:

- **Concurrent Processing** - Handle multiple simultaneous uploads
- **Large Codebases** - Process enterprise-scale projects
- **Memory Management** - Avoid memory leaks with large files
- **Processing Speed** - Meet time requirements for documentation generation

### 🛡️ Error Handling
Test resilience and error recovery:

- **Malformed Files** - Handle corrupted ZIPs gracefully
- **Unsupported Formats** - Reject invalid file types with clear messages
- **Resource Limits** - Enforce file size and complexity limits
- **Service Failures** - Handle external service outages

## Sample Project Details

### React E-commerce Platform
```
Features: Product catalog, shopping cart, user authentication, payment processing
Files: 25+ TypeScript/React components with realistic complexity
Tests: Component testing, API integration, state management
```

### Django Webapp  
```
Features: User management, REST API, database models, admin interface
Files: 15+ Python files with Django patterns and PostgreSQL integration
Tests: Model testing, view testing, API testing
```

### Spring Boot API
```
Features: JWT authentication, JPA entities, REST controllers, comprehensive docs
Files: 20+ Java files with enterprise patterns and Maven configuration
Tests: Unit tests, integration tests, security testing
```

### Next.js Blog
```
Features: Static site generation, markdown processing, file-based routing
Files: 10+ TypeScript files with modern Next.js patterns
Tests: Page testing, API route testing, build testing
```

## Test Data Management

### Database Isolation
- Each test runs with a fresh database instance
- Automatic cleanup between tests
- Seeded data for consistent test conditions

### File Management
- Temporary directories for test files
- Automatic cleanup of generated ZIPs
- Isolated storage to prevent test interference

### Mock Services
- S3 operations mocked for unit tests
- Real S3 integration for E2E tests (with cleanup)
- LLM calls controlled with token limits

## Quality Metrics

### Coverage Targets
- **Unit Tests**: >90% code coverage
- **Integration Tests**: All API endpoints covered
- **E2E Tests**: Complete user journeys validated

### Performance Benchmarks
- **Upload Processing**: <30 seconds for typical projects
- **Documentation Generation**: <60 seconds for standard templates
- **Total Pipeline**: <90 seconds end-to-end

### Quality Standards
- **Documentation Quality**: >75% overall score
- **Completeness**: >70% of code elements documented
- **Accuracy**: >70% accurate analysis
- **Readability**: >75% readable output

## Continuous Integration

### Pre-commit Hooks
- Lint checking with ESLint
- Type checking with TypeScript
- Unit test execution
- Code formatting with Prettier

### CI Pipeline
1. **Install Dependencies** - npm install with cache
2. **Lint & Type Check** - Code quality validation
3. **Unit Tests** - Fast feedback on core logic
4. **Integration Tests** - API and service integration
5. **E2E Tests** - Full pipeline validation
6. **Coverage Report** - Generate and upload coverage

### Test Environment
- **Node.js**: 18+ for all test execution
- **PostgreSQL**: Test database with migrations
- **Redis**: For caching and queue testing (optional)
- **S3**: Test bucket for file operations

## Troubleshooting

### Common Issues

**Tests timing out:**
```bash
# Increase Jest timeout
jest --testTimeout=30000
```

**Database connection issues:**
```bash
# Check PostgreSQL is running
pg_isready -h localhost -p 5432
```

**File permission errors:**
```bash
# Ensure temp directory permissions
chmod 755 /tmp
```

**Memory issues with large tests:**
```bash
# Increase Node.js memory limit
node --max-old-space-size=4096 node_modules/.bin/jest
```

### Debug Mode
```bash
# Run tests with debug output
DEBUG=finishthisidea:* npm test

# Run specific test file
npm test -- tests/e2e/complete-pipeline.test.ts

# Run with verbose output
npm test -- --verbose
```

## Contributing

### Adding New Tests
1. Create test file in appropriate directory
2. Follow naming convention: `*.test.ts`
3. Include setup/teardown for resources
4. Add meaningful assertions and error messages

### Adding Sample Projects
1. Add project definition to `sample-generator.ts`
2. Include realistic file structure and content
3. Test with actual upload pipeline
4. Document project features and complexity

### Test Best Practices
- **Isolation**: Each test should be independent
- **Cleanup**: Always clean up resources
- **Assertions**: Use meaningful expect messages
- **Performance**: Keep test execution time reasonable
- **Coverage**: Test both success and failure cases