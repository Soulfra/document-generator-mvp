import { promises as fs } from 'fs';
import * as path from 'path';
import { logger } from '../../utils/logger';
import { analyticsService } from './analytics-integration.service';
import { emailService } from './email.service';
import { workflowEngine } from './workflow-engine.service';
import { prisma } from '../../utils/database';
import * as Sentry from '@sentry/node';

export interface LaunchChecklistItem {
  id: string;
  title: string;
  description: string;
  category: 'pre-launch' | 'launch' | 'post-launch';
  priority: 'critical' | 'high' | 'medium' | 'low';
  status: 'pending' | 'in_progress' | 'completed' | 'failed' | 'skipped';
  assignee?: string;
  dueDate?: Date;
  completedAt?: Date;
  validationScript?: string;
  dependencies?: string[];
  automationWorkflow?: string;
  notes?: string;
}

export interface LaunchStatus {
  id: string;
  name: string;
  version: string;
  status: 'planning' | 'ready' | 'launching' | 'live' | 'rollback';
  checklist: LaunchChecklistItem[];
  startedAt?: Date;
  completedAt?: Date;
  launchedBy?: string;
  rollbackReason?: string;
  metadata: Record<string, any>;
}

export interface LaunchValidationResult {
  item: string;
  passed: boolean;
  message: string;
  details?: any;
}

export class LaunchPlaybookService {
  private static readonly DEFAULT_CHECKLIST: Omit<LaunchChecklistItem, 'id' | 'status'>[] = [
    // Pre-launch critical items
    {
      title: "All automation modules verified",
      description: "Ensure automation and improvements modules are archived and functional",
      category: "pre-launch",
      priority: "critical",
      validationScript: "npm run test:automation",
    },
    {
      title: "Production environment variables set",
      description: "Configure all production environment variables in .env",
      category: "pre-launch",
      priority: "critical",
      validationScript: "node scripts/validate-env.js",
    },
    {
      title: "Switch to live API keys",
      description: "Stripe and other API keys switched to live/production mode",
      category: "pre-launch",
      priority: "critical",
    },
    {
      title: "Domain and SSL configured",
      description: "Production domain configured with valid SSL certificate",
      category: "pre-launch",
      priority: "critical",
      validationScript: "curl -I https://finishthisidea.com",
    },
    {
      title: "CI/CD pipeline green",
      description: "All tests passing in continuous integration",
      category: "pre-launch",
      priority: "critical",
      validationScript: "npm run test:all",
    },
    {
      title: "Monitoring and analytics enabled",
      description: "Sentry, analytics, and monitoring systems active",
      category: "pre-launch",
      priority: "high",
      validationScript: "npm run test:monitoring",
    },
    {
      title: "Database migrations applied",
      description: "All database migrations applied to production",
      category: "pre-launch",
      priority: "critical",
      validationScript: "npx prisma migrate status",
    },
    {
      title: "Load testing completed",
      description: "System tested under expected load",
      category: "pre-launch",
      priority: "high",
      validationScript: "npm run test:load",
    },

    // Launch items
    {
      title: "Deploy backend and frontend",
      description: "Deploy application to production environment",
      category: "launch",
      priority: "critical",
      automationWorkflow: "deployment-workflow",
    },
    {
      title: "Enable automation services",
      description: "Activate feature flags for automation services",
      category: "launch",
      priority: "high",
    },
    {
      title: "Run final E2E tests",
      description: "Execute end-to-end tests in production environment",
      category: "launch",
      priority: "critical",
      validationScript: "npm run test:e2e:production",
    },
    {
      title: "Health checks passing",
      description: "All system health checks returning green",
      category: "launch",
      priority: "critical",
      validationScript: "curl -f https://api.finishthisidea.com/health",
    },

    // Post-launch items
    {
      title: "Send launch announcements",
      description: "Execute launch announcement workflow",
      category: "post-launch",
      priority: "high",
      automationWorkflow: "launch-announcement-workflow",
    },
    {
      title: "Monitor system metrics",
      description: "Monitor performance, errors, and user activity",
      category: "post-launch",
      priority: "critical",
    },
    {
      title: "Verify payment processing",
      description: "Test payment flows in production",
      category: "post-launch",
      priority: "critical",
    },
    {
      title: "Customer support ready",
      description: "Support team briefed and monitoring channels",
      category: "post-launch",
      priority: "high",
    },
  ];

  /**
   * Create a new launch with default checklist
   */
  public async createLaunch(
    name: string,
    version: string,
    launchedBy: string,
    customItems: Partial<LaunchChecklistItem>[] = []
  ): Promise<LaunchStatus> {
    const launchId = `launch-${Date.now()}`;
    
    // Create checklist items
    const checklist: LaunchChecklistItem[] = [
      ...this.DEFAULT_CHECKLIST.map((item, index) => ({
        id: `item-${index + 1}`,
        status: 'pending' as const,
        ...item,
      })),
      ...customItems.map((item, index) => ({
        id: `custom-${index + 1}`,
        status: 'pending' as const,
        category: 'pre-launch' as const,
        priority: 'medium' as const,
        title: 'Custom Item',
        description: '',
        ...item,
      })),
    ];

    const launch: LaunchStatus = {
      id: launchId,
      name,
      version,
      status: 'planning',
      checklist,
      launchedBy,
      metadata: {
        createdAt: new Date(),
        environment: process.env.NODE_ENV || 'development',
      },
    };

    // Store launch status
    await this.saveLaunchStatus(launch);

    // Track launch creation
    await analyticsService.track({
      event: 'launch_created',
      userId: launchedBy,
      properties: {
        launch_id: launchId,
        launch_name: name,
        version,
        checklist_items: checklist.length,
      },
    });

    logger.info('Launch created', { launchId, name, version, itemCount: checklist.length });
    return launch;
  }

  /**
   * Get launch status
   */
  public async getLaunchStatus(launchId: string): Promise<LaunchStatus | null> {
    try {
      const filePath = this.getLaunchFilePath(launchId);
      const content = await fs.readFile(filePath, 'utf8');
      return JSON.parse(content);
    } catch (error) {
      if ((error as any).code === 'ENOENT') {
        return null;
      }
      throw error;
    }
  }

  /**
   * Update checklist item status
   */
  public async updateChecklistItem(
    launchId: string,
    itemId: string,
    updates: Partial<LaunchChecklistItem>
  ): Promise<LaunchStatus> {
    const launch = await this.getLaunchStatus(launchId);
    if (!launch) {
      throw new Error(`Launch ${launchId} not found`);
    }

    const itemIndex = launch.checklist.findIndex(item => item.id === itemId);
    if (itemIndex === -1) {
      throw new Error(`Checklist item ${itemId} not found`);
    }

    // Update item
    launch.checklist[itemIndex] = {
      ...launch.checklist[itemIndex],
      ...updates,
    };

    // If marking as completed, set timestamp
    if (updates.status === 'completed') {
      launch.checklist[itemIndex].completedAt = new Date();
    }

    // Update launch status based on checklist
    launch.status = this.calculateLaunchStatus(launch);

    // Save updated launch
    await this.saveLaunchStatus(launch);

    // Track item completion
    await analyticsService.track({
      event: 'launch_item_updated',
      userId: launch.launchedBy || 'system',
      properties: {
        launch_id: launchId,
        item_id: itemId,
        status: updates.status,
        category: launch.checklist[itemIndex].category,
        priority: launch.checklist[itemIndex].priority,
      },
    });

    logger.info('Checklist item updated', { 
      launchId, 
      itemId, 
      status: updates.status,
      title: launch.checklist[itemIndex].title,
    });

    return launch;
  }

  /**
   * Validate checklist item
   */
  public async validateChecklistItem(
    launchId: string,
    itemId: string
  ): Promise<LaunchValidationResult> {
    const launch = await this.getLaunchStatus(launchId);
    if (!launch) {
      throw new Error(`Launch ${launchId} not found`);
    }

    const item = launch.checklist.find(item => item.id === itemId);
    if (!item) {
      throw new Error(`Checklist item ${itemId} not found`);
    }

    if (!item.validationScript) {
      return {
        item: itemId,
        passed: true,
        message: 'No validation script configured - manual verification required',
      };
    }

    try {
      // Execute validation script
      const { exec } = require('child_process');
      const { promisify } = require('util');
      const execAsync = promisify(exec);

      const { stdout, stderr } = await execAsync(item.validationScript);
      
      const passed = !stderr && stdout;
      
      // Auto-update item status if validation passes
      if (passed && item.status === 'pending') {
        await this.updateChecklistItem(launchId, itemId, { 
          status: 'completed',
          notes: `Auto-validated: ${new Date().toISOString()}`,
        });
      }

      return {
        item: itemId,
        passed,
        message: passed ? 'Validation passed' : 'Validation failed',
        details: { stdout, stderr },
      };
    } catch (error) {
      logger.error(`Validation failed for item ${itemId}`, { error, item: item.title });
      
      return {
        item: itemId,
        passed: false,
        message: `Validation error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        details: { error },
      };
    }
  }

  /**
   * Execute automation workflow for checklist item
   */
  public async executeItemWorkflow(
    launchId: string,
    itemId: string
  ): Promise<any> {
    const launch = await this.getLaunchStatus(launchId);
    if (!launch) {
      throw new Error(`Launch ${launchId} not found`);
    }

    const item = launch.checklist.find(item => item.id === itemId);
    if (!item || !item.automationWorkflow) {
      throw new Error(`No automation workflow configured for item ${itemId}`);
    }

    // Mark item as in progress
    await this.updateChecklistItem(launchId, itemId, { status: 'in_progress' });

    try {
      // Execute workflow
      const result = await workflowEngine.executeWorkflow(item.automationWorkflow, {
        variables: {
          launch_id: launchId,
          launch_name: launch.name,
          launch_version: launch.version,
          item_id: itemId,
          item_title: item.title,
        },
        userId: launch.launchedBy,
        timestamp: new Date(),
      });

      // Update item status based on workflow result
      await this.updateChecklistItem(launchId, itemId, {
        status: result.success ? 'completed' : 'failed',
        notes: `Workflow executed: ${result.success ? 'success' : 'failed'} (${result.executedSteps}/${result.executedSteps + result.failedSteps} steps)`,
      });

      return result;
    } catch (error) {
      await this.updateChecklistItem(launchId, itemId, {
        status: 'failed',
        notes: `Workflow failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      });
      throw error;
    }
  }

  /**
   * Run all validations for a launch
   */
  public async validateLaunch(launchId: string): Promise<LaunchValidationResult[]> {
    const launch = await this.getLaunchStatus(launchId);
    if (!launch) {
      throw new Error(`Launch ${launchId} not found`);
    }

    const results: LaunchValidationResult[] = [];

    // Validate items with validation scripts
    const validatableItems = launch.checklist.filter(item => item.validationScript);
    
    for (const item of validatableItems) {
      try {
        const result = await this.validateChecklistItem(launchId, item.id);
        results.push(result);
      } catch (error) {
        results.push({
          item: item.id,
          passed: false,
          message: `Validation error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        });
      }
    }

    // Track validation run
    const passedCount = results.filter(r => r.passed).length;
    await analyticsService.track({
      event: 'launch_validation_run',
      userId: launch.launchedBy || 'system',
      properties: {
        launch_id: launchId,
        total_validations: results.length,
        passed_validations: passedCount,
        failed_validations: results.length - passedCount,
      },
    });

    return results;
  }

  /**
   * Start launch process
   */
  public async startLaunch(launchId: string, userId: string): Promise<LaunchStatus> {
    const launch = await this.getLaunchStatus(launchId);
    if (!launch) {
      throw new Error(`Launch ${launchId} not found`);
    }

    if (launch.status !== 'ready') {
      throw new Error(`Launch ${launchId} is not ready to start (status: ${launch.status})`);
    }

    // Update launch status
    launch.status = 'launching';
    launch.startedAt = new Date();
    await this.saveLaunchStatus(launch);

    // Send launch notification
    const adminEmail = process.env.ADMIN_EMAIL;
    if (adminEmail) {
      await emailService.sendEmail({
        to: adminEmail,
        subject: `🚀 Launch Started: ${launch.name} v${launch.version}`,
        html: this.generateLaunchEmail(launch, 'started'),
      });
    }

    // Track launch start
    await analyticsService.track({
      event: 'launch_started',
      userId,
      properties: {
        launch_id: launchId,
        launch_name: launch.name,
        version: launch.version,
      },
    });

    logger.info('Launch started', { launchId, name: launch.name, version: launch.version });
    return launch;
  }

  /**
   * Complete launch
   */
  public async completeLaunch(launchId: string, userId: string): Promise<LaunchStatus> {
    const launch = await this.getLaunchStatus(launchId);
    if (!launch) {
      throw new Error(`Launch ${launchId} not found`);
    }

    // Update launch status
    launch.status = 'live';
    launch.completedAt = new Date();
    await this.saveLaunchStatus(launch);

    // Send completion notification
    const adminEmail = process.env.ADMIN_EMAIL;
    if (adminEmail) {
      await emailService.sendEmail({
        to: adminEmail,
        subject: `✅ Launch Complete: ${launch.name} v${launch.version} is LIVE!`,
        html: this.generateLaunchEmail(launch, 'completed'),
      });
    }

    // Track launch completion
    await analyticsService.track({
      event: 'launch_completed',
      userId,
      properties: {
        launch_id: launchId,
        launch_name: launch.name,
        version: launch.version,
        duration_minutes: launch.startedAt ? 
          Math.round((new Date().getTime() - launch.startedAt.getTime()) / 60000) : 0,
      },
    });

    logger.info('Launch completed', { launchId, name: launch.name, version: launch.version });
    return launch;
  }

  /**
   * Get all launches
   */
  public async getAllLaunches(): Promise<LaunchStatus[]> {
    try {
      const launchDir = this.getLaunchDirectory();
      const files = await fs.readdir(launchDir);
      const launches: LaunchStatus[] = [];

      for (const file of files) {
        if (file.endsWith('.json')) {
          try {
            const content = await fs.readFile(path.join(launchDir, file), 'utf8');
            launches.push(JSON.parse(content));
          } catch (error) {
            logger.warn(`Failed to read launch file ${file}`, { error });
          }
        }
      }

      return launches.sort((a, b) => 
        new Date(b.metadata.createdAt).getTime() - new Date(a.metadata.createdAt).getTime()
      );
    } catch (error) {
      logger.warn('Failed to read launches directory', { error });
      return [];
    }
  }

  /**
   * Calculate launch status based on checklist
   */
  private calculateLaunchStatus(launch: LaunchStatus): LaunchStatus['status'] {
    if (launch.status === 'live' || launch.status === 'rollback') {
      return launch.status;
    }

    const criticalItems = launch.checklist.filter(item => 
      item.priority === 'critical' && item.category === 'pre-launch'
    );
    const allCriticalComplete = criticalItems.every(item => item.status === 'completed');

    const launchItems = launch.checklist.filter(item => item.category === 'launch');
    const allLaunchComplete = launchItems.every(item => 
      item.status === 'completed' || item.status === 'skipped'
    );

    if (allLaunchComplete) {
      return 'live';
    } else if (launch.status === 'launching') {
      return 'launching';
    } else if (allCriticalComplete) {
      return 'ready';
    } else {
      return 'planning';
    }
  }

  /**
   * Generate launch email content
   */
  private generateLaunchEmail(launch: LaunchStatus, type: 'started' | 'completed'): string {
    const completedItems = launch.checklist.filter(item => item.status === 'completed').length;
    const totalItems = launch.checklist.length;

    return `
    <h2>Launch ${type === 'started' ? 'Started' : 'Completed'}: ${launch.name} v${launch.version}</h2>
    
    <h3>Status:</h3>
    <ul>
      <li><strong>Launch ID:</strong> ${launch.id}</li>
      <li><strong>Status:</strong> ${launch.status.toUpperCase()}</li>
      <li><strong>Progress:</strong> ${completedItems}/${totalItems} items completed</li>
      <li><strong>Started:</strong> ${launch.startedAt?.toISOString() || 'Not started'}</li>
      ${type === 'completed' ? `<li><strong>Completed:</strong> ${launch.completedAt?.toISOString()}</li>` : ''}
    </ul>

    <h3>Checklist Progress:</h3>
    <ul>
      ${launch.checklist.map(item => `
        <li>
          ${item.status === 'completed' ? '✅' : item.status === 'failed' ? '❌' : '⏳'} 
          ${item.title} (${item.priority})
        </li>
      `).join('')}
    </ul>

    ${type === 'completed' ? `
      <h3>🎉 Congratulations!</h3>
      <p>The launch is complete and the system is live. Monitor the dashboards closely for the next 24 hours.</p>
    ` : `
      <h3>⚠️ Monitor Closely</h3>
      <p>The launch is in progress. Monitor system health and complete remaining checklist items.</p>
    `}
    `;
  }

  /**
   * Save launch status to file
   */
  private async saveLaunchStatus(launch: LaunchStatus): Promise<void> {
    const filePath = this.getLaunchFilePath(launch.id);
    const dir = path.dirname(filePath);
    
    await fs.mkdir(dir, { recursive: true });
    await fs.writeFile(filePath, JSON.stringify(launch, null, 2));
  }

  /**
   * Get launch file path
   */
  private getLaunchFilePath(launchId: string): string {
    return path.join(this.getLaunchDirectory(), `${launchId}.json`);
  }

  /**
   * Get launch directory
   */
  private getLaunchDirectory(): string {
    return path.join(process.cwd(), 'data', 'launches');
  }
}

// Export singleton instance
export const launchPlaybook = new LaunchPlaybookService();