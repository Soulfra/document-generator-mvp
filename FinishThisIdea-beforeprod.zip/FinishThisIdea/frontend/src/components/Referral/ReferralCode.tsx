import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { Copy, Check, Share2, Gift, Users, Sparkles } from 'lucide-react';

interface ReferralCodeProps {
  userId?: string;
  variant?: 'card' | 'inline' | 'hero';
}

const ReferralCode = ({ userId = 'demo-user', variant = 'card' }: ReferralCodeProps) => {
  const [referralCode, setReferralCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [shareCount, setShareCount] = useState(0);

  // Generate referral code based on user
  useEffect(() => {
    const generateCode = (id: string) => {
      const prefix = 'CLEAN';
      const suffix = id.slice(-4).toUpperCase() + Math.random().toString(36).slice(-3).toUpperCase();
      return `${prefix}${suffix}`;
    };
    
    setReferralCode(generateCode(userId));
  }, [userId]);

  const copyToClipboard = async () => {
    const referralUrl = `${window.location.origin}?ref=${referralCode}`;
    try {
      await navigator.clipboard.writeText(referralUrl);
      setCopied(true);
      setShareCount(prev => prev + 1);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const shareOptions = [
    {
      name: 'Twitter',
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(`🔥 Just found this amazing tool that cleans messy code for $1! Try it with my referral code: ${referralCode} ${window.location.origin}?ref=${referralCode}`)}`,
      color: 'hover:text-blue-400'
    },
    {
      name: 'LinkedIn',
      url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(`${window.location.origin}?ref=${referralCode}`)}`,
      color: 'hover:text-blue-300'
    }
  ];

  if (variant === 'inline') {
    return (
      <div className="flex items-center space-x-3 bg-gray-800/20 rounded-lg p-3">
        <div className="flex items-center space-x-2">
          <Gift className="w-4 h-4 text-accent-400" />
          <span className="text-sm text-gray-300">Your code:</span>
          <code className="bg-gray-900 px-2 py-1 rounded text-accent-400 font-mono text-sm">
            {referralCode}
          </code>
        </div>
        <button
          onClick={copyToClipboard}
          className="btn-secondary text-xs px-3 py-1"
        >
          {copied ? 'Copied!' : 'Copy Link'}
        </button>
      </div>
    );
  }

  if (variant === 'hero') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <motion.div
          animate={{ 
            boxShadow: ['0 0 20px rgba(139, 92, 246, 0.3)', '0 0 30px rgba(139, 92, 246, 0.6)', '0 0 20px rgba(139, 92, 246, 0.3)']
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="inline-block bg-gradient-to-r from-primary-500/20 to-accent-500/20 rounded-2xl p-6 border border-primary-500/30"
        >
          <div className="flex items-center space-x-3 mb-4">
            <Sparkles className="w-6 h-6 text-accent-400" />
            <span className="text-lg font-semibold text-white">Your Referral Code</span>
          </div>
          
          <div className="bg-gray-900 rounded-lg p-4 mb-4">
            <code className="text-2xl font-bold text-accent-400 font-mono tracking-wider">
              {referralCode}
            </code>
          </div>

          <button
            onClick={copyToClipboard}
            className="btn-primary w-full flex items-center justify-center space-x-2"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied Share Link!' : 'Copy Share Link'}</span>
          </button>
        </motion.div>
      </motion.div>
    );
  }

  // Default card variant
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass-card p-6 relative overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-accent-500/20 to-primary-500/20 rounded-full blur-2xl -translate-y-8 translate-x-8" />
      
      {/* Header */}
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-accent-500 to-primary-500 rounded-full flex items-center justify-center">
          <Gift className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-white">Refer & Earn</h3>
          <p className="text-sm text-gray-400">Share with friends, both get rewards</p>
        </div>
      </div>

      {/* Referral Code Display */}
      <div className="bg-gray-900/50 rounded-lg p-4 mb-4">
        <div className="text-xs text-gray-500 mb-1">Your Referral Code</div>
        <div className="flex items-center justify-between">
          <code className="text-xl font-bold text-accent-400 font-mono tracking-wider">
            {referralCode}
          </code>
          <motion.button
            onClick={copyToClipboard}
            className={`p-2 rounded-lg transition-all duration-200 ${
              copied 
                ? 'bg-green-500/20 text-green-400' 
                : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          </motion.button>
        </div>
      </div>

      {/* Benefits */}
      <div className="space-y-3 mb-6">
        <div className="flex items-center space-x-3 text-sm">
          <div className="w-2 h-2 bg-green-400 rounded-full" />
          <span className="text-gray-300">Your friend gets their first cleanup FREE</span>
        </div>
        <div className="flex items-center space-x-3 text-sm">
          <div className="w-2 h-2 bg-blue-400 rounded-full" />
          <span className="text-gray-300">You earn $0.50 credit per referral</span>
        </div>
        <div className="flex items-center space-x-3 text-sm">
          <div className="w-2 h-2 bg-purple-400 rounded-full" />
          <span className="text-gray-300">No limit on referrals!</span>
        </div>
      </div>

      {/* Quick Share */}
      <div className="flex space-x-2">
        <button
          onClick={copyToClipboard}
          className="flex-1 btn-primary text-sm py-2 flex items-center justify-center space-x-2"
        >
          <Copy className="w-4 h-4" />
          <span>{copied ? 'Copied!' : 'Copy Link'}</span>
        </button>
        
        <div className="flex space-x-1">
          {shareOptions.map((option) => (
            <a
              key={option.name}
              href={option.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`p-2 bg-gray-800 rounded-lg transition-colors ${option.color}`}
            >
              <Share2 className="w-4 h-4" />
            </a>
          ))}
        </div>
      </div>

      {/* Share counter */}
      {shareCount > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 text-center"
        >
          <div className="inline-flex items-center space-x-2 bg-accent-500/10 text-accent-400 px-3 py-1 rounded-full text-xs">
            <Users className="w-3 h-3" />
            <span>Shared {shareCount} time{shareCount !== 1 ? 's' : ''}</span>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default ReferralCode;