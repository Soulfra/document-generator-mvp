# Archived Premium Feature Reviews

This folder contains completed premium/paywall feature reviews and developer responses.

- **Read-Only:** Files in this folder should not be modified. They serve as a permanent record of past audits.
- **Summary/Index:** See `index.md` in this folder for a summary of all archived reviews.

---

*For new reviews, use the main `/cursor/` folder and follow the workflow in `/cursor/README.md`.* 