import { Router } from 'express';
import { prisma } from '../../utils/database';
import { documentationService } from '../../services/documentation.service';
import { asyncHandler } from '../../utils/async-handler';
import { authentication } from '../../middleware/auth.middleware';
import { uploadToS3 } from '../../utils/storage';
import { z } from 'zod';
import { logger } from '../../utils/logger';
import { fileProcessingService } from '../../services/file-processing.service';
import { ValidationError } from '../../utils/error-handler';
import { canAccess } from '../../utils/premium-features';

const router = Router();

// Schema for documentation generation request
const generateDocsSchema = z.object({
  jobId: z.string().uuid(),
  templates: z.array(z.string()).optional(),
  includeInOutput: z.boolean().default(true),
});

// Schema for chat log import
const chatLogSchema = z.object({
  messages: z.array(z.object({
    role: z.enum(['user', 'assistant']),
    content: z.string(),
    timestamp: z.string().optional(),
  })),
  platform: z.enum(['chatgpt', 'claude', 'other']).default('other'),
});

/**
 * GET /api/documentation/templates
 * Get available documentation templates (filtered by user tier)
 */
router.get('/templates', authentication(), asyncHandler(async (req, res) => {
  const userId = req.user?.id;
  
  // Get user for tier checking
  const user = userId ? await prisma.user.findUnique({
    where: { id: userId },
  }) : null;

  const allTemplates = [
    {
      id: 'executive-summary',
      name: 'Executive Summary',
      description: 'High-level project overview for stakeholders',
      sections: ['overview', 'vision', 'technical-summary', 'key-features'],
      tier: 'basic',
    },
    {
      id: 'api-contract',
      name: 'API Contract',
      description: 'Complete API documentation with OpenAPI specs',
      sections: ['overview', 'endpoints', 'openapi', 'authentication', 'errors'],
      tier: 'standard',
    },
    {
      id: 'data-models',
      name: 'Data Models',
      description: 'Database schemas and data structures',
      sections: ['overview', 'entity-relationship', 'schemas', 'field-definitions'],
      tier: 'standard',
    },
    {
      id: 'test-plan',
      name: 'Test Plan',
      description: 'Testing strategy and requirements',
      sections: ['overview', 'unit-tests', 'integration-tests', 'test-data'],
      tier: 'advanced',
      premium: true,
    },
    {
      id: 'user-stories',
      name: 'User Stories',
      description: 'User personas and feature requirements',
      sections: ['personas', 'stories', 'acceptance-criteria'],
      tier: 'advanced',
      premium: true,
    },
    {
      id: 'technical-requirements',
      name: 'Technical Requirements',
      description: 'Detailed technical specifications',
      sections: ['functional', 'non-functional', 'integrations'],
      tier: 'enterprise',
      premium: true,
    },
  ];

  // Filter templates based on user tier
  const hasAdvancedTemplates = canAccess(user, 'advanced-templates');
  
  const availableTemplates = allTemplates.map(template => {
    if (template.premium && !hasAdvancedTemplates) {
      return {
        ...template,
        locked: true,
        upgradeRequired: true,
      };
    }
    return template;
  });

  res.json({
    success: true,
    data: availableTemplates,
    userTier: user?.tier || 'FREE',
    hasAdvancedTemplates,
  });
}));

/**
 * POST /api/documentation/generate
 * Generate documentation for a completed cleanup job
 */
router.post('/generate', authentication(), asyncHandler(async (req, res) => {
  const parseResult = generateDocsSchema.safeParse(req.body);
  
  if (!parseResult.success) {
    throw new ValidationError('Invalid request data', {
      issues: parseResult.error.issues.map(issue => ({
        field: issue.path.join('.'),
        message: issue.message,
        code: issue.code
      }))
    });
  }

  const { jobId, templates, includeInOutput } = parseResult.data;

  // Get user for tier validation
  const userId = req.user?.id;
  const user = userId ? await prisma.user.findUnique({
    where: { id: userId },
  }) : null;

  // Verify job exists and belongs to user
  const job = await prisma.job.findFirst({
    where: {
      id: jobId,
      status: 'COMPLETED',
    },
  });

  if (!job) {
    res.status(404).json({
      success: false,
      error: 'Job not found or not completed',
    });
    return;
  }

  // Validate template access for user tier
  if (templates) {
    const premiumTemplates = ['test-plan', 'user-stories', 'technical-requirements'];
    const hasAdvancedTemplates = canAccess(user, 'advanced-templates');
    
    const restrictedTemplates = templates.filter(template => 
      premiumTemplates.includes(template) && !hasAdvancedTemplates
    );
    
    if (restrictedTemplates.length > 0) {
      res.status(403).json({
        success: false,
        error: `Premium templates require upgrade: ${restrictedTemplates.join(', ')}`,
        upgradeRequired: true,
        restrictedTemplates,
      });
      return;
    }
  }

  // Check if documentation already exists
  const existingDoc = await prisma.documentation.findFirst({
    where: { jobId },
  });

  if (existingDoc) {
    res.json({
      success: true,
      data: {
        documentationId: existingDoc.id,
        url: existingDoc.url,
        templates: existingDoc.templates,
      },
    });
    return;
  }

  try {
    // Download and extract the cleaned files
    const extractionResult = await fileProcessingService.downloadAndExtractFiles(job.outputFileUrl!);
    logger.info('File extraction completed', { 
      jobId,
      totalFiles: extractionResult.metadata.totalFiles,
      totalSize: extractionResult.metadata.totalSize,
      languages: extractionResult.metadata.languages,
      projectType: extractionResult.metadata.projectType
    });
    
    // Analyze code for documentation with multi-language support
    logger.info('🔍 Starting multi-language code analysis for documentation', {
      jobId,
      fileCount: extractionResult.files.size,
      detectedLanguages: extractionResult.metadata.languages,
      projectType: extractionResult.metadata.projectType
    });
    
    const codeAnalysis = await documentationService.analyzeCodeForDocumentation(
      extractionResult.files,
      jobId
    );
    
    logger.info('✅ Multi-language code analysis completed', {
      jobId,
      projectName: codeAnalysis.projectInfo.name,
      primaryLanguage: codeAnalysis.projectInfo.language,
      framework: codeAnalysis.projectInfo.framework,
      analysisResults: {
        apis: codeAnalysis.apis.length,
        functions: codeAnalysis.functions.length,
        dataModels: codeAnalysis.dataModels.length,
        dependencies: codeAnalysis.dependencies.length,
        testCoverage: codeAnalysis.testCoverage.coverage
      }
    });

    // Generate documentation
    const templateIds = templates || ['executive-summary', 'api-contract', 'data-models'];
    const docResult = await documentationService.generateDocumentation(
      jobId,
      codeAnalysis,
      templateIds
    );

    // Package documentation
    const docPackage = await fileProcessingService.packageDocumentation(docResult, jobId, true);
    const docUrl = await uploadToS3(docPackage, `docs/${jobId}/documentation.zip`);

    // Save to database
    const documentation = await prisma.documentation.create({
      data: {
        jobId,
        userId: 'anonymous', // TODO: implement proper user auth
        url: docUrl,
        templates: templateIds,
        metadata: {
          quality: docResult.metadata.quality as any,
          tokensUsed: docResult.metadata.aiTokensUsed,
          generatedAt: docResult.metadata.generatedAt.toISOString(),
          extraction: {
            totalFiles: extractionResult.metadata.totalFiles,
            totalSize: extractionResult.metadata.totalSize,
            languages: extractionResult.metadata.languages,
            projectType: extractionResult.metadata.projectType,
            framework: extractionResult.metadata.framework,
            extractionTime: extractionResult.metadata.extractionTime
          }
        } as any,
      },
    });

    // Calculate documentation cost
    const docCost = calculateDocumentationCost(templateIds.length, docResult.metadata.aiTokensUsed);
    
    // Update job cost if applicable
    if (includeInOutput) {
      await prisma.job.update({
        where: { id: jobId },
        data: {
          totalCost: {
            increment: docCost,
          },
        },
      });
    }

    res.json({
      success: true,
      data: {
        documentationId: documentation.id,
        url: docUrl,
        templates: templateIds,
        quality: docResult.metadata.quality,
        cost: docCost,
      },
    });
  } catch (error) {
    logger.error('Documentation generation failed', { jobId, error });
    res.status(500).json({
      success: false,
      error: 'Failed to generate documentation',
    });
  }
}));

/**
 * POST /api/documentation/chat-import
 * Import chat logs to extract requirements
 */
router.post('/chat-import', authentication(), asyncHandler(async (req, res) => {
  const chatLog = chatLogSchema.parse(req.body);

  try {
    // Convert string timestamps to Date objects
    const processedMessages = chatLog.messages.map(msg => ({
      ...msg,
      timestamp: msg.timestamp ? new Date(msg.timestamp) : undefined,
    }));

    // Extract requirements from chat
    const requirements = await documentationService.parseChatlogs({
      ...chatLog,
      messages: processedMessages,
      exportDate: new Date(),
    });

    // Convert to documentation format
    const docContent = formatRequirementsAsDocumentation(requirements);

    res.json({
      success: true,
      data: {
        requirements,
        documentation: docContent,
      },
    });
  } catch (error) {
    logger.error('Chat import failed', { error });
    res.status(500).json({
      success: false,
      error: 'Failed to parse chat logs',
    });
  }
}));

/**
 * GET /api/documentation/:jobId
 * Get documentation for a specific job
 */
router.get('/:jobId', authentication(), asyncHandler(async (req, res) => {
  const { jobId } = req.params;

  const documentation = await prisma.documentation.findFirst({
    where: {
      jobId,
    },
  });

  if (!documentation) {
    res.status(404).json({
      success: false,
      error: 'Documentation not found',
    });
    return;
  }

  res.json({
    success: true,
    data: documentation,
  });
}));

/**
 * GET /api/documentation/:jobId/preview
 * Get a preview of generated documentation
 */
router.get('/:jobId/preview', authentication(), asyncHandler(async (req, res) => {
  const { jobId } = req.params;
  const { template: _template } = req.query;

  const documentation = await prisma.documentation.findFirst({
    where: {
      jobId,
    },
  });

  if (!documentation) {
    res.status(404).json({
      success: false,
      error: 'Documentation not found',
    });
    return;
  }

  // This would fetch and return a preview of the documentation
  // For now, returning the metadata
  res.json({
    success: true,
    data: {
      preview: 'Documentation preview would be here',
      templates: documentation.templates,
      quality: documentation.metadata,
    },
  });
}));

// Helper functions

function calculateDocumentationCost(templateCount: number, tokensUsed: number): number {
  // Base cost per template
  const baseCost = 0.50 * templateCount;
  
  // Additional cost for AI tokens (rough estimate)
  const tokenCost = (tokensUsed / 1000) * 0.01;
  
  return Math.max(1.00, baseCost + tokenCost); // Minimum $1
}

function formatRequirementsAsDocumentation(requirements: any): string {
  // Format extracted requirements into documentation markdown
  return `# Project Requirements

## Features
${requirements.features.map((f: any) => `- **${f.name}**: ${f.description}`).join('\n')}

## User Stories
${requirements.userStories.map((s: any) => 
  `### ${s.id}\nAs a ${s.asA}, I want ${s.iWant} so that ${s.soThat}`
).join('\n\n')}

## Technical Requirements
${requirements.technicalRequirements.map((r: any) => 
  `- **${r.category}**: ${r.description}`
).join('\n')}

## Business Rules
${requirements.businessRules.map((r: any) => `- ${r.description}`).join('\n')}

## Constraints
${requirements.constraints.map((c: any) => 
  `- **${c.type}**: ${c.description} (Impact: ${c.impact})`
).join('\n')}
`;
}

export default router;