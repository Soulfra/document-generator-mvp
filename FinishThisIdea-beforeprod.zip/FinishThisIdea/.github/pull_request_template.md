## Summary
Brief description of what this PR accomplishes.

## Changes Made
- [ ] List of specific changes
- [ ] Include any breaking changes
- [ ] Note any new dependencies

## Type of Change
- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)  
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Refactoring (no functional changes)
- [ ] Security improvement

## Testing Done
- [ ] Unit tests pass (`npm test`)
- [ ] Integration tests pass
- [ ] Manual testing completed
- [ ] Performance impact assessed
- [ ] Security review completed (if applicable)

## Code Quality
- [ ] Code follows project style guidelines
- [ ] Self-review completed
- [ ] Code is self-documenting or comments added where needed
- [ ] No console.log statements left in production code
- [ ] Error handling is appropriate

## Documentation Updated
- [ ] README.md (if applicable)
- [ ] API documentation (if applicable)
- [ ] Code comments added/updated
- [ ] CHANGELOG.md updated

## Dependencies
- [ ] No new dependencies added
- [ ] New dependencies are justified and documented
- [ ] Package.json updated (if applicable)
- [ ] Security audit passed for new dependencies

## Database Changes
- [ ] No database changes
- [ ] Database migration created
- [ ] Migration tested on staging
- [ ] Rollback procedure documented

## Security Considerations
- [ ] No security implications
- [ ] Security review completed
- [ ] Input validation added/updated
- [ ] No sensitive data exposed in logs
- [ ] Authentication/authorization properly implemented

## Breaking Changes
If this PR contains breaking changes, please describe:
- What breaks
- Migration path for users
- Timeline for deprecation (if applicable)

## Related Issues
Fixes #123, Related to #456

## Screenshots/Demo
If applicable, add screenshots or GIFs demonstrating the changes.

## Deployment Notes
Any special considerations for deployment:
- Environment variables to update
- Infrastructure changes needed
- Post-deployment verification steps

## Checklist
- [ ] PR title follows format: `[TYPE] Brief description`
- [ ] Branch is up to date with main
- [ ] All checks pass (CI/CD)
- [ ] Ready for review