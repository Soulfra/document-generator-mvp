import { createReadStream, createWriteStream, promises as fs } from 'fs';
// import { Readable } from 'stream'; // Currently unused
import { pipeline } from 'stream/promises';
import * as path from 'path';
import * as os from 'os';
import axios from 'axios';
import unzipper from 'unzipper';
import archiver from 'archiver';
import { logger } from '../utils/logger';
// import { v4 as uuidv4 } from 'uuid'; // Currently unused
import { 
  withErrorHandling, 
  FileProcessingError, 
  ResourceLimitError, 
  TimeoutError 
} from '../utils/error-handler';

export interface FileProcessingOptions {
  maxFileSize: number; // Maximum individual file size in bytes
  maxTotalSize: number; // Maximum total extraction size in bytes
  allowedExtensions: string[]; // Allowed file extensions
  excludePatterns: string[]; // Patterns to exclude (node_modules, .git, etc.)
  timeout: number; // Processing timeout in milliseconds
}

export interface ProcessedFile {
  path: string;
  content: string;
  size: number;
  language: string;
  encoding: string;
}

export interface FileExtractionResult {
  files: Map<string, string>;
  metadata: {
    totalFiles: number;
    totalSize: number;
    languages: string[];
    projectType: string;
    framework?: string;
    extractionTime: number;
  };
}

const DEFAULT_OPTIONS: FileProcessingOptions = {
  maxFileSize: 2 * 1024 * 1024, // 2MB per file
  maxTotalSize: 50 * 1024 * 1024, // 50MB total
  allowedExtensions: [
    '.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs',
    '.py', '.java', '.kt', '.go', '.rs', '.php',
    '.rb', '.swift', '.c', '.cpp', '.h', '.hpp',
    '.cs', '.vb', '.sql', '.yaml', '.yml', '.json',
    '.md', '.txt', '.env', '.config', '.toml'
  ],
  excludePatterns: [
    'node_modules', '.git', '.svn', '.hg',
    'build', 'dist', 'target', 'bin', 'obj',
    '.next', '.nuxt', '.vscode', '.idea',
    'coverage', '.nyc_output', 'test-results',
    'logs', 'tmp', 'temp', '.cache',
    '*.min.js', '*.min.css', '*.bundle.js',
    '*.lock', 'package-lock.json', 'yarn.lock'
  ],
  timeout: 120000, // 2 minutes
};

export class FileProcessingService {
  private options: FileProcessingOptions;

  constructor(options: Partial<FileProcessingOptions> = {}) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
  }

  /**
   * Download and extract files from a ZIP URL
   */
  async downloadAndExtractFiles(fileUrl: string): Promise<FileExtractionResult> {
    return withErrorHandling(
      this._downloadAndExtractFiles.bind(this),
      `file extraction from ${fileUrl}`,
      this.options.timeout
    )(fileUrl);
  }

  private async _downloadAndExtractFiles(fileUrl: string): Promise<FileExtractionResult> {
    const startTime = Date.now();
    logger.info('Starting file extraction', { fileUrl });

    if (!fileUrl || (!fileUrl.startsWith('http') && !fileUrl.startsWith('file://'))) {
      throw new FileProcessingError('Invalid file URL provided', { fileUrl });
    }

    let tempDir: string | null = null;
    
    try {
      // Create temporary directory
      tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'finishthisidea-'));
      const zipPath = path.join(tempDir, 'codebase.zip');

      // Download the ZIP file
      await this.downloadFile(fileUrl, zipPath);
      
      // Extract and process files
      const result = await this.extractAndProcessFiles(zipPath, tempDir);
      
      // Validate extraction results
      if (result.files.size === 0) {
        throw new FileProcessingError('No valid files found in the archive');
      }

      if (result.metadata.totalSize > this.options.maxTotalSize) {
        throw new ResourceLimitError(
          'total file size',
          this.options.maxTotalSize,
          result.metadata.totalSize
        );
      }
      
      return {
        ...result,
        metadata: {
          ...result.metadata,
          extractionTime: Date.now() - startTime
        }
      };
    } catch (error) {
      logger.error('File extraction failed', { fileUrl, error: error instanceof Error ? error.message : String(error) });
      
      if (error instanceof FileProcessingError || 
          error instanceof ResourceLimitError || 
          error instanceof TimeoutError) {
        throw error;
      }
      
      throw new FileProcessingError(
        `Failed to extract files: ${error instanceof Error ? error.message : String(error)}`,
        { fileUrl, originalError: error instanceof Error ? error.message : String(error) }
      );
    } finally {
      // Cleanup temporary directory
      if (tempDir) {
        await this.cleanupDirectory(tempDir);
      }
    }
  }

  /**
   * Download a file from URL or copy from local path with timeout and size limits
   */
  private async downloadFile(url: string, outputPath: string): Promise<void> {
    logger.info('Downloading file', { url, outputPath });

    // Handle local file URLs for testing
    if (url.startsWith('file://')) {
      const localPath = url.replace('file://', '');
      await fs.copyFile(localPath, outputPath);
      logger.info('File copied from local path', { localPath, outputPath });
      return;
    }

    // Handle HTTP/HTTPS URLs
    const response = await axios({
      method: 'GET',
      url,
      responseType: 'stream',
      timeout: this.options.timeout,
      maxContentLength: this.options.maxTotalSize,
    });

    const writer = createWriteStream(outputPath);
    await pipeline(response.data, writer);
    
    logger.info('File downloaded successfully', { outputPath });
  }

  /**
   * Extract ZIP file and process contents
   */
  private async extractAndProcessFiles(
    zipPath: string, 
    tempDir: string
  ): Promise<FileExtractionResult> {
    const extractDir = path.join(tempDir, 'extracted');
    await fs.mkdir(extractDir, { recursive: true });

    // Extract ZIP file
    await this.extractZip(zipPath, extractDir);

    // Process extracted files
    const files = new Map<string, string>();
    const metadata = {
      totalFiles: 0,
      totalSize: 0,
      languages: new Set<string>(),
      projectType: 'unknown',
      framework: undefined,
      extractionTime: 0
    };

    await this.processDirectory(extractDir, extractDir, files, metadata);

    // Detect project type and framework
    const projectInfo = this.detectProjectInfo(files);
    
    return {
      files,
      metadata: {
        totalFiles: metadata.totalFiles,
        totalSize: metadata.totalSize,
        languages: Array.from(metadata.languages),
        projectType: projectInfo.type,
        framework: projectInfo.framework,
        extractionTime: 0 // Will be set by caller
      }
    };
  }

  /**
   * Extract ZIP file using unzipper
   */
  private async extractZip(zipPath: string, outputDir: string): Promise<void> {
    logger.info('Extracting ZIP file', { zipPath, outputDir });

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('ZIP extraction timeout'));
      }, this.options.timeout);

      createReadStream(zipPath)
        .pipe(unzipper.Extract({ path: outputDir }))
        .on('close', () => {
          clearTimeout(timeout);
          resolve();
        })
        .on('error', (error) => {
          clearTimeout(timeout);
          reject(error);
        });
    });
  }

  /**
   * Recursively process directory and extract file contents
   */
  private async processDirectory(
    dirPath: string,
    basePath: string,
    files: Map<string, string>,
    metadata: any
  ): Promise<void> {
    const entries = await fs.readdir(dirPath, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      const relativePath = path.relative(basePath, fullPath);

      // Skip excluded patterns
      if (this.shouldExcludeFile(relativePath)) {
        continue;
      }

      if (entry.isDirectory()) {
        await this.processDirectory(fullPath, basePath, files, metadata);
      } else if (entry.isFile()) {
        await this.processFile(fullPath, relativePath, files, metadata);
      }
    }
  }

  /**
   * Process individual file
   */
  private async processFile(
    filePath: string,
    relativePath: string,
    files: Map<string, string>,
    metadata: any
  ): Promise<void> {
    const ext = path.extname(filePath);
    const fileName = path.basename(filePath);
    
    // Important files without extensions for project detection
    const importantFiles = [
      'go.mod', 'go.sum', 'Dockerfile', 'Makefile', 'Gemfile', 'Rakefile',
      'requirements.txt', 'setup.py', 'pyproject.toml', 'Cargo.toml', 'Cargo.lock',
      'composer.json', 'composer.lock', 'pom.xml', 'build.gradle', 'gradle.properties'
    ];
    
    // Check if file extension is allowed or if it's an important file
    if (!this.options.allowedExtensions.includes(ext) && !importantFiles.includes(fileName)) {
      return;
    }

    try {
      const stats = await fs.stat(filePath);
      
      // Check file size limit
      if (stats.size > this.options.maxFileSize) {
        logger.warn('File too large, skipping', { relativePath, size: stats.size });
        return;
      }

      // Check total size limit
      if (metadata.totalSize + stats.size > this.options.maxTotalSize) {
        logger.warn('Total size limit reached, stopping extraction');
        throw new ResourceLimitError(
          'total extraction size',
          this.options.maxTotalSize,
          metadata.totalSize + stats.size
        );
      }

      // Read file content
      const content = await fs.readFile(filePath, 'utf-8');
      
      // Store file
      files.set(relativePath, content);
      
      // Update metadata
      metadata.totalFiles++;
      metadata.totalSize += stats.size;
      
      // Detect language
      const language = this.detectLanguage(ext);
      if (language) {
        metadata.languages.add(language);
      }

      logger.debug('Processed file', { relativePath, size: stats.size, language });
      
    } catch (error) {
      logger.warn('Failed to process file', { relativePath, error: error instanceof Error ? error.message : String(error) });
    }
  }

  /**
   * Check if file should be excluded based on patterns
   */
  private shouldExcludeFile(relativePath: string): boolean {
    const normalizedPath = relativePath.replace(/\\/g, '/');
    
    return this.options.excludePatterns.some(pattern => {
      if (pattern.includes('*')) {
        // Simple glob pattern matching
        const regex = new RegExp(pattern.replace(/\*/g, '.*'));
        return regex.test(normalizedPath);
      } else {
        // Direct path matching
        return normalizedPath.includes(pattern);
      }
    });
  }

  /**
   * Detect programming language from file extension
   */
  private detectLanguage(extension: string): string | null {
    const languageMap: Record<string, string> = {
      '.js': 'javascript',
      '.mjs': 'javascript',
      '.cjs': 'javascript',
      '.ts': 'typescript',
      '.tsx': 'typescript',
      '.jsx': 'javascript',
      '.py': 'python',
      '.java': 'java',
      '.kt': 'kotlin',
      '.go': 'go',
      '.rs': 'rust',
      '.php': 'php',
      '.rb': 'ruby',
      '.swift': 'swift',
      '.c': 'c',
      '.cpp': 'cpp',
      '.hpp': 'cpp',
      '.h': 'c',
      '.cs': 'csharp',
      '.vb': 'vb',
      '.sql': 'sql',
      '.yaml': 'yaml',
      '.yml': 'yaml',
      '.json': 'json',
      '.md': 'markdown',
      '.toml': 'toml'
    };

    return languageMap[extension] || null;
  }

  /**
   * Detect project type and framework from files
   */
  private detectProjectInfo(files: Map<string, string>): { type: string; framework?: string } {
    const fileList = Array.from(files.keys());
    // const hasFile = (pattern: string) => fileList.some(f => f.includes(pattern)); // Currently unused
    const hasFileExact = (filename: string) => fileList.includes(filename);

    // Node.js/JavaScript projects
    if (hasFileExact('package.json')) {
      const packageJson = files.get('package.json');
      if (packageJson) {
        try {
          const pkg = JSON.parse(packageJson);
          const deps = { ...pkg.dependencies, ...pkg.devDependencies };
          
          // Framework detection
          if (deps.react) return { type: 'webapp', framework: 'react' };
          if (deps.vue) return { type: 'webapp', framework: 'vue' };
          if (deps.angular) return { type: 'webapp', framework: 'angular' };
          if (deps.next) return { type: 'webapp', framework: 'nextjs' };
          if (deps.nuxt) return { type: 'webapp', framework: 'nuxtjs' };
          if (deps.express) return { type: 'api', framework: 'express' };
          if (deps.fastify) return { type: 'api', framework: 'fastify' };
          if (deps.koa) return { type: 'api', framework: 'koa' };
          if (deps.gatsby) return { type: 'webapp', framework: 'gatsby' };
          if (deps.svelte) return { type: 'webapp', framework: 'svelte' };
        } catch (e) {
          // Invalid JSON, continue
        }
      }
      return { type: 'application' };
    }

    // Python projects
    if (hasFileExact('requirements.txt') || hasFileExact('setup.py') || hasFileExact('pyproject.toml')) {
      const requirementsTxt = files.get('requirements.txt') || '';
      if (requirementsTxt.includes('django')) return { type: 'webapp', framework: 'django' };
      if (requirementsTxt.includes('flask')) return { type: 'api', framework: 'flask' };
      if (requirementsTxt.includes('fastapi')) return { type: 'api', framework: 'fastapi' };
      return { type: 'application' };
    }

    // Java projects
    if (hasFileExact('pom.xml') || hasFileExact('build.gradle')) {
      return { type: 'application', framework: 'spring' };
    }

    // Go projects
    if (hasFileExact('go.mod')) {
      return { type: 'application', framework: 'go' };
    }

    // Rust projects
    if (hasFileExact('Cargo.toml')) {
      return { type: 'application', framework: 'rust' };
    }

    // PHP projects
    if (hasFileExact('composer.json')) {
      const composerJson = files.get('composer.json');
      if (composerJson?.includes('laravel')) return { type: 'webapp', framework: 'laravel' };
      if (composerJson?.includes('symfony')) return { type: 'webapp', framework: 'symfony' };
      return { type: 'application' };
    }

    // Ruby projects
    if (hasFileExact('Gemfile')) {
      return { type: 'application', framework: 'ruby' };
    }

    // Generic detection based on file types
    if (fileList.some(f => f.endsWith('.html') || f.endsWith('.css'))) {
      return { type: 'webapp' };
    }

    return { type: 'library' };
  }

  /**
   * Create documentation package as ZIP buffer
   */
  async packageDocumentation(
    docResult: any, 
    jobId: string,
    includeSourceMaps: boolean = false
  ): Promise<Buffer> {
    logger.info('Creating documentation package', { jobId });

    return new Promise((resolve, reject) => {
      const chunks: Buffer[] = [];
      const archive = archiver('zip', { zlib: { level: 9 } });

      archive.on('data', (chunk) => chunks.push(chunk));
      archive.on('end', () => resolve(Buffer.concat(chunks)));
      archive.on('error', reject);

      // Add main documentation files
      for (const template of docResult.templates) {
        const filename = `${template.templateId}.md`;
        archive.append(template.content, { name: filename });
        
        // Add individual sections if available
        if (template.sections) {
          for (const section of template.sections) {
            const sectionFilename = `sections/${template.templateId}/${section.id}.md`;
            archive.append(section.content, { name: sectionFilename });
          }
        }
      }

      // Add metadata
      const metadata = {
        generatedAt: docResult.metadata.generatedAt,
        templatesUsed: docResult.metadata.templatesUsed,
        quality: docResult.metadata.quality,
        jobId: jobId,
        version: '1.0.0'
      };
      archive.append(JSON.stringify(metadata, null, 2), { name: 'metadata.json' });

      // Add README for the documentation package
      const readme = this.generateDocumentationReadme(docResult, jobId);
      archive.append(readme, { name: 'README.md' });

      // Add source maps if requested
      if (includeSourceMaps && docResult.metadata.sourceMappings) {
        archive.append(
          JSON.stringify(docResult.metadata.sourceMappings, null, 2),
          { name: 'source-mappings.json' }
        );
      }

      archive.finalize();
    });
  }

  /**
   * Generate README for documentation package
   */
  private generateDocumentationReadme(docResult: any, jobId: string): string {
    const templates = docResult.templates.map((t: any) => `- ${t.templateName} (${t.templateId}.md)`).join('\n');
    
    return `# Project Documentation

Generated by FinishThisIdea on ${new Date().toISOString()}

## Contents

${templates}

## Quality Metrics

- **Overall Quality**: ${docResult.metadata.quality.overall}%
- **Completeness**: ${docResult.metadata.quality.completeness}%
- **Accuracy**: ${docResult.metadata.quality.accuracy}%
- **Readability**: ${docResult.metadata.quality.readability}%

## Generation Info

- **Job ID**: ${jobId}
- **Templates Used**: ${docResult.metadata.templatesUsed.length}
- **AI Tokens Used**: ${docResult.metadata.aiTokensUsed || 0}

## Usage

Each markdown file contains complete documentation for a specific aspect of your project. 
You can view these files directly on GitHub, import them into your project wiki, or 
convert them to other formats as needed.

For technical questions about implementation, refer to the detailed sections in each document.
`;
  }

  /**
   * Cleanup temporary directory
   */
  private async cleanupDirectory(dirPath: string): Promise<void> {
    try {
      await fs.rm(dirPath, { recursive: true, force: true });
      logger.debug('Cleaned up temporary directory', { dirPath });
    } catch (error) {
      logger.warn('Failed to cleanup directory', { dirPath, error: error instanceof Error ? error.message : String(error) });
    }
  }
}

// Export singleton instance
export const fileProcessingService = new FileProcessingService();