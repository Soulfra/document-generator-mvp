# FinishThisIdea - $1 Codebase Cleanup

Transform your messy codebase into clean, organized code for just $1.

## 🚀 Quick Start

```bash
# Clone the repo
git clone https://github.com/yourusername/finishthisidea.git
cd finishthisidea

# Install dependencies
npm install

# Set up environment
cp .env.example .env
# Edit .env with your keys

# Start development
npm run dev
```

## 🎯 What It Does

1. **Upload** your messy codebase (zip file)
2. **Pay** $1 via Stripe
3. **Get** clean, organized code in 30 minutes

### Before & After

**Before:**
```
project/
├── old_stuff.js
├── test.py
├── src/
│   ├── utils.js
│   ├── BACKUP_index.js
│   └── index_final_FINAL.js
└── random_files/
    └── todo.txt
```

**After:**
```
project/
├── src/
│   ├── index.js
│   └── utils/
│       └── helpers.js
├── docs/
│   └── README.md
├── tests/
└── .gitignore
```

## 🛠️ Tech Stack

- **Backend**: Express.js + TypeScript
- **Queue**: Bull + Redis
- **Database**: PostgreSQL
- **AI**: Ollama (local) → Claude (fallback)
- **Storage**: AWS S3
- **Payments**: Stripe

## 📁 Project Structure

```
FinishThisIdea/
├── src/
│   ├── server.ts        # Express server
│   ├── api/            # API routes
│   ├── services/       # Business logic
│   ├── llm/           # AI integrations
│   └── jobs/          # Queue processors
├── docs/              # Documentation
├── tests/             # Test files
└── templates/         # Future: service templates
```

## 🔧 Environment Variables

Create a `.env` file:

```bash
# Server
PORT=3001
NODE_ENV=development

# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/finishthisidea

# Redis
REDIS_URL=redis://localhost:6379

# S3 Storage
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
AWS_REGION=us-east-1
S3_BUCKET=finishthisidea-uploads

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Ollama
OLLAMA_BASE_URL=http://localhost:11434

# Claude (optional fallback)
ANTHROPIC_API_KEY=sk-ant-...
```

## 🚦 API Endpoints

### Upload File
```bash
POST /api/upload
Content-Type: multipart/form-data

Returns:
{
  "jobId": "123e4567...",
  "checkoutUrl": "https://checkout.stripe.com/..."
}
```

### Check Status
```bash
GET /api/jobs/:jobId

Returns:
{
  "status": "processing",
  "progress": 45
}
```

### Download Result
```bash
GET /api/download/:jobId

Returns: Cleaned codebase (zip file)
```

## 🧪 Testing

```bash
# Run all tests
npm test

# Watch mode
npm run test:watch

# Coverage report
npm run test:coverage
```

## 🚀 Deployment

### Local Development
```bash
# Start all services
docker-compose up -d

# Run dev server
npm run dev
```

### Production (Railway)
```bash
# Deploy
railway up

# Set environment variables
railway variables set KEY=value
```

## 📈 Roadmap

### MVP (Current)
- [x] File upload
- [x] Payment processing
- [x] Basic cleanup
- [x] Download results

### Next Features
- [ ] Documentation generation (+$3)
- [ ] API generation (+$5)
- [ ] Test generation (+$4)
- [ ] Before/after preview
- [ ] Custom cleanup rules

### Future Vision
- [ ] Template marketplace
- [ ] Team accounts
- [ ] API access
- [ ] GitHub integration

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing`)
5. Open a Pull Request

## 📄 License

MIT License - see [LICENSE](LICENSE) file

## 🙏 Acknowledgments

Built to solve the problem of 59 levels of nested folders and thousands of TODO comments.

---

**Ready to clean your code?** Visit [finishthisidea.com](https://finishthisidea.com)