# Template Review Checklist

Use this checklist to review new project templates before accepting them into the platform.

---

## 1. Documentation
- [ ] Onboarding guide included
- [ ] API docs (OpenAPI/Swagger) present
- [ ] Support/troubleshooting docs

## 2. Automation & Workflows
- [ ] Onboarding automation scripts included
- [ ] Deployment and monitoring scripts present
- [ ] Workflow templates (YAML/JSON/Markdown) provided

## 3. Security & Compliance
- [ ] Server-side validation and error handling
- [ ] Security scans and dependency checks
- [ ] GDPR/data privacy compliance

## 4. Integration
- [ ] Shared auth and analytics configured
- [ ] Payment and notification services integrated
- [ ] Design system/components used

## 5. Quality & Testing
- [ ] Unit and integration tests included
- [ ] CI/CD pipeline configured
- [ ] Manual testing checklist completed

---

*Check off each item before accepting a new template. Update as standards evolve.* 