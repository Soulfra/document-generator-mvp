---
title: "Multi-Project API Gateway Documentation"
description: "Documentation for the multi-tenant API gateway enabling isolated projects/workspaces with project-level permissions and resource isolation"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Multi-Project API Gateway Documentation

## Overview

The Multi-Project API Gateway enables FinishThisIdea to support multiple isolated projects/workspaces per account, with project-level permissions, resource isolation, and usage tracking.

## Architecture

### Core Components

1. **Project Model** - Represents isolated workspaces
2. **Project Members** - User-project relationships with roles
3. **Gateway Service** - Request routing and rate limiting
4. **Project Auth Middleware** - Context extraction and permission checking
5. **Project Management API** - CRUD operations for projects

### Database Schema

```sql
projects
├── id (UUID, primary key)
├── name (string)
├── slug (unique string)
├── owner_id (UUID, references users)
├── settings (JSONB)
├── status (active|suspended|archived)
├── plan (free|pro|enterprise|custom)
└── metadata (JSONB)

project_members
├── id (UUID, primary key)
├── project_id (UUID, references projects)
├── user_id (UUID, references users)
├── role (owner|admin|member|viewer)
├── permissions (JSONB)
└── is_active (boolean)

project_invites
├── id (UUID, primary key)
├── project_id (UUID, references projects)
├── email (string)
├── role (string)
├── token (unique string)
└── status (pending|accepted|declined|expired)
```

## Project Context Resolution

The gateway extracts project context from requests using multiple methods:

1. **Subdomain** - `project-slug.app.com`
2. **URL Path** - `/api/projects/:projectId/...`
3. **Header** - `X-Project-ID: <projectId>`
4. **Query Parameter** - `?projectId=<projectId>`
5. **JWT Payload** - `activeProjectId` in token

## Roles and Permissions

### Built-in Roles

- **Owner** - Full project control
- **Admin** - Manage project except billing/deletion
- **Member** - Create and view resources
- **Viewer** - Read-only access

### Permission Flags

```typescript
interface ProjectPermissions {
  // Project management
  canUpdateProject: boolean;
  canDeleteProject: boolean;
  canManageMembers: boolean;
  canManageBilling: boolean;
  
  // Resources
  canCreateJobs: boolean;
  canViewJobs: boolean;
  canDeleteJobs: boolean;
  canDownloadResults: boolean;
  
  // Integrations
  canManageIntegrations: boolean;
  canManageWebhooks: boolean;
  canManageWorkflows: boolean;
  
  // Analytics
  canViewAnalytics: boolean;
  canExportData: boolean;
}
```

## API Endpoints

### Project Management

```bash
# List user's projects
GET /api/projects
Authorization: Bearer <token>

# Create project
POST /api/projects
{
  "name": "My Project",
  "slug": "my-project",
  "description": "Project description"
}

# Get project details
GET /api/projects/:projectId

# Update project
PATCH /api/projects/:projectId
{
  "name": "Updated Name",
  "settings": {
    "features": {
      "workflowAutomation": true
    }
  }
}

# Delete project (owner only)
DELETE /api/projects/:projectId
```

### Member Management

```bash
# List project members
GET /api/projects/:projectId/members

# Invite member
POST /api/projects/:projectId/members/invite
{
  "email": "user@example.com",
  "role": "member",
  "message": "Join our project!"
}

# Update member role
PATCH /api/projects/:projectId/members/:memberId
{
  "role": "admin"
}

# Remove member
DELETE /api/projects/:projectId/members/:memberId
```

### Project Switching

```bash
# Switch active project
POST /api/auth/switch-project
{
  "projectId": "project-uuid"
}

# Returns new JWT with project context
{
  "token": "new-jwt-token",
  "project": { ... },
  "role": "member",
  "permissions": { ... }
}
```

### Accept Invitation

```bash
# Accept project invite
POST /api/invites/:token/accept
Authorization: Bearer <token>
```

## Usage in Routes

### Protecting Routes with Project Context

```typescript
import { 
  extractProjectContext,
  requireProject,
  requireProjectMember,
  requireProjectPermission 
} from './middleware/project-auth.middleware';

// Require project membership
router.get(
  '/api/projects/:projectId/jobs',
  authenticate,
  extractProjectContext,
  requireProject,
  requireProjectMember,
  async (req, res) => {
    // req.project - Project instance
    // req.projectMember - Member instance
  }
);

// Require specific permission
router.post(
  '/api/projects/:projectId/jobs',
  authenticate,
  extractProjectContext,
  requireProject,
  requireProjectMember,
  requireProjectPermission('canCreateJobs'),
  async (req, res) => {
    // User has permission to create jobs
  }
);
```

### Scoping Queries

```typescript
// Automatically scope queries to project
const jobs = await Job.findAll({
  where: {
    projectId: req.project.id,
    // other conditions
  }
});

// Creating resources with project context
const job = await Job.create({
  ...jobData,
  projectId: req.project.id,
  userId: req.user.id
});
```

## Rate Limiting

Rate limits are applied per project based on plan:

- **Free**: 100 requests/minute
- **Pro**: 1,000 requests/minute
- **Enterprise**: 10,000 requests/minute
- **Custom**: Unlimited

Rate limit headers:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 2024-01-01T00:00:00Z
```

## Project Settings

Projects can be configured with various settings:

```typescript
interface ProjectSettings {
  features?: {
    codeAnalysis?: boolean;
    documentation?: boolean;
    apiGeneration?: boolean;
    workflowAutomation?: boolean;
  };
  integrations?: {
    slack?: { webhookUrl?: string; enabled?: boolean };
    github?: { token?: string; enabled?: boolean };
    discord?: { webhookUrl?: string; enabled?: boolean };
  };
  limits?: {
    maxJobsPerMonth?: number;
    maxFileSizeMb?: number;
    maxConcurrentJobs?: number;
  };
  branding?: {
    primaryColor?: string;
    logo?: string;
    companyName?: string;
  };
}
```

## Multi-Tenant Considerations

### Data Isolation

- All queries must include project context
- Foreign keys ensure data integrity
- Row-level security for additional protection

### Performance

- Project slug indexing for fast subdomain resolution
- Caching of project metadata
- Efficient permission checking

### Security

- Project API keys for external access
- Audit logging of all project actions
- Regular permission reviews

## Migration Guide

### For Existing Users

1. Default project created automatically
2. All existing resources assigned to default project
3. Users become owners of their default project
4. No breaking changes to existing APIs

### For New Features

1. Add `projectId` to new models
2. Use project auth middleware
3. Scope all queries to project
4. Check permissions before operations

## API Key Authentication

Projects can generate API keys for external access:

```bash
# Using API key
GET /api/projects/my-project/jobs
Authorization: ApiKey proj_<projectId>_<hash>

# API key format
proj_550e8400-e29b-41d4-a716-446655440000_c29tZS1oYXNo
```

## Best Practices

1. **Always extract project context** early in request pipeline
2. **Check permissions** before performing actions
3. **Scope all queries** to prevent data leaks
4. **Log project context** for audit trails
5. **Cache project data** for performance
6. **Validate project status** before operations
7. **Handle project switching** in UI gracefully
8. **Implement proper error messages** for permission denials

## Example: Complete Flow

```typescript
// 1. User creates account
const user = await User.create({ email, password });

// 2. Default project created automatically
const project = await Project.create({
  name: `${user.username}'s Project`,
  slug: `${user.username}-default`,
  ownerId: user.id
});

// 3. User added as owner
await ProjectMember.create({
  projectId: project.id,
  userId: user.id,
  role: 'owner',
  permissions: ProjectMember.getDefaultPermissions('owner')
});

// 4. User invites team member
const invite = await ProjectInvite.create({
  projectId: project.id,
  email: 'teammate@example.com',
  role: 'member',
  invitedBy: user.id,
  token: ProjectInvite.generateToken()
});

// 5. Send invitation email
await emailService.sendProjectInvite(invite);

// 6. Teammate accepts invite
const member = await acceptInvite(invite.token, teammate.id);

// 7. Both users can now access project
// with their respective permissions
```

## Troubleshooting

### Common Issues

1. **"Project context required"** - Ensure projectId is provided
2. **"Not a project member"** - User needs invitation
3. **"Permission denied"** - Check user's role and permissions
4. **"Project not found"** - Verify project exists and is active
5. **"Rate limit exceeded"** - Upgrade plan or wait

### Debug Headers

Enable debug mode to see project resolution:
```
X-Debug-Project-ID: <resolved-project-id>
X-Debug-Project-Source: subdomain|path|header|query|jwt
X-Debug-Member-Role: owner|admin|member|viewer
```