import { 
  DocumentationError, 
  FileProcessingError, 
  CodeAnalysisError, 
  TemplateGenerationError, 
  LLMError, 
  ValidationError, 
  TimeoutError, 
  ResourceLimitError,
  withErrorHandling, 
  withRetry, 
  CircuitBreaker,
  isOperationalError 
} from '../src/utils/error-handler';

describe('Error Handling System', () => {
  describe('Custom Error Classes', () => {
    it('should create DocumentationError with correct properties', () => {
      const error = new DocumentationError(
        'Test error message',
        422,
        'TEST_ERROR',
        { detail: 'test' }
      );

      expect(error.message).toBe('Test error message');
      expect(error.statusCode).toBe(422);
      expect(error.code).toBe('TEST_ERROR');
      expect(error.details).toEqual({ detail: 'test' });
      expect(error.isOperational).toBe(true);
      expect(error.name).toBe('DocumentationError');
    });

    it('should create specialized error types correctly', () => {
      const fileError = new FileProcessingError('File error');
      expect(fileError).toBeInstanceOf(DocumentationError);
      expect(fileError.code).toBe('FILE_PROCESSING_ERROR');
      expect(fileError.statusCode).toBe(422);

      const codeError = new CodeAnalysisError('Code error');
      expect(codeError.code).toBe('CODE_ANALYSIS_ERROR');

      const templateError = new TemplateGenerationError('Template error');
      expect(templateError.code).toBe('TEMPLATE_GENERATION_ERROR');

      const llmError = new LLMError('LLM error');
      expect(llmError.code).toBe('LLM_SERVICE_ERROR');
      expect(llmError.statusCode).toBe(503);

      const validationError = new ValidationError('Validation error');
      expect(validationError.code).toBe('VALIDATION_ERROR');
      expect(validationError.statusCode).toBe(400);

      const timeoutError = new TimeoutError('test operation', 5000);
      expect(timeoutError.code).toBe('TIMEOUT_ERROR');
      expect(timeoutError.statusCode).toBe(408);
      expect(timeoutError.details).toEqual({ operation: 'test operation', timeout: 5000 });

      const resourceError = new ResourceLimitError('memory', 1000, 1500);
      expect(resourceError.code).toBe('RESOURCE_LIMIT_ERROR');
      expect(resourceError.statusCode).toBe(413);
      expect(resourceError.details).toEqual({ resource: 'memory', limit: 1000, actual: 1500 });
    });
  });

  describe('withErrorHandling wrapper', () => {
    it('should execute function successfully and log timing', async () => {
      const mockFn = jest.fn().mockResolvedValue('success');
      const wrappedFn = withErrorHandling(mockFn, 'test operation');

      const result = await wrappedFn('arg1', 'arg2');

      expect(result).toBe('success');
      expect(mockFn).toHaveBeenCalledWith('arg1', 'arg2');
    });

    it('should handle operational errors correctly', async () => {
      const operationalError = new FileProcessingError('Test operational error');
      const mockFn = jest.fn().mockRejectedValue(operationalError);
      const wrappedFn = withErrorHandling(mockFn, 'test operation');

      await expect(wrappedFn()).rejects.toThrow(FileProcessingError);
      await expect(wrappedFn()).rejects.toThrow('Test operational error');
    });

    it('should wrap non-operational errors', async () => {
      const programmingError = new Error('Programming error');
      const mockFn = jest.fn().mockRejectedValue(programmingError);
      const wrappedFn = withErrorHandling(mockFn, 'test operation');

      await expect(wrappedFn()).rejects.toThrow(DocumentationError);
      await expect(wrappedFn()).rejects.toThrow('test operation failed: Programming error');
    });

    it('should handle timeout correctly', async () => {
      const slowFn = jest.fn().mockImplementation(() => 
        new Promise(resolve => setTimeout(resolve, 200))
      );
      const wrappedFn = withErrorHandling(slowFn, 'slow operation', 100);

      await expect(wrappedFn()).rejects.toThrow(TimeoutError);
      await expect(wrappedFn()).rejects.toThrow('timed out after 100ms');
    });
  });

  describe('withRetry wrapper', () => {
    it('should succeed on first attempt', async () => {
      const mockFn = jest.fn().mockResolvedValue('success');

      const result = await withRetry(mockFn, { maxRetries: 3 });

      expect(result).toBe('success');
      expect(mockFn).toHaveBeenCalledTimes(1);
    });

    it('should retry on failure and eventually succeed', async () => {
      const mockFn = jest.fn()
        .mockRejectedValueOnce(new Error('Fail 1'))
        .mockRejectedValueOnce(new Error('Fail 2'))
        .mockResolvedValue('success');

      const result = await withRetry(mockFn, { 
        maxRetries: 3, 
        delay: 10,
        context: 'test retry'
      });

      expect(result).toBe('success');
      expect(mockFn).toHaveBeenCalledTimes(3);
    });

    it('should fail after max retries', async () => {
      const mockFn = jest.fn().mockRejectedValue(new Error('Always fails'));

      await expect(
        withRetry(mockFn, { maxRetries: 2, delay: 10 })
      ).rejects.toThrow('Always fails');

      expect(mockFn).toHaveBeenCalledTimes(3); // Initial + 2 retries
    });

    it('should respect retry condition', async () => {
      const mockFn = jest.fn().mockRejectedValue(new FileProcessingError('Dont retry this'));

      await expect(
        withRetry(mockFn, { 
          maxRetries: 3, 
          delay: 10,
          retryOn: (error) => !(error instanceof FileProcessingError)
        })
      ).rejects.toThrow('Dont retry this');

      expect(mockFn).toHaveBeenCalledTimes(1); // No retries
    });

    it('should implement exponential backoff', async () => {
      const mockFn = jest.fn()
        .mockRejectedValueOnce(new Error('Fail 1'))
        .mockRejectedValueOnce(new Error('Fail 2'))
        .mockResolvedValue('success');

      const startTime = Date.now();
      const result = await withRetry(mockFn, { 
        maxRetries: 2, 
        delay: 50,
        backoffMultiplier: 2
      });
      const duration = Date.now() - startTime;

      expect(result).toBe('success');
      expect(duration).toBeGreaterThan(50 + 100 - 20); // 50ms + 100ms with some tolerance
    });
  });

  describe('CircuitBreaker', () => {
    it('should start in CLOSED state', () => {
      const breaker = new CircuitBreaker(3, 1000, 500);
      const state = breaker.getState();

      expect(state.state).toBe('CLOSED');
      expect(state.failures).toBe(0);
    });

    it('should execute function successfully in CLOSED state', async () => {
      const breaker = new CircuitBreaker(3, 1000, 500);
      const mockFn = jest.fn().mockResolvedValue('success');

      const result = await breaker.execute(mockFn, 'test');

      expect(result).toBe('success');
      expect(breaker.getState().state).toBe('CLOSED');
    });

    it('should open circuit after threshold failures', async () => {
      const breaker = new CircuitBreaker(2, 1000, 500);
      const mockFn = jest.fn().mockRejectedValue(new Error('Service down'));

      // First two failures should pass through
      await expect(breaker.execute(mockFn, 'test')).rejects.toThrow('Service down');
      await expect(breaker.execute(mockFn, 'test')).rejects.toThrow('Service down');

      expect(breaker.getState().state).toBe('OPEN');

      // Third call should be circuit breaker error
      await expect(breaker.execute(mockFn, 'test')).rejects.toThrow('Circuit breaker is OPEN');
    });

    it('should transition to HALF_OPEN after reset timeout', async () => {
      const breaker = new CircuitBreaker(1, 1000, 100); // Very short reset timeout
      const mockFn = jest.fn().mockRejectedValue(new Error('Service down'));

      // Trigger circuit breaker
      await expect(breaker.execute(mockFn, 'test')).rejects.toThrow('Service down');
      expect(breaker.getState().state).toBe('OPEN');

      // Wait for reset timeout
      await new Promise(resolve => setTimeout(resolve, 150));

      // Next call should move to HALF_OPEN
      mockFn.mockResolvedValue('service recovered');
      const result = await breaker.execute(mockFn, 'test');

      expect(result).toBe('service recovered');
      expect(breaker.getState().state).toBe('CLOSED');
    });
  });

  describe('isOperationalError', () => {
    it('should identify operational errors correctly', () => {
      expect(isOperationalError(new DocumentationError('test'))).toBe(true);
      expect(isOperationalError(new FileProcessingError('test'))).toBe(true);
      expect(isOperationalError(new CodeAnalysisError('test'))).toBe(true);
      expect(isOperationalError(new TemplateGenerationError('test'))).toBe(true);
      expect(isOperationalError(new LLMError('test'))).toBe(true);
      expect(isOperationalError(new ValidationError('test'))).toBe(true);
      expect(isOperationalError(new TimeoutError('test', 1000))).toBe(true);
      expect(isOperationalError(new ResourceLimitError('test', 100, 200))).toBe(true);
    });

    it('should identify non-operational errors correctly', () => {
      expect(isOperationalError(new Error('Programming error'))).toBe(false);
      expect(isOperationalError(new TypeError('Type error'))).toBe(false);
      expect(isOperationalError(new ReferenceError('Reference error'))).toBe(false);
    });
  });

  describe('Error Propagation in Real Scenarios', () => {
    it('should handle cascading errors in documentation generation', async () => {
      // Simulate a chain of operations where each can fail
      const mockCodeAnalysis = withErrorHandling(
        async () => {
          throw new CodeAnalysisError('Failed to parse files');
        },
        'code analysis'
      );

      const mockTemplateGeneration = withErrorHandling(
        async (analysis: any) => {
          // This won't be called due to previous failure
          return 'generated docs';
        },
        'template generation'
      );

      // The error should propagate properly
      await expect(mockCodeAnalysis()).rejects.toThrow(CodeAnalysisError);
      await expect(mockCodeAnalysis()).rejects.toThrow('Failed to parse files');
    });

    it('should handle partial failures gracefully', async () => {
      // Simulate a scenario where some operations succeed and others fail
      const operations = [
        withErrorHandling(async () => 'success1', 'op1'),
        withErrorHandling(async () => { throw new Error('fail'); }, 'op2'),
        withErrorHandling(async () => 'success3', 'op3')
      ];

      const results = await Promise.allSettled(operations.map(op => op()));

      expect(results[0].status).toBe('fulfilled');
      expect(results[1].status).toBe('rejected');
      expect(results[2].status).toBe('fulfilled');

      if (results[0].status === 'fulfilled') {
        expect(results[0].value).toBe('success1');
      }
      if (results[2].status === 'fulfilled') {
        expect(results[2].value).toBe('success3');
      }
    });
  });
});