/**
 * Project Model
 * Represents a project/workspace in the multi-tenant system
 */

import { 
  Table, 
  Column, 
  Model, 
  DataType, 
  PrimaryKey, 
  Default, 
  CreatedAt, 
  UpdatedAt,
  BelongsToMany,
  HasMany
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';
import { ProjectMember } from './project-member.model';
import { Job } from './job.model';
import { Upload } from './upload.model';
import { Payment } from './payment.model';

export interface ProjectSettings {
  features?: {
    codeAnalysis?: boolean;
    documentation?: boolean;
    apiGeneration?: boolean;
    workflowAutomation?: boolean;
  };
  integrations?: {
    slack?: { webhookUrl?: string; enabled?: boolean };
    github?: { token?: string; enabled?: boolean };
    discord?: { webhookUrl?: string; enabled?: boolean };
  };
  limits?: {
    maxJobsPerMonth?: number;
    maxFileSizeMb?: number;
    maxConcurrentJobs?: number;
  };
  branding?: {
    primaryColor?: string;
    logo?: string;
    companyName?: string;
  };
}

@Table({
  tableName: 'projects',
  timestamps: true
})
export class Project extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
    unique: true
  })
  name!: string;

  @Column({
    type: DataType.STRING,
    allowNull: false,
    unique: true,
    validate: {
      is: /^[a-z0-9-]+$/
    }
  })
  slug!: string;

  @Column({
    type: DataType.TEXT,
    allowNull: true
  })
  description?: string;

  @Column({
    type: DataType.UUID,
    allowNull: false
  })
  ownerId!: string;

  @Column({
    type: DataType.JSONB,
    allowNull: false,
    defaultValue: {}
  })
  settings!: ProjectSettings;

  @Column({
    type: DataType.ENUM('active', 'suspended', 'archived'),
    allowNull: false,
    defaultValue: 'active'
  })
  status!: 'active' | 'suspended' | 'archived';

  @Column({
    type: DataType.ENUM('free', 'pro', 'enterprise', 'custom'),
    allowNull: false,
    defaultValue: 'free'
  })
  plan!: 'free' | 'pro' | 'enterprise' | 'custom';

  @Column({
    type: DataType.INTEGER,
    allowNull: false,
    defaultValue: 0
  })
  usageCredits!: number;

  @Column({
    type: DataType.DATE,
    allowNull: true
  })
  billingCycleStart?: Date;

  @Column({
    type: DataType.DATE,
    allowNull: true
  })
  billingCycleEnd?: Date;

  @Column({
    type: DataType.JSONB,
    allowNull: false,
    defaultValue: {}
  })
  metadata!: Record<string, any>;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  // Associations
  @BelongsToMany(() => User, () => ProjectMember)
  members!: User[];

  @HasMany(() => Job)
  jobs!: Job[];

  @HasMany(() => Upload)
  uploads!: Upload[];

  @HasMany(() => Payment)
  payments!: Payment[];

  // Helper methods
  isActive(): boolean {
    return this.status === 'active';
  }

  canCreateJob(): boolean {
    if (!this.isActive()) return false;
    
    // Check plan limits
    const limits = this.settings.limits || {};
    if (this.plan === 'free' && limits.maxJobsPerMonth) {
      // Would need to check actual usage
      return true; // Simplified for now
    }
    
    return true;
  }

  getApiKey(): string {
    // Generate project-specific API key
    return `proj_${this.id}_${Buffer.from(this.slug).toString('base64')}`;
  }
}