/**
 * Analytics Plugin
 * Track events in analytics platforms
 */

import { BasePlugin } from '../base-plugin';
import { PluginMetadata, PluginField, PluginExecutionResult } from '../interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../../interfaces/workflow.interface';
import { AnalyticsService } from '../../../services/analytics.service';

export default class AnalyticsPlugin extends BasePlugin {
  private analyticsService: AnalyticsService;
  
  metadata: PluginMetadata = {
    id: 'analytics',
    name: 'Analytics Tracking',
    version: '1.0.0',
    description: 'Track events in analytics platforms',
    author: 'FinishThisIdea',
    icon: '📊',
    category: 'data',
    tags: ['analytics', 'tracking', 'metrics', 'events']
  };
  
  fields: PluginField[] = [
    {
      name: 'event',
      label: 'Event Name',
      type: 'text',
      required: true,
      placeholder: 'workflow_completed',
      description: 'Event name to track'
    },
    {
      name: 'properties',
      label: 'Event Properties',
      type: 'json',
      required: false,
      placeholder: '{"status": "success", "duration": 123}',
      description: 'Event properties/data'
    }
  ];
  
  constructor(config?: Record<string, any>) {
    super(config);
    this.analyticsService = AnalyticsService.getInstance();
  }
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    const { event, properties = {} } = step;
    
    if (!event) {
      return this.failure('Event name is required');
    }
    
    try {
      const { duration } = await this.measureExecution(async () => {
        await this.analyticsService.track({
          event,
          properties: {
            ...properties,
            workflowId: context.workflowId,
            workflowName: context.workflowName
          }
        });
      });
      
      return this.success({ event, properties }, duration, [`Tracked event: ${event}`]);
    } catch (error) {
      return this.failure(`Analytics tracking failed: ${error.message}`);
    }
  }
}