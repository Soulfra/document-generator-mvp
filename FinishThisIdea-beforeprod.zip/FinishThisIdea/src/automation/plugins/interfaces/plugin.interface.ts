/**
 * Plugin System Interfaces
 * Defines the contract for workflow step plugins
 */

import { WorkflowStep, WorkflowContext } from '../../interfaces/workflow.interface';

/**
 * Plugin metadata for discovery and UI display
 */
export interface PluginMetadata {
  /** Unique identifier for the plugin */
  id: string;
  
  /** Display name of the plugin */
  name: string;
  
  /** Plugin version (semver) */
  version: string;
  
  /** Brief description of what the plugin does */
  description: string;
  
  /** Plugin author/organization */
  author: string;
  
  /** Icon for UI display (emoji or icon class) */
  icon: string;
  
  /** Category for organization */
  category: 'integration' | 'utility' | 'notification' | 'data' | 'custom';
  
  /** Tags for searchability */
  tags: string[];
  
  /** Required environment variables or configuration */
  requiredConfig?: string[];
  
  /** Whether the plugin is experimental */
  experimental?: boolean;
  
  /** Minimum engine version required */
  minEngineVersion?: string;
}

/**
 * Field definition for plugin configuration
 */
export interface PluginField {
  /** Field name (used as key in step config) */
  name: string;
  
  /** Display label */
  label: string;
  
  /** Field type for UI rendering */
  type: 'text' | 'textarea' | 'number' | 'select' | 'boolean' | 'json' | 'file';
  
  /** Whether the field is required */
  required: boolean;
  
  /** Default value */
  default?: any;
  
  /** Placeholder text */
  placeholder?: string;
  
  /** Help text/description */
  description?: string;
  
  /** Options for select type */
  options?: Array<{ value: string; label: string }>;
  
  /** Validation rules */
  validation?: {
    pattern?: string;
    min?: number;
    max?: number;
    minLength?: number;
    maxLength?: number;
  };
}

/**
 * Plugin execution result
 */
export interface PluginExecutionResult {
  /** Whether the execution was successful */
  success: boolean;
  
  /** Result data to be stored in workflow context */
  data?: any;
  
  /** Error message if execution failed */
  error?: string;
  
  /** Execution duration in milliseconds */
  duration: number;
  
  /** Any warnings or info messages */
  messages?: string[];
  
  /** Metrics for analytics */
  metrics?: Record<string, number>;
}

/**
 * Plugin lifecycle hooks
 */
export interface PluginLifecycle {
  /** Called when the plugin is loaded */
  onLoad?(): Promise<void>;
  
  /** Called when the plugin is being unloaded */
  onUnload?(): Promise<void>;
  
  /** Called before workflow execution starts */
  beforeWorkflowStart?(context: WorkflowContext): Promise<void>;
  
  /** Called after workflow execution completes */
  afterWorkflowComplete?(context: WorkflowContext): Promise<void>;
}

/**
 * Base interface for all workflow step plugins
 */
export interface WorkflowStepPlugin extends PluginLifecycle {
  /** Plugin metadata */
  metadata: PluginMetadata;
  
  /** Fields required for this plugin */
  fields: PluginField[];
  
  /** Validate step configuration */
  validate(step: WorkflowStep): Promise<{ valid: boolean; errors?: string[] }>;
  
  /** Execute the workflow step */
  execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult>;
  
  /** Get dynamic fields based on configuration (optional) */
  getDynamicFields?(config: Record<string, any>): Promise<PluginField[]>;
  
  /** Test connection/configuration (optional) */
  testConnection?(config: Record<string, any>): Promise<{ success: boolean; message?: string }>;
}

/**
 * Plugin constructor type
 */
export type PluginConstructor = new (config?: any) => WorkflowStepPlugin;

/**
 * Plugin package export structure
 */
export interface PluginPackage {
  /** The plugin class */
  Plugin: PluginConstructor;
  
  /** Optional: Multiple plugins in one package */
  plugins?: Record<string, PluginConstructor>;
}

/**
 * Plugin registry entry
 */
export interface PluginRegistryEntry {
  plugin: WorkflowStepPlugin;
  metadata: PluginMetadata;
  loaded: boolean;
  error?: string;
}

/**
 * Plugin configuration in automation config
 */
export interface PluginConfiguration {
  /** Enable/disable the plugin */
  enabled: boolean;
  
  /** Plugin-specific configuration */
  config?: Record<string, any>;
  
  /** Override plugin metadata */
  overrides?: Partial<PluginMetadata>;
}