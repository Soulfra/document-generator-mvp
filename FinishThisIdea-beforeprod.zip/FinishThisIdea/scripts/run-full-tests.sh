#!/bin/bash

# Full Test Suite Runner for FinishThisIdea
# This script runs comprehensive tests including unit, integration, E2E, and load tests

set -e

echo "🚀 Starting Full Test Suite for FinishThisIdea"
echo "=============================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Ensure required tools are available
print_status "Checking prerequisites..."

if ! command_exists node; then
    print_error "Node.js is required but not installed."
    exit 1
fi

if ! command_exists npm; then
    print_error "npm is required but not installed."
    exit 1
fi

NODE_VERSION=$(node --version)
print_success "Node.js version: $NODE_VERSION"

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    print_error "package.json not found. Please run this script from the project root."
    exit 1
fi

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    print_status "Installing dependencies..."
    npm ci
    print_success "Dependencies installed"
else
    print_status "Dependencies already installed"
fi

# Create test results directory
mkdir -p test-results
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
RESULTS_DIR="test-results/run_$TIMESTAMP"
mkdir -p "$RESULTS_DIR"

print_status "Test results will be saved to: $RESULTS_DIR"

# Function to run test and capture results
run_test() {
    local test_name="$1"
    local test_command="$2"
    local log_file="$RESULTS_DIR/${test_name}.log"
    
    print_status "Running $test_name..."
    echo "Command: $test_command" > "$log_file"
    echo "Started: $(date)" >> "$log_file"
    echo "----------------------------------------" >> "$log_file"
    
    if eval "$test_command" >> "$log_file" 2>&1; then
        print_success "$test_name passed"
        echo "Status: PASSED" >> "$log_file"
        return 0
    else
        print_error "$test_name failed"
        echo "Status: FAILED" >> "$log_file"
        return 1
    fi
}

# Test execution
FAILED_TESTS=()
PASSED_TESTS=()

# 1. Type checking
if run_test "type-check" "npm run type-check"; then
    PASSED_TESTS+=("type-check")
else
    FAILED_TESTS+=("type-check")
fi

# 2. Linting
if run_test "lint" "npm run lint"; then
    PASSED_TESTS+=("lint")
else
    FAILED_TESTS+=("lint")
fi

# 3. Unit tests
if run_test "unit-tests" "npm run test:unit"; then
    PASSED_TESTS+=("unit-tests")
else
    FAILED_TESTS+=("unit-tests")
fi

# 4. Integration tests
if run_test "integration-tests" "npm run test -- --testPathPattern=integration"; then
    PASSED_TESTS+=("integration-tests")
else
    FAILED_TESTS+=("integration-tests")
fi

# 5. E2E tests
print_status "Starting E2E tests (this may take a while)..."
if run_test "e2e-tests" "npm run test:e2e"; then
    PASSED_TESTS+=("e2e-tests")
else
    FAILED_TESTS+=("e2e-tests")
fi

# 6. Performance tests
print_status "Running performance tests..."
if run_test "performance-tests" "npm run test -- --testPathPattern=performance"; then
    PASSED_TESTS+=("performance-tests")
else
    FAILED_TESTS+=("performance-tests")
fi

# 7. Load tests
print_status "Running load tests..."
if run_test "load-tests" "npm run test -- --testPathPattern=load-testing"; then
    PASSED_TESTS+=("load-tests")
else
    FAILED_TESTS+=("load-tests")
fi

# 8. Test coverage
print_status "Generating test coverage report..."
if run_test "coverage" "npm run test:coverage"; then
    PASSED_TESTS+=("coverage")
    # Copy coverage report to results directory
    if [ -d "coverage" ]; then
        cp -r coverage "$RESULTS_DIR/"
        print_success "Coverage report saved to $RESULTS_DIR/coverage"
    fi
else
    FAILED_TESTS+=("coverage")
fi

# Generate summary report
SUMMARY_FILE="$RESULTS_DIR/summary.txt"
echo "FinishThisIdea Test Suite Summary" > "$SUMMARY_FILE"
echo "=================================" >> "$SUMMARY_FILE"
echo "Timestamp: $(date)" >> "$SUMMARY_FILE"
echo "Node.js Version: $NODE_VERSION" >> "$SUMMARY_FILE"
echo "" >> "$SUMMARY_FILE"

echo "PASSED TESTS (${#PASSED_TESTS[@]}):" >> "$SUMMARY_FILE"
for test in "${PASSED_TESTS[@]}"; do
    echo "  ✅ $test" >> "$SUMMARY_FILE"
done

echo "" >> "$SUMMARY_FILE"
echo "FAILED TESTS (${#FAILED_TESTS[@]}):" >> "$SUMMARY_FILE"
for test in "${FAILED_TESTS[@]}"; do
    echo "  ❌ $test" >> "$SUMMARY_FILE"
done

echo "" >> "$SUMMARY_FILE"
echo "Total Tests Run: $((${#PASSED_TESTS[@]} + ${#FAILED_TESTS[@]}))" >> "$SUMMARY_FILE"
echo "Success Rate: $(( ${#PASSED_TESTS[@]} * 100 / (${#PASSED_TESTS[@]} + ${#FAILED_TESTS[@]}) ))%" >> "$SUMMARY_FILE"

# Print summary to console
echo ""
echo "=============================================="
echo "🏁 Test Suite Complete"
echo "=============================================="
cat "$SUMMARY_FILE"

# Set exit code based on failures
if [ ${#FAILED_TESTS[@]} -eq 0 ]; then
    print_success "All tests passed! 🎉"
    echo ""
    echo "Next steps:"
    echo "1. Review coverage report: open $RESULTS_DIR/coverage/index.html"
    echo "2. Check performance metrics in test logs"
    echo "3. Ready for deployment!"
    exit 0
else
    print_error "Some tests failed. Check logs in $RESULTS_DIR/"
    echo ""
    echo "To investigate failures:"
    for test in "${FAILED_TESTS[@]}"; do
        echo "  - Check $RESULTS_DIR/${test}.log"
    done
    exit 1
fi