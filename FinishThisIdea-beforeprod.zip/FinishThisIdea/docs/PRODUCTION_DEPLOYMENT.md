---
title: "Production Deployment Guide"
description: "Complete guide for deploying FinishThisIdea to production environments"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Production Deployment Guide

This guide walks through deploying FinishThisIdea to production.

## Prerequisites

- Domain name purchased
- Hosting provider chosen (Railway, Vercel, AWS, etc.)
- Stripe account with live keys
- PostgreSQL database
- Redis instance
- S3-compatible storage (AWS S3, DigitalOcean Spaces, etc.)

## Step 1: Environment Setup

### 1.1 Create Production Environment Variables

Copy `.env.example` to `.env.production` and update with production values:

```bash
# Core Configuration
NODE_ENV=production
PORT=3001
API_URL=https://api.finishthisidea.com
FRONTEND_URL=https://finishthisidea.com

# Database (Use connection pooling for production)
DATABASE_URL=postgresql://user:password@host:port/database?sslmode=require

# Redis (Use Redis Cloud or AWS ElastiCache)
REDIS_URL=redis://user:password@host:port

# S3 Storage (Use real S3, not MinIO)
AWS_ACCESS_KEY_ID=your-production-key
AWS_SECRET_ACCESS_KEY=your-production-secret
AWS_REGION=us-east-1
S3_BUCKET=finishthisidea-production

# Stripe (IMPORTANT: Use live keys)
STRIPE_SECRET_KEY=sk_live_your_live_key
STRIPE_WEBHOOK_SECRET=whsec_your_live_webhook_secret

# Security (Generate new secrets for production)
JWT_SECRET=generate-new-32-char-secret
ENCRYPTION_KEY=generate-new-32-char-key
```

### 1.2 Set Up External Services

1. **Stripe**:
   - Switch to live mode in Stripe Dashboard
   - Create webhook endpoint: `https://api.finishthisidea.com/api/stripe/webhook`
   - Copy live webhook secret

2. **Sentry**:
   - Create new project for production
   - Update DSN in environment variables

3. **Analytics**:
   - Create production projects in Mixpanel/GA4
   - Update tracking IDs

## Step 2: Database Setup

### 2.1 Create Production Database

```bash
# Create database
createdb finishthisidea_production

# Run migrations
DATABASE_URL=your-production-url npx prisma migrate deploy

# Seed initial data (if needed)
DATABASE_URL=your-production-url npx prisma db seed
```

### 2.2 Set Up Database Backups

Configure automated daily backups with your hosting provider or use the GitHub Action in `.github/workflows/scheduled-tasks.yml`.

## Step 3: Deployment

### Option A: Railway Deployment

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login to Railway
railway login

# Create new project
railway new

# Set environment variables
railway variables set NODE_ENV=production
railway variables set DATABASE_URL=...
# Set all other variables

# Deploy
railway up
```

### Option B: Docker Deployment

```dockerfile
# Create Dockerfile
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./
COPY prisma ./prisma/

# Install dependencies
RUN npm ci --only=production
RUN npx prisma generate

# Copy application files
COPY . .

# Build TypeScript
RUN npm run build

# Expose port
EXPOSE 3001

# Start server
CMD ["node", "dist/server.js"]
```

### Option C: Traditional VPS

```bash
# SSH into server
ssh user@your-server

# Install Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Clone repository
git clone https://github.com/yourusername/finishthisidea.git
cd finishthisidea

# Install dependencies
npm ci --only=production

# Build application
npm run build

# Set up PM2 for process management
npm install -g pm2
pm2 start dist/server.js --name finishthisidea
pm2 save
pm2 startup
```

## Step 4: Domain & SSL Setup

### 4.1 Configure DNS

Point your domain to your server:
- A record: `@` → Your server IP
- A record: `api` → Your server IP
- CNAME: `www` → `@`

### 4.2 Set Up SSL

Using Certbot for Let's Encrypt:

```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d finishthisidea.com -d www.finishthisidea.com -d api.finishthisidea.com

# Auto-renewal
sudo certbot renew --dry-run
```

## Step 5: Post-Deployment Checklist

### 5.1 Verify Core Functionality

- [ ] Homepage loads
- [ ] File upload works
- [ ] Payment processing works
- [ ] Email notifications send
- [ ] Job processing completes
- [ ] Analytics tracking works
- [ ] Error monitoring active

### 5.2 Security Checklist

- [ ] HTTPS enforced
- [ ] Environment variables secure
- [ ] Database connection encrypted
- [ ] CORS configured correctly
- [ ] Rate limiting active
- [ ] Input validation working

### 5.3 Performance Optimization

```bash
# Enable compression
npm install compression

# Set up CDN for static assets
# Configure CloudFlare or similar

# Enable Redis caching
# Configure job queue optimization
```

### 5.4 Monitoring Setup

1. **Uptime Monitoring**:
   - Set up UptimeRobot or Pingdom
   - Monitor `/health` endpoint
   - Alert on downtime

2. **Application Monitoring**:
   - Verify Sentry is receiving errors
   - Check analytics data flow
   - Monitor job queue health

3. **Server Monitoring**:
   - CPU/Memory usage
   - Disk space
   - Database connections
   - Redis memory

## Step 6: Launch Tasks

### 6.1 Final Testing

```bash
# Run production smoke tests
npm run test:production

# Load testing
npm run test:load

# Security scanning
npm audit
```

### 6.2 Go Live

1. Update DNS to production server
2. Enable production mode in all services
3. Announce launch on social media
4. Monitor closely for first 24 hours

## Rollback Plan

If issues occur:

```bash
# Quick rollback
pm2 restart finishthisidea --update-env
pm2 logs finishthisidea

# Database rollback
npx prisma migrate rollback

# Full rollback
git checkout previous-version
npm ci
npm run build
pm2 restart finishthisidea
```

## Maintenance

### Daily Tasks
- Check error logs
- Monitor job queue
- Review analytics

### Weekly Tasks
- Review performance metrics
- Check disk space
- Update dependencies

### Monthly Tasks
- Security updates
- Database optimization
- Cost review

## Support Contacts

- **Hosting Issues**: support@your-host.com
- **Domain/DNS**: support@your-registrar.com
- **Payment Issues**: support@stripe.com
- **Error Monitoring**: support@sentry.io

## Congratulations! 🎉

Your FinishThisIdea platform is now live and fully automated. Monitor the dashboards, respond to any critical alerts, and focus on growing your user base!