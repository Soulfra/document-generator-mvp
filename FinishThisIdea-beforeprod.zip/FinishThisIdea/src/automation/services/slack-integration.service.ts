import { WebClient } from '@slack/web-api';
import { logger } from '../../utils/logger';
import automationConfig from '../config/automation-config.json';

export interface SlackMessage {
  channel: string;
  text: string;
  blocks?: any[];
  attachments?: any[];
  thread_ts?: string;
  username?: string;
  icon_emoji?: string;
  icon_url?: string;
}

export interface SlackChannelInfo {
  id: string;
  name: string;
  is_private: boolean;
  is_archived: boolean;
  num_members?: number;
}

export interface SlackUser {
  id: string;
  name: string;
  real_name?: string;
  email?: string;
  is_bot: boolean;
  is_admin?: boolean;
}

export class SlackIntegrationService {
  private client: WebClient | null = null;
  private isEnabled = false;
  private botToken: string | null = null;

  constructor() {
    this.initialize();
  }

  /**
   * Initialize Slack integration
   */
  private initialize(): void {
    if (!automationConfig.notifications.slack.enabled) {
      logger.info('Slack integration disabled in configuration');
      return;
    }

    this.botToken = process.env.SLACK_BOT_TOKEN;
    if (!this.botToken) {
      logger.warn('SLACK_BOT_TOKEN not found in environment variables');
      return;
    }

    try {
      this.client = new WebClient(this.botToken);
      this.isEnabled = true;
      logger.info('Slack integration initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize Slack client', { error });
    }
  }

  /**
   * Send a message to a Slack channel
   */
  public async sendMessage(message: SlackMessage): Promise<any> {
    if (!this.isEnabled || !this.client) {
      throw new Error('Slack integration not enabled or configured');
    }

    try {
      // Resolve channel name to ID if needed
      const channelId = await this.resolveChannelId(message.channel);

      const result = await this.client.chat.postMessage({
        channel: channelId,
        text: message.text,
        blocks: message.blocks,
        attachments: message.attachments,
        thread_ts: message.thread_ts,
        username: message.username,
        icon_emoji: message.icon_emoji,
        icon_url: message.icon_url,
      });

      logger.info('Slack message sent successfully', {
        channel: message.channel,
        timestamp: result.ts,
      });

      return result;
    } catch (error) {
      logger.error('Failed to send Slack message', { error, channel: message.channel });
      throw error;
    }
  }

  /**
   * Send a formatted notification
   */
  public async sendNotification(
    channel: string,
    title: string,
    message: string,
    options: {
      color?: 'good' | 'warning' | 'danger' | string;
      fields?: Array<{ title: string; value: string; short?: boolean }>;
      actions?: any[];
      username?: string;
      icon_emoji?: string;
    } = {}
  ): Promise<any> {
    const attachment = {
      color: options.color || 'good',
      title,
      text: message,
      fields: options.fields || [],
      actions: options.actions || [],
      ts: Math.floor(Date.now() / 1000),
    };

    return this.sendMessage({
      channel,
      text: title, // Fallback text
      attachments: [attachment],
      username: options.username,
      icon_emoji: options.icon_emoji,
    });
  }

  /**
   * Send deployment notification
   */
  public async sendDeploymentNotification(
    channel: string,
    service: string,
    version: string,
    status: 'started' | 'success' | 'failed',
    details?: string
  ): Promise<any> {
    const statusEmojis = {
      started: '🚀',
      success: '✅',
      failed: '❌',
    };

    const colors = {
      started: '#36a64f',
      success: 'good',
      failed: 'danger',
    };

    const title = `${statusEmojis[status]} Deployment ${status.charAt(0).toUpperCase() + status.slice(1)}`;
    const message = `Service: ${service}\nVersion: ${version}${details ? `\nDetails: ${details}` : ''}`;

    return this.sendNotification(channel, title, message, {
      color: colors[status],
      fields: [
        { title: 'Service', value: service, short: true },
        { title: 'Version', value: version, short: true },
        { title: 'Status', value: status.charAt(0).toUpperCase() + status.slice(1), short: true },
        { title: 'Time', value: new Date().toISOString(), short: true },
      ],
    });
  }

  /**
   * Send error alert
   */
  public async sendErrorAlert(
    channel: string,
    error: string,
    service?: string,
    metadata?: Record<string, any>
  ): Promise<any> {
    const fields = [
      { title: 'Error', value: error, short: false },
      { title: 'Time', value: new Date().toISOString(), short: true },
    ];

    if (service) {
      fields.unshift({ title: 'Service', value: service, short: true });
    }

    if (metadata) {
      Object.entries(metadata).forEach(([key, value]) => {
        fields.push({
          title: key.charAt(0).toUpperCase() + key.slice(1),
          value: String(value),
          short: true,
        });
      });
    }

    return this.sendNotification(channel, '🚨 Error Alert', error, {
      color: 'danger',
      fields,
    });
  }

  /**
   * Send user activity notification
   */
  public async sendUserActivity(
    channel: string,
    event: string,
    user: { id?: string; email?: string; name?: string },
    metadata?: Record<string, any>
  ): Promise<any> {
    const fields = [
      { title: 'Event', value: event, short: true },
      { title: 'Time', value: new Date().toISOString(), short: true },
    ];

    if (user.name) fields.push({ title: 'User', value: user.name, short: true });
    if (user.email) fields.push({ title: 'Email', value: user.email, short: true });

    if (metadata) {
      Object.entries(metadata).forEach(([key, value]) => {
        fields.push({
          title: key.charAt(0).toUpperCase() + key.slice(1),
          value: String(value),
          short: true,
        });
      });
    }

    return this.sendNotification(channel, '👤 User Activity', event, {
      color: '#36a64f',
      fields,
    });
  }

  /**
   * Get channel list
   */
  public async getChannels(): Promise<SlackChannelInfo[]> {
    if (!this.isEnabled || !this.client) {
      throw new Error('Slack integration not enabled or configured');
    }

    try {
      const result = await this.client.conversations.list({
        types: 'public_channel,private_channel',
        limit: 200,
      });

      return (result.channels || []).map(channel => ({
        id: channel.id!,
        name: channel.name!,
        is_private: channel.is_private || false,
        is_archived: channel.is_archived || false,
        num_members: channel.num_members,
      }));
    } catch (error) {
      logger.error('Failed to get Slack channels', { error });
      throw error;
    }
  }

  /**
   * Get user list
   */
  public async getUsers(): Promise<SlackUser[]> {
    if (!this.isEnabled || !this.client) {
      throw new Error('Slack integration not enabled or configured');
    }

    try {
      const result = await this.client.users.list({
        limit: 200,
      });

      return (result.members || []).map(member => ({
        id: member.id!,
        name: member.name!,
        real_name: member.real_name,
        email: member.profile?.email,
        is_bot: member.is_bot || false,
        is_admin: member.is_admin,
      }));
    } catch (error) {
      logger.error('Failed to get Slack users', { error });
      throw error;
    }
  }

  /**
   * Test Slack connection
   */
  public async testConnection(): Promise<boolean> {
    if (!this.isEnabled || !this.client) {
      return false;
    }

    try {
      const result = await this.client.auth.test();
      logger.info('Slack connection test successful', {
        team: result.team,
        user: result.user,
      });
      return true;
    } catch (error) {
      logger.error('Slack connection test failed', { error });
      return false;
    }
  }

  /**
   * Resolve channel name to ID
   */
  private async resolveChannelId(channelInput: string): Promise<string> {
    // If it's already a channel ID (starts with 'C' or 'G'), return as-is
    if (channelInput.match(/^[CG][A-Z0-9]+$/)) {
      return channelInput;
    }

    // If it starts with '#', remove it
    const channelName = channelInput.replace(/^#/, '');

    try {
      const channels = await this.getChannels();
      const channel = channels.find(c => c.name === channelName);
      
      if (!channel) {
        throw new Error(`Channel not found: ${channelName}`);
      }

      return channel.id;
    } catch (error) {
      logger.warn(`Failed to resolve channel ID for ${channelName}, using as-is`, { error });
      return channelInput;
    }
  }

  /**
   * Check if Slack integration is enabled
   */
  public isIntegrationEnabled(): boolean {
    return this.isEnabled;
  }

  /**
   * Get integration status
   */
  public getStatus(): {
    enabled: boolean;
    configured: boolean;
    botToken: boolean;
    connectionOk?: boolean;
  } {
    return {
      enabled: automationConfig.notifications.slack.enabled,
      configured: this.isEnabled,
      botToken: !!this.botToken,
    };
  }
}

// Export singleton instance
export const slackIntegration = new SlackIntegrationService();