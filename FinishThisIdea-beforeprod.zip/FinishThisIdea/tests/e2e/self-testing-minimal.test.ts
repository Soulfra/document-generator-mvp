import { ZipManager } from '../utils/zip-manager';
import { promises as fs } from 'fs';
import * as path from 'path';
import * as os from 'os';

describe('Self-Testing: FinishThisIdea Core Files', () => {
  let tempDir: string;
  let finishThisIdeaZip: string;

  beforeAll(async () => {
    // Create temporary directory
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'finishthisidea-minimal-'));
    console.log('🚀 Starting minimal self-test in:', tempDir);
    
    // Create ZIP of only essential source files
    console.log('🔄 Creating minimal ZIP of FinishThisIdea source...');
    
    const projectRoot = path.resolve(__dirname, '../..');
    finishThisIdeaZip = path.join(tempDir, 'finishthisidea-minimal.zip');
    
    await createMinimalProjectZip(projectRoot, finishThisIdeaZip);
    
    // Verify the ZIP was created
    const zipInfo = await ZipManager.getZipInfo(finishThisIdeaZip);
    console.log(`✅ Created minimal FinishThisIdea ZIP: ${zipInfo.fileCount} files, ${(zipInfo.totalSize / 1024 / 1024).toFixed(2)}MB`);
    
    // Should be much smaller and manageable now that node_modules are excluded
    expect(zipInfo.fileCount).toBeLessThan(1000); // More realistic expectation
    expect(zipInfo.totalSize).toBeLessThan(100 * 1024 * 1024); // Under 100MB
  });

  afterAll(async () => {
    // Clean up
    await fs.rm(tempDir, { recursive: true, force: true });
    console.log('✅ Minimal self-test cleanup completed');
  });

  describe('Core Source Analysis', () => {
    it('should extract and validate FinishThisIdea core structure', async () => {
      console.log('📂 Testing core file extraction...');

      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip);
      
      console.log(`📊 Extracted ${extractedFiles.size} core files from FinishThisIdea`);
      
      // Verify essential files exist
      expect(extractedFiles.has('package.json')).toBe(true);
      expect(extractedFiles.has('README.md')).toBe(true);
      expect(extractedFiles.has('tsconfig.json')).toBe(true);
      
      // Check for key source directories
      const srcFiles = Array.from(extractedFiles.keys()).filter(f => f.startsWith('src/'));
      const testFiles = Array.from(extractedFiles.keys()).filter(f => f.startsWith('tests/'));
      
      expect(srcFiles.length).toBeGreaterThan(10);
      expect(testFiles.length).toBeGreaterThan(5);
      
      console.log(`✅ Core structure validated: ${srcFiles.length} src files, ${testFiles.length} test files`);
    });

    it('should analyze FinishThisIdea API structure', async () => {
      console.log('🔗 Analyzing API structure...');

      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip);
      
      // Find API route files
      const apiRoutes = Array.from(extractedFiles.keys())
        .filter(f => f.includes('api/routes/') && f.endsWith('.ts'));
      
      console.log(`📡 Found ${apiRoutes.length} API route files:`, apiRoutes);
      
      // Analyze route content
      const routeAnalysis = {
        totalRoutes: apiRoutes.length,
        hasUpload: false,
        hasDocumentation: false,
        hasProfiles: false,
        hasHealth: false,
        endpoints: [] as string[]
      };

      for (const routeFile of apiRoutes) {
        const content = extractedFiles.get(routeFile) || '';
        
        if (content.includes('upload')) routeAnalysis.hasUpload = true;
        if (content.includes('documentation')) routeAnalysis.hasDocumentation = true;
        if (content.includes('profile')) routeAnalysis.hasProfiles = true;
        if (content.includes('health')) routeAnalysis.hasHealth = true;

        // Extract HTTP methods
        const methods = content.match(/router\.(get|post|put|delete|patch)/g) || [];
        routeAnalysis.endpoints.push(...methods);
      }

      console.log('🎯 API Analysis Results:', {
        totalRoutes: routeAnalysis.totalRoutes,
        hasUpload: routeAnalysis.hasUpload,
        hasDocumentation: routeAnalysis.hasDocumentation,
        hasProfiles: routeAnalysis.hasProfiles,
        hasHealth: routeAnalysis.hasHealth,
        totalEndpoints: routeAnalysis.endpoints.length
      });

      // Validate core API functionality
      expect(routeAnalysis.totalRoutes).toBeGreaterThan(3);
      expect(routeAnalysis.hasUpload).toBe(true);
      expect(routeAnalysis.hasDocumentation).toBe(true);
      expect(routeAnalysis.endpoints.length).toBeGreaterThan(5);

      console.log('✅ API structure analysis passed');
    });

    it('should analyze service layer architecture', async () => {
      console.log('⚙️ Analyzing service layer...');

      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip);
      
      // Find service files
      const serviceFiles = Array.from(extractedFiles.keys())
        .filter(f => f.includes('services/') && f.endsWith('.ts'));
      
      console.log(`🔧 Found ${serviceFiles.length} service files:`, serviceFiles);
      
      const serviceAnalysis = {
        totalServices: serviceFiles.length,
        hasDocumentationService: false,
        hasFileProcessingService: false,
        hasProfileService: false,
        classes: [] as string[],
        functions: [] as string[]
      };

      for (const serviceFile of serviceFiles) {
        const content = extractedFiles.get(serviceFile) || '';
        
        if (serviceFile.includes('documentation')) serviceAnalysis.hasDocumentationService = true;
        if (serviceFile.includes('file') || serviceFile.includes('processing')) serviceAnalysis.hasFileProcessingService = true;
        if (serviceFile.includes('profile')) serviceAnalysis.hasProfileService = true;

        // Look for class declarations
        const classMatches = content.match(/class\s+(\w+)/g) || [];
        serviceAnalysis.classes.push(...classMatches);

        // Look for exported functions
        const functionMatches = content.match(/export\s+(async\s+)?function\s+(\w+)/g) || [];
        serviceAnalysis.functions.push(...functionMatches);
      }

      console.log('🏗️ Service Layer Analysis:', {
        totalServices: serviceAnalysis.totalServices,
        hasDocumentationService: serviceAnalysis.hasDocumentationService,
        hasFileProcessingService: serviceAnalysis.hasFileProcessingService,
        hasProfileService: serviceAnalysis.hasProfileService,
        classes: serviceAnalysis.classes.length,
        functions: serviceAnalysis.functions.length
      });

      // Validate service architecture
      expect(serviceAnalysis.totalServices).toBeGreaterThan(2);
      expect(serviceAnalysis.hasDocumentationService).toBe(true);
      expect(serviceAnalysis.classes.length + serviceAnalysis.functions.length).toBeGreaterThan(0);

      console.log('✅ Service layer analysis passed');
    });

    it('should validate TypeScript quality and configuration', async () => {
      console.log('📝 Analyzing TypeScript configuration...');

      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip);
      
      // Check TypeScript config
      const tsconfigContent = extractedFiles.get('tsconfig.json');
      expect(tsconfigContent).toBeDefined();
      
      const tsconfig = JSON.parse(tsconfigContent!);
      console.log('⚙️ TypeScript config:', {
        target: tsconfig.compilerOptions?.target,
        module: tsconfig.compilerOptions?.module,
        strict: tsconfig.compilerOptions?.strict,
        outDir: tsconfig.compilerOptions?.outDir
      });

      // Analyze TypeScript files
      const tsFiles = Array.from(extractedFiles.keys()).filter(f => f.endsWith('.ts') && !f.endsWith('.d.ts'));
      const tsxFiles = Array.from(extractedFiles.keys()).filter(f => f.endsWith('.tsx'));
      
      console.log(`📊 TypeScript Files: ${tsFiles.length} .ts files, ${tsxFiles.length} .tsx files`);

      // Sample a few TypeScript files for quality analysis
      let hasInterfaces = false;
      let hasTypes = false;
      let hasAsyncAwait = false;
      let hasErrorHandling = false;

      const sampleFiles = tsFiles.slice(0, 10); // Sample first 10 files
      for (const file of sampleFiles) {
        const content = extractedFiles.get(file) || '';
        
        if (content.includes('interface ')) hasInterfaces = true;
        if (content.includes('type ')) hasTypes = true;
        if (content.includes('async ') || content.includes('await ')) hasAsyncAwait = true;
        if (content.includes('try {') || content.includes('catch')) hasErrorHandling = true;
      }

      console.log('🎯 TypeScript Quality Indicators:', {
        hasInterfaces,
        hasTypes,
        hasAsyncAwait,
        hasErrorHandling,
        strictMode: tsconfig.compilerOptions?.strict
      });

      // Validate TypeScript usage
      expect(tsFiles.length).toBeGreaterThan(20);
      expect(tsconfig.compilerOptions?.strict).toBe(true);
      expect(hasInterfaces).toBe(true);
      expect(hasAsyncAwait).toBe(true);

      console.log('✅ TypeScript quality validation passed');
    });
  });

  describe('Test Coverage Analysis', () => {
    it('should validate comprehensive test suite exists', async () => {
      console.log('🧪 Analyzing test coverage...');

      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip);
      
      // Find test files
      const testFiles = Array.from(extractedFiles.keys())
        .filter(f => f.includes('test') && f.endsWith('.ts'));
      
      const unitTests = testFiles.filter(f => !f.includes('e2e'));
      const e2eTests = testFiles.filter(f => f.includes('e2e'));
      
      console.log(`🎯 Test Analysis: ${testFiles.length} total tests`);
      console.log(`   Unit Tests: ${unitTests.length}`);
      console.log(`   E2E Tests: ${e2eTests.length}`);
      
      // Analyze test content
      const testTypes = {
        hasDescribeBlocks: false,
        hasItBlocks: false,
        hasBeforeAfter: false,
        hasExpectations: false,
        hasMocks: false
      };

      for (const testFile of testFiles.slice(0, 5)) { // Sample 5 test files
        const content = extractedFiles.get(testFile) || '';
        
        if (content.includes('describe(')) testTypes.hasDescribeBlocks = true;
        if (content.includes('it(') || content.includes('test(')) testTypes.hasItBlocks = true;
        if (content.includes('beforeAll') || content.includes('afterAll')) testTypes.hasBeforeAfter = true;
        if (content.includes('expect(')) testTypes.hasExpectations = true;
        if (content.includes('jest.mock') || content.includes('mock')) testTypes.hasMocks = true;
      }

      console.log('📊 Test Quality:', testTypes);

      // Validate test suite
      expect(testFiles.length).toBeGreaterThan(5);
      expect(unitTests.length).toBeGreaterThan(3);
      expect(e2eTests.length).toBeGreaterThan(1);
      expect(testTypes.hasDescribeBlocks).toBe(true);
      expect(testTypes.hasExpectations).toBe(true);

      console.log('✅ Test coverage analysis passed');
    });
  });

  describe('Production Readiness', () => {
    it('should validate production configuration exists', async () => {
      console.log('🚀 Validating production readiness...');

      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip);
      
      // Check package.json for production indicators
      const packageJson = JSON.parse(extractedFiles.get('package.json')!);
      
      const productionIndicators = {
        hasStartScript: !!packageJson.scripts?.start,
        hasBuildScript: !!packageJson.scripts?.build,
        hasTestScript: !!packageJson.scripts?.test,
        hasLintScript: !!packageJson.scripts?.lint,
        hasProductionDeps: Object.keys(packageJson.dependencies || {}).length > 5,
        hasDevDeps: Object.keys(packageJson.devDependencies || {}).length > 5,
        hasEngines: !!packageJson.engines,
        hasKeywords: (packageJson.keywords || []).length > 0
      };

      console.log('🎯 Production Readiness Check:', productionIndicators);

      // Check for essential production files
      const hasDockerfile = extractedFiles.has('Dockerfile');
      const hasEnvExample = extractedFiles.has('.env.example') || extractedFiles.has('.env.template');
      const hasGitignore = extractedFiles.has('.gitignore');
      const hasPrettierConfig = extractedFiles.has('.prettierrc') || extractedFiles.has('prettier.config.js');

      console.log('📁 Production Files:', {
        hasDockerfile,
        hasEnvExample,
        hasGitignore,
        hasPrettierConfig
      });

      // Validate production readiness
      expect(productionIndicators.hasStartScript).toBe(true);
      expect(productionIndicators.hasBuildScript).toBe(true);
      expect(productionIndicators.hasTestScript).toBe(true);
      expect(productionIndicators.hasProductionDeps).toBe(true);

      console.log('✅ Production readiness validated - FinishThisIdea is ready to ship!');
    });
  });
});

// Helper function to create minimal ZIP with only essential files
async function createMinimalProjectZip(sourceDir: string, outputPath: string): Promise<void> {
  const archiver = require('archiver');
  const output = require('fs').createWriteStream(outputPath);
  const archive = archiver('zip', { zlib: { level: 9 } });

  return new Promise((resolve, reject) => {
    output.on('close', resolve);
    output.on('error', reject);
    archive.on('error', reject);

    archive.pipe(output);

    // Only include essential source files - properly exclude all node_modules
    archive.glob('**/*', {
      cwd: sourceDir,
      ignore: [
        '**/node_modules/**',   // Any node_modules anywhere
        'node_modules/**',      // Root level node_modules
        'frontend/node_modules/**', // Frontend node_modules specifically
        'dist/**',
        'coverage/**',
        '.git/**',
        '.next/**',
        'build/**',
        'out/**',
        '*.log',
        'tmp/**',
        'temp/**',
        '**/*.map',
        '**/*.chunk.js',
        '**/.DS_Store',
        '**/Thumbs.db',
        'debug-zip-contents.js', // Exclude our debug file
        'debug.zip'
      ]
    });

    archive.finalize();
  });
}