import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { HelpCircle, X, MessageCircle, Book, Mail, ChevronRight } from 'lucide-react';

interface FAQ {
  question: string;
  answer: string;
  category: 'general' | 'upload' | 'payment' | 'technical';
}

const FAQS: FAQ[] = [
  {
    question: 'What file formats are supported?',
    answer: 'We support ZIP, TAR, and TAR.GZ archives containing your project files. Individual code files in any major programming language are also supported.',
    category: 'upload',
  },
  {
    question: 'What is the file size limit?',
    answer: 'Free users can upload files up to 50MB. Premium users enjoy a 500MB limit for larger projects.',
    category: 'upload',
  },
  {
    question: 'How long does processing take?',
    answer: 'Most projects are processed within 2-5 minutes. Larger projects may take up to 10 minutes. Premium users get priority processing.',
    category: 'general',
  },
  {
    question: 'What documentation types can be generated?',
    answer: 'We generate executive summaries, API documentation, data models, test plans, user stories, and technical requirements. Premium users get access to advanced templates.',
    category: 'general',
  },
  {
    question: 'Is my code secure?',
    answer: 'Yes! Your code is processed securely and never stored permanently. All uploads are deleted after processing, and we use enterprise-grade encryption.',
    category: 'technical',
  },
  {
    question: 'How do I upgrade to Premium?',
    answer: 'Click on any premium feature or the upgrade button in your dashboard. Payment is processed securely through Stripe.',
    category: 'payment',
  },
  {
    question: 'Can I cancel my premium subscription?',
    answer: 'Premium is a one-time payment, not a subscription. You keep premium features forever after upgrading.',
    category: 'payment',
  },
  {
    question: 'What if processing fails?',
    answer: "If your job fails, you'll receive an email with troubleshooting steps. Common issues include corrupted archives or unsupported file types. Try re-uploading or contact support.",
    category: 'technical',
  },
];

export const HelpWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);

  const categories = [
    { id: 'general', label: 'General', icon: HelpCircle },
    { id: 'upload', label: 'Upload & Processing', icon: MessageCircle },
    { id: 'payment', label: 'Pricing & Payment', icon: Book },
    { id: 'technical', label: 'Technical Issues', icon: Mail },
  ];

  const filteredFAQs = selectedCategory
    ? FAQS.filter(faq => faq.category === selectedCategory)
    : FAQS;

  return (
    <>
      {/* Help Button */}
      <motion.button
        className="fixed bottom-4 left-4 bg-primary-600 hover:bg-primary-700 text-white rounded-full 
                   p-4 shadow-lg z-40 transition-all"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(true)}
      >
        <HelpCircle className="w-6 h-6" />
      </motion.button>

      {/* Help Modal */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black bg-opacity-50 z-40"
              onClick={() => setIsOpen(false)}
            />

            {/* Modal */}
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.95 }}
              className="fixed bottom-20 left-4 bg-gray-900 rounded-xl shadow-2xl w-96 max-h-[600px] 
                       overflow-hidden z-50"
            >
              {/* Header */}
              <div className="bg-gray-800 p-4 flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white flex items-center space-x-2">
                  <HelpCircle className="w-5 h-5" />
                  <span>Help & Support</span>
                </h3>
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Content */}
              <div className="p-4 overflow-y-auto max-h-[400px]">
                {/* Quick Links */}
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-gray-400 mb-3">Quick Links</h4>
                  <div className="space-y-2">
                    <a
                      href="/docs"
                      className="flex items-center justify-between p-3 bg-gray-800 rounded-lg 
                               hover:bg-gray-700 transition-colors"
                    >
                      <span className="text-white">Documentation</span>
                      <ChevronRight className="w-4 h-4 text-gray-400" />
                    </a>
                    <a
                      href="mailto:support@finishthisidea.com"
                      className="flex items-center justify-between p-3 bg-gray-800 rounded-lg 
                               hover:bg-gray-700 transition-colors"
                    >
                      <span className="text-white">Email Support</span>
                      <ChevronRight className="w-4 h-4 text-gray-400" />
                    </a>
                  </div>
                </div>

                {/* Categories */}
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-3">Browse by Category</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {categories.map((category) => {
                      const Icon = category.icon;
                      return (
                        <button
                          key={category.id}
                          onClick={() => setSelectedCategory(
                            selectedCategory === category.id ? null : category.id
                          )}
                          className={`p-3 rounded-lg text-sm font-medium transition-all ${
                            selectedCategory === category.id
                              ? 'bg-primary-600 text-white'
                              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                          }`}
                        >
                          <Icon className="w-4 h-4 mb-1 mx-auto" />
                          {category.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* FAQs */}
                <div>
                  <h4 className="text-sm font-medium text-gray-400 mb-3">
                    {selectedCategory ? 'Filtered FAQs' : 'Frequently Asked Questions'}
                  </h4>
                  <div className="space-y-2">
                    {filteredFAQs.map((faq, index) => (
                      <div
                        key={index}
                        className="bg-gray-800 rounded-lg overflow-hidden"
                      >
                        <button
                          onClick={() => setExpandedFAQ(
                            expandedFAQ === index ? null : index
                          )}
                          className="w-full p-3 text-left flex items-center justify-between 
                                   hover:bg-gray-700 transition-colors"
                        >
                          <span className="text-sm text-white pr-2">{faq.question}</span>
                          <ChevronRight
                            className={`w-4 h-4 text-gray-400 flex-shrink-0 transform 
                                     transition-transform ${
                              expandedFAQ === index ? 'rotate-90' : ''
                            }`}
                          />
                        </button>
                        <AnimatePresence>
                          {expandedFAQ === index && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="px-3 pb-3"
                            >
                              <p className="text-sm text-gray-400 leading-relaxed">
                                {faq.answer}
                              </p>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Contact Support */}
                <div className="mt-6 p-4 bg-primary-900/20 rounded-lg border border-primary-700">
                  <h4 className="text-sm font-medium text-primary-400 mb-2">
                    Still need help?
                  </h4>
                  <p className="text-xs text-gray-400 mb-3">
                    Our support team is here to help you succeed.
                  </p>
                  <a
                    href="mailto:support@finishthisidea.com"
                    className="inline-flex items-center space-x-2 text-sm text-primary-400 
                             hover:text-primary-300 transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                    <span>Contact Support</span>
                  </a>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

// Help Tooltip Component
interface HelpTooltipProps {
  content: string;
  children: React.ReactNode;
}

export const HelpTooltip: React.FC<HelpTooltipProps> = ({ content, children }) => {
  const [isVisible, setIsVisible] = useState(false);

  return (
    <div className="relative inline-block">
      <div
        onMouseEnter={() => setIsVisible(true)}
        onMouseLeave={() => setIsVisible(false)}
      >
        {children}
      </div>
      
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 5 }}
            className="absolute z-50 bottom-full mb-2 left-1/2 transform -translate-x-1/2"
          >
            <div className="bg-gray-800 text-white text-xs rounded-lg py-2 px-3 max-w-xs">
              {content}
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-px">
                <div className="w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent 
                           border-t-gray-800" />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};