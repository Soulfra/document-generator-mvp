---
title: "Premium Features Guide"
description: "Complete guide to premium features and subscription benefits for enhanced code analysis workflows"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Premium Features Guide

Upgrade to Premium to unlock powerful features that save time and enhance your code analysis workflow.

## Free vs Premium Comparison

| Feature | Free | Premium |
|---------|------|---------|
| **File Upload Size** | 50 MB max | 500 MB max |
| **Custom Profiles** | 2 profiles | 10 profiles |
| **Batch Processing** | 1 file at a time | Up to 10 files |
| **Documentation Templates** | Basic templates | All advanced templates |
| **Export Formats** | ZIP only | ZIP, PDF, HTML, Markdown |
| **Processing Priority** | Standard queue | Priority processing |

## Premium Features Overview

### 🚀 Large File Uploads
- Upload code archives up to **500 MB** (10x larger than free)
- Perfect for large enterprise codebases and monorepos
- No more splitting archives or excluding important files

### ⚡ Priority Processing  
- Your jobs are processed **faster** than free users
- Jump to the front of the processing queue
- Get results in minutes, not hours during peak times

### 📁 Batch Processing
- Process **up to 10 files simultaneously**
- Massive time savings for multiple project analysis
- Perfect for comparing different versions or modules

### 📄 Advanced Templates
- Access to **all documentation templates**:
  - Test Plans with comprehensive testing strategies
  - User Stories with acceptance criteria
  - Technical Requirements with detailed specifications
- Professional-quality documentation output

### 💼 Custom Profiles
- Create **up to 10 custom analysis profiles**
- Tailor analysis for different projects and frameworks
- Save time with reusable configurations

### 📤 Multiple Export Formats
- **ZIP archives** (same as free)
- **PDF documents** for sharing and presentations
- **HTML websites** for interactive documentation
- **Markdown files** for GitHub and wikis

## How to Upgrade

1. Click the **"Upgrade to Premium"** button when you encounter a limit
2. Choose your billing preference (monthly or annual)
3. Complete payment through our secure Stripe checkout
4. Start using premium features immediately

## Troubleshooting

### "File size exceeded" Error
**Problem:** Your file is larger than your current limit.
**Solution:** 
- For files 50-500 MB: Upgrade to Premium
- For files over 500 MB: Contact support for enterprise options

### "Profile limit reached" Error  
**Problem:** You've created the maximum profiles for your tier.
**Solution:** Upgrade to Premium for 10 profiles, or delete unused profiles

### "Batch processing not available" Error
**Problem:** You're trying to process multiple files on a free account.
**Solution:** Upgrade to Premium for batch processing up to 10 files

### Premium Template Locked
**Problem:** Template shows as locked or requires upgrade.
**Solution:** Upgrade to Premium to access all advanced templates

### Export Format Not Available
**Problem:** PDF, HTML, or Markdown export options are grayed out.
**Solution:** Upgrade to Premium for multiple export formats

## Getting Help

- **Premium Support:** Premium users get priority email support
- **Documentation:** Check our help docs at `/help`
- **Contact:** Email support@finishthisidea.com for assistance

## Billing & Account

- **Billing:** Manage subscription in Account Settings
- **Cancellation:** Cancel anytime, premium features remain until period ends
- **Refunds:** Contact support within 30 days for refund requests

---

*Questions about premium features? Contact our support team at support@finishthisidea.com*