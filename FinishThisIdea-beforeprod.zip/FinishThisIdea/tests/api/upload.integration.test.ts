import { describe, it, expect, beforeAll, afterAll } from '@jest/globals';
import request from 'supertest';
import { app } from '../../src/server';
import { prisma } from '../../src/utils/database';
import { UserTier } from '@prisma/client';

describe('Upload API - Premium Features Integration', () => {
  let freeUser: any;
  let premiumUser: any;
  let freeUserToken: string;
  let premiumUserToken: string;

  beforeAll(async () => {
    // Create test users
    freeUser = await prisma.user.create({
      data: {
        email: 'free-test@example.com',
        username: 'freetester',
        tier: UserTier.FREE,
      },
    });

    premiumUser = await prisma.user.create({
      data: {
        email: 'premium-test@example.com',
        username: 'premiumtester',
        tier: UserTier.PREMIUM,
      },
    });

    // Mock authentication tokens (adjust based on your auth system)
    freeUserToken = 'mock-free-token';
    premiumUserToken = 'mock-premium-token';
  });

  afterAll(async () => {
    // Cleanup test data
    await prisma.user.deleteMany({
      where: {
        id: { in: [freeUser.id, premiumUser.id] },
      },
    });
  });

  describe('POST /api/upload - File Size Restrictions', () => {
    it('should reject large files for free users', async () => {
      // Create a buffer representing a 75MB file
      const largeFileBuffer = Buffer.alloc(75 * 1024 * 1024, 'a');

      const response = await request(app)
        .post('/api/upload')
        .set('Authorization', `Bearer ${freeUserToken}`)
        .attach('file', largeFileBuffer, 'large-file.zip')
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('exceeds limit of 50MB');
      expect(response.body.error).toContain('Upgrade to Premium');
      expect(response.body.code).toBe('FILE_SIZE_EXCEEDED');
    });

    it('should accept large files for premium users', async () => {
      // Create a buffer representing a 75MB file
      const largeFileBuffer = Buffer.alloc(75 * 1024 * 1024, 'a');

      const response = await request(app)
        .post('/api/upload')
        .set('Authorization', `Bearer ${premiumUserToken}`)
        .attach('file', largeFileBuffer, 'large-file.zip')
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data.id).toBeDefined();
      expect(response.body.data.size).toBe(75 * 1024 * 1024);
    });

    it('should accept small files for free users', async () => {
      // Create a buffer representing a 10MB file
      const smallFileBuffer = Buffer.alloc(10 * 1024 * 1024, 'a');

      const response = await request(app)
        .post('/api/upload')
        .set('Authorization', `Bearer ${freeUserToken}`)
        .attach('file', smallFileBuffer, 'small-file.zip')
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data.id).toBeDefined();
      expect(response.body.data.size).toBe(10 * 1024 * 1024);
    });

    it('should include user tier in upload logs', async () => {
      const fileBuffer = Buffer.alloc(1024, 'a');

      const response = await request(app)
        .post('/api/upload')
        .set('Authorization', `Bearer ${freeUserToken}`)
        .attach('file', fileBuffer, 'test-file.zip')
        .expect(201);

      expect(response.body.success).toBe(true);
      // Note: In a real test, you'd verify log output contains userTier
    });
  });

  describe('Authentication Requirements', () => {
    it('should require authentication for uploads', async () => {
      const fileBuffer = Buffer.alloc(1024, 'a');

      const response = await request(app)
        .post('/api/upload')
        .attach('file', fileBuffer, 'test-file.zip')
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('not authenticated');
    });
  });

  describe('Error Response Format', () => {
    it('should return consistent error format for file size violations', async () => {
      const largeFileBuffer = Buffer.alloc(60 * 1024 * 1024, 'a');

      const response = await request(app)
        .post('/api/upload')
        .set('Authorization', `Bearer ${freeUserToken}`)
        .attach('file', largeFileBuffer, 'oversized-file.zip')
        .expect(400);

      expect(response.body).toHaveProperty('success', false);
      expect(response.body).toHaveProperty('error');
      expect(response.body).toHaveProperty('code', 'FILE_SIZE_EXCEEDED');
      expect(response.body.error).toMatch(/\d+MB exceeds limit of \d+MB/);
    });
  });
});