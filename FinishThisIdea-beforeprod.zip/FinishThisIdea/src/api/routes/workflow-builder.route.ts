import express from 'express';
import { asyncHandler } from '../middleware/async-handler';
import { authentication } from '../../middleware/auth.middleware';
import { workflowEngine } from '../../automation/services/workflow-engine.service';
import { logger } from '../../utils/logger';
import * as yaml from 'js-yaml';
import { promises as fs } from 'fs';
import * as path from 'path';

const router = express.Router();

interface WorkflowNode {
  id: string;
  type: 'script' | 'email' | 'slack' | 'github' | 'analytics' | 'notification' | 'delay' | 'discord' | 'teams';
  position: { x: number; y: number };
  data: {
    name: string;
    [key: string]: any;
  };
}

interface WorkflowConnection {
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
}

interface WorkflowBuilderData {
  name: string;
  description: string;
  nodes: WorkflowNode[];
  connections: WorkflowConnection[];
  variables?: Record<string, any>;
  triggers?: string[];
}

/**
 * Get available workflow step types and their schemas
 */
router.get('/step-types', authentication(), asyncHandler(async (req, res) => {
  const stepTypes = [
    {
      type: 'script',
      name: 'Shell Script',
      description: 'Execute a shell command or script',
      icon: '🔧',
      color: '#3b82f6',
      fields: [
        { name: 'command', type: 'text', required: true, placeholder: 'echo "Hello World"' },
        { name: 'timeout', type: 'number', required: false, placeholder: '30000', description: 'Timeout in milliseconds' },
        { name: 'onError', type: 'select', required: false, options: ['continue', 'stop', 'retry'], default: 'stop' },
        { name: 'retries', type: 'number', required: false, placeholder: '0', description: 'Number of retry attempts' }
      ]
    },
    {
      type: 'email',
      name: 'Send Email',
      description: 'Send an email notification',
      icon: '📧',
      color: '#10b981',
      fields: [
        { name: 'to', type: 'text', required: true, placeholder: 'user@example.com' },
        { name: 'subject', type: 'text', required: true, placeholder: 'Email subject' },
        { name: 'message', type: 'textarea', required: true, placeholder: 'Email content...' },
        { name: 'template', type: 'text', required: false, placeholder: 'template-file.html' }
      ]
    },
    {
      type: 'slack',
      name: 'Slack Message',
      description: 'Send a message to Slack',
      icon: '💬',
      color: '#4a154b',
      fields: [
        { name: 'channel', type: 'text', required: true, placeholder: '#general' },
        { name: 'message', type: 'textarea', required: true, placeholder: 'Message content...' },
        { name: 'subject', type: 'text', required: false, placeholder: 'Optional title' },
        { name: 'username', type: 'text', required: false, placeholder: 'Bot name' },
        { name: 'icon_emoji', type: 'text', required: false, placeholder: ':robot_face:' }
      ]
    },
    {
      type: 'github',
      name: 'GitHub Action',
      description: 'Perform GitHub operations',
      icon: '🐙',
      color: '#24292e',
      fields: [
        { name: 'repo', type: 'text', required: true, placeholder: 'owner/repository' },
        { name: 'action', type: 'select', required: true, options: ['create_issue', 'create_pr', 'create_deployment', 'update_deployment_status', 'trigger_workflow', 'add_comment'] },
        { name: 'issue_title', type: 'text', required: false, placeholder: 'Issue or PR title' },
        { name: 'message', type: 'textarea', required: false, placeholder: 'Description or comment...' },
        { name: 'assignee', type: 'text', required: false, placeholder: 'username' }
      ]
    },
    {
      type: 'analytics',
      name: 'Track Event',
      description: 'Track an analytics event',
      icon: '📊',
      color: '#8b5cf6',
      fields: [
        { name: 'event', type: 'text', required: true, placeholder: 'workflow_completed' },
        { name: 'userId', type: 'text', required: false, placeholder: '{{ userId }}' },
        { name: 'properties', type: 'json', required: false, placeholder: '{"key": "value"}' }
      ]
    },
    {
      type: 'notification',
      name: 'Notification',
      description: 'Send a general notification',
      icon: '🔔',
      color: '#f59e0b',
      fields: [
        { name: 'message', type: 'textarea', required: true, placeholder: 'Notification message...' },
        { name: 'type', type: 'select', required: false, options: ['info', 'success', 'warning', 'error'], default: 'info' }
      ]
    },
    {
      type: 'delay',
      name: 'Delay',
      description: 'Wait for a specified time',
      icon: '⏱️',
      color: '#6b7280',
      fields: [
        { name: 'delay', type: 'number', required: true, placeholder: '5000', description: 'Delay in milliseconds' }
      ]
    },
    {
      type: 'discord',
      name: 'Discord Message',
      description: 'Send a message to Discord',
      icon: '🎮',
      color: '#5865f2',
      fields: [
        { name: 'channel', type: 'text', required: true, placeholder: 'general', description: 'Discord channel name' },
        { name: 'message', type: 'textarea', required: true, placeholder: 'Message content...' },
        { name: 'subject', type: 'text', required: false, placeholder: 'Optional title' },
        { name: 'type', type: 'select', required: false, options: ['info', 'success', 'warning', 'error'], default: 'info' },
        { name: 'url', type: 'text', required: false, placeholder: 'Optional URL' }
      ]
    },
    {
      type: 'teams',
      name: 'Teams Message',
      description: 'Send a message to Microsoft Teams',
      icon: '🎯',
      color: '#6264a7',
      fields: [
        { name: 'channel', type: 'text', required: true, placeholder: 'general', description: 'Teams channel name' },
        { name: 'message', type: 'textarea', required: true, placeholder: 'Message content...' },
        { name: 'subject', type: 'text', required: false, placeholder: 'Optional title' },
        { name: 'type', type: 'select', required: false, options: ['info', 'success', 'warning', 'error'], default: 'info' },
        { name: 'url', type: 'text', required: false, placeholder: 'Optional URL' }
      ]
    }
  ];

  res.json({
    success: true,
    data: stepTypes
  });
}));

/**
 * Get list of existing workflows
 */
router.get('/workflows', authentication(), asyncHandler(async (req, res) => {
  try {
    const templates = workflowEngine.getAvailableTemplates();
    
    // Read workflow files to get metadata
    const workflows = await Promise.all(templates.map(async (templateName) => {
      try {
        const workflowPath = path.join(process.cwd(), 'cursor/launch-support-module/workflow-template-library', `${templateName}.yaml`);
        const content = await fs.readFile(workflowPath, 'utf8');
        const workflow = yaml.load(content) as any;
        
        return {
          id: templateName,
          name: workflow.name || templateName,
          description: workflow.description || 'No description',
          steps: workflow.steps?.length || 0,
          created: new Date().toISOString(), // Placeholder
          lastModified: new Date().toISOString() // Placeholder
        };
      } catch (error) {
        return {
          id: templateName,
          name: templateName,
          description: 'Template workflow',
          steps: 0,
          created: new Date().toISOString(),
          lastModified: new Date().toISOString()
        };
      }
    }));

    res.json({
      success: true,
      data: workflows
    });
  } catch (error) {
    logger.error('Failed to get workflows', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'WORKFLOWS_ERROR',
        message: 'Failed to retrieve workflows'
      }
    });
  }
}));

/**
 * Create or update a workflow
 */
router.post('/workflows', authentication(), asyncHandler(async (req, res) => {
  try {
    const { name, description, nodes, connections, variables, triggers }: WorkflowBuilderData = req.body;

    if (!name || !nodes || !Array.isArray(nodes)) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_WORKFLOW',
          message: 'Workflow name and nodes are required'
        }
      });
    }

    // Convert visual workflow to YAML format
    const workflowYaml = convertToWorkflowYaml({
      name,
      description,
      nodes,
      connections,
      variables,
      triggers
    });

    // Save workflow
    const workflowId = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    const workflowPath = path.join(process.cwd(), 'src/automation/workflows/generated', `${workflowId}.yaml`);
    
    // Ensure directory exists
    await fs.mkdir(path.dirname(workflowPath), { recursive: true });
    await fs.writeFile(workflowPath, workflowYaml);

    // Register with workflow engine
    const workflow = yaml.load(workflowYaml) as any;
    workflowEngine.registerTemplate(workflowId, workflow);

    logger.info('Workflow created via builder', { 
      workflowId, 
      name, 
      nodeCount: nodes.length,
      userId: req.user?.id 
    });

    res.json({
      success: true,
      data: {
        id: workflowId,
        name,
        description,
        nodeCount: nodes.length,
        yaml: workflowYaml
      }
    });

  } catch (error) {
    logger.error('Failed to create workflow', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'WORKFLOW_CREATION_ERROR',
        message: 'Failed to create workflow'
      }
    });
  }
}));

/**
 * Get workflow details
 */
router.get('/workflows/:id', authentication(), asyncHandler(async (req, res) => {
  try {
    const { id } = req.params;
    
    const workflowPath = path.join(process.cwd(), 'src/automation/workflows/generated', `${id}.yaml`);
    
    try {
      const content = await fs.readFile(workflowPath, 'utf8');
      const workflow = yaml.load(content) as any;
      
      res.json({
        success: true,
        data: {
          id,
          name: workflow.name,
          description: workflow.description,
          variables: workflow.variables,
          triggers: workflow.triggers,
          steps: workflow.steps,
          yaml: content
        }
      });
    } catch (error) {
      res.status(404).json({
        success: false,
        error: {
          code: 'WORKFLOW_NOT_FOUND',
          message: 'Workflow not found'
        }
      });
    }

  } catch (error) {
    logger.error('Failed to get workflow', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'WORKFLOW_ERROR',
        message: 'Failed to retrieve workflow'
      }
    });
  }
}));

/**
 * Execute a workflow
 */
router.post('/workflows/:id/execute', authentication(), asyncHandler(async (req, res) => {
  try {
    const { id } = req.params;
    const { variables = {} } = req.body;

    const result = await workflowEngine.executeWorkflow(id, {
      variables: {
        ...variables,
        triggered_by: 'workflow_builder',
        user_id: req.user?.id,
      },
      userId: req.user?.id || 'workflow-builder',
      timestamp: new Date(),
    });

    res.json({
      success: true,
      data: result
    });

  } catch (error) {
    logger.error('Failed to execute workflow', { error, workflowId: req.params.id });
    res.status(500).json({
      success: false,
      error: {
        code: 'WORKFLOW_EXECUTION_ERROR',
        message: 'Failed to execute workflow'
      }
    });
  }
}));

/**
 * Delete a workflow
 */
router.delete('/workflows/:id', authentication(), asyncHandler(async (req, res) => {
  try {
    const { id } = req.params;
    
    const workflowPath = path.join(process.cwd(), 'src/automation/workflows/generated', `${id}.yaml`);
    
    try {
      await fs.unlink(workflowPath);
      
      res.json({
        success: true,
        message: 'Workflow deleted successfully'
      });
    } catch (error) {
      res.status(404).json({
        success: false,
        error: {
          code: 'WORKFLOW_NOT_FOUND',
          message: 'Workflow not found'
        }
      });
    }

  } catch (error) {
    logger.error('Failed to delete workflow', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'WORKFLOW_DELETE_ERROR',
        message: 'Failed to delete workflow'
      }
    });
  }
}));

/**
 * Convert visual workflow builder data to YAML format
 */
function convertToWorkflowYaml(data: WorkflowBuilderData): string {
  const { name, description, nodes, connections, variables, triggers } = data;

  // Create execution order based on connections
  const executionOrder = getExecutionOrder(nodes, connections);
  
  // Convert nodes to workflow steps
  const steps = executionOrder.map(nodeId => {
    const node = nodes.find(n => n.id === nodeId);
    if (!node) throw new Error(`Node ${nodeId} not found`);

    const step: any = {
      name: node.data.name || `${node.type} step`,
      type: node.type,
    };

    // Add step-specific properties
    Object.keys(node.data).forEach(key => {
      if (key !== 'name' && node.data[key] !== undefined && node.data[key] !== '') {
        if (key === 'properties' && typeof node.data[key] === 'string') {
          try {
            step[key] = JSON.parse(node.data[key]);
          } catch {
            step[key] = node.data[key];
          }
        } else {
          step[key] = node.data[key];
        }
      }
    });

    return step;
  });

  const workflow = {
    name: name || 'Untitled Workflow',
    description: description || 'Created with workflow builder',
    ...(variables && Object.keys(variables).length > 0 && { variables }),
    ...(triggers && triggers.length > 0 && { triggers }),
    steps
  };

  return yaml.dump(workflow, { lineWidth: -1, noRefs: true });
}

/**
 * Determine execution order from nodes and connections
 */
function getExecutionOrder(nodes: WorkflowNode[], connections: WorkflowConnection[]): string[] {
  const nodeMap = new Map(nodes.map(n => [n.id, n]));
  const incoming = new Map<string, string[]>();
  const outgoing = new Map<string, string[]>();

  // Build adjacency lists
  nodes.forEach(node => {
    incoming.set(node.id, []);
    outgoing.set(node.id, []);
  });

  connections.forEach(conn => {
    incoming.get(conn.target)?.push(conn.source);
    outgoing.get(conn.source)?.push(conn.target);
  });

  // Topological sort to determine execution order
  const visited = new Set<string>();
  const result: string[] = [];

  function visit(nodeId: string) {
    if (visited.has(nodeId)) return;
    visited.add(nodeId);

    const deps = incoming.get(nodeId) || [];
    deps.forEach(visit);
    
    result.push(nodeId);
  }

  // Start with nodes that have no incoming connections
  const startNodes = nodes.filter(node => 
    (incoming.get(node.id) || []).length === 0
  );

  if (startNodes.length === 0 && nodes.length > 0) {
    // If no clear start, use the first node
    visit(nodes[0].id);
  } else {
    startNodes.forEach(node => visit(node.id));
  }

  // Visit any remaining unvisited nodes
  nodes.forEach(node => {
    if (!visited.has(node.id)) {
      visit(node.id);
    }
  });

  return result;
}

export { router as workflowBuilderRouter };