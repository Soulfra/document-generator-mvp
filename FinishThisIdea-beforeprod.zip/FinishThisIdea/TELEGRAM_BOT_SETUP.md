# Telegram Bot Setup Guide

The FinishThisIdea automation bot allows you to control file operations and workflows remotely via Telegram.

## Quick Setup

1. **Create a Telegram Bot:**
   - Message @BotFather on Telegram
   - Send `/newbot` and follow the instructions
   - Save the bot token provided

2. **Configure Environment Variables:**
   ```bash
   # Add to your .env file
   TELEGRAM_BOT_TOKEN=your_bot_token_here
   TELEGRAM_ADMIN_USER_IDS=your_telegram_user_id,another_admin_id
   ```

3. **Get Your Telegram User ID:**
   - Message @userinfobot on Telegram
   - Send any message to get your user ID
   - Add your ID to `TELEGRAM_ADMIN_USER_IDS`

4. **Start the Bot:**
   - The bot will initialize automatically when you start the server
   - Look for "🤖 Automation services initialized" in the logs

## Available Commands

### Basic Commands
- `/start` - Welcome message and bot introduction
- `/help` - Show all available commands
- `/status` - Check system health and status

### File Operations
- `/list [directory]` - List files in current or specified directory
- `/archive <filename>` - Archive a file (moves to .archive folder)
- `/restore <filename>` - Restore the most recent archived version

### Workflow Management
- `/workflows` - List available workflows
- `/execute <workflow-name>` - Execute a specific workflow

### Launch Management
- `/launches` - List recent launches
- `/launch create <name>` - Create a new launch
- `/launch list` - List all launches

### Git Operations
- `/git status` - Show git repository status
- `/git add` - Add all changes to staging
- `/git commit` - Commit staged changes with timestamp
- `/git push` - Push changes to remote repository

### Admin Commands (Admin users only)
- `/logs [lines]` - Get recent log entries (default: 20 lines)
- `/restart` - Restart automation services

## Security Features

- **User Authorization**: Only configured admin users can use the bot
- **Path Security**: File operations are restricted to the project directory
- **Command Validation**: All inputs are sanitized and validated
- **Admin-Only Commands**: Sensitive operations require admin privileges

## Configuration

The bot configuration is in `src/automation/config/automation-config.json`:

```json
{
  "features": {
    "telegramBot": true
  },
  "telegramBot": {
    "enabled": true,
    "commandPrefix": "/",
    "adminCommands": ["logs", "restart"],
    "maxMessageLength": 4096,
    "rateLimiting": {
      "maxCommandsPerMinute": 10,
      "cooldownSeconds": 2
    }
  }
}
```

## Troubleshooting

### Bot Not Starting
- Check that `TELEGRAM_BOT_TOKEN` is set in your environment
- Verify the token is correct from @BotFather
- Ensure `telegramBot` feature is enabled in config

### Unauthorized Access
- Add your Telegram user ID to `TELEGRAM_ADMIN_USER_IDS`
- Restart the server after adding new user IDs
- Check logs for authorization attempts

### Commands Not Working
- Ensure you're messaging the bot directly (not in a group)
- Check that the command syntax is correct
- Verify you have admin privileges for admin commands

## Example Usage

```
You: /status
Bot: 📊 System Status
     🔄 Queue Health: cleanup: 0 waiting, 0 active, 0 failed
     🚀 Launches: Total: 2, Active: 0
     ⚡ Automation: Workflows: 5 available, Bot: ✅ Online

You: /list src
Bot: 📁 Files in src:
     📁 api
     📁 automation
     📁 services
     📄 server.ts

You: /git status
Bot: 📊 Git Status:
     Branch: main
     Working tree clean ✅
```

## File Archive System

The bot includes a file archiving system:

- **Archive Location**: `.archive/` directory in project root
- **Naming Convention**: `filename-YYYY-MM-DDTHH-mm-ss.ext`
- **Restore Logic**: Always restores the most recent archived version
- **Cleanup**: Automatic cleanup of files older than 30 days

## Integration with Existing Services

The bot integrates with all existing FinishThisIdea services:

- **Workflow Engine**: Execute any registered workflow
- **Launch Playbook**: Control launch processes
- **Analytics**: Track bot usage and file operations
- **Git Operations**: Full git integration for remote commits
- **Health Monitoring**: Real-time system status

---

*This bot was implemented as part of the automation-bot-module from the cursor folder.*