/**
 * API Gateway Service
 * Handles request routing and project context management
 */

import { Request, Response, NextFunction } from 'express';
import { Project } from '../models/project.model';
import { ProjectMember } from '../models/project-member.model';
import { RateLimiterMemory, RateLimiterRes } from 'rate-limiter-flexible';
import { logger } from '../utils/logger';
import { createHash } from 'crypto';

export class GatewayService {
  private static instance: GatewayService;
  private projectCache: Map<string, Project> = new Map();
  private rateLimiters: Map<string, RateLimiterMemory> = new Map();
  
  private constructor() {
    // Initialize rate limiters for different tiers
    this.initializeRateLimiters();
    
    // Clear cache periodically
    setInterval(() => {
      this.projectCache.clear();
    }, 5 * 60 * 1000); // 5 minutes
  }
  
  static getInstance(): GatewayService {
    if (!GatewayService.instance) {
      GatewayService.instance = new GatewayService();
    }
    return GatewayService.instance;
  }
  
  /**
   * Initialize rate limiters for different project plans
   */
  private initializeRateLimiters(): void {
    // Free tier: 100 requests per minute
    this.rateLimiters.set('free', new RateLimiterMemory({
      points: 100,
      duration: 60,
      blockDuration: 60
    }));
    
    // Pro tier: 1000 requests per minute
    this.rateLimiters.set('pro', new RateLimiterMemory({
      points: 1000,
      duration: 60,
      blockDuration: 30
    }));
    
    // Enterprise tier: 10000 requests per minute
    this.rateLimiters.set('enterprise', new RateLimiterMemory({
      points: 10000,
      duration: 60,
      blockDuration: 10
    }));
    
    // Custom tier: No rate limiting
    this.rateLimiters.set('custom', new RateLimiterMemory({
      points: 999999,
      duration: 60
    }));
  }
  
  /**
   * Apply project-based rate limiting
   */
  async applyRateLimit(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      if (!req.project) {
        return next();
      }
      
      const rateLimiter = this.rateLimiters.get(req.project.plan) || this.rateLimiters.get('free')!;
      const key = `${req.project.id}:${req.ip}`;
      
      try {
        await rateLimiter.consume(key);
        next();
      } catch (rateLimiterRes) {
        const secs = Math.round((rateLimiterRes as RateLimiterRes).msBeforeNext / 1000) || 1;
        res.set('Retry-After', String(secs));
        res.set('X-RateLimit-Limit', String(rateLimiter.points));
        res.set('X-RateLimit-Remaining', String((rateLimiterRes as RateLimiterRes).remainingPoints || 0));
        res.set('X-RateLimit-Reset', new Date(Date.now() + (rateLimiterRes as RateLimiterRes).msBeforeNext).toISOString());
        
        res.status(429).json({
          success: false,
          error: {
            message: 'Rate limit exceeded',
            code: 'RATE_LIMIT_EXCEEDED',
            retryAfter: secs
          }
        });
      }
    } catch (error) {
      logger.error('Rate limiting error:', error);
      next(); // Continue on error
    }
  }
  
  /**
   * Route request to project-specific handler
   */
  async routeRequest(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      // Add project context to all responses
      if (req.project) {
        res.set('X-Project-ID', req.project.id);
        res.set('X-Project-Plan', req.project.plan);
      }
      
      // Log request for analytics
      this.logRequest(req);
      
      next();
    } catch (error) {
      logger.error('Gateway routing error:', error);
      next(error);
    }
  }
  
  /**
   * Get or cache project
   */
  async getProject(identifier: string): Promise<Project | null> {
    // Check cache first
    if (this.projectCache.has(identifier)) {
      return this.projectCache.get(identifier)!;
    }
    
    // Try to find by ID or slug
    const project = await Project.findOne({
      where: {
        [Op.or]: [
          { id: identifier },
          { slug: identifier }
        ]
      }
    });
    
    if (project) {
      this.projectCache.set(identifier, project);
    }
    
    return project;
  }
  
  /**
   * Validate API key and extract project context
   */
  async validateApiKey(apiKey: string): Promise<{ project: Project; member?: ProjectMember } | null> {
    try {
      // API key format: proj_<projectId>_<hash>
      const parts = apiKey.split('_');
      if (parts.length !== 3 || parts[0] !== 'proj') {
        return null;
      }
      
      const projectId = parts[1];
      const project = await this.getProject(projectId);
      
      if (!project) {
        return null;
      }
      
      // Validate hash
      const expectedKey = project.getApiKey();
      if (apiKey !== expectedKey) {
        return null;
      }
      
      return { project };
    } catch (error) {
      logger.error('API key validation error:', error);
      return null;
    }
  }
  
  /**
   * Log request for analytics
   */
  private logRequest(req: Request): void {
    if (!req.project) return;
    
    // Log to analytics service
    const logData = {
      projectId: req.project.id,
      projectPlan: req.project.plan,
      method: req.method,
      path: req.path,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      timestamp: new Date(),
      userId: req.user?.id,
      statusCode: req.res?.statusCode
    };
    
    // Send to analytics asynchronously
    process.nextTick(() => {
      logger.info('API request', logData);
      // Could also send to external analytics service
    });
  }
  
  /**
   * Get project usage statistics
   */
  async getProjectUsage(projectId: string): Promise<any> {
    // This would query various models to get usage stats
    const [jobCount, uploadCount, userCount] = await Promise.all([
      Job.count({ where: { projectId } }),
      Upload.count({ where: { projectId } }),
      ProjectMember.count({ where: { projectId, isActive: true } })
    ]);
    
    return {
      jobs: jobCount,
      uploads: uploadCount,
      members: userCount,
      // Add more metrics as needed
    };
  }
  
  /**
   * Check if project has exceeded usage limits
   */
  async checkUsageLimits(project: Project): Promise<{ allowed: boolean; reason?: string }> {
    const limits = project.settings.limits || {};
    
    // Check monthly job limit
    if (limits.maxJobsPerMonth) {
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);
      
      const jobCount = await Job.count({
        where: {
          projectId: project.id,
          createdAt: { [Op.gte]: startOfMonth }
        }
      });
      
      if (jobCount >= limits.maxJobsPerMonth) {
        return {
          allowed: false,
          reason: `Monthly job limit (${limits.maxJobsPerMonth}) exceeded`
        };
      }
    }
    
    // Check concurrent jobs
    if (limits.maxConcurrentJobs) {
      const activeJobs = await Job.count({
        where: {
          projectId: project.id,
          status: ['pending', 'processing']
        }
      });
      
      if (activeJobs >= limits.maxConcurrentJobs) {
        return {
          allowed: false,
          reason: `Concurrent job limit (${limits.maxConcurrentJobs}) reached`
        };
      }
    }
    
    return { allowed: true };
  }
}

// Export singleton instance
export const gatewayService = GatewayService.getInstance();