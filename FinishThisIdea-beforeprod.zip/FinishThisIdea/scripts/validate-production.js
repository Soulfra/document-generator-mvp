#!/usr/bin/env node

/**
 * Production Environment Validation Script
 * 
 * This script validates that all required environment variables and services
 * are properly configured for production deployment.
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// ANSI color codes for pretty output
const colors = {
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  reset: '\x1b[0m',
  bold: '\x1b[1m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function logSection(title) {
  log(`\n${colors.bold}${colors.blue}=== ${title} ===${colors.reset}`);
}

function logSuccess(message) {
  log(`✅ ${message}`, 'green');
}

function logWarning(message) {
  log(`⚠️  ${message}`, 'yellow');
}

function logError(message) {
  log(`❌ ${message}`, 'red');
}

function logInfo(message) {
  log(`ℹ️  ${message}`, 'cyan');
}

class ProductionValidator {
  constructor() {
    this.errors = [];
    this.warnings = [];
    this.checks = {
      environment: [],
      database: [],
      storage: [],
      payments: [],
      analytics: [],
      integrations: [],
      security: []
    };
  }

  // Required environment variables for production
  getRequiredEnvVars() {
    return {
      core: [
        'NODE_ENV',
        'PORT',
        'DATABASE_URL',
        'REDIS_URL',
        'JWT_SECRET',
        'ENCRYPTION_KEY'
      ],
      storage: [
        'AWS_REGION',
        'AWS_ACCESS_KEY_ID', 
        'AWS_SECRET_ACCESS_KEY',
        'S3_BUCKET_NAME'
      ],
      payments: [
        'STRIPE_SECRET_KEY',
        'STRIPE_WEBHOOK_SECRET',
        'STRIPE_PUBLISHABLE_KEY'
      ],
      ai: [
        'ANTHROPIC_API_KEY'
      ],
      optional: [
        'MIXPANEL_PROJECT_TOKEN',
        'GA4_MEASUREMENT_ID',
        'GA4_API_SECRET',
        'SLACK_BOT_TOKEN',
        'GITHUB_TOKEN',
        'TELEGRAM_BOT_TOKEN',
        'SENTRY_DSN'
      ]
    };
  }

  validateEnvironmentVariables() {
    logSection('Environment Variables');
    
    const requiredVars = this.getRequiredEnvVars();
    let missingRequired = [];
    let missingOptional = [];

    // Check core required variables
    [...requiredVars.core, ...requiredVars.storage, ...requiredVars.payments, ...requiredVars.ai].forEach(varName => {
      if (!process.env[varName]) {
        missingRequired.push(varName);
        logError(`Missing required: ${varName}`);
      } else {
        logSuccess(`Found: ${varName}`);
      }
    });

    // Check optional variables
    requiredVars.optional.forEach(varName => {
      if (!process.env[varName]) {
        missingOptional.push(varName);
        logWarning(`Missing optional: ${varName}`);
      } else {
        logSuccess(`Found: ${varName}`);
      }
    });

    // Validate NODE_ENV
    if (process.env.NODE_ENV !== 'production') {
      logWarning(`NODE_ENV is '${process.env.NODE_ENV}', should be 'production'`);
    }

    // Validate secret lengths
    if (process.env.JWT_SECRET && process.env.JWT_SECRET.length < 32) {
      this.errors.push('JWT_SECRET should be at least 32 characters long');
      logError('JWT_SECRET is too short (minimum 32 characters)');
    }

    if (process.env.ENCRYPTION_KEY && process.env.ENCRYPTION_KEY.length !== 32) {
      this.errors.push('ENCRYPTION_KEY must be exactly 32 characters long');
      logError('ENCRYPTION_KEY must be exactly 32 characters');
    }

    this.errors.push(...missingRequired.map(v => `Missing required environment variable: ${v}`));
    this.warnings.push(...missingOptional.map(v => `Missing optional environment variable: ${v}`));
  }

  async validateDatabase() {
    logSection('Database Connectivity');
    
    try {
      // Test database connection
      const { PrismaClient } = require('@prisma/client');
      const prisma = new PrismaClient();
      
      await prisma.$connect();
      logSuccess('Database connection successful');
      
      // Check if migrations are up to date
      try {
        await prisma.$queryRaw`SELECT 1`;
        logSuccess('Database queries working');
      } catch (error) {
        logError(`Database query failed: ${error.message}`);
        this.errors.push(`Database not properly configured: ${error.message}`);
      }
      
      await prisma.$disconnect();
    } catch (error) {
      logError(`Database connection failed: ${error.message}`);
      this.errors.push(`Database connection failed: ${error.message}`);
    }
  }

  async validateRedis() {
    logSection('Redis Connectivity');
    
    try {
      // Simple Redis connection test
      const redis = require('redis');
      const client = redis.createClient({ url: process.env.REDIS_URL });
      
      await client.connect();
      await client.ping();
      logSuccess('Redis connection successful');
      
      await client.quit();
    } catch (error) {
      logError(`Redis connection failed: ${error.message}`);
      this.errors.push(`Redis connection failed: ${error.message}`);
    }
  }

  async validateStorage() {
    logSection('S3 Storage');
    
    if (!process.env.AWS_ACCESS_KEY_ID || !process.env.AWS_SECRET_ACCESS_KEY) {
      logError('AWS credentials not configured');
      this.errors.push('AWS credentials missing');
      return;
    }

    try {
      const AWS = require('aws-sdk');
      const s3 = new AWS.S3({
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
        region: process.env.AWS_REGION || 'us-east-1'
      });

      // Test bucket access
      await s3.headBucket({ Bucket: process.env.S3_BUCKET_NAME }).promise();
      logSuccess('S3 bucket access confirmed');
    } catch (error) {
      logError(`S3 access failed: ${error.message}`);
      this.errors.push(`S3 storage not accessible: ${error.message}`);
    }
  }

  async validateStripe() {
    logSection('Stripe Payment Processing');
    
    if (!process.env.STRIPE_SECRET_KEY || !process.env.STRIPE_WEBHOOK_SECRET) {
      logError('Stripe credentials not configured');
      this.errors.push('Stripe credentials missing');
      return;
    }

    try {
      const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
      
      // Test Stripe connection
      await stripe.account.retrieve();
      logSuccess('Stripe connection successful');
      
      // Check if we're in live mode
      if (process.env.STRIPE_SECRET_KEY.startsWith('sk_test_')) {
        logWarning('Using Stripe test keys in production');
        this.warnings.push('Using Stripe test keys in production environment');
      } else {
        logSuccess('Using Stripe live keys');
      }
    } catch (error) {
      logError(`Stripe validation failed: ${error.message}`);
      this.errors.push(`Stripe not properly configured: ${error.message}`);
    }
  }

  async validateAnalytics() {
    logSection('Analytics Integration');
    
    // Check Mixpanel
    if (process.env.MIXPANEL_PROJECT_TOKEN) {
      logSuccess('Mixpanel token configured');
    } else {
      logWarning('Mixpanel not configured');
    }
    
    // Check GA4
    if (process.env.GA4_MEASUREMENT_ID && process.env.GA4_API_SECRET) {
      logSuccess('Google Analytics 4 configured');
    } else {
      logWarning('Google Analytics 4 not fully configured');
    }
  }

  async validateIntegrations() {
    logSection('External Integrations');
    
    // Slack
    if (process.env.SLACK_BOT_TOKEN) {
      logSuccess('Slack integration configured');
      try {
        const { WebClient } = require('@slack/web-api');
        const slack = new WebClient(process.env.SLACK_BOT_TOKEN);
        await slack.auth.test();
        logSuccess('Slack connection verified');
      } catch (error) {
        logWarning(`Slack connection failed: ${error.message}`);
      }
    } else {
      logInfo('Slack integration not configured (optional)');
    }
    
    // GitHub
    if (process.env.GITHUB_TOKEN) {
      logSuccess('GitHub integration configured');
    } else {
      logInfo('GitHub integration not configured (optional)');
    }
    
    // Telegram
    if (process.env.TELEGRAM_BOT_TOKEN) {
      logSuccess('Telegram bot configured');
    } else {
      logInfo('Telegram bot not configured (optional)');
    }
  }

  validateSecurity() {
    logSection('Security Configuration');
    
    // Check if sensitive files exist
    const sensitiveFiles = ['.env', '.env.local', '.env.production'];
    sensitiveFiles.forEach(file => {
      if (fs.existsSync(file)) {
        logWarning(`Sensitive file ${file} exists - ensure it's not committed to git`);
      }
    });
    
    // Check gitignore
    if (fs.existsSync('.gitignore')) {
      const gitignore = fs.readFileSync('.gitignore', 'utf8');
      if (!gitignore.includes('.env')) {
        logError('.env files not ignored in .gitignore');
        this.errors.push('Environment files not properly ignored in git');
      } else {
        logSuccess('Environment files properly ignored');
      }
    }
    
    // Check for development dependencies in production
    if (process.env.NODE_ENV === 'production') {
      try {
        const packageLock = JSON.parse(fs.readFileSync('package-lock.json', 'utf8'));
        if (packageLock.packages?.['node_modules/nodemon']) {
          logWarning('Development dependencies may be installed in production');
        } else {
          logSuccess('Production dependencies only');
        }
      } catch (error) {
        logInfo('Could not check dependency status');
      }
    }
  }

  async validateBuild() {
    logSection('Build Validation');
    
    try {
      // Check if TypeScript builds without errors
      execSync('npx tsc --noEmit', { stdio: 'pipe' });
      logSuccess('TypeScript compilation successful');
    } catch (error) {
      logError('TypeScript compilation failed');
      this.errors.push('TypeScript compilation errors');
    }
    
    // Check if build directory exists and has files
    if (fs.existsSync('dist') && fs.readdirSync('dist').length > 0) {
      logSuccess('Build output exists');
    } else {
      logWarning('No build output found - run npm run build');
    }
  }

  printSummary() {
    logSection('Validation Summary');
    
    if (this.errors.length === 0 && this.warnings.length === 0) {
      log('\n🎉 All checks passed! Your application is ready for production deployment.\n', 'green');
    } else {
      if (this.errors.length > 0) {
        log(`\n❌ ${this.errors.length} critical issues found:`, 'red');
        this.errors.forEach(error => log(`   • ${error}`, 'red'));
      }
      
      if (this.warnings.length > 0) {
        log(`\n⚠️  ${this.warnings.length} warnings:`, 'yellow');
        this.warnings.forEach(warning => log(`   • ${warning}`, 'yellow'));
      }
      
      if (this.errors.length > 0) {
        log('\n🚫 Please fix critical issues before deploying to production.', 'red');
        process.exit(1);
      } else {
        log('\n✅ No critical issues found. Warnings should be addressed when possible.', 'green');
      }
    }
  }

  async run() {
    log(`${colors.bold}${colors.cyan}
╔═══════════════════════════════════════════╗
║        Production Readiness Validator     ║
║            FinishThisIdea                 ║
╚═══════════════════════════════════════════╝
${colors.reset}`);

    logInfo('Starting production environment validation...\n');

    try {
      this.validateEnvironmentVariables();
      await this.validateDatabase();
      await this.validateRedis();
      await this.validateStorage();
      await this.validateStripe();
      await this.validateAnalytics();
      await this.validateIntegrations();
      this.validateSecurity();
      await this.validateBuild();
    } catch (error) {
      logError(`Validation failed: ${error.message}`);
      this.errors.push(`Validation error: ${error.message}`);
    }

    this.printSummary();
  }
}

// Run validation if called directly
if (require.main === module) {
  const validator = new ProductionValidator();
  validator.run().catch(error => {
    console.error('Validation script failed:', error);
    process.exit(1);
  });
}

module.exports = ProductionValidator;