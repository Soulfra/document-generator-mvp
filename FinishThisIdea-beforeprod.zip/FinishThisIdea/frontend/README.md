# Document Generator Frontend

Modern React frontend for the AI-powered Document Generator service, built with TypeScript, Vite, and Tailwind CSS.

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 🛠️ Development

### Prerequisites
- Node.js 18+
- Backend API running on port 3001

### Development Server
```bash
npm run dev
```
- Frontend: http://localhost:3000
- API proxy: `/api/*` → `http://localhost:3001/api/*`

### Available Scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | Start development server with hot reload |
| `npm run build` | Build for production |
| `npm run preview` | Preview production build locally |
| `npm run type-check` | Run TypeScript type checking |
| `npm run lint` | Run ESLint with auto-fix |

## 🏗️ Architecture

### Tech Stack
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite 5 (fast builds, HMR)
- **Styling**: Tailwind CSS 3 (utility-first)
- **State Management**: Zustand (lightweight)
- **Data Fetching**: React Query (caching, sync)
- **Routing**: React Router DOM 6
- **Animations**: Framer Motion
- **Icons**: Lucide React

### Project Structure
```
frontend/src/
├── components/          # Reusable UI components
│   ├── ui/             # Basic UI elements (buttons, inputs)
│   ├── layout/         # Layout components (header, sidebar)
│   └── features/       # Feature-specific components
├── pages/              # Page components and routing
├── hooks/              # Custom React hooks
├── services/           # API client and external services
├── stores/             # Zustand store definitions
├── types/              # TypeScript type definitions
├── utils/              # Utility functions
└── styles/             # Global styles and Tailwind config
```

## 🎨 UI/UX Design

### Design System
- **Colors**: Dark theme with purple/blue gradients
- **Typography**: Inter font family
- **Components**: Glassmorphism design language
- **Animations**: Smooth micro-interactions
- **Responsive**: Mobile-first design

### Key Features
- **Progressive Web App (PWA)** - Installable, offline-capable
- **Real-time Updates** - WebSocket integration for job status
- **File Upload** - Drag & drop with progress indicators
- **Payment Integration** - Stripe checkout and billing
- **Documentation Viewer** - Rich preview of generated docs

## 🔌 API Integration

### Backend Communication
```typescript
// API client configuration
const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
});

// Example API calls
await api.post('/upload', formData);
await api.get('/jobs/:id/status');
await api.post('/payment/checkout');
```

### Real-time Features
```typescript
// WebSocket connection for job updates
const socket = io(BACKEND_URL);
socket.on('job:progress', (data) => {
  updateJobProgress(data);
});
```

## 🧪 Testing

### Test Setup
- **Framework**: Vitest (Vite-native testing)
- **Utils**: React Testing Library
- **E2E**: Playwright (future implementation)

```bash
# Run tests
npm run test

# Watch mode
npm run test:watch

# Coverage report
npm run test:coverage
```

### Testing Guidelines
- Test user interactions, not implementation details
- Use semantic queries (getByRole, getByLabelText)
- Mock API calls and external dependencies
- Test accessibility and keyboard navigation

## 📱 Progressive Web App

### PWA Features
- **Service Worker**: Caching and offline functionality
- **App Manifest**: Install prompts and app metadata
- **Background Sync**: Queue actions when offline
- **Push Notifications**: Job completion alerts (future)

### Installation
Users can install the app directly from the browser:
- Chrome: Address bar install button
- Safari: Share → Add to Home Screen
- Edge: App available in Microsoft Store

## 🎯 State Management

### Zustand Stores
```typescript
// Job management store
const useJobStore = create((set) => ({
  jobs: [],
  currentJob: null,
  addJob: (job) => set((state) => ({ 
    jobs: [...state.jobs, job] 
  })),
  updateJob: (id, updates) => set((state) => ({
    jobs: state.jobs.map(job => 
      job.id === id ? { ...job, ...updates } : job
    )
  })),
}));

// Usage in components
const { jobs, addJob } = useJobStore();
```

### React Query Integration
```typescript
// Data fetching with caching
const { data, isLoading, error } = useQuery({
  queryKey: ['job', jobId],
  queryFn: () => api.get(`/jobs/${jobId}`),
  refetchInterval: 5000, // Poll for updates
});
```

## 🎨 Styling Guidelines

### Tailwind CSS
```tsx
// Component styling example
const Button = ({ variant = 'primary', children }) => (
  <button className={`
    px-6 py-3 font-semibold rounded-lg
    transform transition-all duration-200
    hover:scale-105 active:scale-95
    ${variant === 'primary' 
      ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white'
      : 'bg-white/10 backdrop-blur-sm border border-white/20'
    }
  `}>
    {children}
  </button>
);
```

### Custom CSS Classes
```css
/* Glassmorphism utility */
.glass-card {
  @apply bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl;
}

/* Gradient text */
.gradient-text {
  @apply bg-gradient-to-r from-primary-400 to-primary-600 bg-clip-text text-transparent;
}
```

## 🔧 Configuration

### Environment Variables
```bash
# .env.local
VITE_API_URL=http://localhost:3001
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_...
VITE_ENABLE_DEV_TOOLS=true
```

### Vite Configuration
```typescript
// vite.config.ts highlights
export default defineConfig({
  server: {
    proxy: {
      '/api': 'http://localhost:3001'
    }
  },
  build: {
    target: 'es2020',
    sourcemap: true
  }
});
```

## 🚀 Deployment

### Build Process
```bash
# Type check
npm run type-check

# Build for production
npm run build

# Output: dist/ directory
```

### Static Hosting
The frontend builds to static files compatible with:
- Vercel (recommended)
- Netlify
- AWS S3 + CloudFront
- GitHub Pages

### Production Checklist
- [ ] Environment variables configured
- [ ] API endpoints point to production backend
- [ ] Stripe keys updated for production
- [ ] PWA manifest updated with production URLs
- [ ] Analytics tracking enabled
- [ ] Error monitoring configured (Sentry)

## 🐛 Troubleshooting

### Common Issues

**Build Errors**
```bash
# Clear dependencies and reinstall
rm -rf node_modules package-lock.json
npm install
```

**Type Errors**
```bash
# Regenerate type definitions
npm run type-check
```

**CSS Not Loading**
```bash
# Restart dev server
npm run dev
```

**API Connection Issues**
- Verify backend is running on port 3001
- Check proxy configuration in vite.config.ts
- Ensure CORS is properly configured on backend

### Performance Tips
- Use React.memo() for expensive components
- Implement virtual scrolling for large lists
- Optimize images with next-gen formats
- Use code splitting for route-based chunks

## 📚 Learn More

- [React Documentation](https://react.dev/)
- [Vite Guide](https://vitejs.dev/guide/)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [Zustand State Management](https://github.com/pmndrs/zustand)
- [React Query](https://tanstack.com/query/latest)

## 🤝 Contributing

See [CONTRIBUTING.md](../CONTRIBUTING.md) for detailed contribution guidelines.

### Frontend-Specific Guidelines
- Follow React best practices (hooks, functional components)
- Use TypeScript strictly (no `any` types)
- Write accessible components (ARIA labels, semantic HTML)
- Test user workflows, not implementation details
- Optimize for performance and bundle size

---

Built with ❤️ using modern web technologies