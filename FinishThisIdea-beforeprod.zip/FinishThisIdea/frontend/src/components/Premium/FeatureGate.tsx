import React from 'react';
import { Lock, Crown } from 'lucide-react';
import { usePremiumFeatures } from '../../hooks/usePremiumFeatures';

interface FeatureGateProps {
  feature: string;
  children: React.ReactNode;
  fallback?: React.ReactNode;
  showLockIcon?: boolean;
  className?: string;
}

export const FeatureGate: React.FC<FeatureGateProps> = ({
  feature,
  children,
  fallback,
  showLockIcon = true,
  className = '',
}) => {
  const { checkFeature } = usePremiumFeatures();
  const featureCheck = checkFeature(feature);

  if (featureCheck.isAllowed) {
    return <>{children}</>;
  }

  if (fallback) {
    return <>{fallback}</>;
  }

  return (
    <div className={`relative ${className}`}>
      <div className="relative">
        {/* Blurred/disabled version */}
        <div className="opacity-50 pointer-events-none select-none">
          {children}
        </div>
        
        {/* Lock overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-75 backdrop-blur-[1px]">
          <button
            onClick={featureCheck.showPaywall}
            className="flex items-center space-x-2 bg-amber-600 hover:bg-amber-700 
                     text-white px-4 py-2 rounded-lg shadow-sm transition-colors"
          >
            {showLockIcon && <Lock className="w-4 h-4" />}
            <span className="text-sm font-medium">
              Upgrade for {featureCheck.featureName}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

interface PremiumBadgeProps {
  className?: string;
}

export const PremiumBadge: React.FC<PremiumBadgeProps> = ({ className = '' }) => {
  return (
    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium 
                    bg-amber-100 text-amber-800 ${className}`}>
      <Crown className="w-3 h-3 mr-1" />
      Premium
    </span>
  );
};

interface PremiumTooltipProps {
  feature: string;
  children: React.ReactNode;
  position?: 'top' | 'bottom' | 'left' | 'right';
}

export const PremiumTooltip: React.FC<PremiumTooltipProps> = ({
  feature,
  children,
  position = 'top',
}) => {
  const { checkFeature } = usePremiumFeatures();
  const featureCheck = checkFeature(feature);

  if (featureCheck.isAllowed) {
    return <>{children}</>;
  }

  const positionClasses = {
    top: 'bottom-full left-1/2 transform -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 transform -translate-x-1/2 mt-2',
    left: 'right-full top-1/2 transform -translate-y-1/2 mr-2',
    right: 'left-full top-1/2 transform -translate-y-1/2 ml-2',
  };

  return (
    <div className="relative group">
      {children}
      
      {/* Tooltip */}
      <div className={`absolute ${positionClasses[position]} opacity-0 group-hover:opacity-100
                     transition-opacity pointer-events-none z-50`}>
        <div className="bg-gray-900 text-white text-xs rounded py-2 px-3 whitespace-nowrap">
          <div className="flex items-center space-x-1">
            <Lock className="w-3 h-3" />
            <span>{featureCheck.featureName} requires Premium</span>
          </div>
          
          {/* Arrow */}
          <div className={`absolute w-2 h-2 bg-gray-900 transform rotate-45 ${
            position === 'top' ? 'top-full left-1/2 -translate-x-1/2 -mt-1' :
            position === 'bottom' ? 'bottom-full left-1/2 -translate-x-1/2 -mb-1' :
            position === 'left' ? 'left-full top-1/2 -translate-y-1/2 -ml-1' :
            'right-full top-1/2 -translate-y-1/2 -mr-1'
          }`} />
        </div>
      </div>
    </div>
  );
};