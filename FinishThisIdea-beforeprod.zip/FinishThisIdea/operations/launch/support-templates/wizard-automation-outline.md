# Wizard Automation Outline

This document outlines how to automate the launch/integration wizard for FinishThisIdea, including architecture, steps, and integration points.

---

## 1. Architecture
- **Core:** Node.js/TypeScript backend (CLI or web server)
- **UI:** React (web) or Inquirer.js (CLI)
- **Templates:** Project templates (code, docs, config) + YAML workflow templates
- **Automation Engine:** Reads YAML, executes steps (email, Slack, GitHub, scripts)

## 2. Steps
1. User selects template and enters project details
2. Wizard loads template files and workflow YAMLs
3. Wizard prompts for required config (API keys, emails, etc.)
4. Wizard generates project files and config
5. Wizard executes automation steps (onboarding, deployment, notifications)
6. Wizard outputs summary and next steps

## 3. Integration Points
- **Email:** SMTP or API (SendGrid, SES)
- **Slack:** Web API for messages/alerts
- **GitHub:** REST API for repo setup, issues, assignments
- **Deployment:** Shell scripts, CI/CD triggers
- **Docs:** Auto-generate onboarding and support docs

## 4. Extensibility
- Add new step types by extending the automation engine
- Support for plugin system (custom steps, integrations)
- UI for mapping workflow YAMLs to project actions

---

*Update this outline as the wizard automation evolves.* 