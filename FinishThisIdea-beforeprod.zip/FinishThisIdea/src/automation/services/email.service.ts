import nodemailer from 'nodemailer';
import { readFileSync } from 'fs';
import { join } from 'path';
import { logger } from '../../utils/logger';
import automationConfig from '../config/automation-config.json';

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

interface EmailTemplateData {
  [key: string]: any;
}

export class EmailService {
  private transporter: nodemailer.Transporter | null = null;
  private isEnabled: boolean;
  private templates: Map<string, string> = new Map();

  constructor() {
    this.isEnabled = automationConfig.email.enabled;
    if (this.isEnabled) {
      this.initializeTransporter();
      this.loadTemplates();
    }
  }

  private initializeTransporter(): void {
    try {
      this.transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: process.env.SMTP_SECURE === 'true',
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });

      // Verify connection
      this.transporter.verify((error) => {
        if (error) {
          logger.error('Email service connection failed', { error });
          this.isEnabled = false;
        } else {
          logger.info('Email service connected successfully');
        }
      });
    } catch (error) {
      logger.error('Failed to initialize email service', { error });
      this.isEnabled = false;
    }
  }

  private loadTemplates(): void {
    // Templates will be loaded from files in the future
    // For now, using inline templates
    this.templates.set('welcome', this.getWelcomeTemplate());
    this.templates.set('jobComplete', this.getJobCompleteTemplate());
    this.templates.set('paymentSuccess', this.getPaymentSuccessTemplate());
  }

  private getWelcomeTemplate(): string {
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #6366f1; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background-color: #f8f9fa; }
        .button { display: inline-block; padding: 12px 24px; background-color: #6366f1; color: white; text-decoration: none; border-radius: 4px; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Welcome to FinishThisIdea!</h1>
        </div>
        <div class="content">
          <h2>Hi {{name}},</h2>
          <p>We're excited to have you on board! FinishThisIdea helps you transform your codebase into professional documentation instantly.</p>
          <p>Here's how to get started:</p>
          <ol>
            <li>Upload your code (ZIP file or individual files)</li>
            <li>Select your context profile (React, Python, etc.)</li>
            <li>Choose documentation templates</li>
            <li>Get your professional docs in seconds!</li>
          </ol>
          <p style="text-align: center; margin: 30px 0;">
            <a href="{{appUrl}}/upload" class="button">Start Your First Project</a>
          </p>
          <p>Need help? Check out our <a href="{{appUrl}}/docs">documentation</a> or reply to this email.</p>
          <p>Happy documenting!</p>
          <p>The FinishThisIdea Team</p>
        </div>
        <div class="footer">
          <p>© 2024 FinishThisIdea. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
    `;
  }

  private getJobCompleteTemplate(): string {
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #10b981; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background-color: #f8f9fa; }
        .button { display: inline-block; padding: 12px 24px; background-color: #10b981; color: white; text-decoration: none; border-radius: 4px; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Your Documentation is Ready!</h1>
        </div>
        <div class="content">
          <h2>Great news, {{name}}!</h2>
          <p>Your documentation has been generated successfully.</p>
          <p><strong>Project Details:</strong></p>
          <ul>
            <li>Job ID: {{jobId}}</li>
            <li>Templates Generated: {{templateCount}}</li>
            <li>Processing Time: {{processingTime}}</li>
          </ul>
          <p style="text-align: center; margin: 30px 0;">
            <a href="{{downloadUrl}}" class="button">Download Your Documentation</a>
          </p>
          <p>Your download link will be available for 7 days.</p>
          <p>Thank you for using FinishThisIdea!</p>
        </div>
        <div class="footer">
          <p>© 2024 FinishThisIdea. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
    `;
  }

  private getPaymentSuccessTemplate(): string {
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #f59e0b; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background-color: #f8f9fa; }
        .button { display: inline-block; padding: 12px 24px; background-color: #f59e0b; color: white; text-decoration: none; border-radius: 4px; }
        .feature-list { background-color: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Welcome to Premium!</h1>
        </div>
        <div class="content">
          <h2>Thank you, {{name}}!</h2>
          <p>Your payment has been processed successfully and your account has been upgraded to Premium.</p>
          <div class="feature-list">
            <h3>Your Premium Features:</h3>
            <ul>
              <li>📁 500MB file uploads (vs 50MB)</li>
              <li>🚀 Batch processing up to 10 files</li>
              <li>📋 Advanced documentation templates</li>
              <li>📊 Multiple export formats (PDF, HTML, MD)</li>
              <li>⚡ Priority processing queue</li>
              <li>👥 Up to 10 custom profiles</li>
            </ul>
          </div>
          <p style="text-align: center; margin: 30px 0;">
            <a href="{{appUrl}}/upload" class="button">Start Using Premium Features</a>
          </p>
          <p>Invoice #{{invoiceNumber}} has been sent to your email.</p>
          <p>Questions? Reply to this email and we'll help you out!</p>
        </div>
        <div class="footer">
          <p>© 2024 FinishThisIdea. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
    `;
  }

  private replaceTemplateVariables(template: string, data: EmailTemplateData): string {
    let result = template;
    Object.keys(data).forEach(key => {
      const regex = new RegExp(`{{${key}}}`, 'g');
      result = result.replace(regex, data[key]);
    });
    return result;
  }

  public async sendEmail(options: EmailOptions): Promise<boolean> {
    if (!this.isEnabled || !this.transporter) {
      logger.warn('Email service is disabled or not configured');
      return false;
    }

    try {
      const mailOptions = {
        from: process.env.EMAIL_FROM || 'FinishThisIdea <noreply@finishthisidea.com>',
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.text || this.stripHtml(options.html),
      };

      const info = await this.transporter.sendMail(mailOptions);
      logger.info('Email sent successfully', { 
        messageId: info.messageId,
        to: options.to,
        subject: options.subject 
      });
      return true;
    } catch (error) {
      logger.error('Failed to send email', { error, to: options.to });
      return false;
    }
  }

  public async sendWelcomeEmail(to: string, name: string): Promise<boolean> {
    if (!automationConfig.email.templates.welcome.enabled) {
      return false;
    }

    const template = this.templates.get('welcome');
    if (!template) return false;

    const html = this.replaceTemplateVariables(template, {
      name,
      appUrl: process.env.FRONTEND_URL || 'http://localhost:3000',
    });

    return this.sendEmail({
      to,
      subject: automationConfig.email.templates.welcome.subject,
      html,
    });
  }

  public async sendJobCompleteEmail(
    to: string, 
    data: {
      name: string;
      jobId: string;
      templateCount: number;
      processingTime: string;
      downloadUrl: string;
    }
  ): Promise<boolean> {
    if (!automationConfig.email.templates.jobComplete.enabled) {
      return false;
    }

    const template = this.templates.get('jobComplete');
    if (!template) return false;

    const html = this.replaceTemplateVariables(template, data);

    return this.sendEmail({
      to,
      subject: automationConfig.email.templates.jobComplete.subject,
      html,
    });
  }

  public async sendPaymentSuccessEmail(
    to: string,
    data: {
      name: string;
      invoiceNumber: string;
      appUrl: string;
    }
  ): Promise<boolean> {
    if (!automationConfig.email.templates.paymentSuccess.enabled) {
      return false;
    }

    const template = this.templates.get('paymentSuccess');
    if (!template) return false;

    const html = this.replaceTemplateVariables(template, data);

    return this.sendEmail({
      to,
      subject: automationConfig.email.templates.paymentSuccess.subject,
      html,
    });
  }

  private stripHtml(html: string): string {
    return html.replace(/<[^>]*>?/gm, '').trim();
  }
}

// Export singleton instance
export const emailService = new EmailService();