import express from 'express';
import { asyncHandler } from '../middleware/async-handler';
import { authentication } from '../../middleware/auth.middleware';
import { analyticsService } from '../../automation/services/analytics-integration.service';
import { logger } from '../../utils/logger';
import { prisma } from '../../utils/database';

const router = express.Router();

/**
 * Get analytics dashboard overview
 */
router.get('/dashboard', authentication({ role: 'admin' }), asyncHandler(async (req, res) => {
  try {
    // Get basic metrics from database
    const [
      totalUsers,
      totalJobs,
      totalPayments,
      recentJobs,
      usersByTier,
      jobsByStatus,
      revenueThisMonth
    ] = await Promise.all([
      prisma.user.count(),
      prisma.job.count(),
      prisma.payment.count({ where: { status: 'SUCCEEDED' } }),
      prisma.job.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: {
          user: { select: { email: true, tier: true } },
          payment: { select: { amount: true, status: true } }
        }
      }),
      prisma.user.groupBy({
        by: ['tier'],
        _count: { tier: true }
      }),
      prisma.job.groupBy({
        by: ['status'],
        _count: { status: true }
      }),
      prisma.payment.aggregate({
        _sum: { amount: true },
        where: {
          status: 'SUCCEEDED',
          createdAt: {
            gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1)
          }
        }
      })
    ]);

    // Get analytics summary from external services
    const externalAnalytics = await analyticsService.getAnalyticsSummary();

    const dashboard = {
      overview: {
        totalUsers,
        totalJobs,
        totalPayments,
        revenueThisMonth: (revenueThisMonth._sum.amount || 0) / 100, // Convert from cents
      },
      users: {
        byTier: usersByTier.reduce((acc, item) => {
          acc[item.tier] = item._count.tier;
          return acc;
        }, {} as Record<string, number>)
      },
      jobs: {
        byStatus: jobsByStatus.reduce((acc, item) => {
          acc[item.status] = item._count.status;
          return acc;
        }, {} as Record<string, number>),
        recent: recentJobs.map(job => ({
          id: job.id,
          status: job.status,
          type: job.type,
          userEmail: job.user?.email,
          userTier: job.user?.tier,
          amount: job.payment?.amount ? job.payment.amount / 100 : null,
          createdAt: job.createdAt,
          completedAt: job.completedAt
        }))
      },
      analytics: externalAnalytics
    };

    res.json({
      success: true,
      data: dashboard
    });

  } catch (error) {
    logger.error('Failed to get analytics dashboard', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'ANALYTICS_ERROR',
        message: 'Failed to retrieve analytics data'
      }
    });
  }
}));

/**
 * Get user activity metrics
 */
router.get('/users', authentication({ role: 'admin' }), asyncHandler(async (req, res) => {
  const { timeframe = '30d', tier } = req.query;

  try {
    let startDate: Date;
    switch (timeframe) {
      case '7d':
        startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        break;
      case '90d':
        startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        break;
      default:
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    }

    const whereClause: any = {
      createdAt: { gte: startDate }
    };
    
    if (tier && typeof tier === 'string') {
      whereClause.tier = tier;
    }

    const [newUsers, activeUsers, userActivity] = await Promise.all([
      prisma.user.count({ where: whereClause }),
      prisma.user.count({
        where: {
          lastLoginAt: { gte: startDate },
          ...(tier && typeof tier === 'string' ? { tier } : {})
        }
      }),
      prisma.job.groupBy({
        by: ['userId'],
        _count: { userId: true },
        where: {
          createdAt: { gte: startDate },
          userId: { not: null }
        },
        orderBy: { _count: { userId: 'desc' } },
        take: 10
      })
    ]);

    res.json({
      success: true,
      data: {
        timeframe,
        newUsers,
        activeUsers,
        topUsers: userActivity.map(activity => ({
          userId: activity.userId,
          jobCount: activity._count.userId
        }))
      }
    });

  } catch (error) {
    logger.error('Failed to get user analytics', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'USER_ANALYTICS_ERROR',
        message: 'Failed to retrieve user analytics'
      }
    });
  }
}));

/**
 * Get revenue metrics
 */
router.get('/revenue', authentication({ role: 'admin' }), asyncHandler(async (req, res) => {
  const { timeframe = '30d' } = req.query;

  try {
    let startDate: Date;
    let groupBy: 'day' | 'week' | 'month';
    
    switch (timeframe) {
      case '7d':
        startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        groupBy = 'day';
        break;
      case '30d':
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        groupBy = 'day';
        break;
      case '90d':
        startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        groupBy = 'week';
        break;
      case '1y':
        startDate = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000);
        groupBy = 'month';
        break;
      default:
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        groupBy = 'day';
    }

    const [totalRevenue, successfulPayments, revenueByUser] = await Promise.all([
      prisma.payment.aggregate({
        _sum: { amount: true },
        _count: { amount: true },
        where: {
          status: 'SUCCEEDED',
          createdAt: { gte: startDate }
        }
      }),
      prisma.payment.findMany({
        where: {
          status: 'SUCCEEDED',
          createdAt: { gte: startDate }
        },
        select: {
          amount: true,
          createdAt: true,
          user: { select: { tier: true } }
        },
        orderBy: { createdAt: 'asc' }
      }),
      prisma.payment.groupBy({
        by: ['userId'],
        _sum: { amount: true },
        _count: { amount: true },
        where: {
          status: 'SUCCEEDED',
          createdAt: { gte: startDate }
        },
        orderBy: { _sum: { amount: 'desc' } },
        take: 10
      })
    ]);

    // Group revenue by time period
    const revenueOverTime: Record<string, number> = {};
    successfulPayments.forEach(payment => {
      let key: string;
      const date = payment.createdAt;
      
      if (groupBy === 'day') {
        key = date.toISOString().split('T')[0];
      } else if (groupBy === 'week') {
        const week = new Date(date.getFullYear(), date.getMonth(), date.getDate() - date.getDay());
        key = week.toISOString().split('T')[0];
      } else {
        key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      }
      
      revenueOverTime[key] = (revenueOverTime[key] || 0) + payment.amount;
    });

    // Convert to dollars
    Object.keys(revenueOverTime).forEach(key => {
      revenueOverTime[key] = revenueOverTime[key] / 100;
    });

    res.json({
      success: true,
      data: {
        timeframe,
        totalRevenue: (totalRevenue._sum.amount || 0) / 100,
        totalTransactions: totalRevenue._count.amount,
        averageTransactionValue: totalRevenue._count.amount > 0 
          ? ((totalRevenue._sum.amount || 0) / totalRevenue._count.amount / 100)
          : 0,
        revenueOverTime,
        topUsers: revenueByUser.map(user => ({
          userId: user.userId,
          totalRevenue: (user._sum.amount || 0) / 100,
          transactionCount: user._count.amount
        }))
      }
    });

  } catch (error) {
    logger.error('Failed to get revenue analytics', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'REVENUE_ANALYTICS_ERROR',
        message: 'Failed to retrieve revenue analytics'
      }
    });
  }
}));

/**
 * Get system health metrics
 */
router.get('/health', authentication({ role: 'admin' }), asyncHandler(async (req, res) => {
  try {
    const [
      failedJobs,
      avgProcessingTime,
      errorRates,
      queueHealth
    ] = await Promise.all([
      prisma.job.count({
        where: {
          status: 'FAILED',
          createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
        }
      }),
      prisma.job.aggregate({
        _avg: {
          // Calculate processing time from start to end
          processingStartedAt: true
        },
        where: {
          status: 'COMPLETED',
          processingStartedAt: { not: null },
          processingEndedAt: { not: null },
          createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
        }
      }),
      prisma.job.groupBy({
        by: ['status'],
        _count: { status: true },
        where: {
          createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
        }
      }),
      // This would come from queue monitoring service
      Promise.resolve({
        waiting: 0,
        active: 0,
        completed: 0,
        failed: 0
      })
    ]);

    res.json({
      success: true,
      data: {
        errorRate: errorRates.reduce((acc, item) => {
          if (item.status === 'FAILED') return item._count.status;
          return acc;
        }, 0),
        avgProcessingTime: avgProcessingTime._avg.processingStartedAt || 0,
        failedJobs,
        queueHealth,
        jobStats: errorRates.reduce((acc, item) => {
          acc[item.status] = item._count.status;
          return acc;
        }, {} as Record<string, number>)
      }
    });

  } catch (error) {
    logger.error('Failed to get health analytics', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'HEALTH_ANALYTICS_ERROR',
        message: 'Failed to retrieve health analytics'
      }
    });
  }
}));

/**
 * Test analytics integrations
 */
router.post('/test', authentication({ role: 'admin' }), asyncHandler(async (req, res) => {
  try {
    // Test event tracking
    await analyticsService.track({
      event: 'admin_analytics_test',
      userId: req.user?.id || 'admin',
      properties: {
        source: 'admin_dashboard',
        timestamp: new Date().toISOString()
      }
    });

    // Test user identification (if user is available)
    if (req.user) {
      await analyticsService.identify({
        userId: req.user.id,
        email: req.user.email || undefined,
        tier: req.user.tier || 'FREE'
      });
    }

    res.json({
      success: true,
      message: 'Analytics test events sent successfully'
    });

  } catch (error) {
    logger.error('Failed to test analytics', { error });
    res.status(500).json({
      success: false,
      error: {
        code: 'ANALYTICS_TEST_ERROR',
        message: 'Failed to test analytics integrations'
      }
    });
  }
}));

export { router as analyticsRouter };