# Production Deployment Guide

This guide walks you through deploying FinishThisIdea to production with all integrations properly configured.

## Prerequisites

- [ ] Domain name configured with DNS
- [ ] SSL certificate (Let's Encrypt recommended)
- [ ] PostgreSQL database (AWS RDS, Railway, or self-hosted)
- [ ] Redis instance (Railway, Upstash, or self-hosted)
- [ ] S3-compatible storage (AWS S3, DigitalOcean Spaces, etc.)
- [ ] Stripe account with live keys
- [ ] Email service (SendGrid, Mailgun, or SMTP)

## Deployment Checklist

### 1. Environment Configuration

1. **Copy environment template:**
   ```bash
   cp .env.production.template .env.production
   ```

2. **Fill in all required environment variables:**
   - Database connections (PostgreSQL, Redis)
   - API keys (Stripe, Anthropic, etc.)
   - Storage configuration (S3)
   - Analytics tokens (Mixpanel, GA4)
   - Integration tokens (Slack, GitHub, Telegram)

3. **Verify environment variables:**
   ```bash
   npm run validate-env
   ```

### 2. Database Setup

1. **Run database migrations:**
   ```bash
   npx prisma migrate deploy
   ```

2. **Seed default data (if needed):**
   ```bash
   npx prisma db seed
   ```

3. **Test database connection:**
   ```bash
   npm run test:db
   ```

### 3. Build & Deploy

#### Option A: Railway (Recommended)

1. **Connect GitHub repository to Railway**
2. **Add environment variables in Railway dashboard**
3. **Deploy automatically via git push**

#### Option B: Manual/VPS Deployment

1. **Build the application:**
   ```bash
   npm run build
   ```

2. **Start with PM2:**
   ```bash
   pm2 start ecosystem.config.js --env production
   ```

3. **Configure nginx reverse proxy**
4. **Set up SSL with certbot**

### 4. Third-Party Service Configuration

#### Stripe Configuration
- [ ] Switch to live mode in Stripe dashboard
- [ ] Configure webhook endpoint: `https://your-domain.com/api/webhook/stripe`
- [ ] Test payment flow with live keys

#### Analytics Setup
- [ ] Create Mixpanel project and get project token
- [ ] Set up GA4 property and get measurement ID + API secret
- [ ] Test analytics with `/api/analytics/test` endpoint

#### Slack Integration
- [ ] Create Slack app and install to workspace
- [ ] Get bot token and configure permissions
- [ ] Test with workflow automation

#### GitHub Integration
- [ ] Create GitHub personal access token or GitHub App
- [ ] Configure repository access permissions
- [ ] Test workflow automation

#### Telegram Bot (Optional)
- [ ] Create bot with @BotFather
- [ ] Get bot token and configure admin user IDs
- [ ] Test remote automation commands

### 5. Production Validation

1. **Run production readiness script:**
   ```bash
   npm run validate:production
   ```

2. **Test all endpoints:**
   ```bash
   npm run test:api
   ```

3. **Monitor health endpoints:**
   - `https://your-domain.com/health`
   - `https://your-domain.com/api/health`

4. **Test core workflows:**
   - [ ] User registration/login
   - [ ] File upload and processing
   - [ ] Payment processing
   - [ ] Documentation generation
   - [ ] Email notifications
   - [ ] Analytics tracking

### 6. Monitoring & Alerts

1. **Set up uptime monitoring:**
   - Use services like Uptime Robot, Pingdom, or UptimeRobot
   - Monitor main application and health endpoints

2. **Configure error tracking:**
   - Sentry for error monitoring
   - Set up alert channels (email, Slack)

3. **Analytics monitoring:**
   - Monitor conversion funnels
   - Track key business metrics
   - Set up custom dashboards

### 7. Security Hardening

1. **SSL/TLS Configuration:**
   - Force HTTPS redirects
   - Configure security headers
   - Set up HSTS

2. **Rate Limiting:**
   - Configure appropriate limits for your traffic
   - Monitor for abuse patterns

3. **Database Security:**
   - Use connection pooling
   - Configure read replicas if needed
   - Regular backups

### 8. Performance Optimization

1. **CDN Setup:**
   - Use Cloudflare or AWS CloudFront
   - Configure caching headers
   - Optimize static assets

2. **Database Optimization:**
   - Index frequently queried fields
   - Configure connection pooling
   - Monitor query performance

3. **Redis Configuration:**
   - Configure appropriate memory limits
   - Set up persistence if needed
   - Monitor queue health

## Post-Deployment

### Daily Operations

1. **Monitor key metrics:**
   - Application health
   - Error rates
   - Performance metrics
   - Business KPIs

2. **Check analytics dashboard:**
   - Visit `/admin/analytics.html`
   - Review user activity
   - Monitor conversion rates

3. **Review logs:**
   - Application errors
   - Security events
   - Performance issues

### Weekly Tasks

1. **Security updates:**
   - Update dependencies
   - Review security alerts
   - Check for vulnerability scans

2. **Performance review:**
   - Database query optimization
   - API response times
   - User experience metrics

### Monthly Tasks

1. **Business metrics review:**
   - Revenue analysis
   - User growth
   - Feature usage

2. **Infrastructure review:**
   - Cost optimization
   - Scaling needs
   - Backup validation

## Troubleshooting

### Common Issues

1. **Database connection errors:**
   - Check connection string
   - Verify database credentials
   - Test network connectivity

2. **Payment processing issues:**
   - Verify Stripe webhook configuration
   - Check webhook secret
   - Test with Stripe CLI

3. **Analytics not tracking:**
   - Verify API keys and tokens
   - Check analytics test endpoint
   - Review browser console for errors

4. **Email delivery issues:**
   - Check SMTP configuration
   - Verify domain authentication
   - Monitor bounce rates

### Emergency Procedures

1. **Application rollback:**
   ```bash
   # If using Railway
   railway deployment rollback

   # If using PM2
   pm2 restart app --env production
   ```

2. **Database rollback:**
   ```bash
   # Restore from backup
   psql -h host -U user -d database < backup.sql
   ```

3. **Traffic diversion:**
   - Use Cloudflare's "Under Attack" mode
   - Implement maintenance page
   - Scale up infrastructure if needed

## Support Contacts

- **Technical Issues:** your-tech-team@domain.com
- **Security Issues:** security@domain.com
- **Business Critical:** emergency@domain.com

---

*This deployment guide should be updated as your infrastructure evolves.*