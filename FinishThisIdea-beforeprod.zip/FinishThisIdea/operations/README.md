# Operations Guide

This folder contains operational guides, launch materials, and handoff documentation for production deployment and team management.

## Structure

### 📋 `/launch/`
Production launch materials and checklists
- `playbook.md` - Complete launch workflow
- `pre-launch-checklist.md` - Final verification steps
- `support-templates/` - Launch announcement and support materials

### 🤖 `/automation/` 
Optional automation tools and scripts
- `telegram-bot-setup.md` - File automation via chat
- `file-automation-scripts/` - Local automation utilities

### 🤝 `/handoff/`
Team onboarding and project handoff materials
- `executive-summary.md` - Project overview and vision
- `technical-deep-dive.md` - Architecture and implementation details
- `team-onboarding.md` - New developer setup guide

## Quick Navigation

**Ready to Launch?** → Start with `/launch/playbook.md`

**New Team Member?** → Read `/handoff/executive-summary.md`

**Need Automation?** → Check `/automation/telegram-bot-setup.md`

---

*These materials complement the main project documentation in `/docs/` and provide operational guidance for production deployment and team management.*