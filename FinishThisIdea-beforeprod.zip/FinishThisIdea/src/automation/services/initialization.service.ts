import { logger } from '../../utils/logger';
import { workflowEngine } from './workflow-engine.service';
import { startupService } from './startup.service';
import { queueHealthMonitor } from './queue-health-monitor.service';
import { conversionTracking } from './conversion-tracking.service';
import { emailService } from './email.service';
import { telegramBot } from './telegram-bot.service';
import { projectWizard } from './project-wizard.service';
import { launchPlaybook } from './launch-playbook.service';
import automationConfig from '../config/automation-config.json';

export class AutomationInitializationService {
  private isInitialized = false;

  /**
   * Initialize all automation services
   */
  public async initializeAll(): Promise<void> {
    if (this.isInitialized) {
      logger.warn('Automation services already initialized');
      return;
    }

    try {
      logger.info('Initializing automation services...');

      // Initialize workflow engine
      await workflowEngine.initialize();
      logger.info('✓ Workflow engine initialized');

      // Initialize startup service
      await startupService.initialize();
      logger.info('✓ Startup service initialized');

      // Initialize project wizard
      await projectWizard.initialize();
      logger.info('✓ Project wizard initialized');

      // Initialize launch playbook
      await launchPlaybook.initialize();
      logger.info('✓ Launch playbook initialized');

      // Initialize Telegram bot if enabled
      if (automationConfig.features.telegramBot) {
        try {
          await telegramBot.initialize();
          logger.info('✓ Telegram bot initialized');
        } catch (error) {
          logger.warn('Telegram bot initialization failed', { error });
        }
      }

      // Start queue health monitoring if enabled
      if (automationConfig.features.queueHealthMonitoring) {
        queueHealthMonitor.startMonitoring(
          automationConfig.queueHealthMonitoring.intervalMinutes
        );
        logger.info('✓ Queue health monitoring started');
      }

      // Test email service if enabled
      if (automationConfig.features.emailNotifications) {
        try {
          await emailService.testConnection();
          logger.info('✓ Email service connected');
        } catch (error) {
          logger.warn('Email service connection failed', { error });
        }
      }

      // Register default workflows
      await this.registerDefaultWorkflows();

      this.isInitialized = true;
      logger.info('All automation services initialized successfully');

      // Track initialization
      await conversionTracking.trackConversion('system', 'automation_initialized', {
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV || 'development',
      });

    } catch (error) {
      logger.error('Failed to initialize automation services', { error });
      throw error;
    }
  }

  /**
   * Register default workflow templates
   */
  private async registerDefaultWorkflows(): Promise<void> {
    // Basic notification workflow
    workflowEngine.registerTemplate('system-notification', {
      name: 'System Notification',
      description: 'Send system notification emails',
      steps: [
        {
          name: 'Send Email',
          type: 'email',
          to: '{{ recipient }}',
          subject: '{{ subject }}',
          message: '{{ message }}',
        },
        {
          name: 'Track Event',
          type: 'analytics',
          event: 'system_notification_sent',
          properties: {
            recipient: '{{ recipient }}',
            subject: '{{ subject }}',
          },
        },
      ],
    });

    // Health check workflow
    workflowEngine.registerTemplate('health-check', {
      name: 'System Health Check',
      description: 'Validate system health and send alerts if needed',
      steps: [
        {
          name: 'Check API Health',
          type: 'script',
          command: 'curl -f http://localhost:3001/health',
          onError: 'continue',
        },
        {
          name: 'Check Database',
          type: 'script',
          command: 'npx prisma db execute --sql "SELECT 1"',
          onError: 'continue',
        },
        {
          name: 'Send Alert on Failure',
          type: 'email',
          to: '{{ admin_email }}',
          subject: 'System Health Alert',
          message: 'Health check detected issues with the system.',
          condition: 'previousStepFailed',
        },
      ],
    });

    // User engagement workflow
    workflowEngine.registerTemplate('user-engagement', {
      name: 'User Engagement',
      description: 'Track and encourage user engagement',
      steps: [
        {
          name: 'Track Engagement',
          type: 'analytics',
          event: 'user_engagement',
          properties: {
            user_id: '{{ user.id }}',
            action: '{{ action }}',
            timestamp: '{{ timestamp }}',
          },
        },
        {
          name: 'Send Encouragement Email',
          type: 'email',
          to: '{{ user.email }}',
          subject: 'Keep up the great work!',
          message: 'Thanks for using FinishThisIdea. Your progress is amazing!',
          condition: 'user.activityLevel === "high"',
        },
      ],
    });

    logger.info('Default workflow templates registered');
  }

  /**
   * Graceful shutdown of automation services
   */
  public async shutdown(): Promise<void> {
    logger.info('Shutting down automation services...');

    try {
      // Stop queue health monitoring
      queueHealthMonitor.stopMonitoring();

      // Shutdown Telegram bot
      if (telegramBot.isRunning()) {
        await telegramBot.shutdown();
        logger.info('✓ Telegram bot shutdown');
      }

      // Shutdown startup service
      await startupService.shutdown();

      this.isInitialized = false;
      logger.info('Automation services shut down successfully');
    } catch (error) {
      logger.error('Error during automation shutdown', { error });
    }
  }

  /**
   * Get initialization status
   */
  public getStatus(): boolean {
    return this.isInitialized;
  }

  /**
   * Health check for automation services
   */
  public async healthCheck(): Promise<{
    status: 'healthy' | 'degraded' | 'unhealthy';
    services: Record<string, { status: string; message?: string }>;
  }> {
    const services: Record<string, { status: string; message?: string }> = {};

    // Check workflow engine
    try {
      const templates = workflowEngine.getAvailableTemplates();
      services.workflowEngine = {
        status: templates.length > 0 ? 'healthy' : 'degraded',
        message: `${templates.length} templates loaded`,
      };
    } catch (error) {
      services.workflowEngine = {
        status: 'unhealthy',
        message: error instanceof Error ? error.message : 'Unknown error',
      };
    }

    // Check email service
    if (automationConfig.features.emailNotifications) {
      try {
        await emailService.testConnection();
        services.emailService = { status: 'healthy' };
      } catch (error) {
        services.emailService = {
          status: 'unhealthy',
          message: error instanceof Error ? error.message : 'Connection failed',
        };
      }
    } else {
      services.emailService = { status: 'disabled' };
    }

    // Check queue monitoring
    services.queueMonitoring = {
      status: automationConfig.features.queueHealthMonitoring ? 'healthy' : 'disabled',
    };

    // Determine overall status
    const statuses = Object.values(services).map(s => s.status);
    const status = statuses.includes('unhealthy') ? 'unhealthy' :
                  statuses.includes('degraded') ? 'degraded' : 'healthy';

    return { status, services };
  }
}

// Export singleton instance
export const automationInitialization = new AutomationInitializationService();