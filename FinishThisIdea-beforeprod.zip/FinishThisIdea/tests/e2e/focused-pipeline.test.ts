import { ZipManager } from '../utils/zip-manager';
import { SampleGenerator } from '../utils/sample-generator';
import { promises as fs } from 'fs';
import * as path from 'path';
import * as os from 'os';

describe('Focused Pipeline E2E Test', () => {
  let tempDir: string;

  beforeAll(async () => {
    // Create temporary directory for test files
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'finishthisidea-focused-'));
    console.log('🚀 Starting focused E2E test in:', tempDir);
  });

  afterAll(async () => {
    // Clean up test files
    await fs.rm(tempDir, { recursive: true, force: true });
    console.log('✅ Cleanup completed');
  });

  describe('Sample Generation and ZIP Processing', () => {
    it('should generate sample React project and create ZIP', async () => {
      console.log('📦 Testing sample generation...');
      
      try {
        // Generate a React sample project
        const reactZipPath = await SampleGenerator.generateSample('react-ecommerce', tempDir);
        
        console.log(`✅ Generated React sample: ${reactZipPath}`);
        
        // Verify the ZIP was created
        const zipExists = await fs.access(reactZipPath).then(() => true).catch(() => false);
        expect(zipExists).toBe(true);
        
        // Get ZIP info
        const zipInfo = await ZipManager.getZipInfo(reactZipPath);
        expect(zipInfo.fileCount).toBeGreaterThan(0);
        expect(zipInfo.totalSize).toBeGreaterThan(0);
        
        console.log(`📊 ZIP contains ${zipInfo.fileCount} files, ${(zipInfo.totalSize / 1024).toFixed(2)}KB total`);
        
        // Verify it contains expected React files
        const hasPackageJson = zipInfo.files.some(f => f.name === 'package.json');
        const hasReactFiles = zipInfo.files.some(f => f.name.includes('src/') && f.name.endsWith('.tsx'));
        
        expect(hasPackageJson).toBe(true);
        expect(hasReactFiles).toBe(true);
        
        console.log('✅ React sample validation passed');
        
      } catch (error) {
        console.error('❌ Sample generation failed:', error);
        throw error;
      }
    });

    it('should generate Django sample project and validate structure', async () => {
      console.log('🐍 Testing Django sample generation...');
      
      try {
        const djangoZipPath = await SampleGenerator.generateSample('django-webapp', tempDir);
        
        console.log(`✅ Generated Django sample: ${djangoZipPath}`);
        
        const zipInfo = await ZipManager.getZipInfo(djangoZipPath);
        expect(zipInfo.fileCount).toBeGreaterThan(0);
        
        // Verify Django-specific files
        const hasPythonFiles = zipInfo.files.some(f => f.name.endsWith('.py'));
        const hasRequirements = zipInfo.files.some(f => f.name === 'requirements.txt');
        const hasManagePy = zipInfo.files.some(f => f.name === 'manage.py');
        
        expect(hasPythonFiles).toBe(true);
        expect(hasRequirements).toBe(true);
        expect(hasManagePy).toBe(true);
        
        console.log('✅ Django sample validation passed');
        
      } catch (error) {
        console.error('❌ Django sample generation failed:', error);
        throw error;
      }
    });

    it('should extract and validate ZIP contents', async () => {
      console.log('📂 Testing ZIP extraction...');
      
      try {
        // Create a test ZIP with known content
        const testFiles = {
          'README.md': '# Test Project\n\nThis is a test project for validation.',
          'src/index.js': 'console.log("Hello, world!");',
          'src/utils/helper.js': 'export function add(a, b) { return a + b; }',
          'package.json': JSON.stringify({
            name: 'test-project',
            version: '1.0.0',
            dependencies: { 'express': '^4.18.0' }
          }, null, 2)
        };
        
        const testZipPath = path.join(tempDir, 'test-extraction.zip');
        await ZipManager.createZip(testFiles, testZipPath);
        
        // Extract the ZIP
        const extractedFiles = await ZipManager.extractZip(testZipPath);
        
        // Verify all files were extracted correctly
        expect(extractedFiles.size).toBe(Object.keys(testFiles).length);
        
        for (const [fileName, expectedContent] of Object.entries(testFiles)) {
          expect(extractedFiles.has(fileName)).toBe(true);
          expect(extractedFiles.get(fileName)).toBe(expectedContent);
        }
        
        console.log('✅ ZIP extraction validation passed');
        
      } catch (error) {
        console.error('❌ ZIP extraction failed:', error);
        throw error;
      }
    });
  });

  describe('File Processing Pipeline', () => {
    it('should identify languages and frameworks from sample projects', async () => {
      console.log('🔍 Testing language/framework detection...');
      
      try {
        // Generate samples for different languages
        const samples = [
          { name: 'react-ecommerce', expectedLang: 'typescript', expectedFramework: 'react' },
          { name: 'django-webapp', expectedLang: 'python', expectedFramework: 'django' },
          { name: 'spring-boot-api', expectedLang: 'java', expectedFramework: 'spring' }
        ];
        
        for (const sample of samples) {
          try {
            const zipPath = await SampleGenerator.generateSample(sample.name, tempDir);
            const extractedFiles = await ZipManager.extractZip(zipPath);
            
            // Simple language detection based on file extensions
            const fileExtensions = Array.from(extractedFiles.keys())
              .map(fileName => path.extname(fileName).toLowerCase())
              .filter(ext => ext.length > 0);
            
            const uniqueExtensions = [...new Set(fileExtensions)];
            console.log(`📝 ${sample.name} extensions:`, uniqueExtensions);
            
            // Verify expected language files are present
            if (sample.expectedLang === 'typescript') {
              expect(uniqueExtensions.some(ext => ['.ts', '.tsx'].includes(ext))).toBe(true);
            } else if (sample.expectedLang === 'python') {
              expect(uniqueExtensions.includes('.py')).toBe(true);
            } else if (sample.expectedLang === 'java') {
              expect(uniqueExtensions.includes('.java')).toBe(true);
            }
            
            console.log(`✅ ${sample.name} language detection passed`);
            
          } catch (error) {
            console.warn(`⚠️ Failed to process ${sample.name}:`, error.message);
          }
        }
        
      } catch (error) {
        console.error('❌ Language detection failed:', error);
        throw error;
      }
    });
  });

  describe('Quality Validation', () => {
    it('should validate sample project quality and completeness', async () => {
      console.log('🎯 Testing project quality validation...');
      
      try {
        const reactZipPath = await SampleGenerator.generateSample('react-ecommerce', tempDir);
        const extractedFiles = await ZipManager.extractZip(reactZipPath);
        
        // Quality metrics
        const metrics = {
          fileCount: extractedFiles.size,
          hasDocumentation: extractedFiles.has('README.md'),
          hasConfiguration: extractedFiles.has('package.json'),
          hasSourceCode: Array.from(extractedFiles.keys()).some(f => f.includes('src/')),
          hasTests: Array.from(extractedFiles.keys()).some(f => f.includes('test') || f.includes('spec')),
          codeFiles: Array.from(extractedFiles.keys()).filter(f => 
            ['.ts', '.tsx', '.js', '.jsx', '.py', '.java'].some(ext => f.endsWith(ext))
          ).length
        };
        
        console.log('📊 Project Quality Metrics:', metrics);
        
        // Validate quality standards (adjusted for sample project size)
        expect(metrics.fileCount).toBeGreaterThan(5); // Should have substantial content
        expect(metrics.hasDocumentation).toBe(true); // Should have README
        expect(metrics.hasConfiguration).toBe(true); // Should have config files
        expect(metrics.hasSourceCode).toBe(true); // Should have source code
        expect(metrics.codeFiles).toBeGreaterThan(2); // Should have multiple code files
        
        console.log('✅ Quality validation passed');
        
      } catch (error) {
        console.error('❌ Quality validation failed:', error);
        throw error;  
      }
    });
  });

  describe('End-to-End Integration', () => {
    it('should process multiple project types in sequence', async () => {
      console.log('🔄 Testing sequential processing of multiple projects...');
      
      const projectTypes = ['react-ecommerce', 'django-webapp'];
      const results = [];
      
      for (const projectType of projectTypes) {
        try {
          console.log(`Processing ${projectType}...`);
          
          const startTime = Date.now();
          const zipPath = await SampleGenerator.generateSample(projectType, tempDir);
          const zipInfo = await ZipManager.getZipInfo(zipPath);
          const extractedFiles = await ZipManager.extractZip(zipPath);
          const processingTime = Date.now() - startTime;
          
          const result = {
            projectType,
            zipPath,
            fileCount: zipInfo.fileCount,
            totalSize: zipInfo.totalSize,
            extractedFileCount: extractedFiles.size,
            processingTime,
            success: true
          };
          
          results.push(result);
          console.log(`✅ ${projectType} processed in ${processingTime}ms`);
          
        } catch (error) {
          console.error(`❌ Failed to process ${projectType}:`, error);
          results.push({
            projectType,
            success: false,
            error: error.message
          });
        }
      }
      
      // Validate results
      const successfulResults = results.filter(r => r.success);
      expect(successfulResults.length).toBeGreaterThan(0);
      
      console.log('🎉 Sequential processing completed:', {
        total: results.length,
        successful: successfulResults.length,
        failed: results.length - successfulResults.length
      });
      
    });
  });
});