---
title: "Discord/Teams Integration Guide"
description: "Setup and usage guide for Discord and Microsoft Teams webhook integrations in FinishThisIdea workflows"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Discord/Teams Integration Guide

This document explains how to set up and use Discord and Microsoft Teams integrations in FinishThisIdea workflows.

## Overview

The Discord/Teams integration service allows you to send rich notifications to Discord channels via webhooks and Microsoft Teams channels via incoming webhooks. This enables real-time notifications for deployment status, workflow completions, and other automation events.

## Features

- ✅ Discord webhook notifications with rich embeds
- ✅ Microsoft Teams adaptive card notifications
- ✅ Support for multiple channels per platform
- ✅ Rich formatting with colors, fields, and attachments
- ✅ Integration with workflow engine
- ✅ Analytics tracking for notifications

## Setup

### Discord Setup

1. **Create a Discord Webhook:**
   - Go to your Discord server settings
   - Navigate to Integrations → Webhooks
   - Click "Create Webhook"
   - Choose the channel and copy the webhook URL

2. **Configure Environment Variables:**
   ```bash
   # Discord Integration (JSON object with channel_name: webhook_url)
   DISCORD_WEBHOOKS={"general": "https://discord.com/api/webhooks/your-webhook-id/your-webhook-token", "alerts": "https://discord.com/api/webhooks/your-alert-webhook-id/your-alert-webhook-token"}
   
   # Enable Discord integration
   ENABLE_DISCORD_INTEGRATION=true
   ```

### Microsoft Teams Setup

1. **Create a Teams Incoming Webhook:**
   - Go to your Teams channel
   - Click the three dots (⋯) next to the channel name
   - Select "Connectors"
   - Find "Incoming Webhook" and click "Configure"
   - Provide a name and upload an image (optional)
   - Copy the webhook URL

2. **Configure Environment Variables:**
   ```bash
   # Microsoft Teams Integration (JSON object with channel_name: webhook_url)
   TEAMS_WEBHOOKS={"general": "https://outlook.office.com/webhook/your-teams-webhook-url", "alerts": "https://outlook.office.com/webhook/your-teams-alert-webhook-url"}
   
   # Enable Teams integration
   ENABLE_TEAMS_INTEGRATION=true
   ```

## Usage in Workflows

### Discord Workflow Step

```yaml
- name: Send Discord Notification
  type: discord
  channel: general  # Must match a key in DISCORD_WEBHOOKS
  subject: "Deployment Update"
  message: "🚀 {{project_name}} has been deployed to {{environment}}"
  properties:
    type: "success"  # info, success, warning, error
    url: "https://your-app.com"
    fields:
      Environment: "{{environment}}"
      Version: "{{version}}"
      Duration: "{{duration}}ms"
```

### Teams Workflow Step

```yaml
- name: Send Teams Notification
  type: teams
  channel: general  # Must match a key in TEAMS_WEBHOOKS
  subject: "Deployment Notification"
  message: "📢 Deployment completed for {{project_name}}"
  properties:
    type: "info"  # info, success, warning, error
    url: "https://your-app.com"
    fields:
      Status: "{{status}}"
      Environment: "{{environment}}"
```

## Service Methods

### Available Methods

```typescript
// Send Discord message
await discordTeamsService.sendDiscordMessage('general', {
  content: 'Simple text message',
  embeds: [{
    title: 'Rich Embed',
    description: 'This is a rich embed message',
    color: 0x00ff00,
    fields: [
      { name: 'Field 1', value: 'Value 1', inline: true },
      { name: 'Field 2', value: 'Value 2', inline: true }
    ]
  }]
});

// Send Teams message
await discordTeamsService.sendTeamsMessage('general', {
  '@type': 'MessageCard',
  '@context': 'http://schema.org/extensions',
  summary: 'Notification Summary',
  title: 'Notification Title',
  text: 'Notification message',
  themeColor: '0078D4'
});

// Send unified notification (automatically detects platform)
await discordTeamsService.sendNotification('general', {
  title: 'Notification Title',
  message: 'Notification message',
  type: 'success',
  url: 'https://example.com',
  fields: [
    { name: 'Field 1', value: 'Value 1' }
  ]
});
```

### Predefined Notifications

```typescript
// Deployment notification
await discordTeamsService.sendDeploymentNotification('production', 'success', {
  version: '1.2.3',
  duration: 45000,
  url: 'https://your-app.com'
});

// Workflow notification
await discordTeamsService.sendWorkflowNotification('deploy-app', 'completed', {
  duration: 120000,
  stepCount: 5
});
```

## Message Formatting

### Discord Embeds

Discord supports rich embeds with:
- **Colors**: Use hex color codes (0x00ff00 for green)
- **Fields**: Up to 25 fields per embed
- **Images**: Thumbnail and full-size images
- **Author**: Author information with avatar
- **Footer**: Footer text with timestamp

### Teams Cards

Teams supports MessageCard format with:
- **Theme Colors**: Use hex colors without 0x prefix
- **Sections**: Organized content sections
- **Facts**: Key-value pairs for structured data
- **Actions**: Clickable buttons and links

## Error Handling

The service includes comprehensive error handling:

```typescript
try {
  await discordTeamsService.sendNotification('general', notification);
} catch (error) {
  // Service automatically logs errors
  // Continue with workflow or handle as needed
}
```

## Analytics Integration

All notifications are automatically tracked:

```typescript
// Automatic tracking includes:
{
  event: 'discord_notification_sent',
  properties: {
    channel: 'general',
    platform: 'discord',
    notification_type: 'deployment',
    success: true
  }
}
```

## Configuration Validation

The service validates configuration on startup:

- ✅ Webhook URL format validation
- ✅ Channel name validation
- ✅ JSON parsing of environment variables
- ✅ Connection testing (optional)

## Best Practices

1. **Channel Organization:**
   - Use separate channels for different notification types
   - Example: `general`, `alerts`, `deployments`, `workflows`

2. **Message Content:**
   - Keep messages concise but informative
   - Use emojis for visual appeal
   - Include relevant links and context

3. **Error Handling:**
   - Configure fallback channels
   - Use graceful degradation when services are unavailable
   - Monitor notification delivery success rates

4. **Rate Limiting:**
   - Discord: 5 requests per second per webhook
   - Teams: 4 requests per second per webhook
   - Service includes built-in rate limiting

## Troubleshooting

### Common Issues

1. **Webhook Not Working:**
   - Verify webhook URL format
   - Check webhook permissions in Discord/Teams
   - Ensure webhook hasn't been deleted

2. **Messages Not Appearing:**
   - Check channel permissions
   - Verify JSON format in environment variables
   - Review service logs for errors

3. **Rich Formatting Issues:**
   - Validate embed/card structure
   - Check field limits (25 for Discord, unlimited for Teams)
   - Verify color format (0x prefix for Discord, none for Teams)

### Debug Mode

Enable debug logging:

```bash
LOG_LEVEL=debug
```

This will log all notification attempts and responses.

## Examples

### Complete Workflow Example

```yaml
name: Production Deployment with Notifications
description: Deploy to production with Discord/Teams notifications

variables:
  app_name: "FinishThisIdea"
  environment: "production"
  version: "v1.2.3"

steps:
  - name: Start Deployment Notification
    type: discord
    channel: deployments
    subject: "🚀 Deployment Started"
    message: "Starting deployment of {{app_name}} {{version}} to {{environment}}"
    properties:
      type: "info"
      fields:
        Application: "{{app_name}}"
        Version: "{{version}}"
        Environment: "{{environment}}"
        Started: "{{timestamp}}"

  - name: Run Deployment Script
    type: script
    command: "./deploy.sh production"
    onError: "stop"

  - name: Success Notification (Discord)
    type: discord
    channel: deployments
    subject: "✅ Deployment Successful"
    message: "{{app_name}} {{version}} has been successfully deployed to {{environment}}"
    properties:
      type: "success"
      url: "https://finishthisidea.com"
      fields:
        Duration: "{{duration}}ms"
        Status: "Success"

  - name: Success Notification (Teams)
    type: teams
    channel: general
    subject: "🎉 Production Deployment Complete"
    message: "The latest version of {{app_name}} is now live!"
    properties:
      type: "success"
      url: "https://finishthisidea.com"
      fields:
        Version: "{{version}}"
        Environment: "{{environment}}"
        Deployed At: "{{timestamp}}"
```

## Migration Guide

If migrating from other notification systems:

1. **From Slack**: Similar webhook concept, adjust message format
2. **From Email**: Convert HTML formatting to Discord/Teams format
3. **From SMS**: Expand abbreviated messages for rich formatting

## Support

For issues with Discord/Teams integration:

1. Check the service logs
2. Verify webhook configurations
3. Test with simple messages first
4. Review Discord/Teams API documentation
5. Create an issue in the project repository