/**
 * Project Authentication Middleware
 * Handles project context and permissions
 */

import { Request, Response, NextFunction } from 'express';
import { Project } from '../models/project.model';
import { ProjectMember, ProjectPermissions } from '../models/project-member.model';
import { logger } from '../utils/logger';

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      project?: Project;
      projectMember?: ProjectMember;
      projectId?: string;
    }
  }
}

/**
 * Extract project context from request
 */
export async function extractProjectContext(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    let projectId: string | undefined;
    
    // 1. Check subdomain (e.g., project-slug.app.com)
    const subdomain = req.hostname.split('.')[0];
    if (subdomain && subdomain !== 'app' && subdomain !== 'www') {
      const project = await Project.findOne({ where: { slug: subdomain } });
      if (project) {
        projectId = project.id;
      }
    }
    
    // 2. Check URL path (e.g., /api/projects/:projectId/...)
    if (!projectId && req.params.projectId) {
      projectId = req.params.projectId;
    }
    
    // 3. Check header (e.g., X-Project-ID)
    if (!projectId && req.headers['x-project-id']) {
      projectId = req.headers['x-project-id'] as string;
    }
    
    // 4. Check query parameter (e.g., ?projectId=...)
    if (!projectId && req.query.projectId) {
      projectId = req.query.projectId as string;
    }
    
    // 5. Check JWT payload
    if (!projectId && req.user?.activeProjectId) {
      projectId = req.user.activeProjectId;
    }
    
    // Store in request
    req.projectId = projectId;
    
    next();
  } catch (error) {
    logger.error('Failed to extract project context:', error);
    next(); // Continue without project context
  }
}

/**
 * Require project context
 */
export async function requireProject(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.projectId) {
      return res.status(400).json({
        success: false,
        error: {
          message: 'Project context required',
          code: 'PROJECT_REQUIRED'
        }
      });
    }
    
    // Load project
    const project = await Project.findByPk(req.projectId);
    if (!project) {
      return res.status(404).json({
        success: false,
        error: {
          message: 'Project not found',
          code: 'PROJECT_NOT_FOUND'
        }
      });
    }
    
    // Check if project is active
    if (!project.isActive()) {
      return res.status(403).json({
        success: false,
        error: {
          message: 'Project is not active',
          code: 'PROJECT_INACTIVE'
        }
      });
    }
    
    req.project = project;
    next();
  } catch (error) {
    logger.error('Failed to load project:', error);
    res.status(500).json({
      success: false,
      error: {
        message: 'Failed to load project',
        code: 'PROJECT_LOAD_ERROR'
      }
    });
  }
}

/**
 * Check project membership
 */
export async function requireProjectMember(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: {
          message: 'Authentication required',
          code: 'AUTH_REQUIRED'
        }
      });
    }
    
    if (!req.project) {
      return res.status(400).json({
        success: false,
        error: {
          message: 'Project context required',
          code: 'PROJECT_REQUIRED'
        }
      });
    }
    
    // Find membership
    const membership = await ProjectMember.findOne({
      where: {
        projectId: req.project.id,
        userId: req.user.id,
        isActive: true
      }
    });
    
    if (!membership) {
      return res.status(403).json({
        success: false,
        error: {
          message: 'You are not a member of this project',
          code: 'NOT_PROJECT_MEMBER'
        }
      });
    }
    
    req.projectMember = membership;
    next();
  } catch (error) {
    logger.error('Failed to check project membership:', error);
    res.status(500).json({
      success: false,
      error: {
        message: 'Failed to verify project access',
        code: 'MEMBERSHIP_CHECK_ERROR'
      }
    });
  }
}

/**
 * Require specific project permission
 */
export function requireProjectPermission(permission: keyof ProjectPermissions) {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    if (!req.projectMember) {
      return res.status(403).json({
        success: false,
        error: {
          message: 'Project membership required',
          code: 'MEMBERSHIP_REQUIRED'
        }
      });
    }
    
    if (!req.projectMember.hasPermission(permission)) {
      return res.status(403).json({
        success: false,
        error: {
          message: `You don't have permission to ${permission}`,
          code: 'PERMISSION_DENIED',
          requiredPermission: permission
        }
      });
    }
    
    next();
  };
}

/**
 * Optional project context - doesn't fail if no project
 */
export async function optionalProject(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (req.projectId) {
      const project = await Project.findByPk(req.projectId);
      if (project && project.isActive()) {
        req.project = project;
        
        // Try to load membership if user is authenticated
        if (req.user) {
          const membership = await ProjectMember.findOne({
            where: {
              projectId: project.id,
              userId: req.user.id,
              isActive: true
            }
          });
          if (membership) {
            req.projectMember = membership;
          }
        }
      }
    }
    
    next();
  } catch (error) {
    logger.error('Failed to load optional project context:', error);
    next(); // Continue without project
  }
}

/**
 * Scope database queries to project
 */
export function scopeToProject(modelName: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.project) {
      return next();
    }
    
    // Add project scope to req for use in queries
    (req as any).projectScope = {
      projectId: req.project.id,
      modelName
    };
    
    next();
  };
}