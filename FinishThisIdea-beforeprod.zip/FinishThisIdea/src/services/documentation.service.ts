import { logger } from '../utils/logger';
import { llmRouter } from '../llm/router';
import { 
  withErrorHandling, 
  withRetry, 
  CodeAnalysisError, 
  // TemplateGenerationError, // Unused 
  LLMError,
  ValidationError,
  llmCircuitBreaker 
} from '../utils/error-handler';
import { ContextProfile } from '../types/context-profile';
import { templateTransformationService } from './template-transformations.service';
import { ParserIntegrationService } from './parser-integration.service';
import path from 'path';
import fs from 'fs/promises';
import {
  CodeAnalysis,
  APIEndpoint,
  DataModel,
  Field,
  Relationship,
  FunctionSignature,
  Parameter,
  Dependency,
  TestMetrics,
  ArchitectureInfo,
  Component as _Component, // Imported but not used directly
  BusinessRule,
  FileStructure,
  FileNode
} from '../types/code-analysis';

// Documentation template types
export interface DocumentationTemplate {
  id: string;
  name: string;
  description: string;
  sections: TemplateSection[];
  requiredAnalysis: string[]; // What code analysis is needed
}

export interface TemplateSection {
  id: string;
  title: string;
  template: string; // Markdown template with placeholders
  dataMapping: DataMapping[]; // How to map code analysis to this section
  aiPrompt?: string; // Custom prompt for AI generation
}

export interface DataMapping {
  placeholder: string; // e.g., "{{projectName}}"
  source: string; // e.g., "analysis.projectInfo.name"
  transform?: string; // Optional transformation function
}

// Documentation generation result
export interface DocumentationResult {
  jobId: string;
  templates: GeneratedTemplate[];
  metadata: {
    generatedAt: Date;
    templatesUsed: string[];
    aiTokensUsed: number;
    quality: QualityMetrics;
  };
}

export interface GeneratedTemplate {
  templateId: string;
  templateName: string;
  content: string; // Markdown content
  sections: GeneratedSection[];
}

export interface GeneratedSection {
  id: string;
  title: string;
  content: string;
  dataUsed: string[]; // Which analysis data was used
  aiGenerated: boolean;
}

export interface QualityMetrics {
  completeness: number; // 0-100
  accuracy: number; // 0-100
  readability: number; // 0-100
  overall: number; // 0-100
}

// Chat log parsing types
export interface ChatLog {
  messages: ChatMessage[];
  platform: 'chatgpt' | 'claude' | 'other';
  exportDate: Date;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp?: Date;
}

export interface ExtractedRequirements {
  features: Feature[];
  userStories: UserStory[];
  technicalRequirements: TechnicalRequirement[];
  businessRules: BusinessRule[];
  constraints: Constraint[];
}

export interface Feature {
  name: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  userStories: string[];
}

export interface UserStory {
  id: string;
  asA: string;
  iWant: string;
  soThat: string;
  acceptanceCriteria: string[];
}

export interface TechnicalRequirement {
  id: string;
  category: string;
  description: string;
  implementation?: string;
}

export interface Constraint {
  type: string;
  description: string;
  impact: string;
}

class DocumentationService {
  private templates: Map<string, DocumentationTemplate>;
  private templatesLoaded: Promise<void>;
  private parserIntegrationService: ParserIntegrationService;

  constructor() {
    this.templates = new Map();
    this.templatesLoaded = this.loadDefaultTemplates();
    this.parserIntegrationService = ParserIntegrationService.getInstance();
  }

  private async loadDefaultTemplates() {
    try {
      // Load YAML templates from the templates directory
      const templateDir = path.join(__dirname, '../templates/documentation');
      const templateFiles = ['executive-summary.yaml', 'api-contract.yaml', 'data-models.yaml', 'test-plan.yaml'];
      
      for (const templateFile of templateFiles) {
        try {
          const filePath = path.join(templateDir, templateFile);
          const content = await fs.readFile(filePath, 'utf-8');
          const yaml = await import('js-yaml');
          const templateData = yaml.load(content) as DocumentationTemplate;
          
          this.templates.set(templateData.id, templateData);
          logger.info('Loaded documentation template', { id: templateData.id, name: templateData.name });
        } catch (error) {
          logger.error('Failed to load template file', { templateFile, error });
        }
      }
    } catch (error) {
      logger.error('Failed to load default templates', { error });
      
      // Fallback to basic templates if YAML loading fails
      this.loadFallbackTemplates();
    }
  }

  private loadFallbackTemplates() {
    const basicTemplates: DocumentationTemplate[] = [
      {
        id: 'executive-summary',
        name: 'Executive Summary',
        description: 'High-level project overview for stakeholders',
        sections: [
          {
            id: 'overview',
            title: 'Project Overview',
            template: '# {{projectName}}\n\n{{projectDescription}}',
            dataMapping: [
              { placeholder: '{{projectName}}', source: 'projectInfo.name' },
              { placeholder: '{{projectDescription}}', source: 'projectInfo.description' }
            ]
          }
        ],
        requiredAnalysis: ['projectInfo']
      }
    ];

    basicTemplates.forEach(template => {
      this.templates.set(template.id, template);
    });
  }

  async generateDocumentation(
    jobId: string,
    codeAnalysis: CodeAnalysis,
    templateIds: string[],
    profile?: ContextProfile
  ): Promise<DocumentationResult> {
    return withErrorHandling(
      this._generateDocumentation.bind(this),
      `documentation generation for job ${jobId}`,
      300000 // 5 minute timeout
    )(jobId, codeAnalysis, templateIds, profile);
  }

  private async _generateDocumentation(
    jobId: string,
    codeAnalysis: CodeAnalysis,
    templateIds: string[],
    profile?: ContextProfile
  ): Promise<DocumentationResult> {
    logger.info('Starting documentation generation', { jobId, templateIds });

    // Ensure templates are loaded before proceeding
    await this.templatesLoaded;

    logger.info('Templates available', { 
      available: Array.from(this.templates.keys()), 
      requested: templateIds 
    });

    const generatedTemplates: GeneratedTemplate[] = [];
    let totalTokensUsed = 0;

    for (const templateId of templateIds) {
      const template = this.templates.get(templateId);
      if (!template) {
        logger.warn('Template not found', { templateId });
        continue;
      }

      const generatedSections: GeneratedSection[] = [];

      for (const section of template.sections) {
        try {
          const sectionContent = await withRetry(
            () => this.generateSection(section, codeAnalysis, profile),
            {
              maxRetries: 2,
              delay: 1000,
              context: `section ${section.id} for template ${templateId}`,
              retryOn: (error) => error.name === 'LLMError' || error.code === 'ECONNRESET'
            }
          );

          generatedSections.push({
            id: section.id,
            title: section.title,
            content: sectionContent.content,
            dataUsed: sectionContent.dataUsed,
            aiGenerated: sectionContent.aiGenerated
          });

          totalTokensUsed += sectionContent.tokensUsed || 0;
        } catch (error) {
          logger.error('Failed to generate section', { 
            templateId, 
            sectionId: section.id, 
            error: error instanceof Error ? error.message : String(error) 
          });
          
          // Create a placeholder section for failed generation
          generatedSections.push({
            id: section.id,
            title: section.title,
            content: `# ${section.title}\n\n*Section generation failed: ${error instanceof Error ? error.message : String(error)}*\n\nPlease regenerate this section or add content manually.`,
            dataUsed: [],
            aiGenerated: false
          });
        }
      }

      const fullContent = generatedSections
        .map(s => `${s.content}`)
        .join('\n\n');

      generatedTemplates.push({
        templateId,
        templateName: template.name,
        content: fullContent,
        sections: generatedSections
      });
    }

    // Calculate quality metrics
    const quality = this.calculateQualityMetrics(generatedTemplates, codeAnalysis);

    return {
      jobId,
      templates: generatedTemplates,
      metadata: {
        generatedAt: new Date(),
        templatesUsed: templateIds,
        aiTokensUsed: totalTokensUsed,
        quality
      }
    };
  }

  private async generateSection(
    section: TemplateSection,
    codeAnalysis: CodeAnalysis,
    profile?: ContextProfile
  ): Promise<{
    content: string;
    dataUsed: string[];
    aiGenerated: boolean;
    tokensUsed?: number;
  }> {
    let content = section.template;
    const dataUsed: string[] = [];
    let aiGenerated = false;
    let tokensUsed = 0;

    // Apply data mappings
    for (const mapping of section.dataMapping) {
      const value = this.extractValue(codeAnalysis, mapping.source);
      let transformedValue = value;

      if (mapping.transform) {
        transformedValue = await this.applyTransform(value, mapping.transform, codeAnalysis);
      }

      // If no value found and AI prompt exists, use AI to generate
      if (!transformedValue && section.aiPrompt) {
        const aiResult = await this.generateWithAI(
          section.aiPrompt,
          codeAnalysis,
          profile
        );
        transformedValue = aiResult.content;
        tokensUsed += aiResult.tokensUsed;
        aiGenerated = true;
      }

      content = content.replace(mapping.placeholder, transformedValue || '');
      if (transformedValue) {
        dataUsed.push(mapping.source);
      }
    }

    // If the section has an AI prompt and still has placeholders, use AI
    if (section.aiPrompt && content.includes('{{')) {
      const aiResult = await this.generateWithAI(
        section.aiPrompt,
        codeAnalysis,
        profile
      );
      content = aiResult.content;
      tokensUsed += aiResult.tokensUsed;
      aiGenerated = true;
    }

    return {
      content,
      dataUsed,
      aiGenerated,
      tokensUsed
    };
  }

  private extractValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  private async applyTransform(value: any, transform: string, fullAnalysis: CodeAnalysis): Promise<string> {
    try {
      // Try the template transformation service first
      return await templateTransformationService.transform(transform, value, fullAnalysis);
    } catch (error) {
      logger.warn('Template transformation failed, trying local fallback', { transform, error });
      
      // Try local method fallbacks for critical transforms
      try {
        switch (transform) {
          case 'generateOpenAPISpec':
            return this.generateOpenAPISpec(value, fullAnalysis);
          default:
            logger.error('No local fallback available for transform', { transform });
            return String(value || '');
        }
      } catch (fallbackError) {
        logger.error('Local fallback also failed', { transform, fallbackError });
        return String(value || '');
      }
    }
  }

  // Removed individual transform functions - now using templateTransformationService

  private generateOpenAPISpec(apis: APIEndpoint[], analysis: CodeAnalysis): string {
    const spec: any = {
      openapi: '3.0.0',
      info: {
        title: `${analysis.projectInfo.name} API`,
        version: '1.0.0',
        description: analysis.projectInfo.description
      },
      paths: {}
    };

    apis.forEach(api => {
      if (!spec.paths[api.path]) {
        spec.paths[api.path] = {};
      }
      
      spec.paths[api.path][api.method.toLowerCase()] = {
        summary: api.description,
        parameters: api.parameters?.map(param => ({
          name: param.name,
          in: 'query',
          required: param.required,
          schema: { type: param.type }
        })) || [],
        responses: api.responses || {
          '200': { description: 'Success' }
        }
      };
    });

    return require('js-yaml').dump(spec);
  }

  // Removed generateSchemaOverview - now using templateTransformationService

  private async generateWithAI(
    prompt: string,
    codeAnalysis: CodeAnalysis,
    profile?: ContextProfile
  ): Promise<{ content: string; tokensUsed: number }> {
    try {
      const context = `
Project Information:
- Name: ${codeAnalysis.projectInfo.name}
- Type: ${codeAnalysis.projectInfo.type}
- Language: ${codeAnalysis.projectInfo.language}
- Framework: ${codeAnalysis.projectInfo.framework || 'None'}

Project Statistics:
- API Endpoints: ${codeAnalysis.apis.length}
- Data Models: ${codeAnalysis.dataModels.length}
- Functions: ${codeAnalysis.functions.length}
- Dependencies: ${codeAnalysis.dependencies.length}

${prompt}
`;

      const result = await llmCircuitBreaker.execute(
        async () => {
          return await llmRouter.route({
            type: 'documentation',
            input: { prompt: context },
            options: { 
              preferLocal: false, // Use Claude for better documentation
              maxCost: 0.10,
              profile 
            }
          });
        },
        'LLM documentation generation'
      );

      return {
        content: result.data,
        tokensUsed: (result as any).tokensUsed || 0
      };
    } catch (error) {
      logger.error('LLM generation failed', { 
        error: error instanceof Error ? error.message : String(error),
        projectName: codeAnalysis.projectInfo.name,
        promptLength: prompt.length
      });
      
      throw new LLMError(
        `AI generation failed: ${error instanceof Error ? error.message : String(error)}`,
        {
          projectName: codeAnalysis.projectInfo.name,
          promptLength: prompt.length,
          originalError: error instanceof Error ? error.message : String(error)
        }
      );
    }
  }

  private calculateQualityMetrics(
    templates: GeneratedTemplate[],
    _analysis: CodeAnalysis
  ): QualityMetrics {
    let completeness = 0;
    let accuracy = 0;
    let readability = 0;

    // Calculate completeness based on filled sections
    const totalSections = templates.reduce((sum, t) => sum + t.sections.length, 0);
    const filledSections = templates.reduce((sum, t) => 
      sum + t.sections.filter(s => s.content.trim().length > 50).length, 0
    );
    completeness = (filledSections / totalSections) * 100;

    // Estimate accuracy based on data usage
    const dataUsedSections = templates.reduce((sum, t) => 
      sum + t.sections.filter(s => s.dataUsed.length > 0).length, 0
    );
    accuracy = (dataUsedSections / totalSections) * 100;

    // Estimate readability (simplified)
    readability = 80; // Base readability score

    const overall = (completeness + accuracy + readability) / 3;

    return {
      completeness: Math.round(completeness),
      accuracy: Math.round(accuracy),
      readability: Math.round(readability),
      overall: Math.round(overall)
    };
  }

  async parseChatlogs(chatLog: ChatLog): Promise<ExtractedRequirements> {
    return withErrorHandling(
      this._parseChatlogs.bind(this),
      'chat log parsing',
      60000 // 1 minute timeout
    )(chatLog);
  }

  private async _parseChatlogs(chatLog: ChatLog): Promise<ExtractedRequirements> {
    logger.info('Parsing chat logs for requirements extraction', {
      messageCount: chatLog.messages.length,
      platform: chatLog.platform
    });

    if (!chatLog.messages || chatLog.messages.length === 0) {
      throw new ValidationError('No messages provided in chat log');
    }

    // First, try to extract requirements directly from conversation text
    const conversationText = chatLog.messages.map(m => m.content).join('\n\n');
    const directExtraction = this.parseRequirementsFromText(conversationText);

    // If we found significant requirements, use them
    if (this.hasSignificantRequirements(directExtraction)) {
      logger.info('Extracted requirements directly from conversation');
      return directExtraction;
    }

    // Otherwise, use AI to analyze the conversation
    try {
      const prompt = `
Analyze the following chat conversation between a user and an AI assistant to extract software requirements.

Please identify and extract:

1. **Features & Functionality**: What features or capabilities were discussed?
2. **User Stories**: Convert discussions into user story format where possible
3. **Technical Requirements**: What technical specifications, frameworks, or constraints were mentioned?
4. **Business Rules**: What business logic or rules were discussed?
5. **Constraints**: Any limitations, deadlines, budget constraints, or technical restrictions

Format your response in sections with clear headings. Focus on extracting concrete, actionable requirements.

Chat Conversation:
${chatLog.messages.map(m => `**${m.role.toUpperCase()}**: ${m.content}`).join('\n\n')}

Platform: ${chatLog.platform}
Export Date: ${chatLog.exportDate?.toISOString() || 'Not specified'}
`;

      const result = await llmCircuitBreaker.execute(
        async () => {
          return await llmRouter.route({
            type: 'requirements',
            input: { prompt },
            options: { 
              preferLocal: false, 
              maxCost: 0.20
              // Note: temperature option not available in current router interface
            }
          });
        },
        'chat log analysis'
      );

      // Parse the AI response into structured requirements
      const aiExtraction = this.parseRequirementsFromText(result.data);
      
      // Merge direct extraction with AI extraction
      const mergedResults = this.mergeRequirements(directExtraction, aiExtraction);
      
      logger.info('Chat log analysis completed', {
        features: mergedResults.features.length,
        userStories: mergedResults.userStories.length,
        technicalRequirements: mergedResults.technicalRequirements.length,
        businessRules: mergedResults.businessRules.length,
        constraints: mergedResults.constraints.length
      });

      return mergedResults;
    } catch (error) {
      logger.warn('AI analysis failed, using direct extraction', { error: error instanceof Error ? error.message : String(error) });
      return directExtraction;
    }
  }

  private hasSignificantRequirements(requirements: ExtractedRequirements): boolean {
    const totalItems = 
      requirements.features.length +
      requirements.userStories.length +
      requirements.technicalRequirements.length +
      requirements.businessRules.length +
      requirements.constraints.length;
    
    return totalItems >= 3; // Need at least 3 extracted items to be considered significant
  }

  private mergeRequirements(
    direct: ExtractedRequirements, 
    ai: ExtractedRequirements
  ): ExtractedRequirements {
    return {
      features: this.mergeArrays(direct.features, ai.features, 'description'),
      userStories: this.mergeArrays(direct.userStories, ai.userStories, 'iWant'),
      technicalRequirements: this.mergeArrays(direct.technicalRequirements, ai.technicalRequirements, 'description'),
      businessRules: this.mergeArrays(direct.businessRules, ai.businessRules, 'description'),
      constraints: this.mergeArrays(direct.constraints, ai.constraints, 'description')
    };
  }

  private mergeArrays(arr1: any[], arr2: any[], compareField: string): any[] {
    const merged = [...arr1];
    
    for (const item of arr2) {
      const isDuplicate = merged.some(existing => {
        const existingText = existing[compareField]?.toLowerCase().trim() || '';
        const newText = item[compareField]?.toLowerCase().trim() || '';
        
        if (!existingText || !newText) return false;
        
        return existingText === newText || 
               (existingText.length > 10 && newText.includes(existingText)) ||
               (newText.length > 10 && existingText.includes(newText));
      });
      
      if (!isDuplicate) {
        merged.push({
          ...item,
          source: item.source || 'ai_analysis'
        });
      }
    }
    
    return merged;
  }

  private parseRequirementsFromText(text: string): ExtractedRequirements {
    try {
      // Try to parse as JSON first (if LLM returns structured data)
      const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/);
      if (jsonMatch) {
        try {
          return JSON.parse(jsonMatch[1] || '{}');
        } catch {
          // Continue with text parsing if JSON parsing fails
        }
      }

      // Parse structured text response
      const features = this.extractFeatures(text);
      const userStories = this.extractUserStories(text);
      const technicalRequirements = this.extractTechnicalRequirements(text);
      const businessRules = this.extractBusinessRules(text);
      const constraints = this.extractConstraints(text);

      return {
        features,
        userStories,
        technicalRequirements,
        businessRules,
        constraints
      };
    } catch (error) {
      logger.error('Failed to parse requirements from text', { error: error instanceof Error ? error.message : String(error) });
      return {
        features: [],
        userStories: [],
        technicalRequirements: [],
        businessRules: [],
        constraints: []
      };
    }
  }

  private extractSection(text: string, sectionName: string, regex: RegExp): any[] {
    const match = text.match(regex);
    if (!match || !match[1]) return [];

    const content = match[1].trim();
    const lines = content.split('\n').filter(line => line.trim());
    
    return lines.map(line => {
      // Remove bullet points and clean up
      const cleaned = line.replace(/^[-•*]\s*/, '').trim();
      if (cleaned.length < 5) return null;
      
      return {
        id: `${sectionName.replace(/\s+/g, '_')}_${Math.random().toString(36).substr(2, 9)}`,
        description: cleaned,
        source: 'chat_log',
        confidence: this.calculateConfidence(cleaned)
      };
    }).filter(Boolean);
  }

  private extractUserStories(text: string): any[] {
    const userStories: any[] = [];
    
    // Look for "As a ... I want ... so that ..." patterns
    const userStoryRegex = /as\s+(?:a|an)\s+([^,]+),?\s+I\s+want\s+to\s+([^.]+?)\s+so\s+that\s+([^.]+)/gi;
    let match;
    
    while ((match = userStoryRegex.exec(text)) !== null) {
      if (match[1] && match[2] && match[3]) {
        userStories.push({
          id: `user_story_${Math.random().toString(36).substr(2, 9)}`,
          asA: match[1].trim(),
          iWant: match[2].trim(),
          soThat: match[3].trim(),
          source: 'chat_log',
          confidence: 0.9 // High confidence for explicit user story format
        });
      }
    }

    // Also look for implicit user stories in conversation
    const implicitPatterns = [
      /(?:users?|customers?)\s+(?:should|need|want|require)\s+([^.]+)/gi,
      /(?:the system|application|app)\s+(?:should|must|needs? to)\s+([^.]+)/gi,
      /(?:I|we)\s+(?:need|want|require)\s+([^.]+)/gi
    ];

    implicitPatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        if (match[1]) {
          const requirement = match[1].trim();
          if (requirement.length > 10 && !this.isDuplicate(userStories, requirement)) {
          userStories.push({
            id: `user_story_${Math.random().toString(36).substr(2, 9)}`,
            asA: 'user',
            iWant: requirement,
            soThat: 'meet system requirements',
            source: 'chat_log_inferred',
            confidence: 0.6 // Lower confidence for inferred stories
          });
          }
        }
      }
    });

    return userStories;
  }

  private extractFeatures(text: string): any[] {
    const features: any[] = [];
    
    // Try structured extraction first
    const structuredFeatures = this.extractSection(text, 'features', /(?:^|\n)(?:## )?(?:features|functionality)(?::|\n)([\s\S]*?)(?=\n## |\n# |$)/i);
    features.push(...structuredFeatures);
    
    // Extract inline feature mentions
    const featurePatterns = [
      /(?:need|want|require)s?\s+(?:a|an)?\s*([\w\s]{5,30}(?:system|feature|functionality|component|module))/gi,
      /(?:build|create|implement|add)s?\s+(?:a|an)?\s*([\w\s]{5,30}(?:system|feature|functionality|component))/gi,
      /I\s+need\s+([\w\s]{10,50}(?:upload|management|browsing|authentication|registration)(?:\s+system)?)/gi,
      /(file\s+upload\s+system)/gi,
      /(drag\s+and\s+drop)/gi,
      /(progress\s+bars?)/gi,
      /(file\s+type\s+validation)/gi,
      /(organiz[e]\s+files\s+into\s+folders)/gi
    ];
    
    featurePatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        if (match[1]) {
          const description = match[1].trim();
          if (description.length > 10 && !this.isDuplicate(features, description)) {
          features.push({
            id: `feature_${Math.random().toString(36).substr(2, 9)}`,
            description,
            source: 'chat_log',
            confidence: this.calculateConfidence(description)
          });
          }
        }
      }
    });
    
    return features;
  }

  private extractTechnicalRequirements(text: string): any[] {
    const techRequirements: any[] = [];
    
    // Try structured extraction first
    const structuredTech = this.extractSection(text, 'technical requirements', /(?:^|\n)(?:## )?(?:technical requirements?|tech specs?)(?::|\n)([\s\S]*?)(?=\n## |\n# |$)/i);
    techRequirements.push(...structuredTech);
    
    // Extract specific technical mentions
    const techPatterns = [
      /(React\s+frontend(?:\s+framework)?)/gi,
      /(Node\.?js\s+(?:backend|server)(?:\s+with\s+Express)?)/gi,
      /(Express(?:\s+backend)?)/gi,
      /(PostgreSQL\s+database)/gi,
      /(JWT\s+(?:tokens?|authentication))/gi,
      /(REST\s+(?:API|endpoints?))/gi,
      /(?:use|with|using)\s+(React|Node\.?js|Express|PostgreSQL|JWT|MongoDB|MySQL)/gi,
      /(?:connect to|use)\s+(?:a\s+)?(PostgreSQL|MySQL|MongoDB)\s+database/gi,
      /(authentication\s+with\s+JWT\s+tokens?)/gi
    ];
    
    techPatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const description = match[1] || match[0];
        const cleanDescription = description.trim();
        
        if (cleanDescription.length > 5 && !this.isDuplicate(techRequirements, cleanDescription) && 
            !techRequirements.some(req => cleanDescription.toLowerCase().includes(req.description.toLowerCase()) || 
                                           req.description.toLowerCase().includes(cleanDescription.toLowerCase()))) {
          techRequirements.push({
            id: `tech_req_${Math.random().toString(36).substr(2, 9)}`,
            description: cleanDescription,
            source: 'chat_log',
            confidence: this.calculateConfidence(cleanDescription)
          });
        }
      }
    });
    
    return techRequirements;
  }

  private extractBusinessRules(text: string): any[] {
    const businessRules: any[] = [];
    
    // Try structured extraction first
    const structuredRules = this.extractSection(text, 'business rules', /(?:^|\n)(?:## )?(?:business rules?|business logic)(?::|\n)([\s\S]*?)(?=\n## |\n# |$)/i);
    businessRules.push(...structuredRules);
    
    // Extract inline business rules
    const rulePatterns = [
      /(Users?\s+must\s+verify\s+(?:their\s+)?email(?:\s+before\s+[\w\s]+)?)/gi,
      /((?:Free|Premium)\s+users?\s+(?:are\s+)?limited\s+to\s+[\w\s\d]+)/gi,
      /((?:Free|Premium)\s+users?\s+get\s+[\w\s\d]+)/gi,
      /(All\s+content\s+must\s+be\s+moderated)/gi,
      /((?:Users?|Customers?|Admins?)\s+(?:must|should|cannot)\s+[\w\s]+)/gi
    ];
    
    rulePatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        if (match[1]) {
          const description = match[1].trim();
          if (description.length > 10 && !this.isDuplicate(businessRules, description)) {
          businessRules.push({
            id: `business_rule_${Math.random().toString(36).substr(2, 9)}`,
            description,
            source: 'chat_log',
            confidence: this.calculateConfidence(description)
          });
          }
        }
      }
    });
    
    return businessRules;
  }

  private extractConstraints(text: string): any[] {
    const constraints: any[] = [];
    
    const constraintPatterns = [
      // Performance patterns - more flexible
      { pattern: /load\s+in\s+under\s+(\d+\s+seconds?)/gi, type: 'performance' },
      { pattern: /(\d+\s+seconds?)\s+(?:load|response|performance)/gi, type: 'performance' },
      { pattern: /(?:performance|speed|latency|load time).*?(\d+.*?(?:second|ms|millisecond))/gi, type: 'performance' },
      
      // Budget patterns
      { pattern: /budget.*?(?:limited to|under|maximum of)?\s*(\$[\d,]+)/gi, type: 'budget' },
      { pattern: /cost.*?under\s*(\$[\d,]+)/gi, type: 'budget' },
      { pattern: /(\$[\d,]+).*?budget/gi, type: 'budget' },
      
      // Timeline patterns
      { pattern: /deadline.*?(\d+\s+(?:months?|weeks?|days?))/gi, type: 'timeline' },
      { pattern: /(\d+\s+(?:months?|weeks?|days?)).*?deadline/gi, type: 'timeline' },
      
      // Security patterns
      { pattern: /(cannot\s+store\s+plain\s+text\s+passwords?)/gi, type: 'security' },
      { pattern: /(security\s+is\s+critical)/gi, type: 'security' },
      { pattern: /(must\s+(?:be\s+)?(?:secure|hash(?:ed)?)\s+passwords?)/gi, type: 'security' },
      
      // Platform/compatibility patterns
      { pattern: /(support\s+mobile\s+devices?)/gi, type: 'platform' },
      { pattern: /(mobile\s+(?:support|compatibility))/gi, type: 'platform' },
      { pattern: /(work\s+with.*?(?:existing|current).*?system)/gi, type: 'platform' },
      
      // Concurrent user patterns
      { pattern: /(support\s+\d+\+?\s+concurrent\s+users?)/gi, type: 'performance' },
      { pattern: /(\d+\+?\s+concurrent\s+users?)/gi, type: 'performance' }
    ];

    constraintPatterns.forEach(({ pattern, type }) => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const description = match[1] || match[0];
        const cleanDescription = description.trim();
        
        if (cleanDescription.length > 5 && !this.isDuplicate(constraints, cleanDescription)) {
          constraints.push({
            id: `constraint_${Math.random().toString(36).substr(2, 9)}`,
            type,
            description: cleanDescription,
            impact: this.assessImpact(cleanDescription),
            source: 'chat_log',
            confidence: this.calculateConfidence(cleanDescription)
          });
        }
      }
    });

    return constraints;
  }

  private calculateConfidence(text: string): number {
    let confidence = 0.5; // Base confidence
    
    // Increase confidence for specific technical terms
    const technicalTerms = ['api', 'database', 'authentication', 'endpoint', 'frontend', 'backend', 'server', 'client', 'jwt', 'token', 'rest', 'postgresql', 'mysql', 'mongodb', 'react', 'node', 'express', 'framework'];
    const foundTerms = technicalTerms.filter(term => text.toLowerCase().includes(term));
    confidence += foundTerms.length * 0.15;
    
    // Increase confidence for detailed descriptions
    if (text.length > 50) confidence += 0.1;
    if (text.includes('should') || text.includes('must') || text.includes('require')) confidence += 0.15;
    
    // Decrease confidence for vague language
    if (text.includes('maybe') || text.includes('perhaps') || text.includes('possibly')) confidence -= 0.2;
    
    return Math.min(0.95, Math.max(0.1, confidence));
  }

  private isDuplicate(existing: any[], newText: string): boolean {
    return existing.some(item => {
      const existingText = item.description?.toLowerCase().trim() || '';
      const compareText = newText.toLowerCase().trim();
      
      return existingText === compareText || 
             (existingText.length > 10 && compareText.includes(existingText)) ||
             (compareText.length > 10 && existingText.includes(compareText));
    });
  }

  private assessImpact(description: string): 'low' | 'medium' | 'high' {
    const highImpactTerms = ['critical', 'must', 'security', 'cannot', '1000+', 'concurrent', 'performance'];
    const mediumImpactTerms = ['should', 'important', 'prefer', 'timeline'];
    
    const text = description.toLowerCase();
    
    if (highImpactTerms.some(term => text.includes(term))) {
      return 'high';
    } else if (mediumImpactTerms.some(term => text.includes(term))) {
      return 'medium';
    }
    
    return 'low';
  }

  async analyzeCodeForDocumentation(
    files: Map<string, string>,
    projectPath: string
  ): Promise<CodeAnalysis> {
    return withErrorHandling(
      this._analyzeCodeForDocumentation.bind(this),
      `code analysis for project ${projectPath}`,
      120000 // 2 minute timeout
    )(files, projectPath);
  }

  private async _analyzeCodeForDocumentation(
    files: Map<string, string>,
    projectPath: string
  ): Promise<CodeAnalysis> {
    logger.info('🔍 Starting multi-language code analysis for documentation', {
      fileCount: files.size,
      projectPath,
      fileTypes: Array.from(files.keys()).map(f => f.split('.').pop()).filter((ext, i, arr) => arr.indexOf(ext) === i)
    });

    if (files.size === 0) {
      throw new CodeAnalysisError('No files provided for analysis');
    }

    try {
      // Use the new multi-language parser integration service
      const analysis = await this.parserIntegrationService.analyzeCodebase(files, {
        includePrivate: false,
        includeTests: true,
        maxDepth: 10,
        followImports: false,
        primaryLanguageOnly: false // Enable multi-language analysis
      });

      logger.info('✅ Multi-language code analysis completed successfully', {
        projectName: analysis.projectInfo.name,
        projectType: analysis.projectInfo.type,
        primaryLanguage: analysis.projectInfo.language,
        framework: analysis.projectInfo.framework,
        summary: {
          apis: analysis.apis.length,
          functions: analysis.functions.length,
          dataModels: analysis.dataModels.length,
          dependencies: analysis.dependencies.length,
          testCoverage: analysis.testCoverage.coverage
        },
        architecture: analysis.architecture.style,
        businessRules: analysis.businessLogic.length
      });

      // Enhance analysis with documentation-specific enrichments
      return this.enrichAnalysisForDocumentation(analysis, projectPath);
    } catch (error) {
      logger.error('❌ Multi-language code analysis failed', {
        fileCount: files.size,
        projectPath,
        error: error instanceof Error ? error.message : String(error)
      });

      // Fallback to basic analysis if multi-language analysis fails
      logger.warn('⚠️ Falling back to basic analysis due to multi-language analysis failure');
      return this.fallbackAnalysis(files, projectPath, error);
    }
  }

  /**
   * Enhance the multi-language analysis with documentation-specific enrichments
   */
  private async enrichAnalysisForDocumentation(
    analysis: CodeAnalysis,
    _projectPath: string
  ): Promise<CodeAnalysis> {
    logger.info('🔧 Enriching analysis for documentation generation');

    try {
      // Add documentation-specific metadata
      const enhancedAnalysis = {
        ...analysis,
        projectInfo: {
          ...analysis.projectInfo,
          // Add additional project metadata if available
          version: await this.extractVersion(analysis),
          license: await this.extractLicense(analysis),
          repository: await this.extractRepository(analysis)
        }
      };

      return enhancedAnalysis;
    } catch (error) {
      logger.warn('⚠️ Failed to enrich analysis, using original', {
        error: error instanceof Error ? error.message : String(error)
      });
      return analysis;
    }
  }

  /**
   * Fallback analysis when multi-language analysis fails
   */
  private async fallbackAnalysis(
    files: Map<string, string>,
    projectPath: string,
    originalError: any
  ): Promise<CodeAnalysis> {
    logger.info('🔄 Performing fallback analysis with basic extraction');

    try {
      // Use basic extraction methods as fallback
      const projectInfo = await this.safeExtract(() => this.extractProjectInfo(files, projectPath), 'project info');
      const apis = await this.safeExtract(() => this.extractAPIs(files), 'APIs');
      const dataModels = await this.safeExtract(() => this.extractDataModels(files), 'data models');
      const functions = await this.safeExtract(() => this.extractFunctions(files), 'functions');
      const dependencies = await this.safeExtract(() => this.extractDependencies(files), 'dependencies');
      const testCoverage = await this.safeExtract(() => this.extractTestMetrics(files), 'test metrics');
      const architecture = await this.safeExtract(() => this.analyzeArchitecture(files), 'architecture');
      const businessLogic = await this.safeExtract(() => this.extractBusinessLogic(files), 'business logic');
      const fileStructure = await this.safeExtract(() => this.analyzeFileStructure(files, projectPath), 'file structure');

      logger.info('✅ Fallback analysis completed successfully');

      return {
        projectInfo,
        apis,
        dataModels,
        functions,
        dependencies,
        testCoverage,
        architecture,
        businessLogic,
        fileStructure
      };
    } catch (fallbackError) {
      logger.error('❌ Fallback analysis also failed', {
        originalError: originalError instanceof Error ? originalError.message : String(originalError),
        fallbackError: fallbackError instanceof Error ? fallbackError.message : String(fallbackError)
      });
      
      throw new CodeAnalysisError(
        `Both multi-language and fallback analysis failed. Original: ${originalError}. Fallback: ${fallbackError}`,
        { fileCount: files.size, projectPath }
      );
    }
  }

  private async extractVersion(analysis: CodeAnalysis): Promise<string | undefined> {
    // Try to extract version from dependencies or project info
    const packageJsonDep = analysis.dependencies.find(d => d.source?.endsWith('package.json'));
    if (packageJsonDep) {
      // Version would be in the raw package.json, which we don't have access to here
      // This is a placeholder for future enhancement
    }
    return undefined;
  }

  private async extractLicense(_analysis: CodeAnalysis): Promise<string | undefined> {
    // Placeholder for license extraction
    return undefined;
  }

  private async extractRepository(_analysis: CodeAnalysis): Promise<string | undefined> {
    // Placeholder for repository URL extraction
    return undefined;
  }

  private async safeExtract<T>(
    extractFn: () => Promise<T> | T,
    context: string
  ): Promise<T> {
    try {
      return await extractFn();
    } catch (error) {
      logger.warn(`Failed to extract ${context}`, { error: error instanceof Error ? error.message : String(error) });
      
      // Return safe defaults based on context
      switch (context) {
        case 'project info':
          return {
            name: 'Unknown Project',
            description: 'Project description could not be determined',
            type: 'application',
            language: 'unknown'
          } as T;
        case 'APIs':
        case 'data models':
        case 'functions':
        case 'dependencies':
        case 'business logic':
          return [] as T;
        case 'test metrics':
          return {
            coverage: 0,
            testFiles: 0,
            testCases: 0,
            passingTests: 0,
            failingTests: 0
          } as T;
        case 'architecture':
          return {
            pattern: 'Unknown',
            layers: [],
            components: []
          } as T;
        case 'file structure':
          return {
            rootDir: 'unknown',
            structure: { name: 'root', type: 'directory', path: '/', children: [] },
            totalFiles: 0,
            linesOfCode: 0,
            directories: [],
            mainFiles: []
          } as T;
        default:
          throw error;
      }
    }
  }

  private async extractProjectInfo(
    files: Map<string, string>,
    projectPath: string
  ): Promise<CodeAnalysis['projectInfo']> {
    // Look for package.json, README, or other project files
    const packageJson = files.get('package.json');
    // const _readme = files.get('README.md'); // May be used for enhanced description extraction in future
    
    let name = path.basename(projectPath);
    let description = '';
    let type = 'application';
    let language = 'javascript';
    let framework = undefined;

    if (packageJson) {
      try {
        const pkg = JSON.parse(packageJson);
        name = pkg.name || name;
        description = pkg.description || '';
        
        // Detect framework from dependencies
        const deps = { ...pkg.dependencies, ...pkg.devDependencies };
        if (deps.react) framework = 'react';
        else if (deps.vue) framework = 'vue';
        else if (deps.express) framework = 'express';
        else if (deps.next) framework = 'nextjs';
      } catch (e) {
        logger.error('Failed to parse package.json', { error: e });
      }
    }

    // Detect language from file extensions
    const extensions = Array.from(files.keys()).map(f => path.extname(f));
    if (extensions.some(ext => ext === '.ts' || ext === '.tsx')) {
      language = 'typescript';
    } else if (extensions.some(ext => ext === '.py')) {
      language = 'python';
    }

    return { name, description, type, language, framework };
  }

  private async extractAPIs(files: Map<string, string>): Promise<APIEndpoint[]> {
    const apis: APIEndpoint[] = [];
    
    // Look for Express routes, REST endpoints, etc.
    for (const [filename, content] of files.entries()) {
      if (this.isAPIFile(filename)) {
        const fileApis = this.parseAPIEndpoints(content, filename);
        apis.push(...fileApis);
      }
    }

    return apis;
  }

  private isAPIFile(filename: string): boolean {
    const apiPatterns = [
      /route/i, /api/i, /controller/i, /endpoint/i, /handler/i,
      /server\.ts$/, /server\.js$/, /app\.ts$/, /app\.js$/
    ];
    
    return apiPatterns.some(pattern => pattern.test(filename));
  }

  private parseAPIEndpoints(content: string, _filename: string): APIEndpoint[] {
    const apis: APIEndpoint[] = [];
    
    // Express.js route patterns
    const expressRouteRegex = /(?:router|app)\.(get|post|put|delete|patch)\s*\(\s*['"`]([^'"`]+)['"`]\s*,?\s*(?:.*?(?:async\s+)?\([^)]*\)\s*=>\s*{|.*?function[^(]*\([^)]*\)\s*{)/g;
    
    let match;
    
    // Parse Express.js routes
    while ((match = expressRouteRegex.exec(content)) !== null) {
      if (match[1] && match[2]) {
        const method = match[1].toUpperCase();
        const path = match[2];
      
      apis.push({
        method,
        path,
        description: this.extractRouteDescription(content, match.index),
        parameters: this.extractRouteParameters(content, match.index, path),
        responses: this.extractRouteResponses(content, match.index),
        authentication: this.detectAuthentication(content, match.index)
      });
      }
    }
    
    return apis;
  }

  private extractRouteDescription(content: string, routeIndex: number): string {
    // Look for comments above the route
    const beforeRoute = content.substring(0, routeIndex);
    const lines = beforeRoute.split('\n');
    
    // Check the last few lines for comments
    for (let i = lines.length - 1; i >= Math.max(0, lines.length - 5); i--) {
      const line = lines[i]?.trim() || '';
      
      // Single line comment
      if (line.startsWith('//') || line.startsWith('#')) {
        const comment = line.replace(/^(\/\/|#)\s*/, '');
        if (comment.length > 10) { // Meaningful comment
          return comment;
        }
      }
      
      // Multi-line comment
      if (line.includes('*/')) {
        const commentMatch = line.match(/\*\s*(.+)/);
        if (commentMatch && commentMatch[1] && commentMatch[1].length > 10) {
          return commentMatch[1] || 'API endpoint';
        }
      }
    }
    
    return 'API endpoint'; // Default description
  }

  private extractRouteParameters(content: string, routeIndex: number, path: string): Parameter[] {
    const parameters: Parameter[] = [];
    
    // Extract path parameters (e.g., /users/:id)
    const pathParamRegex = /:(\w+)/g;
    let pathMatch;
    while ((pathMatch = pathParamRegex.exec(path)) !== null) {
      parameters.push({
        name: pathMatch[1] || 'param',
        type: 'string',
        required: true,
        description: `Path parameter: ${pathMatch[1] || 'param'}`
      });
    }
    
    // Look for query parameters in the route function
    const afterRoute = content.substring(routeIndex, routeIndex + 500); // Look ahead 500 chars
    
    // Common query parameter patterns
    const queryPatterns = [
      /req\.query\.(\w+)/g,
      /req\.params\.(\w+)/g
    ];
    
    queryPatterns.forEach(regex => {
      let match;
      while ((match = regex.exec(afterRoute)) !== null) {
        const paramName = match[1];
        if (!parameters.find(p => p.name === paramName)) {
          parameters.push({
            name: paramName || 'queryParam',
            type: 'string',
            required: false,
            description: `Query parameter: ${paramName || 'queryParam'}`
          });
        }
      }
    });
    
    return parameters;
  }

  private extractRouteResponses(content: string, routeIndex: number): Record<string, any> {
    const responses: Record<string, any> = {};
    
    // Look for response patterns in the route function
    const afterRoute = content.substring(routeIndex, routeIndex + 1000); // Look ahead 1000 chars
    
    // Common response patterns
    const responsePatterns = [
      { regex: /res\.status\((\d+)\)/g, extract: (match: RegExpExecArray) => match[1] },
      { regex: /res\.json\(/g, extract: () => '200' }
    ];
    
    responsePatterns.forEach(({ regex, extract }) => {
      let match;
      while ((match = regex.exec(afterRoute)) !== null) {
        const statusCode = extract(match);
        if (statusCode && !responses[statusCode]) {
          responses[statusCode] = {
            description: this.getResponseDescription(statusCode)
          };
        }
      }
    });
    
    // Default success response if none found
    if (Object.keys(responses).length === 0) {
      responses['200'] = { description: 'Success' };
    }
    
    return responses;
  }

  private detectAuthentication(content: string, routeIndex: number): string | undefined {
    const beforeRoute = content.substring(Math.max(0, routeIndex - 200), routeIndex);
    const afterRoute = content.substring(routeIndex, routeIndex + 300);
    const context = beforeRoute + afterRoute;
    
    // Authentication patterns
    const authPatterns = [
      { regex: /auth(?:entication|orization)?/i, type: 'Authentication required' },
      { regex: /bearer\s+token/i, type: 'Bearer token' },
      { regex: /jwt/i, type: 'JWT token' },
      { regex: /api[_-]?key/i, type: 'API key' },
      { regex: /passport/i, type: 'Passport authentication' },
      { regex: /middleware.*auth/i, type: 'Authentication middleware' }
    ];
    
    for (const { regex, type } of authPatterns) {
      if (regex.test(context)) {
        return type;
      }
    }
    
    return undefined;
  }

  private getResponseDescription(statusCode: string): string {
    const statusDescriptions: Record<string, string> = {
      '200': 'Success',
      '201': 'Created',
      '400': 'Bad Request',
      '401': 'Unauthorized',
      '403': 'Forbidden',
      '404': 'Not Found',
      '422': 'Unprocessable Entity',
      '500': 'Internal Server Error'
    };
    
    return statusDescriptions[statusCode] || 'Response';
  }

  private async extractDataModels(files: Map<string, string>): Promise<DataModel[]> {
    const models: DataModel[] = [];
    
    // Look for database schemas, Prisma models, TypeORM entities, etc.
    for (const [filename, content] of files.entries()) {
      if (this.isSchemaFile(filename)) {
        const fileModels = this.parseDataModels(content, filename);
        models.push(...fileModels);
      }
    }

    return models;
  }

  private isSchemaFile(filename: string): boolean {
    const schemaPatterns = [
      /schema/i, /model/i, /entity/i,
      /\\.prisma$/, /\\.sql$/, /migration/i,
      /database/i, /db/i
    ];
    
    return schemaPatterns.some(pattern => pattern.test(filename));
  }

  private parseDataModels(content: string, filename: string): DataModel[] {
    const models: DataModel[] = [];
    
    if (filename.endsWith('.prisma')) {
      return this.parsePrismaModels(content);
    }
    
    // Add support for other schema types (TypeORM, Sequelize, etc.)
    if (filename.includes('entity') || content.includes('@Entity')) {
      return this.parseTypeORMModels(content);
    }
    
    return models;
  }

  private parsePrismaModels(content: string): DataModel[] {
    const models: DataModel[] = [];
    
    // Prisma model regex pattern
    const modelRegex = /model\\s+(\\w+)\\s*{([^}]*)}/g;
    let match;
    
    while ((match = modelRegex.exec(content)) !== null) {
      const modelName = match[1];
      const modelBody = match[2];
      
      const fields = this.parsePrismaFields(modelBody || '');
      const relationships = this.parsePrismaRelationships(modelBody || '', modelName || 'Model');
      const indexes = this.parsePrismaIndexes(modelBody || '');
      
      models.push({
        name: modelName || 'Model',
        type: 'table',
        fields,
        relationships,
        indexes
      });
    }
    
    return models;
  }

  private parsePrismaFields(modelBody: string): Field[] {
    const fields: Field[] = [];
    const lines = modelBody.split('\\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('@@') || trimmed.startsWith('//')) {
        continue;
      }
      
      // Field pattern: fieldName Type @attributes
      const fieldMatch = trimmed.match(/^(\\w+)\\s+(\\w+)(\\??|\\[\\])?\\s*(.*)?$/);
      if (fieldMatch) {
        const [, name, type, optional, attributes] = fieldMatch;
        
        fields.push({
          name: name || 'field',
          type: this.normalizePrismaType(type || 'String'),
          required: !optional?.includes('?'),
          description: this.extractFieldDescription(attributes || ''),
          constraints: this.extractFieldConstraints(attributes || '')
        });
      }
    }
    
    return fields;
  }

  private parsePrismaRelationships(modelBody: string, _modelName: string): Relationship[] {
    const relationships: Relationship[] = [];
    const lines = modelBody.split('\\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      
      // Look for relationship fields
      const relationMatch = trimmed.match(/^(\\w+)\\s+(\\w+)(\\[\\])?\\s*@relation/);
      if (relationMatch) {
        const [, fieldName, targetType, isArray] = relationMatch;
        
        relationships.push({
          type: isArray ? 'one-to-many' : 'one-to-one',
          target: targetType || 'unknown',
          field: fieldName || 'id'
        });
      }
    }
    
    return relationships;
  }

  private parsePrismaIndexes(modelBody: string): string[] {
    const indexes: string[] = [];
    const lines = modelBody.split('\\n');
    
    for (const line of lines) {
      const trimmed = line.trim();
      
      // Look for index definitions
      if (trimmed.includes('@unique') || trimmed.includes('@id')) {
        const fieldMatch = trimmed.match(/^(\\w+)/);
        if (fieldMatch) {
          indexes.push(fieldMatch[1] || '');
        }
      }
      
      // Look for compound indexes
      const compoundMatch = trimmed.match(/@@index\\(\\[([^\\]]+)\\]/);
      if (compoundMatch) {
        indexes.push(compoundMatch[1]?.replace(/[\"'\\s]/g, '') || '');
      }
    }
    
    return indexes;
  }

  private parseTypeORMModels(content: string): DataModel[] {
    const models: DataModel[] = [];
    
    // TypeORM entity pattern
    const entityRegex = /@Entity\\(\\)\\s*export\\s+class\\s+(\\w+)/g;
    let match;
    
    while ((match = entityRegex.exec(content)) !== null) {
      const modelName = match[1];
      
      // Extract fields from the class
      const classStart = content.indexOf(match[0]);
      const classBody = this.extractClassBody(content, classStart);
      
      if (classBody) {
        const fields = this.parseTypeORMFields(classBody);
        
        models.push({
          name: modelName || 'Entity',
          type: 'entity',
          fields,
          relationships: [] // Could be enhanced to parse TypeORM relationships
        });
      }
    }
    
    return models;
  }

  private parseTypeORMFields(classBody: string): Field[] {
    const fields: Field[] = [];
    
    // TypeORM column pattern
    const columnRegex = /@Column\\([^)]*\\)\\s*([\\w!?]+)\\s*:\\s*(\\w+)/g;
    let match;
    
    while ((match = columnRegex.exec(classBody)) !== null) {
      const [, fieldName, fieldType] = match;
      
      fields.push({
        name: fieldName?.replace(/[!?]/g, '') || 'field',
        type: this.normalizeTypeScriptType(fieldType || 'any'),
        required: !fieldName?.includes('?'),
        description: `TypeORM column: ${fieldName || 'field'}`
      });
    }
    
    return fields;
  }

  private extractClassBody(content: string, classStart: number): string | null {
    const openBrace = content.indexOf('{', classStart);
    if (openBrace === -1) return null;
    
    let braceCount = 1;
    let i = openBrace + 1;
    
    while (i < content.length && braceCount > 0) {
      if (content[i] === '{') braceCount++;
      if (content[i] === '}') braceCount--;
      i++;
    }
    
    return content.substring(openBrace + 1, i - 1);
  }

  private normalizePrismaType(prismaType: string): string {
    const typeMap: Record<string, string> = {
      'String': 'string',
      'Int': 'number',
      'Float': 'number',
      'Boolean': 'boolean',
      'DateTime': 'date',
      'Json': 'object'
    };
    
    return typeMap[prismaType] || prismaType.toLowerCase();
  }

  private normalizeTypeScriptType(tsType: string): string {
    const typeMap: Record<string, string> = {
      'string': 'string',
      'number': 'number',
      'boolean': 'boolean',
      'Date': 'date'
    };
    
    return typeMap[tsType] || tsType;
  }

  private extractFieldDescription(attributes: string): string {
    // Extract description from comments or decorators
    if (attributes.includes('//')) {
      const comment = attributes.split('//')[1]?.trim();
      if (comment) return comment;
    }
    
    return '';
  }

  private extractFieldConstraints(attributes: string): string[] {
    const constraints: string[] = [];
    
    if (attributes.includes('@unique')) {
      constraints.push('unique');
    }
    
    if (attributes.includes('@id')) {
      constraints.push('primary_key');
    }
    
    if (attributes.includes('@default')) {
      constraints.push('has_default');
    }
    
    return constraints;
  }

  private async extractFunctions(files: Map<string, string>): Promise<FunctionSignature[]> {
    const functions: FunctionSignature[] = [];
    
    // Process JavaScript/TypeScript files for function extraction
    for (const [filename, content] of files.entries()) {
      if (this.isCodeFile(filename)) {
        const fileFunctions = this.parseFunctionSignatures(content, filename);
        functions.push(...fileFunctions);
      }
    }
    
    return functions;
  }

  private isCodeFile(filename: string): boolean {
    const codeExtensions = ['.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs'];
    return codeExtensions.some(ext => filename.endsWith(ext)) && 
           !filename.includes('.test.') && 
           !filename.includes('.spec.') && 
           !filename.includes('.d.ts'); // Skip test and declaration files
  }

  private parseFunctionSignatures(content: string, _filename: string): FunctionSignature[] {
    const functions: FunctionSignature[] = [];
    const processedNames = new Set<string>(); // Prevent duplicates
    
    // Function declaration patterns for JavaScript/TypeScript
    const patterns = [
      // Regular function declarations: function myFunc(params) { }
      {
        regex: /(?:^|\n)\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)\s*(?::\s*([^{]+?))?\s*\{/gm,
        type: 'function_declaration'
      },
      // Arrow functions with simple params: const myFunc = (params) => { }
      {
        regex: /(?:^|\n)\s*(?:export\s+)?const\s+(\w+)\s*=\s*(?:async\s+)?\(([^)]*)\)\s*(?::\s*([^=]+?))?\s*=>/gm,
        type: 'arrow_function'
      },
      // Arrow functions with destructuring: const myFunc = async ({ param1, param2 }, callback?) => {}
      {
        regex: /(?:^|\n)\s*(?:export\s+)?const\s+(\w+)\s*=\s*(?:async\s+)?(\([^)]*\))\s*(?::\s*([^=]+?))?\s*=>/gm,
        type: 'arrow_function_complex'
      },
      // Method definitions in classes with various indentation: methodName(params) { }
      {
        regex: /(?:^|\n)\s{2,}(?:public|private|protected|static)?\s*(?:async\s+)?(\w+)\s*\(([^)]*)\)\s*(?::\s*([^{]+?))?\s*\{/gm,
        type: 'method'
      }
    ];

    patterns.forEach(({ regex, type }) => {
      let match;
      regex.lastIndex = 0; // Reset regex state
      
      while ((match = regex.exec(content)) !== null) {
        const functionName = match[1];
        let paramString = match[2] || '';
        let returnType = 'void';
        
        // Handle different pattern types
        if (type === 'arrow_function_complex') {
          // For complex arrow functions, the parameter might be in match[2] differently
          paramString = match[2] || '';
          if (match[3]) {
            returnType = match[3].trim();
          }
        } else {
          if (match[3]) {
            returnType = match[3].trim();
          }
        }

        // Skip invalid function names and duplicates
        if (!functionName || 
            functionName.length < 2 || 
            ['if', 'for', 'while', 'catch', 'try', 'switch', 'case'].includes(functionName.toLowerCase()) ||
            functionName === 'constructor' || 
            functionName.startsWith('get') || 
            functionName.startsWith('set') ||
            processedNames.has(functionName)) {
          continue;
        }

        // Validate that this is actually a function by checking context
        const beforeMatch = content.substring(Math.max(0, match.index - 50), match.index);
        const afterMatch = content.substring(match.index + match[0].length, match.index + match[0].length + 20);
        
        // Skip if this looks like it's inside a comment or string
        if (beforeMatch.includes('//') || beforeMatch.includes('/*') || afterMatch.includes('*/')) {
          continue;
        }

        // Find function body based on pattern type
        let functionBody = '';
        if (type === 'function_expression') {
          // For function expressions, we need to find the body differently
          const bodyStart = content.indexOf('{', match.index);
          if (bodyStart > -1) {
            functionBody = this.extractFunctionBody(content, bodyStart);
          } else {
            functionBody = '{}'; // Minimal body for expression without braces
          }
        } else if (type.includes('arrow_function')) {
          // For arrow functions, body might start with { or be an expression
          const arrowIndex = content.indexOf('=>', match.index);
          if (arrowIndex > -1) {
            const bodyStart = content.indexOf('{', arrowIndex);
            if (bodyStart > -1) {
              functionBody = this.extractFunctionBody(content, bodyStart);
            } else {
              // Expression body, estimate a single line
              const lineEnd = content.indexOf('\n', arrowIndex);
              functionBody = content.substring(arrowIndex + 2, lineEnd > -1 ? lineEnd : arrowIndex + 50);
            }
          }
        } else {
          // Regular function declarations and methods
          const braceIndex = content.indexOf('{', match.index);
          if (braceIndex > -1) {
            functionBody = this.extractFunctionBody(content, braceIndex);
          }
        }

        const parameters = this.parseParameters(paramString);
        const complexity = this.calculateCyclomaticComplexity(functionBody);
        const linesOfCode = Math.max(1, functionBody.split('\n').filter(line => line.trim()).length);
        const description = this.extractFunctionDescription(content, match.index, functionName);

        functions.push({
          name: functionName,
          description,
          parameters,
          returnType: this.normalizeReturnType(returnType),
          complexity,
          linesOfCode,
          testCoverage: this.estimateTestCoverage(functionName, content)
        });
        
        processedNames.add(functionName);
      }
    });

    return functions;
  }

  private extractFunctionBody(content: string, startIndex: number): string {
    let braceCount = 0;
    let inFunction = false;
    let body = '';
    
    for (let i = startIndex; i < content.length; i++) {
      const char = content[i];
      
      if (char === '{') {
        braceCount++;
        inFunction = true;
      } else if (char === '}') {
        braceCount--;
      }
      
      if (inFunction) {
        body += char;
      }
      
      if (inFunction && braceCount === 0) {
        break;
      }
    }
    
    return body;
  }

  private parseParameters(paramString: string): Parameter[] {
    const parameters: Parameter[] = [];
    
    if (!paramString.trim()) {
      return parameters;
    }
    
    // Split parameters by comma, but be careful of destructuring and default values
    const params = this.smartSplitParameters(paramString);
    
    params.forEach(param => {
      const trimmed = param.trim();
      if (!trimmed) return;
      
      // Handle destructuring patterns { name, age, email }: UserData
      if (trimmed.startsWith('{') && trimmed.includes('}')) {
        const destructureMatch = trimmed.match(/\{\s*([^}]+)\s*\}\s*(?::\s*([^=]+))?(?:\s*=\s*(.+))?$/);
        if (destructureMatch) {
          const [, fields, type, defaultValue] = destructureMatch;
          const fieldNames = fields?.split(',').map(f => f.trim().split(':')[0]?.trim() || '') || [];
          
          // For destructuring, create one parameter representing the object
          if (fieldNames.length > 0) {
            parameters.push({
              name: `{${fieldNames.slice(0, 3).join(', ')}${fieldNames.length > 3 ? ', ...' : ''}}`,
              type: this.normalizeParameterType(type?.trim() || 'object'),
              required: !defaultValue,
              description: `Destructured object with ${fieldNames.length} fields`
            });
          }
          return;
        }
      }
      
      // Handle rest parameters: ...args: type[]
      const restMatch = trimmed.match(/^(\.\.\.(\w+))(?::\s*([^=]+))?(?:\s*=\s*(.+))?$/);
      if (restMatch) {
        const [, fullName, name, type, defaultValue] = restMatch;
        parameters.push({
          name: fullName || 'restParam',
          type: this.normalizeParameterType(type?.trim() || 'array'),
          required: !defaultValue,
          description: this.generateParameterDescription(name || 'parameter', type?.trim() || 'array')
        });
        return;
      }
      
      // Handle regular parameters: name: type = default
      const paramMatch = trimmed.match(/^(\w+)(\??)?(?::\s*([^=]+?))?(?:\s*=\s*(.+))?$/);
      if (paramMatch) {
        const [, name, optional, type, defaultValue] = paramMatch;
        
        parameters.push({
          name: name || 'param',
          type: this.normalizeParameterType(type?.trim() || 'any'),
          required: !optional && !defaultValue,
          description: this.generateParameterDescription(name || 'parameter', type?.trim() || 'any')
        });
      } else {
        // Fallback for complex patterns
        const simpleName = trimmed.split(/[:\s=]/)[0]?.replace(/[{}[\]]/g, '').trim() || '';
        if (simpleName && simpleName.length > 0) {
          parameters.push({
            name: simpleName,
            type: 'any',
            required: !trimmed.includes('='),
            description: `Parameter: ${simpleName}`
          });
        }
      }
    });
    
    return parameters;
  }

  private smartSplitParameters(paramString: string): string[] {
    const params: string[] = [];
    let current = '';
    let depth = 0;
    let inString = false;
    let stringChar = '';
    
    for (let i = 0; i < paramString.length; i++) {
      const char = paramString[i];
      const prev = paramString[i - 1];
      
      if (!inString && (char === '"' || char === "'" || char === '`')) {
        inString = true;
        stringChar = char;
      } else if (inString && char === stringChar && prev !== '\\') {
        inString = false;
      } else if (!inString) {
        if (char === '(' || char === '{' || char === '[') {
          depth++;
        } else if (char === ')' || char === '}' || char === ']') {
          depth--;
        } else if (char === ',' && depth === 0) {
          params.push(current.trim());
          current = '';
          continue;
        }
      }
      
      current += char;
    }
    
    if (current.trim()) {
      params.push(current.trim());
    }
    
    return params;
  }

  private calculateCyclomaticComplexity(functionBody: string): number {
    let complexity = 1; // Base complexity
    
    // Count decision points
    const decisionPatterns = [
      /\bif\s*\(/g,
      /\belse\s+if\s*\(/g,
      /\bwhile\s*\(/g,
      /\bfor\s*\(/g,
      /\bswitch\s*\(/g,
      /\bcase\s+/g,
      /\bcatch\s*\(/g,
      /\?\s*[^:]+:/g, // Ternary operators
      /&&/g,
      /\|\|/g
    ];
    
    decisionPatterns.forEach(pattern => {
      const matches = functionBody.match(pattern);
      if (matches) {
        complexity += matches.length;
      }
    });
    
    return Math.min(complexity, 10); // Cap at 10
  }

  private extractFunctionDescription(content: string, functionIndex: number, functionName: string): string {
    // Look for JSDoc comments or regular comments above the function
    const beforeFunction = content.substring(0, functionIndex);
    const lines = beforeFunction.split('\n');
    
    // Check for JSDoc comments
    for (let i = lines.length - 1; i >= Math.max(0, lines.length - 10); i--) {
      const line = lines[i]?.trim() || '';
      
      // JSDoc comment block
      if (line.includes('*/')) {
        let description = '';
        for (let j = i; j >= 0; j--) {
          const commentLine = lines[j]?.trim() || '';
          if (commentLine.includes('/**') || commentLine.includes('/*')) {
            break; // Stop at start of comment block
          }
          
          // Extract description from comment lines
          const descMatch = commentLine.match(/^\*\s*(.+)$/);
          if (descMatch) {
            const desc = descMatch[1]?.trim() || '';
            if (!desc.startsWith('@') && !desc.includes('*/') && desc.length > 0) {
              description = desc + (description ? '. ' + description : '');
            }
          }
        }
        
        // Clean up description
        if (description) {
          return description
            .replace(/^\s*\*?\s*/, '') // Remove leading * and spaces
            .replace(/\s*\*?\s*$/, '') // Remove trailing * and spaces
            .replace(/\s*\/\s*$/, '') // Remove trailing /
            .replace(/\s*\.\s*$/, '') // Remove trailing period and spaces
            .trim();
        }
      }
      
      // Single line comment
      if (line.startsWith('//')) {
        const comment = line.replace(/^\/\/\s*/, '');
        if (comment.length > 5 && !comment.includes('TODO') && !comment.includes('FIXME')) {
          return comment;
        }
      }
    }
    
    // Generate description based on function name
    return this.generateFunctionDescription(functionName);
  }

  private generateFunctionDescription(functionName: string): string {
    // Convert camelCase/PascalCase to readable description
    const words = functionName
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, str => str.toUpperCase())
      .trim();
    
    // Common function prefixes
    if (functionName.startsWith('get')) return `Retrieves ${words.substring(4)}`;
    if (functionName.startsWith('set')) return `Sets ${words.substring(4)}`;
    if (functionName.startsWith('create')) return `Creates ${words.substring(7)}`;
    if (functionName.startsWith('update')) return `Updates ${words.substring(7)}`;
    if (functionName.startsWith('delete')) return `Deletes ${words.substring(7)}`;
    if (functionName.startsWith('handle')) return `Handles ${words.substring(7)}`;
    if (functionName.startsWith('process')) return `Processes ${words.substring(8)}`;
    if (functionName.startsWith('validate')) return `Validates ${words.substring(9)}`;
    if (functionName.startsWith('calculate')) return `Calculates ${words.substring(10)}`;
    if (functionName.startsWith('generate')) return `Generates ${words.substring(9)}`;
    if (functionName.startsWith('parse')) return `Parses ${words.substring(6)}`;
    if (functionName.startsWith('format')) return `Formats ${words.substring(7)}`;
    if (functionName.startsWith('transform')) return `Transforms ${words.substring(10)}`;
    
    return `${words} function`;
  }

  private normalizeParameterType(type: string): string {
    if (!type || type === 'any') return 'any';
    
    // Handle common TypeScript types
    const typeMap: Record<string, string> = {
      'string': 'string',
      'number': 'number',
      'boolean': 'boolean',
      'Date': 'date',
      'Array': 'array',
      'object': 'object',
      'Function': 'function',
      'Promise': 'promise'
    };
    
    // Extract base type from complex types like Promise<string> or Array<User>
    const baseType = type.split('<')[0]?.split('|')[0]?.trim() || type;
    return typeMap[baseType] || baseType;
  }

  private normalizeReturnType(returnType: string): string {
    if (!returnType || returnType.trim() === '') return 'void';
    
    return this.normalizeParameterType(returnType.replace(/Promise<(.+)>/, '$1'));
  }

  private generateParameterDescription(name: string, type?: string): string {
    const nameWords = name.replace(/([A-Z])/g, ' $1').toLowerCase().trim();
    const typeInfo = type && type !== 'any' ? ` (${type})` : '';
    
    return `${nameWords}${typeInfo}`;
  }

  private estimateTestCoverage(functionName: string, fileContent: string): number | undefined {
    // Look for test files that might test this function
    const testPatterns = [
      new RegExp(`describe\\s*\\(\\s*['"\`].*${functionName}.*['"\`]`, 'i'),
      new RegExp(`it\\s*\\(\\s*['"\`].*${functionName}.*['"\`]`, 'i'),
      new RegExp(`test\\s*\\(\\s*['"\`].*${functionName}.*['"\`]`, 'i'),
      new RegExp(`${functionName}\\s*\\(`, 'g')
    ];
    
    let hasTests = false;
    let callCount = 0;
    
    testPatterns.forEach((pattern, index) => {
      const matches = fileContent.match(pattern);
      if (matches) {
        if (index < 3) hasTests = true;
        if (index === 3) callCount = matches.length;
      }
    });
    
    if (!hasTests) return undefined;
    
    // Estimate coverage based on test presence and usage
    return callCount > 2 ? 80 : 50;
  }

  private async extractDependencies(files: Map<string, string>): Promise<Dependency[]> {
    const dependencies: Dependency[] = [];
    
    // Extract from package.json, requirements.txt, etc.
    const packageJson = files.get('package.json');
    if (packageJson) {
      try {
        const pkg = JSON.parse(packageJson);
        const deps = { ...pkg.dependencies, ...pkg.devDependencies };
        
        for (const [name, version] of Object.entries(deps)) {
          dependencies.push({
            name,
            version: version as string,
            type: pkg.dependencies?.[name] ? 'production' : 'development'
          });
        }
      } catch (e) {
        logger.error('Failed to parse dependencies', { error: e });
      }
    }

    return dependencies;
  }

  private async extractTestMetrics(files: Map<string, string>): Promise<TestMetrics> {
    // Look for test files and coverage reports
    const testFiles = Array.from(files.keys()).filter(f => 
      f.includes('.test.') || f.includes('.spec.') || f.includes('__tests__')
    );

    return {
      coverage: 0, // Would extract from coverage reports
      testFiles: testFiles.length,
      testCases: 0, // Would count test cases
      passingTests: 0,
      failingTests: 0
    };
  }

  private async analyzeArchitecture(_files: Map<string, string>): Promise<ArchitectureInfo> {
    // Analyze folder structure and imports to determine architecture
    return {
      pattern: 'MVC', // Would detect actual pattern
      layers: ['presentation', 'business', 'data'],
      components: []
    };
  }

  private async extractBusinessLogic(_files: Map<string, string>): Promise<BusinessRule[]> {
    const rules: BusinessRule[] = [];
    
    // Look for business logic in service files, use cases, etc.
    // Extract comments that describe business rules
    
    return rules;
  }

  private async analyzeFileStructure(
    files: Map<string, string>,
    projectPath: string
  ): Promise<FileStructure> {
    const root: FileNode = {
      name: path.basename(projectPath),
      type: 'directory',
      path: '/',
      children: []
    };

    let totalLinesOfCode = 0;
    const directories = new Set<string>();
    const mainFiles: string[] = [];

    // Build file tree structure and calculate metrics
    for (const [filepath, content] of files.entries()) {
      const parts = filepath.split('/');
      let current = root;
      
      // Add directories to the set
      for (let i = 0; i < parts.length - 1; i++) {
        directories.add(parts[i] || '');
      }
      
      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        const isFile = i === parts.length - 1;
        
        if (isFile) {
          // Calculate lines of code for this file
          const lines = content.split('\n').length;
          totalLinesOfCode += lines;
          
          // Check if this is a main file
          if (this.isMainFile(part || '')) {
            mainFiles.push(filepath);
          }
          
          current.children = current.children || [];
          current.children.push({
            name: part || 'file',
            type: 'file',
            path: filepath,
            metadata: {
              language: this.detectLanguage(path.extname(part || '')),
              linesOfCode: lines
            }
          });
        } else {
          let child = current.children?.find(c => c.name === part);
          if (!child) {
            child = {
              name: part || 'dir',
              type: 'directory',
              path: parts.slice(0, i + 1).join('/'),
              children: []
            };
            current.children = current.children || [];
            current.children.push(child);
          }
          current = child!; // We know child exists here
        }
      }
    }

    return {
      rootDir: projectPath,
      structure: root,
      totalFiles: files.size,
      linesOfCode: totalLinesOfCode,
      directories: Array.from(directories).sort(),
      mainFiles: mainFiles
    };
  }

  private isMainFile(filename: string): boolean {
    const mainFilePatterns = [
      'index.js', 'index.ts', 'index.jsx', 'index.tsx',
      'app.js', 'app.ts', 'app.jsx', 'app.tsx',
      'main.js', 'main.ts', 'main.jsx', 'main.tsx',
      'server.js', 'server.ts',
      'App.js', 'App.ts', 'App.jsx', 'App.tsx',
      'package.json', 'README.md', 'tsconfig.json',
      'vite.config.js', 'vite.config.ts',
      'next.config.js', 'next.config.ts'
    ];
    
    return mainFilePatterns.includes(filename);
  }

  private detectLanguage(ext: string): string {
    const languageMap: Record<string, string> = {
      '.js': 'javascript',
      '.ts': 'typescript',
      '.py': 'python',
      '.java': 'java',
      '.go': 'go',
      '.rb': 'ruby',
      '.php': 'php',
      '.cs': 'csharp',
      '.cpp': 'cpp',
      '.c': 'c',
      '.rs': 'rust',
      '.swift': 'swift',
      '.kt': 'kotlin'
    };
    
    return languageMap[ext] || 'unknown';
  }
}

export const documentationService = new DocumentationService();