import { ParserIntegrationService } from '../../src/services/parser-integration.service';
import { LanguageDetectionService } from '../../src/services/language-detection.service';

describe('Multi-Language E2E Test', () => {
  let parserService: ParserIntegrationService;
  let languageService: LanguageDetectionService;

  beforeEach(() => {
    parserService = ParserIntegrationService.getInstance();
    languageService = LanguageDetectionService.getInstance();
  });

  it('should analyze a full-stack TypeScript/Python project', async () => {
    const files = new Map<string, string>([
      // Frontend - TypeScript/React
      ['frontend/package.json', JSON.stringify({
        name: 'frontend',
        dependencies: {
          'react': '^18.0.0',
          'react-dom': '^18.0.0',
          'axios': '^1.0.0'
        },
        devDependencies: {
          'typescript': '^5.0.0',
          '@types/react': '^18.0.0'
        }
      })],
      ['frontend/src/App.tsx', `
import React, { useState, useEffect } from 'react';
import { UserService } from './services/UserService';

interface User {
  id: string;
  name: string;
  email: string;
}

export const App: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  
  useEffect(() => {
    UserService.getUsers().then(setUsers);
  }, []);
  
  return (
    <div>
      <h1>Users</h1>
      {users.map(user => (
        <div key={user.id}>{user.name}</div>
      ))}
    </div>
  );
};
      `],
      ['frontend/src/services/UserService.ts', `
import axios from 'axios';

export class UserService {
  static async getUsers() {
    const response = await axios.get('/api/users');
    return response.data;
  }
  
  static async createUser(userData: any) {
    const response = await axios.post('/api/users', userData);
    return response.data;
  }
}
      `],
      
      // Backend - Python/Flask
      ['backend/requirements.txt', `
flask==2.3.0
flask-cors==4.0.0
sqlalchemy==2.0.0
      `],
      ['backend/app.py', `
from flask import Flask, jsonify, request
from flask_cors import CORS
from models import User, db

app = Flask(__name__)
CORS(app)

@app.route('/api/users', methods=['GET'])
def get_users():
    """Get all users"""
    users = User.query.all()
    return jsonify([user.to_dict() for user in users])

@app.route('/api/users', methods=['POST'])
def create_user():
    """Create a new user"""
    data = request.json
    user = User(name=data['name'], email=data['email'])
    db.session.add(user)
    db.session.commit()
    return jsonify(user.to_dict()), 201

if __name__ == '__main__':
    app.run(debug=True)
      `],
      ['backend/models.py', `
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    """User model"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email
        }
      `]
    ]);

    // Test language detection
    const languageResult = await languageService.detectLanguage(files);
    console.log('🔍 Language Detection Results:', {
      primary: languageResult.primary,
      secondary: languageResult.secondary,
      confidence: languageResult.confidence,
      framework: languageResult.framework
    });

    // Test full analysis
    console.log('📁 Files being analyzed:', Array.from(files.keys()));
    const analysis = await parserService.analyzeCodebase(files);
    console.log('📊 Analysis Results Summary:', {
      projectType: analysis.projectInfo.type,
      language: analysis.projectInfo.language,
      framework: analysis.projectInfo.framework,
      totalAPIs: analysis.apis.length,
      totalFunctions: analysis.functions.length,
      totalModels: analysis.dataModels.length,
      totalDependencies: analysis.dependencies.length
    });
    
    // Verify we found both TypeScript and Python code
    expect(analysis.projectInfo.type).toBe('webapp');
    
    // Check APIs were found from both languages
    const pythonAPIs = analysis.apis.filter(api => api.description.includes('Flask'));
    const tsClasses = analysis.dataModels.filter(model => model.file.includes('.ts'));
    
    expect(pythonAPIs.length).toBeGreaterThan(0);
    expect(tsClasses.length).toBeGreaterThan(0);
    
    // Check dependencies from both ecosystems
    const npmDeps = analysis.dependencies.filter(dep => dep.source.endsWith('package.json'));
    const pipDeps = analysis.dependencies.filter(dep => dep.source.endsWith('requirements.txt'));
    
    console.log('📦 Dependencies Analysis:', {
      npmDependencies: npmDeps.length,
      pipDependencies: pipDeps.length,
      npmPackages: npmDeps.map(d => d.name).slice(0, 5),
      pipPackages: pipDeps.map(d => d.name)
    });
    
    expect(npmDeps.length).toBeGreaterThan(0);
    expect(pipDeps.length).toBeGreaterThan(0);
    
    // Verify functions from both languages
    const tsFunctions = analysis.functions.filter(f => f.file.includes('.ts'));
    const pyFunctions = analysis.functions.filter(f => f.file.includes('.py'));
    
    expect(tsFunctions.length).toBeGreaterThan(0);
    expect(pyFunctions.length).toBeGreaterThan(0);
    
  });

  it('should analyze FinishThisIdea codebase itself', async () => {
    // Create a subset of files from FinishThisIdea
    const files = new Map<string, string>([
      ['package.json', JSON.stringify({
        name: 'finishthisidea-mvp',
        dependencies: {
          'express': '^4.18.2',
          'typescript': '^5.3.3'
        }
      })],
      ['src/server.ts', `
import express from 'express';
import { documentationRoutes } from './routes/documentation.routes';

const app = express();
app.use('/api/documentation', documentationRoutes);

export default app;
      `],
      ['src/services/documentation.service.ts', `
export class DocumentationService {
  async generateDocumentation(files: Map<string, string>) {
    // Implementation
    return { success: true };
  }
}
      `]
    ]);

    const analysis = await parserService.analyzeCodebase(files);
    
    expect(analysis.projectInfo.language).toBe('typescript');
    expect(analysis.dataModels.length).toBeGreaterThan(0);
    expect(analysis.apis.length).toBeGreaterThan(0);
  });
});