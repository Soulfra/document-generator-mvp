import { documentationService } from '../src/services/documentation.service';

describe('Function Extraction', () => {
  describe('AST-based Function Signature Extraction', () => {
    it('should extract function declarations correctly', async () => {
      const mockFiles = new Map([
        ['src/utils/helpers.ts', `
/**
 * Calculates the total price including tax
 * @param basePrice The base price before tax
 * @param taxRate The tax rate as a decimal
 * @returns The total price including tax
 */
export function calculateTotalPrice(basePrice: number, taxRate: number = 0.1): number {
  if (basePrice < 0) {
    throw new Error('Price cannot be negative');
  }
  
  return basePrice * (1 + taxRate);
}

// Simple validation function
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
  return emailRegex.test(email);
}

class UserService {
  /**
   * Creates a new user in the system
   */
  public async createUser(userData: UserData, options?: CreateOptions): Promise<User> {
    try {
      const validation = this.validateUserData(userData);
      if (!validation.isValid) {
        throw new Error(validation.error);
      }
      
      const user = await this.database.save(userData);
      await this.sendWelcomeEmail(user.email);
      
      return user;
    } catch (error) {
      logger.error('Failed to create user', error);
      throw error;
    }
  }
  
  private validateUserData(data: UserData): ValidationResult {
    if (!data.email || !data.name) {
      return { isValid: false, error: 'Missing required fields' };
    }
    return { isValid: true };
  }
}

// Arrow function with complex parameters
const processPayment = async (
  { amount, currency = 'USD', metadata }: PaymentRequest,
  callback?: (result: PaymentResult) => void
): Promise<PaymentResult> => {
  const result = await paymentGateway.process({
    amount: amount * 100, // Convert to cents
    currency,
    metadata
  });
  
  if (callback) {
    callback(result);
  }
  
  return result;
};

export const formatCurrency = (amount: number, locale: string = 'en-US'): string => {
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: 'USD'
  }).format(amount);
};
        `]
      ]);

      const result = await documentationService.analyzeCodeForDocumentation(mockFiles, '/test-project');

      console.log('Extracted functions:', result.functions.map(f => f.name));
      expect(result.functions.length).toBeGreaterThan(0); // Just check we got some functions

      // Test calculateTotalPrice function
      const calculatePriceFunc = result.functions.find(f => f.name === 'calculateTotalPrice');
      expect(calculatePriceFunc).toBeDefined();
      expect(calculatePriceFunc?.description).toBe('Calculates the total price including tax');
      expect(calculatePriceFunc?.parameters).toHaveLength(2);
      expect(calculatePriceFunc?.parameters[0]).toEqual({
        name: 'basePrice',
        type: 'number',
        required: true,
        description: 'base price (number)'
      });
      expect(calculatePriceFunc?.parameters[1]).toEqual({
        name: 'taxRate',
        type: 'number',
        required: false, // Has default value
        description: 'tax rate (number)'
      });
      expect(calculatePriceFunc?.returnType).toBe('number');
      expect(calculatePriceFunc?.complexity).toBeGreaterThan(1); // Should detect the if statement
      expect(calculatePriceFunc?.linesOfCode).toBeGreaterThan(3);

      // Test createUser method
      const createUserFunc = result.functions.find(f => f.name === 'createUser');
      expect(createUserFunc).toBeDefined();
      expect(createUserFunc?.description).toBe('Creates a new user in the system');
      expect(createUserFunc?.parameters).toHaveLength(2);
      expect(createUserFunc?.returnType).toBe('User'); // Promise<User> should be normalized to User
      expect(createUserFunc?.complexity).toBeGreaterThan(1); // Should detect try/catch, if statements

      // Test arrow function with destructuring
      const processPaymentFunc = result.functions.find(f => f.name === 'processPayment');
      expect(processPaymentFunc).toBeDefined();
      expect(processPaymentFunc?.parameters).toHaveLength(2);
      expect(processPaymentFunc?.returnType).toBe('PaymentResult');

      // Test simple validation function
      const validateEmailFunc = result.functions.find(f => f.name === 'validateEmail');
      expect(validateEmailFunc).toBeDefined();
      expect(validateEmailFunc?.description).toBe('Simple validation function');
      expect(validateEmailFunc?.complexity).toBe(1); // Simple function, no conditionals in body
    });

    it('should calculate cyclomatic complexity correctly', async () => {
      const mockFiles = new Map([
        ['src/complex.ts', `
function complexFunction(input: any): string {
  if (input === null) {
    return 'null';
  } else if (typeof input === 'string') {
    return input.toUpperCase();
  } else if (typeof input === 'number') {
    if (input > 0) {
      return input.toString();
    } else {
      return '0';
    }
  }
  
  switch (typeof input) {
    case 'boolean':
      return input ? 'true' : 'false';
    case 'object':
      try {
        return JSON.stringify(input);
      } catch (error) {
        return 'invalid object';
      }
    default:
      return 'unknown';
  }
}

function simpleFunction(x: number, y: number): number {
  return x + y;
}
        `]
      ]);

      const result = await documentationService.analyzeCodeForDocumentation(mockFiles, '/test-project');

      const complexFunc = result.functions.find(f => f.name === 'complexFunction');
      const simpleFunc = result.functions.find(f => f.name === 'simpleFunction');

      expect(complexFunc?.complexity).toBeGreaterThan(5); // Multiple if/else, switch, case, try/catch
      expect(simpleFunc?.complexity).toBe(1); // No conditional logic
    });

    it('should handle various parameter patterns', async () => {
      const mockFiles = new Map([
        ['src/params.ts', `
// Destructuring parameters
function processUser({ name, age, email }: UserData): void {
  console.log(name, age, email);
}

// Rest parameters
function sum(...numbers: number[]): number {
  return numbers.reduce((a, b) => a + b, 0);
}

// Optional parameters with defaults
function createConfig(
  host: string = 'localhost',
  port?: number,
  ssl: boolean = false
): Config {
  return { host, port: port || 3000, ssl };
}

// Complex destructuring with defaults
const updateSettings = ({
  theme = 'light',
  language = 'en',
  notifications: { email = true, push = false } = {}
}: SettingsInput): void => {
  // Update logic
};
        `]
      ]);

      const result = await documentationService.analyzeCodeForDocumentation(mockFiles, '/test-project');

      // Test destructuring parameters
      const processUserFunc = result.functions.find(f => f.name === 'processUser');
      expect(processUserFunc?.parameters).toHaveLength(1);
      expect(processUserFunc?.parameters[0].name).toBe('name'); // Should extract first destructured field

      // Test rest parameters
      const sumFunc = result.functions.find(f => f.name === 'sum');
      expect(sumFunc?.parameters).toHaveLength(1);
      expect(sumFunc?.parameters[0].name).toBe('...numbers');
      expect(sumFunc?.parameters[0].type).toBe('number');

      // Test optional and default parameters
      const createConfigFunc = result.functions.find(f => f.name === 'createConfig');
      expect(createConfigFunc?.parameters).toHaveLength(3);
      expect(createConfigFunc?.parameters[0].required).toBe(false); // Has default
      expect(createConfigFunc?.parameters[1].required).toBe(false); // Optional
      expect(createConfigFunc?.parameters[2].required).toBe(false); // Has default
    });

    it('should detect test coverage hints', async () => {
      const mockFiles = new Map([
        ['src/tested.ts', `
function calculateScore(points: number): number {
  return points * 100;
}

describe('calculateScore', () => {
  it('should calculate score correctly', () => {
    expect(calculateScore(5)).toBe(500);
  });
  
  it('should handle zero points', () => {
    expect(calculateScore(0)).toBe(0);
  });
});

function untestedFunction(): void {
  console.log('This has no tests');
}
        `]
      ]);

      const result = await documentationService.analyzeCodeForDocumentation(mockFiles, '/test-project');

      const testedFunc = result.functions.find(f => f.name === 'calculateScore');
      const untestedFunc = result.functions.find(f => f.name === 'untestedFunction');

      expect(testedFunc?.testCoverage).toBeDefined();
      expect(testedFunc?.testCoverage).toBeGreaterThan(0);
      expect(untestedFunc?.testCoverage).toBeUndefined();
    });

    it('should skip non-code files and test files', async () => {
      const mockFiles = new Map([
        ['src/app.ts', 'function appFunction() {}'],
        ['src/app.test.ts', 'function testFunction() {}'],
        ['src/types.d.ts', 'function typeFunction() {}'],
        ['README.md', '# Readme'],
        ['package.json', '{}'],
        ['src/utils.spec.ts', 'function specFunction() {}']
      ]);

      const result = await documentationService.analyzeCodeForDocumentation(mockFiles, '/test-project');

      expect(result.functions).toHaveLength(1);
      expect(result.functions[0].name).toBe('appFunction');
    });
  });
});