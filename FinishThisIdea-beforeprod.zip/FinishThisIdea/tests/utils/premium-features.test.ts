import { describe, it, expect } from '@jest/globals';
import {
  hasPremium,
  isFree,
  getPremiumLimits,
  getJobPriority,
  canAccess,
  validateFileSize,
  validateBatchSize,
  validateExportFormat,
  validateProfileCount,
  getUpgradeMessage,
  PREMIUM_CONFIG
} from '../../src/utils/premium-features';
import { UserTier } from '@prisma/client';

// Mock user objects
const freeUser = {
  id: 'user-1',
  tier: UserTier.FREE,
  email: 'free@test.com',
  username: 'freeuser',
  stripeCustomerId: null,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastLoginAt: null,
};

const premiumUser = {
  id: 'user-2',
  tier: UserTier.PREMIUM,
  email: 'premium@test.com',
  username: 'premiumuser',
  stripeCustomerId: 'cus_premium',
  createdAt: new Date(),
  updatedAt: new Date(),
  lastLoginAt: null,
};

describe('Premium Features Utilities', () => {
  describe('hasPremium()', () => {
    it('should return true for premium users', () => {
      expect(hasPremium(premiumUser)).toBe(true);
    });

    it('should return false for free users', () => {
      expect(hasPremium(freeUser)).toBe(false);
    });

    it('should return false for null users', () => {
      expect(hasPremium(null)).toBe(false);
    });
  });

  describe('isFree()', () => {
    it('should return false for premium users', () => {
      expect(isFree(premiumUser)).toBe(false);
    });

    it('should return true for free users', () => {
      expect(isFree(freeUser)).toBe(true);
    });

    it('should return true for null users', () => {
      expect(isFree(null)).toBe(true);
    });
  });

  describe('getPremiumLimits()', () => {
    it('should return premium limits for premium users', () => {
      const limits = getPremiumLimits(premiumUser);
      expect(limits.maxFileSize).toBe(500 * 1024 * 1024);
      expect(limits.maxProfiles).toBe(10);
      expect(limits.maxBatchSize).toBe(10);
      expect(limits.allowedExportFormats).toEqual(['zip', 'pdf', 'html', 'md']);
      expect(limits.hasAdvancedTemplates).toBe(true);
      expect(limits.hasPriorityProcessing).toBe(true);
    });

    it('should return free limits for free users', () => {
      const limits = getPremiumLimits(freeUser);
      expect(limits.maxFileSize).toBe(50 * 1024 * 1024);
      expect(limits.maxProfiles).toBe(2);
      expect(limits.maxBatchSize).toBe(1);
      expect(limits.allowedExportFormats).toEqual(['zip']);
      expect(limits.hasAdvancedTemplates).toBe(false);
      expect(limits.hasPriorityProcessing).toBe(false);
    });

    it('should return free limits for null users', () => {
      const limits = getPremiumLimits(null);
      expect(limits.maxFileSize).toBe(50 * 1024 * 1024);
      expect(limits.maxProfiles).toBe(2);
      expect(limits.maxBatchSize).toBe(1);
    });
  });

  describe('getJobPriority()', () => {
    it('should return priority 2 for premium users', () => {
      expect(getJobPriority(premiumUser)).toBe(2);
    });

    it('should return priority 1 for free users', () => {
      expect(getJobPriority(freeUser)).toBe(1);
    });

    it('should return priority 1 for null users', () => {
      expect(getJobPriority(null)).toBe(1);
    });
  });

  describe('canAccess()', () => {
    it('should allow premium users to access all features', () => {
      expect(canAccess(premiumUser, 'priority-processing')).toBe(true);
      expect(canAccess(premiumUser, 'advanced-templates')).toBe(true);
      expect(canAccess(premiumUser, 'batch-processing')).toBe(true);
      expect(canAccess(premiumUser, 'large-files')).toBe(true);
      expect(canAccess(premiumUser, 'export-formats')).toBe(true);
    });

    it('should restrict free users from premium features', () => {
      expect(canAccess(freeUser, 'priority-processing')).toBe(false);
      expect(canAccess(freeUser, 'advanced-templates')).toBe(false);
      expect(canAccess(freeUser, 'batch-processing')).toBe(false);
      expect(canAccess(freeUser, 'large-files')).toBe(false);
      expect(canAccess(freeUser, 'export-formats')).toBe(false);
    });

    it('should return false for null users', () => {
      expect(canAccess(null, 'priority-processing')).toBe(false);
    });
  });

  describe('validateFileSize()', () => {
    it('should allow 50MB files for free users', () => {
      expect(() => validateFileSize(freeUser, 50 * 1024 * 1024)).not.toThrow();
    });

    it('should reject 51MB files for free users', () => {
      expect(() => validateFileSize(freeUser, 51 * 1024 * 1024)).toThrow();
    });

    it('should allow 500MB files for premium users', () => {
      expect(() => validateFileSize(premiumUser, 500 * 1024 * 1024)).not.toThrow();
    });

    it('should reject 501MB files for premium users', () => {
      expect(() => validateFileSize(premiumUser, 501 * 1024 * 1024)).toThrow();
    });

    it('should provide upgrade message for free users', () => {
      expect(() => validateFileSize(freeUser, 75 * 1024 * 1024)).toThrow(/Upgrade to Premium/);
    });
  });

  describe('validateBatchSize()', () => {
    it('should allow 1 file for free users', () => {
      expect(() => validateBatchSize(freeUser, 1)).not.toThrow();
    });

    it('should reject 2 files for free users', () => {
      expect(() => validateBatchSize(freeUser, 2)).toThrow();
    });

    it('should allow 10 files for premium users', () => {
      expect(() => validateBatchSize(premiumUser, 10)).not.toThrow();
    });

    it('should reject 11 files for premium users', () => {
      expect(() => validateBatchSize(premiumUser, 11)).toThrow();
    });
  });

  describe('validateExportFormat()', () => {
    it('should allow zip format for free users', () => {
      expect(() => validateExportFormat(freeUser, 'zip')).not.toThrow();
    });

    it('should reject pdf format for free users', () => {
      expect(() => validateExportFormat(freeUser, 'pdf')).toThrow();
    });

    it('should allow all formats for premium users', () => {
      expect(() => validateExportFormat(premiumUser, 'zip')).not.toThrow();
      expect(() => validateExportFormat(premiumUser, 'pdf')).not.toThrow();
      expect(() => validateExportFormat(premiumUser, 'html')).not.toThrow();
      expect(() => validateExportFormat(premiumUser, 'md')).not.toThrow();
    });
  });

  describe('validateProfileCount()', () => {
    it('should allow 2 profiles for free users', () => {
      expect(() => validateProfileCount(freeUser, 1)).not.toThrow();
    });

    it('should reject 3rd profile for free users', () => {
      expect(() => validateProfileCount(freeUser, 2)).toThrow();
    });

    it('should allow 10 profiles for premium users', () => {
      expect(() => validateProfileCount(premiumUser, 9)).not.toThrow();
    });

    it('should reject 11th profile for premium users', () => {
      expect(() => validateProfileCount(premiumUser, 10)).toThrow();
    });
  });

  describe('getUpgradeMessage()', () => {
    it('should return proper upgrade messages for features', () => {
      expect(getUpgradeMessage('priority-processing')).toContain('Priority Processing');
      expect(getUpgradeMessage('advanced-templates')).toContain('Advanced Templates');
      expect(getUpgradeMessage('batch-processing')).toContain('Batch Processing');
      expect(getUpgradeMessage('large-files')).toContain('Large File Upload');
      expect(getUpgradeMessage('export-formats')).toContain('Multiple Export Formats');
    });
  });

  describe('PREMIUM_CONFIG', () => {
    it('should have correct FREE tier configuration', () => {
      expect(PREMIUM_CONFIG.FREE.maxFileSize).toBe(50 * 1024 * 1024);
      expect(PREMIUM_CONFIG.FREE.maxProfiles).toBe(2);
      expect(PREMIUM_CONFIG.FREE.maxBatchSize).toBe(1);
      expect(PREMIUM_CONFIG.FREE.exportFormats).toEqual(['zip']);
      expect(PREMIUM_CONFIG.FREE.priority).toBe(1);
    });

    it('should have correct PREMIUM tier configuration', () => {
      expect(PREMIUM_CONFIG.PREMIUM.maxFileSize).toBe(500 * 1024 * 1024);
      expect(PREMIUM_CONFIG.PREMIUM.maxProfiles).toBe(10);
      expect(PREMIUM_CONFIG.PREMIUM.maxBatchSize).toBe(10);
      expect(PREMIUM_CONFIG.PREMIUM.exportFormats).toEqual(['zip', 'pdf', 'html', 'md']);
      expect(PREMIUM_CONFIG.PREMIUM.priority).toBe(2);
    });
  });
});