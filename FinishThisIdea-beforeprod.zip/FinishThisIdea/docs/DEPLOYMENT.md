---
title: "Deployment Guide"
description: "Complete guide for deploying the Document Generator to production environments with multiple deployment options"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Deployment Guide

Complete guide for deploying the Document Generator to production environments.

## 🚀 Deployment Overview

The Document Generator is designed as a microservices architecture with the following components:
- **Backend API** (Node.js/Express)
- **Frontend SPA** (React/Vite)
- **PostgreSQL Database**
- **Redis Queue**
- **Object Storage** (S3/MinIO)
- **AI Service** (Ollama/Claude)

## 🎯 Deployment Options

### Option 1: Docker Compose (Recommended for small deployments)
### Option 2: Kubernetes (Recommended for production)
### Option 3: Cloud Platforms (Vercel + Railway/Render)

---

## 🐳 Docker Compose Deployment

### Prerequisites
- Docker 20.10+
- Docker Compose 2.0+
- Domain name with SSL certificate
- At least 4GB RAM, 2 CPU cores

### 1. Production Docker Compose

Create `docker-compose.prod.yml`:

```yaml
version: '3.8'

services:
  # Backend API
  api:
    build:
      context: .
      dockerfile: Dockerfile.prod
    container_name: finishthisidea-api
    environment:
      NODE_ENV: production
      DATABASE_URL: postgresql://postgres:${POSTGRES_PASSWORD}@postgres:5432/finishthisidea
      REDIS_URL: redis://redis:6379
      STRIPE_SECRET_KEY: ${STRIPE_SECRET_KEY}
      ANTHROPIC_API_KEY: ${ANTHROPIC_API_KEY}
      AWS_ACCESS_KEY_ID: ${AWS_ACCESS_KEY_ID}
      AWS_SECRET_ACCESS_KEY: ${AWS_SECRET_ACCESS_KEY}
      S3_BUCKET: ${S3_BUCKET}
      JWT_SECRET: ${JWT_SECRET}
    ports:
      - "3001:3001"
    depends_on:
      - postgres
      - redis
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3001/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Frontend (Nginx)
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile.prod
    container_name: finishthisidea-frontend
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/ssl/certs
    depends_on:
      - api
    restart: unless-stopped

  # PostgreSQL Database
  postgres:
    image: postgres:15-alpine
    container_name: finishthisidea-postgres
    environment:
      POSTGRES_DB: finishthisidea
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./backups:/backups
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 30s
      timeout: 10s
      retries: 5

  # Redis Cache & Queue
  redis:
    image: redis:7-alpine
    container_name: finishthisidea-redis
    command: redis-server --requirepass ${REDIS_PASSWORD}
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "redis-cli", "--no-auth-warning", "auth", "${REDIS_PASSWORD}", "ping"]
      interval: 30s
      timeout: 10s
      retries: 5

  # Ollama AI Service
  ollama:
    image: ollama/ollama:latest
    container_name: finishthisidea-ollama
    ports:
      - "11434:11434"
    volumes:
      - ollama_data:/root/.ollama
    environment:
      - OLLAMA_HOST=0.0.0.0
    restart: unless-stopped
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]

volumes:
  postgres_data:
  redis_data:
  ollama_data:

networks:
  default:
    name: finishthisidea-prod
```

### 2. Environment Configuration

Create `.env.prod`:

```bash
# Database
POSTGRES_PASSWORD=secure_postgres_password_here
DATABASE_URL=postgresql://postgres:${POSTGRES_PASSWORD}@localhost:5432/finishthisidea

# Redis
REDIS_PASSWORD=secure_redis_password_here
REDIS_URL=redis://:${REDIS_PASSWORD}@localhost:6379

# API Keys
STRIPE_SECRET_KEY=sk_live_your_stripe_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
ANTHROPIC_API_KEY=sk-ant-your_claude_key

# AWS S3
AWS_ACCESS_KEY_ID=your_s3_access_key
AWS_SECRET_ACCESS_KEY=your_s3_secret_key
S3_BUCKET=finishthisidea-production
AWS_REGION=us-east-1

# Security
JWT_SECRET=your_jwt_secret_at_least_32_chars_long
ENCRYPTION_KEY=your_encryption_key_32_chars_long

# Application
NODE_ENV=production
PORT=3001
FRONTEND_URL=https://yourdomain.com
```

### 3. Production Dockerfiles

**Backend Dockerfile (`Dockerfile.prod`):**
```dockerfile
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

FROM node:18-alpine AS production

RUN addgroup -g 1001 -S nodejs
RUN adduser -S nextjs -u 1001

WORKDIR /app

COPY --from=builder --chown=nextjs:nodejs /app/dist ./dist
COPY --from=builder --chown=nextjs:nodejs /app/node_modules ./node_modules
COPY --from=builder --chown=nextjs:nodejs /app/package*.json ./
COPY --from=builder --chown=nextjs:nodejs /app/prisma ./prisma

USER nextjs

EXPOSE 3001

HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:3001/health || exit 1

CMD ["npm", "start"]
```

**Frontend Dockerfile (`frontend/Dockerfile.prod`):**
```dockerfile
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

FROM nginx:alpine AS production

COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf

EXPOSE 80 443

CMD ["nginx", "-g", "daemon off;"]
```

### 4. Nginx Configuration

Create `nginx/nginx.conf`:

```nginx
events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml;

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;

    server {
        listen 80;
        listen 443 ssl http2;
        server_name yourdomain.com;

        # SSL Configuration
        ssl_certificate /etc/ssl/certs/fullchain.pem;
        ssl_certificate_key /etc/ssl/certs/privkey.pem;

        # Frontend
        location / {
            root /usr/share/nginx/html;
            try_files $uri $uri/ /index.html;
            
            # Cache static assets
            location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
                expires 1y;
                add_header Cache-Control "public, immutable";
            }
        }

        # API proxy
        location /api/ {
            limit_req zone=api burst=20 nodelay;
            proxy_pass http://api:3001/api/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            
            # WebSocket support
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
        }

        # Health check
        location /health {
            proxy_pass http://api:3001/health;
        }
    }
}
```

### 5. Deployment Script

Create `deploy.sh`:

```bash
#!/bin/bash
set -e

echo "🚀 Starting production deployment..."

# Pull latest code
git pull origin main

# Build and start services
docker-compose -f docker-compose.prod.yml down
docker-compose -f docker-compose.prod.yml build --no-cache
docker-compose -f docker-compose.prod.yml up -d

# Run database migrations
docker-compose -f docker-compose.prod.yml exec api npx prisma migrate deploy

# Pull Ollama model
docker-compose -f docker-compose.prod.yml exec ollama ollama pull codellama

# Health check
sleep 30
curl -f http://localhost/health || exit 1

echo "✅ Deployment completed successfully!"
```

---

## ☸️ Kubernetes Deployment

### 1. Namespace and ConfigMap

```yaml
# k8s/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: finishthisidea

---
# k8s/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
  namespace: finishthisidea
data:
  NODE_ENV: "production"
  PORT: "3001"
  FRONTEND_URL: "https://yourdomain.com"
  REDIS_URL: "redis://redis-service:6379"
  DATABASE_URL: "postgresql://postgres:password@postgres-service:5432/finishthisidea"
```

### 2. Database Deployment

```yaml
# k8s/postgres.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: postgres
  namespace: finishthisidea
spec:
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:15-alpine
        env:
        - name: POSTGRES_DB
          value: "finishthisidea"
        - name: POSTGRES_USER
          value: "postgres"
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: postgres-password
        ports:
        - containerPort: 5432
        volumeMounts:
        - name: postgres-storage
          mountPath: /var/lib/postgresql/data
      volumes:
      - name: postgres-storage
        persistentVolumeClaim:
          claimName: postgres-pvc

---
apiVersion: v1
kind: Service
metadata:
  name: postgres-service
  namespace: finishthisidea
spec:
  selector:
    app: postgres
  ports:
  - port: 5432
    targetPort: 5432
```

### 3. API Deployment

```yaml
# k8s/api.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api
  namespace: finishthisidea
spec:
  replicas: 3
  selector:
    matchLabels:
      app: api
  template:
    metadata:
      labels:
        app: api
    spec:
      containers:
      - name: api
        image: finishthisidea/api:latest
        envFrom:
        - configMapRef:
            name: app-config
        - secretRef:
            name: app-secrets
        ports:
        - containerPort: 3001
        livenessProbe:
          httpGet:
            path: /health
            port: 3001
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 3001
          initialDelaySeconds: 5
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: api-service
  namespace: finishthisidea
spec:
  selector:
    app: api
  ports:
  - port: 80
    targetPort: 3001
  type: ClusterIP
```

---

## ☁️ Cloud Platform Deployment

### Vercel + Railway Configuration

**Frontend (Vercel):**

1. Connect your GitHub repository to Vercel
2. Configure build settings:

```json
{
  "builds": [
    {
      "src": "frontend/package.json",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "dist"
      }
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "https://your-backend.railway.app/api/$1"
    },
    {
      "src": "/(.*)",
      "dest": "/frontend/$1"
    }
  ]
}
```

**Backend (Railway):**

1. Create a new Railway project
2. Connect your GitHub repository
3. Add the following services:
   - PostgreSQL database
   - Redis
   - Node.js API

Railway configuration (`railway.toml`):
```toml
[build]
builder = "nixpacks"
buildCommand = "npm install && npm run build"

[deploy]
startCommand = "npm start"
healthcheckPath = "/health"
healthcheckTimeout = 300
restartPolicyType = "always"
```

---

## 🔧 Environment Setup

### Production Environment Variables

```bash
# Required for all deployments
NODE_ENV=production
DATABASE_URL=postgresql://user:password@host:port/database
REDIS_URL=redis://user:password@host:port

# API Keys (obtain from respective services)
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
ANTHROPIC_API_KEY=sk-ant-...

# AWS S3 Configuration
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
S3_BUCKET=your-production-bucket
AWS_REGION=us-east-1

# Security
JWT_SECRET=your-32-char-secret
ENCRYPTION_KEY=your-32-char-encryption-key

# Optional
SENTRY_DSN=https://...@sentry.io/...
LOG_LEVEL=info
```

### SSL Certificate Setup

**Using Let's Encrypt with Certbot:**

```bash
# Install certbot
sudo apt-get install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d yourdomain.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

---

## 📊 Monitoring & Logging

### Health Checks

**Application health endpoint:**
```typescript
// src/routes/health.ts
app.get('/health', async (req, res) => {
  const checks = {
    database: await checkDatabase(),
    redis: await checkRedis(),
    storage: await checkStorage(),
    ai: await checkAI(),
  };

  const isHealthy = Object.values(checks).every(check => check.status === 'ok');

  res.status(isHealthy ? 200 : 503).json({
    status: isHealthy ? 'ok' : 'degraded',
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version,
    checks,
  });
});
```

### Logging Configuration

```typescript
// src/utils/logger.ts
import winston from 'winston';

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' }),
  ],
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple()
  }));
}
```

---

## 🔄 CI/CD Pipeline

### GitHub Actions Workflow

```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      
      - run: npm ci
      - run: npm run test
      - run: npm run build

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Deploy to production
        uses: appleboy/ssh-action@v0.1.5
        with:
          host: ${{ secrets.HOST }}
          username: ${{ secrets.USERNAME }}
          key: ${{ secrets.SSH_KEY }}
          script: |
            cd /path/to/app
            git pull origin main
            ./deploy.sh
```

---

## 🚨 Backup & Recovery

### Database Backup Script

```bash
#!/bin/bash
# backup.sh

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="/backups"
DB_NAME="finishthisidea"

# Create backup
docker exec finishthisidea-postgres pg_dump -U postgres $DB_NAME > "$BACKUP_DIR/backup_$TIMESTAMP.sql"

# Upload to S3
aws s3 cp "$BACKUP_DIR/backup_$TIMESTAMP.sql" s3://your-backup-bucket/database/

# Cleanup old backups (keep last 7 days)
find $BACKUP_DIR -name "backup_*.sql" -mtime +7 -delete

echo "Backup completed: backup_$TIMESTAMP.sql"
```

### Recovery Procedure

```bash
# Stop application
docker-compose down

# Restore database
docker exec -i finishthisidea-postgres psql -U postgres $DB_NAME < backup_file.sql

# Start application
docker-compose up -d

# Verify health
curl -f http://localhost/health
```

---

## 🐛 Troubleshooting

### Common Issues

**Container won't start:**
```bash
# Check logs
docker logs finishthisidea-api

# Check resource usage
docker stats

# Restart service
docker-compose restart api
```

**Database connection issues:**
```bash
# Test database connection
docker exec finishthisidea-postgres psql -U postgres -d finishthisidea -c "SELECT 1;"

# Check network connectivity
docker network ls
docker network inspect finishthisidea-prod
```

**Performance issues:**
```bash
# Monitor resource usage
htop
iostat -x 1

# Check application metrics
curl http://localhost:3001/admin/stats
```

### Emergency Procedures

1. **Service outage**: Scale down to maintenance mode
2. **Database issues**: Switch to read-only mode
3. **Security breach**: Rotate all secrets immediately
4. **Data corruption**: Restore from latest backup

---

## 📞 Support

- **Documentation**: [Full docs](../README.md)
- **Issues**: [GitHub Issues](https://github.com/your-repo/issues)
- **Emergency**: ops-team@finishthisidea.com

---

**Last Updated**: 2024-01-15  
**Deploy Version**: 1.0.0