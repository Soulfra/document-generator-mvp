import * as fs from 'fs/promises';
import * as path from 'path';
import archiver from 'archiver';
import { createWriteStream } from 'fs';

export interface SampleProject {
  name: string;
  language: string;
  framework?: string;
  projectType: 'webapp' | 'api' | 'cli' | 'library' | 'mobile' | 'desktop';
  complexity: 'minimal' | 'standard' | 'enterprise' | 'large-scale';
  files: Record<string, string>;
}

export class SampleGenerator {
  private static readonly SAMPLE_PROJECTS: Record<string, SampleProject> = {
    // JavaScript/TypeScript Projects
    'react-ecommerce': {
      name: 'React E-commerce Platform',
      language: 'typescript',
      framework: 'react',
      projectType: 'webapp',
      complexity: 'enterprise',
      files: {
        'package.json': JSON.stringify({
          name: 'react-ecommerce',
          version: '1.0.0',
          description: 'Full-featured e-commerce platform built with React and TypeScript',
          dependencies: {
            'react': '^18.2.0',
            'react-dom': '^18.2.0',
            'react-router-dom': '^6.8.0',
            'axios': '^1.3.0',
            'react-query': '^3.39.0',
            'react-hook-form': '^7.43.0',
            'stripe': '^11.15.0',
            'tailwindcss': '^3.2.0',
            '@reduxjs/toolkit': '^1.9.0',
            'react-redux': '^8.0.0'
          },
          devDependencies: {
            '@types/react': '^18.0.0',
            '@types/react-dom': '^18.0.0',
            '@typescript-eslint/eslint-plugin': '^5.0.0',
            'typescript': '^4.9.0',
            'vite': '^4.1.0',
            'jest': '^29.0.0',
            '@testing-library/react': '^13.0.0'
          },
          scripts: {
            'dev': 'vite',
            'build': 'tsc && vite build',
            'test': 'jest',
            'lint': 'eslint src --ext ts,tsx --report-unused-disable-directives --max-warnings 0'
          }
        }, null, 2),
        'tsconfig.json': JSON.stringify({
          compilerOptions: {
            target: 'ES2020',
            useDefineForClassFields: true,
            lib: ['ES2020', 'DOM', 'DOM.Iterable'],
            module: 'ESNext',
            skipLibCheck: true,
            moduleResolution: 'bundler',
            allowImportingTsExtensions: true,
            resolveJsonModule: true,
            isolatedModules: true,
            noEmit: true,
            jsx: 'react-jsx',
            strict: true,
            noUnusedLocals: true,
            noUnusedParameters: true,
            noFallthroughCasesInSwitch: true
          },
          include: ['src'],
          references: [{ path: './tsconfig.node.json' }]
        }, null, 2),
        'src/App.tsx': `import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import { Provider } from 'react-redux';
import { store } from './store';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import './App.css';

const queryClient = new QueryClient();

function App() {
  return (
    <Provider store={store}>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <CartProvider>
            <Router>
              <div className="min-h-screen bg-gray-50">
                <Header />
                <main className="container mx-auto px-4 py-8">
                  <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/products" element={<ProductsPage />} />
                    <Route path="/products/:id" element={<ProductDetailPage />} />
                    <Route path="/cart" element={<CartPage />} />
                    <Route path="/checkout" element={<CheckoutPage />} />
                  </Routes>
                </main>
                <Footer />
              </div>
            </Router>
          </CartProvider>
        </AuthProvider>
      </QueryClientProvider>
    </Provider>
  );
}

export default App;`,
        'src/components/layout/Header.tsx': `import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useCart } from '../../hooks/useCart';
import { SearchBar } from '../common/SearchBar';
import { ShoppingCartIcon, UserIcon, MenuIcon } from '@heroicons/react/24/outline';

export const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  const { itemCount } = useCart();
  const navigate = useNavigate();

  const handleSearch = (query: string) => {
    navigate(\`/products?search=\${encodeURIComponent(query)}\`);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <img src="/logo.svg" alt="E-commerce" className="h-8 w-8" />
            <span className="text-xl font-bold text-gray-900">E-Shop</span>
          </Link>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-lg mx-8">
            <SearchBar onSearch={handleSearch} />
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/products" className="text-gray-600 hover:text-gray-900">
              Products
            </Link>
            
            {/* Cart */}
            <Link to="/cart" className="relative text-gray-600 hover:text-gray-900">
              <ShoppingCartIcon className="h-6 w-6" />
              {itemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {itemCount}
                </span>
              )}
            </Link>

            {/* User Menu */}
            <div className="relative">
              {user ? (
                <div className="flex items-center space-x-2">
                  <span className="text-gray-600">Hi, {user.name}</span>
                  <button
                    onClick={logout}
                    className="text-gray-600 hover:text-gray-900"
                  >
                    Logout
                  </button>
                </div>
              ) : (
                <Link to="/login" className="text-gray-600 hover:text-gray-900">
                  <UserIcon className="h-6 w-6" />
                </Link>
              )}
            </div>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="md:hidden text-gray-600 hover:text-gray-900"
          >
            <MenuIcon className="h-6 w-6" />
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="mb-4">
              <SearchBar onSearch={handleSearch} />
            </div>
            <nav className="space-y-2">
              <Link
                to="/products"
                className="block py-2 text-gray-600 hover:text-gray-900"
                onClick={() => setIsMenuOpen(false)}
              >
                Products
              </Link>
              <Link
                to="/cart"
                className="flex items-center py-2 text-gray-600 hover:text-gray-900"
                onClick={() => setIsMenuOpen(false)}
              >
                <ShoppingCartIcon className="h-5 w-5 mr-2" />
                Cart ({itemCount})
              </Link>
              {user ? (
                <button
                  onClick={() => {
                    logout();
                    setIsMenuOpen(false);
                  }}
                  className="block py-2 text-gray-600 hover:text-gray-900"
                >
                  Logout
                </button>
              ) : (
                <Link
                  to="/login"
                  className="block py-2 text-gray-600 hover:text-gray-900"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Login
                </Link>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};`,
        'src/types/product.ts': `export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: Category;
  images: ProductImage[];
  variants: ProductVariant[];
  inventory: InventoryInfo;
  ratings: ProductRating;
  features: string[];
  specifications: Record<string, string>;
  shipping: ShippingInfo;
  createdAt: Date;
  updatedAt: Date;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  parentId?: string;
  children?: Category[];
}

export interface ProductImage {
  id: string;
  url: string;
  alt: string;
  isPrimary: boolean;
  sortOrder: number;
}

export interface ProductVariant {
  id: string;
  name: string;
  sku: string;
  price: number;
  originalPrice?: number;
  attributes: Record<string, string>; // e.g., { "color": "red", "size": "L" }
  inventory: InventoryInfo;
  images: ProductImage[];
}

export interface InventoryInfo {
  inStock: boolean;
  quantity: number;
  lowStockThreshold: number;
  allowBackorder: boolean;
  estimatedRestockDate?: Date;
}

export interface ProductRating {
  average: number;
  count: number;
  distribution: Record<number, number>; // e.g., { 5: 120, 4: 45, 3: 12, 2: 3, 1: 1 }
}

export interface ShippingInfo {
  weight: number;
  dimensions: {
    length: number;
    width: number;
    height: number;
  };
  freeShippingEligible: boolean;
  estimatedDeliveryDays: number;
  shippingMethods: ShippingMethod[];
}

export interface ShippingMethod {
  id: string;
  name: string;
  price: number;
  estimatedDays: number;
}

// Cart and Order Types
export interface CartItem {
  id: string;
  product: Product;
  variant?: ProductVariant;
  quantity: number;
  customizations?: Record<string, string>;
}

export interface Cart {
  id: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  shipping: number;
  total: number;
  discounts: Discount[];
}

export interface Discount {
  id: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  description: string;
}

// User and Authentication Types
export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  addresses: Address[];
  preferences: UserPreferences;
  orderHistory: Order[];
  createdAt: Date;
}

export interface Address {
  id: string;
  type: 'billing' | 'shipping';
  isDefault: boolean;
  firstName: string;
  lastName: string;
  company?: string;
  address1: string;
  address2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone?: string;
}

export interface UserPreferences {
  currency: string;
  language: string;
  notifications: {
    email: boolean;
    sms: boolean;
    push: boolean;
  };
  marketing: {
    promotions: boolean;
    recommendations: boolean;
  };
}

export interface Order {
  id: string;
  orderNumber: string;
  status: OrderStatus;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  shipping: number;
  total: number;
  discounts: Discount[];
  shippingAddress: Address;
  billingAddress: Address;
  paymentMethod: PaymentMethod;
  fulfillment: FulfillmentInfo;
  createdAt: Date;
  updatedAt: Date;
}

export type OrderStatus = 
  | 'pending'
  | 'confirmed'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled'
  | 'refunded';

export interface OrderItem {
  id: string;
  product: Product;
  variant?: ProductVariant;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  customizations?: Record<string, string>;
}

export interface PaymentMethod {
  id: string;
  type: 'credit_card' | 'debit_card' | 'paypal' | 'apple_pay' | 'google_pay';
  last4?: string;
  brand?: string;
  expiryMonth?: number;
  expiryYear?: number;
}

export interface FulfillmentInfo {
  trackingNumber?: string;
  carrier?: string;
  estimatedDelivery?: Date;
  actualDelivery?: Date;
  deliveryInstructions?: string;
}`,
        'src/services/api.ts': `import axios, { AxiosInstance, AxiosRequestConfig, AxiosError } from 'axios';
import { Product, User, Cart, Order } from '../types/product';

/**
 * API Service for handling all HTTP requests to the backend
 * Provides centralized request/response handling, authentication, and error management
 */
class ApiService {
  private client: AxiosInstance;
  private baseURL: string;

  constructor() {
    this.baseURL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  /**
   * Configure request and response interceptors for authentication and error handling
   */
  private setupInterceptors(): void {
    // Request interceptor for adding auth token
    this.client.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('authToken');
        if (token) {
          config.headers.Authorization = \`Bearer \${token}\`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor for handling common errors
    this.client.interceptors.response.use(
      (response) => response,
      (error: AxiosError) => {
        if (error.response?.status === 401) {
          // Clear auth token and redirect to login
          localStorage.removeItem('authToken');
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  /**
   * Generic request method with error handling
   */
  private async request<T>(config: AxiosRequestConfig): Promise<T> {
    try {
      const response = await this.client.request<T>(config);
      return response.data;
    } catch (error) {
      if (axios.isAxiosError(error)) {
        throw new ApiError(
          error.response?.data?.message || error.message,
          error.response?.status || 500,
          error.response?.data
        );
      }
      throw error;
    }
  }

  // Product API Methods
  
  /**
   * Get all products with optional filtering and pagination
   */
  async getProducts(params?: {
    category?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    sortBy?: 'price' | 'rating' | 'newest' | 'popular';
    sortOrder?: 'asc' | 'desc';
    page?: number;
    limit?: number;
  }): Promise<{ products: Product[]; total: number; page: number; totalPages: number }> {
    return this.request({
      method: 'GET',
      url: '/products',
      params,
    });
  }

  /**
   * Get a single product by ID
   */
  async getProduct(id: string): Promise<Product> {
    return this.request({
      method: 'GET',
      url: \`/products/\${id}\`,
    });
  }

  /**
   * Get product recommendations based on user behavior and preferences
   */
  async getProductRecommendations(productId?: string, limit = 10): Promise<Product[]> {
    return this.request({
      method: 'GET',
      url: '/products/recommendations',
      params: { productId, limit },
    });
  }

  /**
   * Search products with advanced filtering
   */
  async searchProducts(query: string, filters?: {
    categories?: string[];
    priceRange?: [number, number];
    rating?: number;
    availability?: boolean;
  }): Promise<{ products: Product[]; suggestions: string[] }> {
    return this.request({
      method: 'POST',
      url: '/products/search',
      data: { query, filters },
    });
  }

  // User Authentication API Methods

  /**
   * Register a new user account
   */
  async register(userData: {
    email: string;
    password: string;
    name: string;
    phone?: string;
  }): Promise<{ user: User; token: string }> {
    const response = await this.request<{ user: User; token: string }>({
      method: 'POST',
      url: '/auth/register',
      data: userData,
    });

    // Store auth token
    localStorage.setItem('authToken', response.token);
    return response;
  }

  /**
   * Login with email and password
   */
  async login(email: string, password: string): Promise<{ user: User; token: string }> {
    const response = await this.request<{ user: User; token: string }>({
      method: 'POST',
      url: '/auth/login',
      data: { email, password },
    });

    // Store auth token
    localStorage.setItem('authToken', response.token);
    return response;
  }

  /**
   * Logout current user
   */
  async logout(): Promise<void> {
    try {
      await this.request({
        method: 'POST',
        url: '/auth/logout',
      });
    } finally {
      localStorage.removeItem('authToken');
    }
  }

  /**
   * Get current user profile
   */
  async getCurrentUser(): Promise<User> {
    return this.request({
      method: 'GET',
      url: '/auth/me',
    });
  }

  /**
   * Update user profile
   */
  async updateProfile(updates: Partial<User>): Promise<User> {
    return this.request({
      method: 'PUT',
      url: '/auth/profile',
      data: updates,
    });
  }

  // Cart API Methods

  /**
   * Get current user's cart
   */
  async getCart(): Promise<Cart> {
    return this.request({
      method: 'GET',
      url: '/cart',
    });
  }

  /**
   * Add item to cart
   */
  async addToCart(productId: string, variantId?: string, quantity = 1): Promise<Cart> {
    return this.request({
      method: 'POST',
      url: '/cart/items',
      data: { productId, variantId, quantity },
    });
  }

  /**
   * Update cart item quantity
   */
  async updateCartItem(itemId: string, quantity: number): Promise<Cart> {
    return this.request({
      method: 'PUT',
      url: \`/cart/items/\${itemId}\`,
      data: { quantity },
    });
  }

  /**
   * Remove item from cart
   */
  async removeFromCart(itemId: string): Promise<Cart> {
    return this.request({
      method: 'DELETE',
      url: \`/cart/items/\${itemId}\`,
    });
  }

  /**
   * Apply discount code to cart
   */
  async applyDiscount(code: string): Promise<Cart> {
    return this.request({
      method: 'POST',
      url: '/cart/discounts',
      data: { code },
    });
  }

  /**
   * Clear entire cart
   */
  async clearCart(): Promise<void> {
    return this.request({
      method: 'DELETE',
      url: '/cart',
    });
  }

  // Order API Methods

  /**
   * Create new order from cart
   */
  async createOrder(orderData: {
    shippingAddressId: string;
    billingAddressId: string;
    paymentMethodId: string;
    notes?: string;
  }): Promise<Order> {
    return this.request({
      method: 'POST',
      url: '/orders',
      data: orderData,
    });
  }

  /**
   * Get user's order history
   */
  async getOrders(params?: {
    status?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ orders: Order[]; total: number }> {
    return this.request({
      method: 'GET',
      url: '/orders',
      params,
    });
  }

  /**
   * Get specific order by ID
   */
  async getOrder(orderId: string): Promise<Order> {
    return this.request({
      method: 'GET',
      url: \`/orders/\${orderId}\`,
    });
  }

  /**
   * Cancel an order
   */
  async cancelOrder(orderId: string, reason?: string): Promise<Order> {
    return this.request({
      method: 'POST',
      url: \`/orders/\${orderId}/cancel\`,
      data: { reason },
    });
  }

  // Payment Methods API

  /**
   * Get user's saved payment methods
   */
  async getPaymentMethods(): Promise<PaymentMethod[]> {
    return this.request({
      method: 'GET',
      url: '/payment-methods',
    });
  }

  /**
   * Add new payment method
   */
  async addPaymentMethod(paymentData: {
    type: string;
    token: string; // Stripe token or similar
    isDefault?: boolean;
  }): Promise<PaymentMethod> {
    return this.request({
      method: 'POST',
      url: '/payment-methods',
      data: paymentData,
    });
  }

  /**
   * Process payment for order
   */
  async processPayment(orderId: string, paymentData: {
    paymentMethodId: string;
    amount: number;
    currency: string;
  }): Promise<{ success: boolean; transactionId: string }> {
    return this.request({
      method: 'POST',
      url: \`/orders/\${orderId}/payment\`,
      data: paymentData,
    });
  }
}

/**
 * Custom API Error class for better error handling
 */
export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public data?: any
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

// Export singleton instance
export const apiService = new ApiService();
export default apiService;`,
        'README.md': `# React E-commerce Platform

A full-featured e-commerce platform built with React, TypeScript, and modern web technologies.

## Features

### Core E-commerce Features
- **Product Catalog**: Browse and search products with advanced filtering
- **Shopping Cart**: Add, update, and manage cart items
- **User Authentication**: Secure registration and login system
- **Order Management**: Complete checkout process with order tracking
- **Payment Processing**: Integration with Stripe for secure payments
- **User Profiles**: Manage addresses, payment methods, and preferences

### Advanced Features
- **Product Recommendations**: AI-powered product suggestions
- **Inventory Management**: Real-time stock tracking and availability
- **Multi-variant Products**: Support for different sizes, colors, etc.
- **Discount System**: Coupon codes and promotional pricing
- **Reviews & Ratings**: Customer feedback and product ratings
- **Responsive Design**: Mobile-first approach with Tailwind CSS

## Tech Stack

### Frontend
- **React 18** with TypeScript
- **React Router** for navigation
- **React Query** for data fetching and caching
- **Redux Toolkit** for state management
- **React Hook Form** for form validation
- **Tailwind CSS** for styling
- **Heroicons** for icons

### Development Tools
- **Vite** for fast development and building
- **ESLint** for code linting
- **Jest** for testing
- **Testing Library** for component testing

## Project Structure

\`\`\`
src/
├── components/          # Reusable UI components
│   ├── common/         # Generic components (buttons, forms, etc.)
│   ├── layout/         # Layout components (header, footer, etc.)
│   └── product/        # Product-specific components
├── pages/              # Page components
├── hooks/              # Custom React hooks
├── contexts/           # React context providers
├── services/           # API and external service integrations
├── store/              # Redux store configuration
├── types/              # TypeScript type definitions
├── utils/              # Utility functions
└── assets/             # Static assets (images, fonts, etc.)
\`\`\`

## Getting Started

### Prerequisites
- Node.js 16+ and npm
- Backend API server running on port 3001

### Installation

1. Clone the repository
\`\`\`bash
git clone https://github.com/yourorg/react-ecommerce.git
cd react-ecommerce
\`\`\`

2. Install dependencies
\`\`\`bash
npm install
\`\`\`

3. Set up environment variables
\`\`\`bash
cp .env.example .env
# Edit .env with your configuration
\`\`\`

4. Start the development server
\`\`\`bash
npm run dev
\`\`\`

The application will be available at \`http://localhost:3000\`.

### Environment Variables

\`\`\`
REACT_APP_API_URL=http://localhost:3001/api
REACT_APP_STRIPE_PUBLISHABLE_KEY=pk_test_...
REACT_APP_GOOGLE_ANALYTICS_ID=GA_MEASUREMENT_ID
\`\`\`

## Testing

Run the test suite:
\`\`\`bash
npm test
\`\`\`

Run tests with coverage:
\`\`\`bash
npm test -- --coverage
\`\`\`

## Building for Production

\`\`\`bash
npm run build
\`\`\`

The built files will be in the \`dist/\` directory.

## API Integration

This frontend integrates with a REST API backend. Key endpoints include:

- \`GET /api/products\` - Product catalog
- \`POST /api/auth/login\` - User authentication
- \`GET /api/cart\` - Shopping cart management
- \`POST /api/orders\` - Order processing
- \`POST /api/payments\` - Payment processing

## Contributing

1. Fork the repository
2. Create your feature branch (\`git checkout -b feature/amazing-feature\`)
3. Commit your changes (\`git commit -m 'Add some amazing feature'\`)
4. Push to the branch (\`git push origin feature/amazing-feature\`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Architecture Notes

### State Management
- **Redux Toolkit** manages global application state
- **React Query** handles server state and caching
- **Context API** for user authentication and cart state

### Performance Optimizations
- Code splitting with React.lazy()
- Image optimization and lazy loading
- Memoization of expensive calculations
- Virtual scrolling for large product lists

### Security Features
- JWT token authentication
- HTTPS enforcement in production
- Input validation and sanitization
- CSRF protection
- Secure payment processing with Stripe

### Accessibility
- WCAG 2.1 AA compliance
- Keyboard navigation support
- Screen reader compatibility
- High contrast mode support`
      }
    },

    'nextjs-blog': {
      name: 'Next.js Blog Platform',
      language: 'typescript',
      framework: 'nextjs',
      projectType: 'webapp',
      complexity: 'standard',
      files: {
        'package.json': JSON.stringify({
          name: 'nextjs-blog',
          version: '0.1.0',
          description: 'Modern blog platform built with Next.js and TypeScript',
          dependencies: {
            'next': '^13.4.0',
            'react': '^18.2.0',
            'react-dom': '^18.2.0',
            '@next/mdx': '^13.4.0',
            'gray-matter': '^4.0.3',
            'remark': '^14.0.3',
            'remark-html': '^15.0.2',
            'date-fns': '^2.30.0'
          },
          devDependencies: {
            '@types/node': '^20.0.0',
            '@types/react': '^18.0.0',
            '@types/react-dom': '^18.0.0',
            'typescript': '^5.0.0',
            'eslint': '^8.0.0',
            'eslint-config-next': '^13.4.0'
          },
          scripts: {
            'dev': 'next dev',
            'build': 'next build',
            'start': 'next start',
            'lint': 'next lint'
          }
        }, null, 2),
        'next.config.js': `/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    appDir: true,
  },
  images: {
    domains: ['images.unsplash.com', 'via.placeholder.com'],
  },
}

module.exports = nextConfig`,
        'app/layout.tsx': `import './globals.css'
import { Inter } from 'next/font/google'
import { Header } from '../components/Header'
import { Footer } from '../components/Footer'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'My Blog',
  description: 'A modern blog built with Next.js',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-1">
            {children}
          </main>
          <Footer />
        </div>
      </body>
    </html>
  )
}`,
        'lib/posts.ts': `import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'
import { remark } from 'remark'
import html from 'remark-html'

const postsDirectory = path.join(process.cwd(), 'posts')

export interface Post {
  id: string
  title: string
  date: string
  excerpt: string
  content: string
  author: string
  tags: string[]
  coverImage?: string
}

export function getSortedPostsData(): Post[] {
  // Get file names under /posts
  const fileNames = fs.readdirSync(postsDirectory)
  const allPostsData = fileNames.map((fileName) => {
    // Remove ".md" from file name to get id
    const id = fileName.replace(/\\.md$/, '')

    // Read markdown file as string
    const fullPath = path.join(postsDirectory, fileName)
    const fileContents = fs.readFileSync(fullPath, 'utf8')

    // Use gray-matter to parse the post metadata section
    const matterResult = matter(fileContents)

    // Combine the data with the id
    return {
      id,
      ...matterResult.data,
    } as Post
  })

  // Sort posts by date
  return allPostsData.sort((a, b) => {
    if (a.date < b.date) {
      return 1
    } else {
      return -1
    }
  })
}

export function getAllPostIds() {
  const fileNames = fs.readdirSync(postsDirectory)
  return fileNames.map((fileName) => {
    return {
      params: {
        id: fileName.replace(/\\.md$/, ''),
      },
    }
  })
}

export async function getPostData(id: string): Promise<Post> {
  const fullPath = path.join(postsDirectory, \`\${id}.md\`)
  const fileContents = fs.readFileSync(fullPath, 'utf8')

  // Use gray-matter to parse the post metadata section
  const matterResult = matter(fileContents)

  // Use remark to convert markdown into HTML string
  const processedContent = await remark()
    .use(html)
    .process(matterResult.content)
  const contentHtml = processedContent.toString()

  // Combine the data with the id and contentHtml
  return {
    id,
    content: contentHtml,
    ...matterResult.data,
  } as Post
}

export function getPostsByTag(tag: string): Post[] {
  const allPosts = getSortedPostsData()
  return allPosts.filter(post => post.tags.includes(tag))
}

export function getAllTags(): string[] {
  const allPosts = getSortedPostsData()
  const tagSet = new Set<string>()
  
  allPosts.forEach(post => {
    post.tags.forEach(tag => tagSet.add(tag))
  })
  
  return Array.from(tagSet).sort()
}`
      }
    },

    // Python Django Project
    'django-webapp': {
      name: 'Django Web Application',
      language: 'python',
      framework: 'django',
      projectType: 'webapp',
      complexity: 'enterprise',
      files: {
        'requirements.txt': `Django==4.2.0
djangorestframework==3.14.0
django-cors-headers==4.0.0
django-filter==23.1
Pillow==9.5.0
python-decouple==3.8
psycopg2-binary==2.9.6
redis==4.5.4
celery==5.2.7
gunicorn==20.1.0
whitenoise==6.4.0
pytest-django==4.5.2
black==23.3.0
flake8==6.0.0`,
        'manage.py': `#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys


def main():
    """Run administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myproject.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()`,
        'myproject/settings.py': `"""
Django settings for myproject project.

Generated by 'django-admin startproject' using Django 4.2.

For more information on this file, see
https://docs.djangoproject.com/en/4.2/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/4.2/ref/settings/
"""

from pathlib import Path
from decouple import config
import os

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = config('SECRET_KEY', default='django-insecure-change-me')

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = config('DEBUG', default=True, cast=bool)

ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='localhost,127.0.0.1', cast=lambda v: [s.strip() for s in v.split(',')])

# Application definition
DJANGO_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
]

THIRD_PARTY_APPS = [
    'rest_framework',
    'corsheaders',
    'django_filters',
]

LOCAL_APPS = [
    'accounts',
    'blog',
    'products',
    'orders',
]

INSTALLED_APPS = DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'myproject.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'myproject.wsgi.application'

# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': config('DB_NAME', default='myproject'),
        'USER': config('DB_USER', default='postgres'),
        'PASSWORD': config('DB_PASSWORD', default='password'),
        'HOST': config('DB_HOST', default='localhost'),
        'PORT': config('DB_PORT', default='5432'),
    }
}

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_DIRS = [BASE_DIR / 'static']

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Custom user model
AUTH_USER_MODEL = 'accounts.User'

# Django REST Framework
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.TokenAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 20,
    'DEFAULT_FILTER_BACKENDS': [
        'django_filters.rest_framework.DjangoFilterBackend',
        'rest_framework.filters.SearchFilter',
        'rest_framework.filters.OrderingFilter',
    ],
}

# CORS settings
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
]

# Celery Configuration
CELERY_BROKER_URL = config('REDIS_URL', default='redis://localhost:6379')
CELERY_RESULT_BACKEND = config('REDIS_URL', default='redis://localhost:6379')
CELERY_ACCEPT_CONTENT = ['application/json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = TIME_ZONE

# Email configuration
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = config('EMAIL_HOST', default='smtp.gmail.com')
EMAIL_PORT = config('EMAIL_PORT', default=587, cast=int)
EMAIL_USE_TLS = True
EMAIL_HOST_USER = config('EMAIL_HOST_USER', default='')
EMAIL_HOST_PASSWORD = config('EMAIL_HOST_PASSWORD', default='')
DEFAULT_FROM_EMAIL = config('DEFAULT_FROM_EMAIL', default='noreply@example.com')

# Security settings for production
if not DEBUG:
    SECURE_BROWSER_XSS_FILTER = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_REDIRECT_EXEMPT = []
    SECURE_SSL_REDIRECT = True
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True`,
        'accounts/models.py': `from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils.translation import gettext_lazy as _


class User(AbstractUser):
    """
    Custom user model that extends Django's AbstractUser.
    
    Adds additional fields for enhanced user profiles and business requirements.
    """
    
    email = models.EmailField(_('email address'), unique=True)
    phone_number = models.CharField(
        _('phone number'), 
        max_length=20, 
        blank=True, 
        null=True,
        help_text=_('User\'s phone number for contact and verification')
    )
    date_of_birth = models.DateField(
        _('date of birth'), 
        blank=True, 
        null=True,
        help_text=_('User\'s date of birth for age verification and personalization')
    )
    avatar = models.ImageField(
        _('avatar'), 
        upload_to='avatars/%Y/%m/%d/', 
        blank=True, 
        null=True,
        help_text=_('User profile picture')
    )
    
    # Account status and preferences
    is_verified = models.BooleanField(
        _('verified'), 
        default=False,
        help_text=_('Designates whether this user has verified their email address.')
    )
    is_premium = models.BooleanField(
        _('premium member'), 
        default=False,
        help_text=_('Designates whether this user has a premium subscription.')
    )
    newsletter_subscription = models.BooleanField(
        _('newsletter subscription'), 
        default=True,
        help_text=_('Whether user wants to receive newsletter emails')
    )
    
    # Timestamps
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)
    last_login_ip = models.GenericIPAddressField(
        _('last login IP'), 
        blank=True, 
        null=True,
        help_text=_('IP address of the user\'s last login')
    )
    
    # User preferences
    preferred_language = models.CharField(
        _('preferred language'),
        max_length=10,
        choices=[
            ('en', _('English')),
            ('es', _('Spanish')),
            ('fr', _('French')),
            ('de', _('German')),
            ('it', _('Italian')),
        ],
        default='en',
        help_text=_('User\'s preferred language for the interface')
    )
    
    timezone = models.CharField(
        _('timezone'),
        max_length=50,
        default='UTC',
        help_text=_('User\'s timezone for displaying dates and times')
    )
    
    # Business fields
    company = models.CharField(
        _('company'), 
        max_length=100, 
        blank=True, 
        null=True,
        help_text=_('Company or organization the user is associated with')
    )
    job_title = models.CharField(
        _('job title'), 
        max_length=100, 
        blank=True, 
        null=True,
        help_text=_('User\'s job title or role')
    )
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'first_name', 'last_name']
    
    class Meta:
        verbose_name = _('User')
        verbose_name_plural = _('Users')
        db_table = 'auth_user'
        indexes = [
            models.Index(fields=['email']),
            models.Index(fields=['is_active', 'is_verified']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        return f"{self.get_full_name()} ({self.email})"
    
    def get_full_name(self):
        """
        Return the first_name plus the last_name, with a space in between.
        """
        full_name = f'{self.first_name} {self.last_name}'
        return full_name.strip()
    
    def get_display_name(self):
        """
        Return the user's display name. Prefer full name, fallback to username.
        """
        full_name = self.get_full_name()
        return full_name if full_name else self.username
    
    @property
    def is_profile_complete(self):
        """
        Check if user profile has essential information filled out.
        """
        required_fields = [self.first_name, self.last_name, self.email]
        return all(field for field in required_fields)
    
    def get_avatar_url(self):
        """
        Return user's avatar URL or a default avatar if none exists.
        """
        if self.avatar:
            return self.avatar.url
        return '/static/images/default-avatar.png'


class UserProfile(models.Model):
    """
    Extended user profile information that doesn't belong in the main User model.
    
    This model stores additional user data that might change frequently or
    is not essential for authentication and basic user operations.
    """
    
    user = models.OneToOneField(
        User, 
        on_delete=models.CASCADE, 
        related_name='profile',
        verbose_name=_('user')
    )
    
    # Personal information
    bio = models.TextField(
        _('bio'), 
        max_length=500, 
        blank=True,
        help_text=_('Brief description about the user')
    )
    website = models.URLField(
        _('website'), 
        blank=True,
        help_text=_('User\'s personal website or portfolio')
    )
    location = models.CharField(
        _('location'), 
        max_length=100, 
        blank=True,
        help_text=_('User\'s current location (city, country)')
    )
    
    # Social media links
    twitter_handle = models.CharField(
        _('Twitter handle'), 
        max_length=50, 
        blank=True,
        help_text=_('Twitter username without @')
    )
    linkedin_url = models.URLField(
        _('LinkedIn URL'), 
        blank=True,
        help_text=_('Full LinkedIn profile URL')
    )
    github_username = models.CharField(
        _('GitHub username'), 
        max_length=50, 
        blank=True,
        help_text=_('GitHub username for developers')
    )
    
    # Privacy settings
    show_email = models.BooleanField(
        _('show email publicly'), 
        default=False,
        help_text=_('Whether to display email on public profile')
    )
    show_location = models.BooleanField(
        _('show location publicly'), 
        default=True,
        help_text=_('Whether to display location on public profile')
    )
    allow_messages = models.BooleanField(
        _('allow direct messages'), 
        default=True,
        help_text=_('Whether other users can send direct messages')
    )
    
    # Notification preferences
    email_notifications = models.BooleanField(
        _('email notifications'), 
        default=True,
        help_text=_('Receive notifications via email')
    )
    push_notifications = models.BooleanField(
        _('push notifications'), 
        default=True,
        help_text=_('Receive push notifications in browser/app')
    )
    weekly_digest = models.BooleanField(
        _('weekly digest'), 
        default=True,
        help_text=_('Receive weekly summary email')
    )
    
    # Activity tracking
    profile_views = models.PositiveIntegerField(
        _('profile views'), 
        default=0,
        help_text=_('Number of times this profile has been viewed')
    )
    last_seen = models.DateTimeField(
        _('last seen'), 
        auto_now=True,
        help_text=_('Last time user was active on the platform')
    )
    
    # Timestamps
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)
    
    class Meta:
        verbose_name = _('User Profile')
        verbose_name_plural = _('User Profiles')
        db_table = 'user_profiles'
    
    def __str__(self):
        return f"{self.user.get_display_name()}'s Profile"
    
    @property
    def social_links(self):
        """
        Return a dictionary of available social media links.
        """
        links = {}
        if self.twitter_handle:
            links['twitter'] = f"https://twitter.com/{self.twitter_handle}"
        if self.linkedin_url:
            links['linkedin'] = self.linkedin_url
        if self.github_username:
            links['github'] = f"https://github.com/{self.github_username}"
        if self.website:
            links['website'] = self.website
        return links


class UserAddress(models.Model):
    """
    Model to store multiple addresses for a user (shipping, billing, etc.)
    """
    
    ADDRESS_TYPES = [
        ('shipping', _('Shipping')),
        ('billing', _('Billing')),
        ('both', _('Both Shipping and Billing')),
    ]
    
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        related_name='addresses',
        verbose_name=_('user')
    )
    
    type = models.CharField(
        _('address type'),
        max_length=20,
        choices=ADDRESS_TYPES,
        default='shipping'
    )
    
    is_default = models.BooleanField(
        _('default address'), 
        default=False,
        help_text=_('Whether this is the user\'s default address')
    )
    
    # Address fields
    label = models.CharField(
        _('address label'),
        max_length=50,
        help_text=_('User-friendly name for this address (e.g., "Home", "Office")')
    )
    first_name = models.CharField(_('first name'), max_length=50)
    last_name = models.CharField(_('last name'), max_length=50)
    company = models.CharField(_('company'), max_length=100, blank=True)
    
    address_line_1 = models.CharField(_('address line 1'), max_length=255)
    address_line_2 = models.CharField(_('address line 2'), max_length=255, blank=True)
    city = models.CharField(_('city'), max_length=100)
    state_province = models.CharField(_('state/province'), max_length=100)
    postal_code = models.CharField(_('postal code'), max_length=20)
    country = models.CharField(_('country'), max_length=100)
    
    phone_number = models.CharField(
        _('phone number'), 
        max_length=20, 
        blank=True,
        help_text=_('Phone number for delivery contact')
    )
    
    # Special instructions
    delivery_instructions = models.TextField(
        _('delivery instructions'),
        blank=True,
        help_text=_('Special instructions for delivery (e.g., gate code, building entrance)')
    )
    
    # Timestamps
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)
    
    class Meta:
        verbose_name = _('User Address')
        verbose_name_plural = _('User Addresses')
        db_table = 'user_addresses'
        unique_together = ['user', 'label']  # Prevent duplicate labels per user
        indexes = [
            models.Index(fields=['user', 'is_default']),
            models.Index(fields=['user', 'type']),
        ]
    
    def __str__(self):
        return f"{self.user.get_display_name()} - {self.label}"
    
    def get_full_address(self):
        """
        Return the complete formatted address as a single string.
        """
        lines = [self.address_line_1]
        if self.address_line_2:
            lines.append(self.address_line_2)
        lines.append(f"{self.city}, {self.state_province} {self.postal_code}")
        lines.append(self.country)
        return "\\n".join(lines)
    
    def get_recipient_name(self):
        """
        Return the full name of the address recipient.
        """
        return f"{self.first_name} {self.last_name}".strip()`,
        'README.md': `# Django Web Application

A comprehensive web application built with Django 4.2 and Django REST Framework.

## Features

### User Management
- Custom user model with extended profile information
- Email-based authentication
- User profiles with social media integration
- Multiple address management
- Account verification and premium subscriptions

### Core Features
- RESTful API with Django REST Framework
- PostgreSQL database integration
- Redis caching and Celery task queue
- Email notification system
- Media file handling with Pillow
- CORS support for frontend integration

### Development Features
- Environment-based configuration
- Comprehensive test coverage with pytest
- Code formatting with Black
- Linting with Flake8
- Static file serving with WhiteNoise
- Production-ready security settings

## Project Structure

\`\`\`
myproject/
├── myproject/           # Main project configuration
│   ├── settings.py     # Django settings with environment configs
│   ├── urls.py         # Main URL configuration
│   └── wsgi.py         # WSGI application
├── accounts/            # User authentication and profiles
│   ├── models.py       # Custom User model and UserProfile
│   ├── views.py        # Authentication views
│   ├── serializers.py  # API serializers
│   └── admin.py        # Admin interface customization
├── blog/               # Blog application (if applicable)
├── products/           # Product management
├── orders/             # Order processing
├── templates/          # HTML templates
├── static/             # Static files (CSS, JS, images)
├── media/              # User-uploaded files
└── requirements.txt    # Python dependencies
\`\`\`

## Technology Stack

- **Backend**: Django 4.2, Django REST Framework
- **Database**: PostgreSQL
- **Cache/Queue**: Redis, Celery
- **Media**: Pillow for image processing
- **Testing**: pytest-django
- **Code Quality**: Black, Flake8
- **Deployment**: Gunicorn, WhiteNoise

## Getting Started

### Prerequisites
- Python 3.8+
- PostgreSQL 12+
- Redis (for caching and Celery)

### Installation

1. Clone the repository:
\`\`\`bash
git clone <repository-url>
cd django-webapp
\`\`\`

2. Create and activate virtual environment:
\`\`\`bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\\Scripts\\activate
\`\`\`

3. Install dependencies:
\`\`\`bash
pip install -r requirements.txt
\`\`\`

4. Set up environment variables:
\`\`\`bash
cp .env.example .env
# Edit .env with your configuration
\`\`\`

5. Set up the database:
\`\`\`bash
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
\`\`\`

6. Collect static files:
\`\`\`bash
python manage.py collectstatic
\`\`\`

7. Run the development server:
\`\`\`bash
python manage.py runserver
\`\`\`

### Running with Celery

Start the Celery worker in a separate terminal:
\`\`\`bash
celery -A myproject worker -l info
\`\`\`

Start the Celery beat scheduler:
\`\`\`bash
celery -A myproject beat -l info
\`\`\`

## API Documentation

The application provides a RESTful API with the following key endpoints:

### Authentication
- \`POST /api/auth/register/\` - User registration
- \`POST /api/auth/login/\` - User login
- \`POST /api/auth/logout/\` - User logout
- \`GET /api/auth/user/\` - Get current user info

### User Profiles
- \`GET /api/users/profile/\` - Get user profile
- \`PUT /api/users/profile/\` - Update user profile
- \`GET /api/users/addresses/\` - List user addresses
- \`POST /api/users/addresses/\` - Create new address

## Configuration

### Environment Variables

\`\`\`bash
# Database
DB_NAME=myproject
DB_USER=postgres
DB_PASSWORD=your_password
DB_HOST=localhost
DB_PORT=5432

# Redis
REDIS_URL=redis://localhost:6379

# Email
EMAIL_HOST=smtp.gmail.com
EMAIL_HOST_USER=your_email@gmail.com
EMAIL_HOST_PASSWORD=your_app_password
DEFAULT_FROM_EMAIL=noreply@yoursite.com

# Security
SECRET_KEY=your-secret-key
DEBUG=False
ALLOWED_HOSTS=yoursite.com,www.yoursite.com
\`\`\`

## Testing

Run the test suite:
\`\`\`bash
pytest
\`\`\`

Run with coverage:
\`\`\`bash
pytest --cov=.
\`\`\`

## Code Quality

Format code with Black:
\`\`\`bash
black .
\`\`\`

Lint code with Flake8:
\`\`\`bash
flake8 .
\`\`\`

## Deployment

### Production Checklist
- [ ] Set \`DEBUG=False\`
- [ ] Configure \`ALLOWED_HOSTS\`
- [ ] Set up PostgreSQL database
- [ ] Configure Redis for caching
- [ ] Set up static file serving
- [ ] Configure email backend
- [ ] Set up SSL/HTTPS
- [ ] Configure logging
- [ ] Set up monitoring

### Deployment Commands
\`\`\`bash
# Collect static files
python manage.py collectstatic --noinput

# Run migrations
python manage.py migrate

# Start Gunicorn
gunicorn myproject.wsgi:application --bind 0.0.0.0:8000
\`\`\`

## Contributing

1. Fork the repository
2. Create your feature branch (\`git checkout -b feature/amazing-feature\`)
3. Commit your changes (\`git commit -m 'Add some amazing feature'\`)
4. Push to the branch (\`git push origin feature/amazing-feature\`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.`
      }
    },

    // Java Spring Boot Project
    'spring-boot-api': {
      name: 'Spring Boot REST API',
      language: 'java',
      framework: 'spring-boot',
      projectType: 'api',
      complexity: 'enterprise',
      files: {
        'pom.xml': `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.1.0</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    
    <groupId>com.example</groupId>
    <artifactId>spring-boot-api</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>spring-boot-api</name>
    <description>Spring Boot REST API for user and product management</description>
    
    <properties>
        <java.version>17</java.version>
        <spring-cloud.version>2022.0.3</spring-cloud.version>
    </properties>
    
    <dependencies>
        <!-- Spring Boot Starters -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-cache</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        
        <!-- Database -->
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>org.flywaydb</groupId>
            <artifactId>flyway-core</artifactId>
        </dependency>
        
        <!-- JWT -->
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-api</artifactId>
            <version>0.11.5</version>
        </dependency>
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-impl</artifactId>
            <version>0.11.5</version>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-jackson</artifactId>
            <version>0.11.5</version>
            <scope>runtime</scope>
        </dependency>
        
        <!-- Documentation -->
        <dependency>
            <groupId>org.springdoc</groupId>
            <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
            <version>2.1.0</version>
        </dependency>
        
        <!-- Testing -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.springframework.security</groupId>
            <artifactId>spring-security-test</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>junit-jupiter</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>postgresql</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
    
    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>org.testcontainers</groupId>
                <artifactId>testcontainers-bom</artifactId>
                <version>1.18.3</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>
    
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <configuration>
                    <excludes>
                        <exclude>
                            <groupId>org.projectlombok</groupId>
                            <artifactId>lombok</artifactId>
                        </exclude>
                    </excludes>
                </configuration>
            </plugin>
            
            <plugin>
                <groupId>org.flywaydb</groupId>
                <artifactId>flyway-maven-plugin</artifactId>
                <version>9.8.1</version>
                <configuration>
                    <url>jdbc:postgresql://localhost:5432/springapi</url>
                    <user>postgres</user>
                    <password>password</password>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>`,
        'src/main/java/com/example/springbootapi/SpringBootApiApplication.java': `package com.example.springbootapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Main application class for the Spring Boot REST API.
 * 
 * This application provides a comprehensive REST API for user and product management
 * with features including:
 * - JWT-based authentication and authorization
 * - RESTful endpoints for CRUD operations
 * - PostgreSQL database integration with JPA
 * - Caching support for improved performance
 * - Comprehensive validation and error handling
 * - OpenAPI documentation with Swagger UI
 * - Actuator endpoints for monitoring and health checks
 * 
 * @author Development Team
 * @version 1.0.0
 * @since 2023-06-01
 */
@SpringBootApplication
@EnableJpaAuditing
@EnableCaching
@EnableAsync
public class SpringBootApiApplication {

    /**
     * Main method to start the Spring Boot application.
     * 
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(SpringBootApiApplication.class, args);
    }
}`,
        'src/main/java/com/example/springbootapi/model/User.java': `package com.example.springbootapi.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * User entity representing a user in the system.
 * 
 * This entity implements Spring Security's UserDetails interface to integrate
 * seamlessly with Spring Security authentication and authorization mechanisms.
 * 
 * Features:
 * - JWT-compatible user authentication
 * - Role-based access control
 * - Account status management (enabled, locked, expired)
 * - Audit fields for tracking creation and modification
 * - Email uniqueness constraint
 * - Password strength validation
 * 
 * @author Development Team
 * @version 1.0.0
 */
@Entity
@Table(name = "users", 
       uniqueConstraints = {
           @UniqueConstraint(columnNames = "username"),
           @UniqueConstraint(columnNames = "email")
       })
@EntityListeners(AuditingEntityListener.class)
public class User implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 20, message = "Username must be between 3 and 20 characters")
    @Column(name = "username", unique = true, nullable = false)
    private String username;

    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    @Size(max = 50, message = "Email must be less than 50 characters")
    @Column(name = "email", unique = true, nullable = false)
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 8, max = 120, message = "Password must be between 8 and 120 characters")
    @JsonIgnore
    @Column(name = "password", nullable = false)
    private String password;

    @NotBlank(message = "First name is required")
    @Size(max = 50, message = "First name must be less than 50 characters")
    @Column(name = "first_name", nullable = false)
    private String firstName;

    @NotBlank(message = "Last name is required")
    @Size(max = 50, message = "Last name must be less than 50 characters")
    @Column(name = "last_name", nullable = false)
    private String lastName;

    @Size(max = 15, message = "Phone number must be less than 15 characters")
    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "is_enabled", nullable = false)
    private Boolean enabled = true;

    @Column(name = "is_account_non_expired", nullable = false)
    private Boolean accountNonExpired = true;

    @Column(name = "is_account_non_locked", nullable = false)
    private Boolean accountNonLocked = true;

    @Column(name = "is_credentials_non_expired", nullable = false)
    private Boolean credentialsNonExpired = true;

    @Column(name = "email_verified", nullable = false)
    private Boolean emailVerified = false;

    @Column(name = "last_login")
    private LocalDateTime lastLogin;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user_roles",
               joinColumns = @JoinColumn(name = "user_id"),
               inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles;

    @CreatedDate
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // Constructors
    public User() {}

    public User(String username, String email, String password, String firstName, String lastName) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // UserDetails implementation
    @Override
    @JsonIgnore
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return roles.stream()
                   .map(role -> new SimpleGrantedAuthority("ROLE_" + role.getName().name()))
                   .toList();
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    @JsonIgnore
    public boolean isAccountNonExpired() {
        return accountNonExpired;
    }

    @Override
    @JsonIgnore
    public boolean isAccountNonLocked() {
        return accountNonLocked;
    }

    @Override
    @JsonIgnore
    public boolean isCredentialsNonExpired() {
        return credentialsNonExpired;
    }

    @Override
    @JsonIgnore
    public boolean isEnabled() {
        return enabled;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Boolean getAccountNonExpired() {
        return accountNonExpired;
    }

    public void setAccountNonExpired(Boolean accountNonExpired) {
        this.accountNonExpired = accountNonExpired;
    }

    public Boolean getAccountNonLocked() {
        return accountNonLocked;
    }

    public void setAccountNonLocked(Boolean accountNonLocked) {
        this.accountNonLocked = accountNonLocked;
    }

    public Boolean getCredentialsNonExpired() {
        return credentialsNonExpired;
    }

    public void setCredentialsNonExpired(Boolean credentialsNonExpired) {
        this.credentialsNonExpired = credentialsNonExpired;
    }

    public Boolean getEmailVerified() {
        return emailVerified;
    }

    public void setEmailVerified(Boolean emailVerified) {
        this.emailVerified = emailVerified;
    }

    public LocalDateTime getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(LocalDateTime lastLogin) {
        this.lastLogin = lastLogin;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    // Business methods
    /**
     * Returns the full name of the user by combining first and last name.
     * 
     * @return Full name as "firstName lastName"
     */
    public String getFullName() {
        return firstName + " " + lastName;
    }

    /**
     * Checks if the user has a specific role.
     * 
     * @param roleName The role name to check
     * @return true if user has the role, false otherwise
     */
    public boolean hasRole(RoleName roleName) {
        return roles.stream()
                   .anyMatch(role -> role.getName().equals(roleName));
    }

    /**
     * Updates the last login timestamp to current time.
     */
    public void updateLastLogin() {
        this.lastLogin = LocalDateTime.now();
    }

    /**
     * Checks if the user profile is complete.
     * A complete profile has all required fields filled.
     * 
     * @return true if profile is complete, false otherwise
     */
    public boolean isProfileComplete() {
        return username != null && !username.isBlank() &&
               email != null && !email.isBlank() &&
               firstName != null && !firstName.isBlank() &&
               lastName != null && !lastName.isBlank();
    }

    // equals, hashCode, and toString
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(id, user.id) &&
               Objects.equals(username, user.username) &&
               Objects.equals(email, user.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, username, email);
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\\'' +
                ", email='" + email + '\\'' +
                ", firstName='" + firstName + '\\'' +
                ", lastName='" + lastName + '\\'' +
                ", enabled=" + enabled +
                ", emailVerified=" + emailVerified +
                ", createdAt=" + createdAt +
                '}';
    }
}`,
        'src/main/java/com/example/springbootapi/controller/UserController.java': `package com.example.springbootapi.controller;

import com.example.springbootapi.dto.UserDto;
import com.example.springbootapi.dto.UserUpdateRequest;
import com.example.springbootapi.model.User;
import com.example.springbootapi.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

/**
 * REST Controller for user management operations.
 * 
 * This controller provides endpoints for:
 * - Retrieving user information
 * - Updating user profiles
 * - Managing user accounts (admin operations)
 * - User search and filtering
 * 
 * All endpoints require authentication, and some require specific roles.
 * 
 * @author Development Team
 * @version 1.0.0
 */
@RestController
@RequestMapping("/api/users")
@Tag(name = "User Management", description = "Operations related to user management")
@SecurityRequirement(name = "bearerAuth")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Get current user's profile information.
     * 
     * @param authentication Current authentication context
     * @return Current user's profile data
     */
    @GetMapping("/me")
    @Operation(summary = "Get current user profile", 
               description = "Retrieve the profile information of the currently authenticated user")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved user profile",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = UserDto.class))),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token"),
        @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<UserDto> getCurrentUser(Authentication authentication) {
        String username = authentication.getName();
        UserDto user = userService.getUserByUsername(username);
        return ResponseEntity.ok(user);
    }

    /**
     * Update current user's profile information.
     * 
     * @param authentication Current authentication context
     * @param updateRequest Updated user information
     * @return Updated user profile
     */
    @PutMapping("/me")
    @Operation(summary = "Update current user profile", 
               description = "Update the profile information of the currently authenticated user")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully updated user profile",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = UserDto.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input data"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token"),
        @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<UserDto> updateCurrentUser(
            Authentication authentication,
            @Valid @RequestBody UserUpdateRequest updateRequest) {
        
        String username = authentication.getName();
        UserDto updatedUser = userService.updateUser(username, updateRequest);
        return ResponseEntity.ok(updatedUser);
    }

    /**
     * Get all users with pagination and optional filtering.
     * Requires ADMIN role.
     * 
     * @param pageable Pagination parameters
     * @param search Optional search term for filtering users
     * @param enabled Optional filter by enabled status
     * @return Paginated list of users
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get all users", 
               description = "Retrieve a paginated list of all users. Requires ADMIN role.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved users"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token"),
        @ApiResponse(responseCode = "403", description = "Forbidden - Insufficient privileges")
    })
    public ResponseEntity<Page<UserDto>> getAllUsers(
            @PageableDefault(size = 20) Pageable pageable,
            @Parameter(description = "Search term to filter users by username, email, or name")
            @RequestParam(required = false) String search,
            @Parameter(description = "Filter users by enabled status")
            @RequestParam(required = false) Boolean enabled) {
        
        Page<UserDto> users = userService.getAllUsers(pageable, search, enabled);
        return ResponseEntity.ok(users);
    }

    /**
     * Get user by ID.
     * Requires ADMIN role or the user must be requesting their own information.
     * 
     * @param userId User ID to retrieve
     * @param authentication Current authentication context
     * @return User information
     */
    @GetMapping("/{userId}")
    @PreAuthorize("hasRole('ADMIN') or #userId == authentication.principal.id")
    @Operation(summary = "Get user by ID", 
               description = "Retrieve user information by ID. Users can access their own data, admins can access any user.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved user",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = UserDto.class))),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token"),
        @ApiResponse(responseCode = "403", description = "Forbidden - Insufficient privileges"),
        @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<UserDto> getUserById(
            @Parameter(description = "User ID", required = true)
            @PathVariable Long userId,
            Authentication authentication) {
        
        UserDto user = userService.getUserById(userId);
        return ResponseEntity.ok(user);
    }

    /**
     * Update user by ID.
     * Requires ADMIN role.
     * 
     * @param userId User ID to update
     * @param updateRequest Updated user information
     * @return Updated user information
     */
    @PutMapping("/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Update user by ID", 
               description = "Update user information by ID. Requires ADMIN role.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully updated user",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = UserDto.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input data"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token"),
        @ApiResponse(responseCode = "403", description = "Forbidden - Insufficient privileges"),
        @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<UserDto> updateUser(
            @Parameter(description = "User ID", required = true)
            @PathVariable Long userId,
            @Valid @RequestBody UserUpdateRequest updateRequest) {
        
        UserDto updatedUser = userService.updateUserById(userId, updateRequest);
        return ResponseEntity.ok(updatedUser);
    }

    /**
     * Enable or disable user account.
     * Requires ADMIN role.
     * 
     * @param userId User ID to update
     * @param enabled Whether to enable or disable the account
     * @return Updated user information
     */
    @PatchMapping("/{userId}/enabled")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Enable or disable user account", 
               description = "Enable or disable a user account. Requires ADMIN role.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully updated user status",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = UserDto.class))),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token"),
        @ApiResponse(responseCode = "403", description = "Forbidden - Insufficient privileges"),
        @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<UserDto> setUserEnabled(
            @Parameter(description = "User ID", required = true)
            @PathVariable Long userId,
            @Parameter(description = "Whether to enable the user account", required = true)
            @RequestParam Boolean enabled) {
        
        UserDto updatedUser = userService.setUserEnabled(userId, enabled);
        return ResponseEntity.ok(updatedUser);
    }

    /**
     * Delete user account.
     * Requires ADMIN role.
     * 
     * @param userId User ID to delete
     * @return No content response
     */
    @DeleteMapping("/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete user account", 
               description = "Permanently delete a user account. Requires ADMIN role.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Successfully deleted user"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token"),
        @ApiResponse(responseCode = "403", description = "Forbidden - Insufficient privileges"),
        @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<Void> deleteUser(
            @Parameter(description = "User ID", required = true)
            @PathVariable Long userId) {
        
        userService.deleteUser(userId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Get user statistics.
     * Requires ADMIN role.
     * 
     * @return User statistics including total count, active users, etc.
     */
    @GetMapping("/statistics")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get user statistics", 
               description = "Retrieve user statistics including total count, active users, new registrations, etc. Requires ADMIN role.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved user statistics"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token"),
        @ApiResponse(responseCode = "403", description = "Forbidden - Insufficient privileges")
    })
    public ResponseEntity<?> getUserStatistics() {
        // This would typically return user statistics
        // Implementation would depend on specific requirements
        return ResponseEntity.ok().build();
    }
}`,
        'src/main/resources/application.yml': `# Spring Boot Application Configuration
spring:
  application:
    name: spring-boot-api
  
  # Database Configuration
  datasource:
    url: jdbc:postgresql://localhost:5432/springapi
    username: \${DB_USERNAME:postgres}
    password: \${DB_PASSWORD:password}
    driver-class-name: org.postgresql.Driver
    hikari:
      connection-timeout: 20000
      maximum-pool-size: 10
      minimum-idle: 2
      idle-timeout: 300000
      max-lifetime: 1200000
      leak-detection-threshold: 60000
  
  # JPA Configuration
  jpa:
    hibernate:
      ddl-auto: validate
    show-sql: false
    properties:
      hibernate:
        dialect: org.hibernate.dialect.PostgreSQLDialect
        format_sql: true
        use_sql_comments: true
        jdbc:
          batch_size: 20
        order_inserts: true
        order_updates: true
        batch_versioned_data: true
    open-in-view: false
  
  # Flyway Configuration
  flyway:
    enabled: true
    baseline-on-migrate: true
    locations: classpath:db/migration
    schemas: public
  
  # Security Configuration
  security:
    user:
      name: admin
      password: admin
      roles: ADMIN
  
  # Cache Configuration
  cache:
    type: simple
    cache-names:
      - users
      - roles
      - permissions
  
  # JSON Configuration
  jackson:
    serialization:
      write-dates-as-timestamps: false
    time-zone: UTC
    date-format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'
  
  # File Upload Configuration
  servlet:
    multipart:
      max-file-size: 10MB
      max-request-size: 10MB
  
  # Profile Configuration
  profiles:
    active: \${SPRING_PROFILES_ACTIVE:dev}

# Server Configuration
server:
  port: \${SERVER_PORT:8080}
  servlet:
    context-path: /api/v1
  error:
    include-message: always
    include-binding-errors: always
    include-stacktrace: on_param
    include-exception: false

# Application Configuration
app:
  jwt:
    secret: \${JWT_SECRET:mySecretKey}
    expiration: \${JWT_EXPIRATION:86400000} # 24 hours in milliseconds
    refresh-expiration: \${JWT_REFRESH_EXPIRATION:2592000000} # 30 days in milliseconds
  
  security:
    cors:
      allowed-origins: \${CORS_ALLOWED_ORIGINS:http://localhost:3000,http://localhost:4200}
      allowed-methods: GET,POST,PUT,DELETE,OPTIONS,PATCH
      allowed-headers: "*"
      allow-credentials: true
      max-age: 3600
  
  swagger:
    contact-name: Development Team
    contact-email: dev-team@example.com
    contact-url: https://example.com
    app-name: Spring Boot REST API
    app-description: A comprehensive REST API for user and product management
    app-version: 1.0.0
    app-license-url: https://www.apache.org/licenses/LICENSE-2.0.html
    app-license: Apache 2.0

# Logging Configuration
logging:
  level:
    com.example.springbootapi: DEBUG
    org.springframework.security: DEBUG
    org.springframework.web: INFO
    org.hibernate.SQL: DEBUG
    org.hibernate.type.descriptor.sql.BasicBinder: TRACE
  pattern:
    console: "%d{yyyy-MM-dd HH:mm:ss} - %msg%n"
    file: "%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n"
  file:
    name: logs/application.log
    max-size: 10MB
    max-history: 30

# Actuator Configuration
management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics,prometheus
      base-path: /actuator
  endpoint:
    health:
      show-details: when-authorized
      show-components: always
  info:
    env:
      enabled: true
    java:
      enabled: true
    os:
      enabled: true
  metrics:
    export:
      prometheus:
        enabled: true

# Custom Application Info
info:
  application:
    name: \${spring.application.name}
    description: Spring Boot REST API for user and product management
    version: \${app.swagger.app-version}
    java-version: \${java.runtime.version}
    spring-boot-version: \${spring-boot.version}

---
# Development Profile
spring:
  config:
    activate:
      on-profile: dev
  datasource:
    url: jdbc:postgresql://localhost:5432/springapi_dev
  jpa:
    hibernate:
      ddl-auto: create-drop
    show-sql: true
  h2:
    console:
      enabled: true

logging:
  level:
    root: INFO
    com.example.springbootapi: DEBUG

---
# Test Profile
spring:
  config:
    activate:
      on-profile: test
  datasource:
    url: jdbc:h2:mem:testdb
    driver-class-name: org.h2.Driver
    username: sa
    password: password
  jpa:
    hibernate:
      ddl-auto: create-drop
    database-platform: org.hibernate.dialect.H2Dialect
  h2:
    console:
      enabled: true

---
# Production Profile
spring:
  config:
    activate:
      on-profile: prod
  datasource:
    url: \${DATABASE_URL}
    username: \${DB_USERNAME}
    password: \${DB_PASSWORD}
  jpa:
    hibernate:
      ddl-auto: validate
    show-sql: false

logging:
  level:
    root: WARN
    com.example.springbootapi: INFO
  file:
    name: /var/log/spring-boot-api/application.log

server:
  port: \${PORT:8080}`,
        'README.md': `# Spring Boot REST API

A comprehensive REST API built with Spring Boot 3.1, featuring user management, JWT authentication, PostgreSQL integration, and comprehensive documentation.

## Features

### Core Features
- **RESTful API Design**: Following REST principles with proper HTTP methods and status codes
- **JWT Authentication**: Secure token-based authentication with refresh token support
- **Role-based Authorization**: Fine-grained access control with Spring Security
- **Database Integration**: PostgreSQL with JPA/Hibernate and Flyway migrations
- **API Documentation**: Interactive Swagger UI with OpenAPI 3.0 specification
- **Caching**: Built-in caching support for improved performance
- **Monitoring**: Actuator endpoints for health checks and metrics

### Advanced Features
- **Pagination**: Built-in pagination support for large datasets
- **Validation**: Comprehensive input validation with custom error messages
- **Error Handling**: Global exception handling with proper error responses
- **Testing**: Comprehensive test suite with TestContainers for integration tests
- **Security**: CORS configuration, CSRF protection, and security headers
- **Auditing**: Automatic tracking of entity creation and modification timestamps

## Technology Stack

### Backend Framework
- **Spring Boot 3.1** - Main application framework
- **Spring Security 6** - Authentication and authorization
- **Spring Data JPA** - Data access layer
- **Spring Web** - REST API endpoints
- **Spring Validation** - Input validation
- **Spring Cache** - Caching abstraction

### Database & Migration
- **PostgreSQL** - Primary database
- **Flyway** - Database migration management
- **HikariCP** - High-performance connection pooling

### Security & Documentation
- **JWT (JSON Web Tokens)** - Stateless authentication
- **SpringDoc OpenAPI** - API documentation generation
- **BCrypt** - Password hashing

### Testing
- **JUnit 5** - Unit testing framework
- **TestContainers** - Integration testing with real databases
- **Spring Boot Test** - Spring-specific testing utilities

## Project Structure

\`\`\`
src/main/java/com/example/springbootapi/
├── SpringBootApiApplication.java    # Main application class
├── config/                          # Configuration classes
│   ├── SecurityConfig.java         # Security configuration
│   ├── JwtConfig.java              # JWT configuration
│   └── SwaggerConfig.java          # API documentation config
├── controller/                      # REST controllers
│   ├── AuthController.java         # Authentication endpoints
│   ├── UserController.java         # User management endpoints
│   └── ProductController.java      # Product management endpoints
├── model/                          # JPA entities
│   ├── User.java                   # User entity
│   ├── Role.java                   # Role entity
│   └── Product.java                # Product entity
├── repository/                     # Data access layer
│   ├── UserRepository.java         # User data operations
│   ├── RoleRepository.java         # Role data operations
│   └── ProductRepository.java      # Product data operations
├── service/                        # Business logic layer
│   ├── UserService.java            # User business logic
│   ├── AuthService.java            # Authentication logic
│   └── ProductService.java         # Product business logic
├── dto/                            # Data Transfer Objects
│   ├── UserDto.java                # User response DTO
│   ├── LoginRequest.java           # Login request DTO
│   └── JwtResponse.java            # JWT response DTO
├── security/                       # Security components
│   ├── JwtAuthenticationFilter.java # JWT filter
│   ├── JwtTokenProvider.java       # JWT token utilities
│   └── UserPrincipal.java          # Custom user principal
└── exception/                      # Exception handling
    ├── GlobalExceptionHandler.java # Global error handler
    └── ResourceNotFoundException.java # Custom exceptions

src/main/resources/
├── application.yml                 # Application configuration
├── application-dev.yml            # Development configuration
├── application-prod.yml           # Production configuration
└── db/migration/                   # Flyway migration scripts
    ├── V1__Create_users_table.sql
    ├── V2__Create_roles_table.sql
    └── V3__Create_user_roles_table.sql
\`\`\`

## Getting Started

### Prerequisites
- Java 17 or higher
- Maven 3.6 or higher
- PostgreSQL 12 or higher
- Docker (optional, for running PostgreSQL)

### Setup Instructions

1. **Clone the repository:**
\`\`\`bash
git clone <repository-url>
cd spring-boot-api
\`\`\`

2. **Set up PostgreSQL database:**
\`\`\`bash
# Using Docker
docker run --name postgres-db -e POSTGRES_DB=springapi -e POSTGRES_USER=postgres -e POSTGRES_PASSWORD=password -p 5432:5432 -d postgres:15

# Or install PostgreSQL locally and create database
createdb springapi
\`\`\`

3. **Configure application properties:**
\`\`\`bash
# Copy and edit configuration
cp src/main/resources/application.yml.example src/main/resources/application.yml
# Edit database connection details if needed
\`\`\`

4. **Build and run the application:**
\`\`\`bash
# Build the project
mvn clean install

# Run the application
mvn spring-boot:run

# Or run the JAR file
java -jar target/spring-boot-api-0.0.1-SNAPSHOT.jar
\`\`\`

The application will start on \`http://localhost:8080\`.

### Environment Variables

For production deployment, set these environment variables:

\`\`\`bash
# Database Configuration
DB_USERNAME=your_db_username
DB_PASSWORD=your_db_password
DATABASE_URL=jdbc:postgresql://localhost:5432/springapi

# JWT Configuration
JWT_SECRET=your-jwt-secret-key-here
JWT_EXPIRATION=86400000

# CORS Configuration
CORS_ALLOWED_ORIGINS=https://yourdomain.com

# Server Configuration
SERVER_PORT=8080
SPRING_PROFILES_ACTIVE=prod
\`\`\`

## API Documentation

### Swagger UI
Once the application is running, you can access the interactive API documentation at:
- **Swagger UI**: \`http://localhost:8080/swagger-ui.html\`
- **OpenAPI JSON**: \`http://localhost:8080/v3/api-docs\`

### Key Endpoints

#### Authentication
- \`POST /api/auth/register\` - Register a new user
- \`POST /api/auth/login\` - Authenticate user and get JWT token
- \`POST /api/auth/refresh\` - Refresh JWT token
- \`POST /api/auth/logout\` - Logout user

#### User Management
- \`GET /api/users/me\` - Get current user profile
- \`PUT /api/users/me\` - Update current user profile
- \`GET /api/users\` - Get all users (Admin only)
- \`GET /api/users/{id}\` - Get user by ID
- \`PUT /api/users/{id}\` - Update user by ID (Admin only)
- \`DELETE /api/users/{id}\` - Delete user (Admin only)

#### Health & Monitoring
- \`GET /actuator/health\` - Application health status
- \`GET /actuator/metrics\` - Application metrics
- \`GET /actuator/info\` - Application information

### Authentication
Most endpoints require authentication. Include the JWT token in the Authorization header:

\`\`\`
Authorization: Bearer <your-jwt-token>
\`\`\`

## Testing

### Running Tests
\`\`\`bash
# Run all tests
mvn test

# Run tests with coverage
mvn test jacoco:report

# Run only unit tests
mvn test -Dtest="*UnitTest"

# Run only integration tests
mvn test -Dtest="*IntegrationTest"
\`\`\`

### Test Categories
- **Unit Tests**: Fast tests for individual components
- **Integration Tests**: Tests with real database using TestContainers
- **API Tests**: Full HTTP request/response testing

## Deployment

### Production Deployment

1. **Build production JAR:**
\`\`\`bash
mvn clean package -Pprod
\`\`\`

2. **Set environment variables:**
\`\`\`bash
export SPRING_PROFILES_ACTIVE=prod
export DATABASE_URL=jdbc:postgresql://prod-db:5432/springapi
export DB_USERNAME=prod_user
export DB_PASSWORD=secure_password
export JWT_SECRET=your-production-jwt-secret
\`\`\`

3. **Run the application:**
\`\`\`bash
java -jar target/spring-boot-api-0.0.1-SNAPSHOT.jar
\`\`\`

### Docker Deployment

\`\`\`dockerfile
FROM openjdk:17-jre-slim
COPY target/spring-boot-api-0.0.1-SNAPSHOT.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "/app.jar"]
\`\`\`

\`\`\`bash
# Build and run Docker container
docker build -t spring-boot-api .
docker run -p 8080:8080 -e SPRING_PROFILES_ACTIVE=prod spring-boot-api
\`\`\`

## Performance Considerations

### Database Optimization
- Connection pooling with HikariCP
- JPA batch operations for bulk inserts/updates
- Proper indexing on frequently queried columns
- Database query optimization with EXPLAIN ANALYZE

### Caching Strategy
- Application-level caching for user data and roles
- HTTP caching headers for static content
- Redis integration for distributed caching (optional)

### Security Best Practices
- JWT tokens with reasonable expiration times
- Password hashing with BCrypt
- CORS configuration for frontend domains
- Security headers for XSS and CSRF protection
- Input validation and sanitization

## Contributing

1. Fork the repository
2. Create your feature branch (\`git checkout -b feature/amazing-feature\`)
3. Commit your changes (\`git commit -m 'Add some amazing feature'\`)
4. Push to the branch (\`git push origin feature/amazing-feature\`)
5. Open a Pull Request

### Development Guidelines
- Follow Java coding conventions
- Write comprehensive tests for new features
- Update API documentation for new endpoints
- Use meaningful commit messages
- Add proper logging for debugging

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support and questions:
- Create an issue in the GitHub repository
- Contact the development team at dev-team@example.com
- Check the documentation at \`/swagger-ui.html\` for API details`
      }
    }
  };

  /**
   * Generate a sample project by name
   */
  static async generateSample(
    projectName: string, 
    outputDir: string
  ): Promise<string> {
    const project = this.SAMPLE_PROJECTS[projectName];
    if (!project) {
      throw new Error(`Sample project '${projectName}' not found`);
    }

    return this.createProjectZip(project, outputDir);
  }

  /**
   * Generate all available sample projects
   */
  static async generateAllSamples(outputDir: string): Promise<string[]> {
    const zipPaths: string[] = [];
    
    for (const [projectName, project] of Object.entries(this.SAMPLE_PROJECTS)) {
      const zipPath = await this.createProjectZip(project, outputDir, projectName);
      zipPaths.push(zipPath);
    }

    return zipPaths;
  }

  /**
   * Get list of available sample projects
   */
  static getAvailableSamples(): Array<{
    name: string;
    language: string;
    framework?: string;
    projectType: string;
    complexity: string;
    description: string;
  }> {
    return Object.entries(this.SAMPLE_PROJECTS).map(([key, project]) => ({
      name: key,
      language: project.language,
      framework: project.framework,
      projectType: project.projectType,
      complexity: project.complexity,
      description: project.name
    }));
  }

  /**
   * Create a ZIP file from a project definition
   */
  private static async createProjectZip(
    project: SampleProject,
    outputDir: string,
    customName?: string
  ): Promise<string> {
    const zipName = customName || project.name.toLowerCase().replace(/\s+/g, '-');
    const zipPath = path.join(outputDir, `${zipName}.zip`);
    
    return new Promise((resolve, reject) => {
      const output = createWriteStream(zipPath);
      const archive = archiver('zip', { zlib: { level: 9 } });

      output.on('close', () => resolve(zipPath));
      archive.on('error', reject);

      archive.pipe(output);

      // Add all project files to the archive
      for (const [filePath, content] of Object.entries(project.files)) {
        archive.append(content, { name: filePath });
      }

      archive.finalize();
    });
  }

  /**
   * Create a custom sample project programmatically
   */
  static async createCustomSample(
    config: {
      name: string;
      language: string;
      framework?: string;
      files: Record<string, string>;
    },
    outputDir: string
  ): Promise<string> {
    const project: SampleProject = {
      name: config.name,
      language: config.language,
      framework: config.framework,
      projectType: 'application',
      complexity: 'standard',
      files: config.files
    };

    return this.createProjectZip(project, outputDir);
  }
}