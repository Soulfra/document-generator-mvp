---
title: "API Contract"
description: "Template for defining all API endpoints, request/response formats, authentication, and integration contracts"
author: "Backend Team"
lastUpdated: "2024-06-28"
version: "1.0"
template: true
status: "ready"
---

# API Contract

## Overview
This document defines all API endpoints, request/response formats, authentication, and integration contracts for the project.

## API Endpoints Summary
**List all endpoints (REST/GraphQL/WebSocket)**

| Method | Endpoint | Description | Auth Required | Rate Limit |
|--------|----------|-------------|---------------|------------|
| GET | `/api/example` | Get example data | Yes | 100/min |
| POST | `/api/example` | Create new example | Yes | 10/min |
| PUT | `/api/example/{id}` | Update example | Yes | 20/min |
| DELETE | `/api/example/{id}` | Delete example | Yes | 5/min |

## OpenAPI/Swagger Specification

```yaml
openapi: 3.0.0
info:
  title: [Project Name] API
  description: API documentation for [Project Name]
  version: 1.0.0
  contact:
    name: API Support
    email: api-support@company.com
  license:
    name: MIT
    url: https://opensource.org/licenses/MIT

servers:
  - url: https://api.example.com/v1
    description: Production server
  - url: https://staging-api.example.com/v1
    description: Staging server
  - url: http://localhost:3000/api/v1
    description: Development server

security:
  - BearerAuth: []
  - ApiKeyAuth: []

paths:
  /example:
    get:
      summary: Get example data
      description: Retrieve a list of example items with optional filtering
      tags:
        - Examples
      parameters:
        - name: limit
          in: query
          description: Number of items to return
          required: false
          schema:
            type: integer
            minimum: 1
            maximum: 100
            default: 20
        - name: offset
          in: query
          description: Number of items to skip
          required: false
          schema:
            type: integer
            minimum: 0
            default: 0
        - name: filter
          in: query
          description: Filter criteria
          required: false
          schema:
            type: string
      responses:
        '200':
          description: Successful response
          content:
            application/json:
              schema:
                type: object
                properties:
                  data:
                    type: array
                    items:
                      $ref: '#/components/schemas/Example'
                  pagination:
                    $ref: '#/components/schemas/Pagination'
                  meta:
                    $ref: '#/components/schemas/ResponseMeta'
        '400':
          description: Bad request
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'
        '401':
          description: Unauthorized
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'
        '500':
          description: Internal server error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'

    post:
      summary: Create new example
      description: Create a new example item
      tags:
        - Examples
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CreateExampleRequest'
      responses:
        '201':
          description: Created successfully
          content:
            application/json:
              schema:
                type: object
                properties:
                  data:
                    $ref: '#/components/schemas/Example'
                  meta:
                    $ref: '#/components/schemas/ResponseMeta'
        '400':
          description: Bad request
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'
        '401':
          description: Unauthorized
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'

  /example/{id}:
    get:
      summary: Get example by ID
      description: Retrieve a specific example item by its ID
      tags:
        - Examples
      parameters:
        - name: id
          in: path
          required: true
          description: Unique identifier for the example
          schema:
            type: string
            format: uuid
      responses:
        '200':
          description: Successful response
          content:
            application/json:
              schema:
                type: object
                properties:
                  data:
                    $ref: '#/components/schemas/Example'
                  meta:
                    $ref: '#/components/schemas/ResponseMeta'
        '404':
          description: Example not found
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'

    put:
      summary: Update example
      description: Update an existing example item
      tags:
        - Examples
      parameters:
        - name: id
          in: path
          required: true
          description: Unique identifier for the example
          schema:
            type: string
            format: uuid
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/UpdateExampleRequest'
      responses:
        '200':
          description: Updated successfully
          content:
            application/json:
              schema:
                type: object
                properties:
                  data:
                    $ref: '#/components/schemas/Example'
                  meta:
                    $ref: '#/components/schemas/ResponseMeta'

    delete:
      summary: Delete example
      description: Delete an example item
      tags:
        - Examples
      parameters:
        - name: id
          in: path
          required: true
          description: Unique identifier for the example
          schema:
            type: string
            format: uuid
      responses:
        '204':
          description: Deleted successfully
        '404':
          description: Example not found
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'

components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
    ApiKeyAuth:
      type: apiKey
      in: header
      name: X-API-Key

  schemas:
    Example:
      type: object
      required:
        - id
        - name
        - createdAt
      properties:
        id:
          type: string
          format: uuid
          description: Unique identifier
          example: "123e4567-e89b-12d3-a456-426614174000"
        name:
          type: string
          description: Example name
          example: "Sample Example"
        description:
          type: string
          description: Example description
          example: "This is a sample example item"
        status:
          type: string
          enum: [active, inactive, pending]
          description: Current status
          example: "active"
        createdAt:
          type: string
          format: date-time
          description: Creation timestamp
          example: "2023-12-07T10:30:00Z"
        updatedAt:
          type: string
          format: date-time
          description: Last update timestamp
          example: "2023-12-07T10:30:00Z"

    CreateExampleRequest:
      type: object
      required:
        - name
      properties:
        name:
          type: string
          minLength: 1
          maxLength: 100
          description: Example name
          example: "New Example"
        description:
          type: string
          maxLength: 500
          description: Example description
          example: "Description of the new example"

    UpdateExampleRequest:
      type: object
      properties:
        name:
          type: string
          minLength: 1
          maxLength: 100
          description: Example name
        description:
          type: string
          maxLength: 500
          description: Example description
        status:
          type: string
          enum: [active, inactive, pending]
          description: Current status

    Pagination:
      type: object
      properties:
        limit:
          type: integer
          description: Number of items returned
          example: 20
        offset:
          type: integer
          description: Number of items skipped
          example: 0
        total:
          type: integer
          description: Total number of items available
          example: 150
        hasMore:
          type: boolean
          description: Whether more items are available
          example: true

    ResponseMeta:
      type: object
      properties:
        timestamp:
          type: string
          format: date-time
          description: Response timestamp
          example: "2023-12-07T10:30:00Z"
        requestId:
          type: string
          description: Unique request identifier
          example: "req_123456789"
        version:
          type: string
          description: API version
          example: "1.0.0"

    Error:
      type: object
      required:
        - error
      properties:
        error:
          type: object
          required:
            - code
            - message
          properties:
            code:
              type: string
              description: Error code
              example: "VALIDATION_ERROR"
            message:
              type: string
              description: Human-readable error message
              example: "The provided data is invalid"
            details:
              type: array
              description: Detailed error information
              items:
                type: object
                properties:
                  field:
                    type: string
                    description: Field that caused the error
                  message:
                    type: string
                    description: Field-specific error message
        meta:
          $ref: '#/components/schemas/ResponseMeta'
```

## Authentication & Authorization

### Authentication Methods
- **Bearer Token (JWT)**: Primary authentication method
  - Header: `Authorization: Bearer <token>`
  - Token expiration: 24 hours
  - Refresh token available: Yes

- **API Key**: Alternative for service-to-service communication
  - Header: `X-API-Key: <api-key>`
  - Rate limiting: Per API key
  - Rotation policy: Monthly

### Authorization Levels
- **Public**: No authentication required
- **User**: Requires valid user token
- **Admin**: Requires admin privileges
- **System**: Requires system-level API key

## Rate Limiting

### Rate Limit Policies
- **User API calls**: 100 requests per minute
- **Admin operations**: 50 requests per minute
- **Bulk operations**: 10 requests per minute
- **File uploads**: 5 requests per minute

### Rate Limit Headers
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 87
X-RateLimit-Reset: 1701943800
X-RateLimit-Window: 60
```

### Rate Limit Exceeded Response
```json
{
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Rate limit exceeded. Try again in 30 seconds."
  },
  "meta": {
    "retryAfter": 30,
    "timestamp": "2023-12-07T10:30:00Z"
  }
}
```

## Error Handling

### Standard Error Format
All errors follow a consistent format with:
- HTTP status code
- Error code (machine-readable)
- Error message (human-readable)
- Optional details array for field-specific errors

### Common Error Codes
- `VALIDATION_ERROR`: Input validation failed
- `AUTHENTICATION_REQUIRED`: No valid authentication provided
- `AUTHORIZATION_DENIED`: Insufficient permissions
- `RESOURCE_NOT_FOUND`: Requested resource doesn't exist
- `RATE_LIMIT_EXCEEDED`: Too many requests
- `INTERNAL_ERROR`: Server-side error

## WebSocket APIs (if applicable)

### Connection
```javascript
// Connection endpoint
const ws = new WebSocket('wss://api.example.com/ws');

// Authentication
ws.send(JSON.stringify({
  type: 'auth',
  token: 'jwt-token-here'
}));
```

### Message Format
```json
{
  "type": "message_type",
  "id": "unique-message-id",
  "timestamp": "2023-12-07T10:30:00Z",
  "data": {
    // Message-specific data
  }
}
```

## Versioning Strategy

### API Versioning
- **URL Versioning**: `/api/v1/`, `/api/v2/`
- **Backward Compatibility**: Maintained for 2 major versions
- **Deprecation Notice**: 6 months before removal
- **Breaking Changes**: Only in major version updates

### Changelog
- **v1.0.0**: Initial release
- **v1.1.0**: Added filtering support
- **v1.2.0**: Enhanced error responses

## Performance Requirements

### Response Times
- **GET requests**: < 200ms (95th percentile)
- **POST/PUT requests**: < 500ms (95th percentile)
- **File uploads**: < 5 seconds for files up to 100MB

### Throughput
- **Peak load**: 1000 requests per second
- **Average load**: 100 requests per second
- **Concurrent connections**: Up to 10,000

## Integration Examples

### JavaScript/Node.js
```javascript
const response = await fetch('/api/example', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer ' + token,
    'Content-Type': 'application/json'
  }
});
const data = await response.json();
```

### Python
```python
import requests

headers = {
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json'
}
response = requests.get('/api/example', headers=headers)
data = response.json()
```

### cURL
```bash
curl -X GET \
  https://api.example.com/v1/example \
  -H 'Authorization: Bearer <token>' \
  -H 'Content-Type: application/json'
```

---

**Document Owner**: _[Name and role]_
**API Developer**: _[Backend developer]_
**Last Updated**: _[Date]_
**API Version**: _[Current version]_