import { logger } from '../../utils/logger';
import automationConfig from '../config/automation-config.json';
import Mixpanel from 'mixpanel';
import axios from 'axios';

interface AnalyticsEvent {
  event: string;
  userId?: string;
  properties?: Record<string, any>;
  timestamp?: Date;
}

interface UserTraits {
  userId: string;
  email?: string;
  name?: string;
  tier?: 'FREE' | 'PREMIUM';
  createdAt?: Date;
  [key: string]: any;
}

export class AnalyticsIntegrationService {
  private mixpanelToken: string | null = null;
  private ga4MeasurementId: string | null = null;
  private ga4ApiSecret: string | null = null;
  private isEnabled: boolean = false;
  private mixpanelClient: Mixpanel.Mixpanel | null = null;

  constructor() {
    this.initialize();
  }

  private initialize(): void {
    // Mixpanel setup
    if (automationConfig.analytics.mixpanel.enabled && process.env.MIXPANEL_PROJECT_TOKEN) {
      this.mixpanelToken = process.env.MIXPANEL_PROJECT_TOKEN;
      try {
        this.mixpanelClient = Mixpanel.init(this.mixpanelToken);
        this.isEnabled = true;
        logger.info('Mixpanel analytics enabled');
      } catch (error) {
        logger.error('Failed to initialize Mixpanel client', { error });
      }
    }

    // Google Analytics 4 setup
    if (automationConfig.analytics.googleAnalytics.enabled && process.env.GA4_MEASUREMENT_ID) {
      this.ga4MeasurementId = process.env.GA4_MEASUREMENT_ID;
      this.ga4ApiSecret = process.env.GA4_API_SECRET;
      if (this.ga4ApiSecret) {
        this.isEnabled = true;
        logger.info('Google Analytics 4 enabled');
      } else {
        logger.warn('GA4_API_SECRET not found, GA4 integration disabled');
      }
    }
  }

  /**
   * Track an analytics event
   */
  public async track(event: AnalyticsEvent): Promise<void> {
    if (!this.isEnabled) {
      // Still log internally even if external analytics disabled
      if (automationConfig.analytics.internal.enabled) {
        logger.info('Analytics Event', {
          analytics: true,
          ...event,
        });
      }
      return;
    }

    try {
      // Send to Mixpanel
      if (this.mixpanelToken) {
        await this.sendToMixpanel(event);
      }

      // Send to Google Analytics 4
      if (this.ga4MeasurementId) {
        await this.sendToGA4(event);
      }

      // Log internally
      if (automationConfig.analytics.internal.enabled) {
        logger.info('Analytics Event', {
          analytics: true,
          ...event,
        });
      }
    } catch (error) {
      logger.error('Failed to track analytics event', { error, event });
    }
  }

  /**
   * Identify a user with traits
   */
  public async identify(traits: UserTraits): Promise<void> {
    if (!this.isEnabled) return;

    try {
      if (this.mixpanelToken) {
        await this.identifyMixpanel(traits);
      }

      logger.info('User identified', {
        analytics: true,
        userId: traits.userId,
        tier: traits.tier,
      });
    } catch (error) {
      logger.error('Failed to identify user', { error, userId: traits.userId });
    }
  }

  /**
   * Track conversion events
   */
  public async trackConversion(
    conversionType: 'signup' | 'upgrade' | 'payment' | 'job_complete',
    userId: string,
    value?: number,
    metadata?: Record<string, any>
  ): Promise<void> {
    await this.track({
      event: `conversion_${conversionType}`,
      userId,
      properties: {
        value,
        conversionType,
        ...metadata,
      },
    });
  }

  /**
   * Track feature usage
   */
  public async trackFeatureUsage(
    feature: string,
    userId: string,
    success: boolean,
    metadata?: Record<string, any>
  ): Promise<void> {
    await this.track({
      event: 'feature_used',
      userId,
      properties: {
        feature,
        success,
        ...metadata,
      },
    });
  }

  /**
   * Track page views (for frontend integration)
   */
  public async trackPageView(
    page: string,
    userId?: string,
    metadata?: Record<string, any>
  ): Promise<void> {
    await this.track({
      event: 'page_view',
      userId,
      properties: {
        page,
        ...metadata,
      },
    });
  }

  /**
   * Send event to Mixpanel
   */
  private async sendToMixpanel(event: AnalyticsEvent): Promise<void> {
    if (!this.mixpanelClient) return;

    try {
      const distinctId = event.userId || 'anonymous';
      const properties = {
        ...event.properties,
        timestamp: event.timestamp || new Date(),
      };

      // Use the official Mixpanel SDK
      this.mixpanelClient.track(event.event, properties, distinctId);
      
      logger.debug('Mixpanel event sent', { 
        event: event.event, 
        distinctId, 
        properties: Object.keys(properties) 
      });
    } catch (error) {
      logger.error('Failed to send to Mixpanel', { error });
    }
  }

  /**
   * Send event to Google Analytics 4
   */
  private async sendToGA4(event: AnalyticsEvent): Promise<void> {
    if (!this.ga4MeasurementId || !this.ga4ApiSecret) return;

    try {
      const ga4Event = {
        client_id: event.userId || 'anonymous',
        events: [{
          name: event.event.replace(/[^a-zA-Z0-9_]/g, '_'), // GA4 event names must be alphanumeric + underscore
          params: {
            ...event.properties,
            event_category: 'backend',
            event_source: 'finishthisidea',
          },
        }],
      };

      // Use GA4 Measurement Protocol
      const response = await axios.post(
        `https://www.google-analytics.com/mp/collect?measurement_id=${this.ga4MeasurementId}&api_secret=${this.ga4ApiSecret}`,
        ga4Event,
        {
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: 5000, // 5 second timeout
        }
      );

      logger.debug('GA4 event sent', { 
        event: event.event, 
        status: response.status,
        clientId: ga4Event.client_id
      });
    } catch (error) {
      logger.error('Failed to send to GA4', { error, event: event.event });
    }
  }

  /**
   * Identify user in Mixpanel
   */
  private async identifyMixpanel(traits: UserTraits): Promise<void> {
    if (!this.mixpanelClient) return;

    try {
      const profile = {
        $email: traits.email,
        $name: traits.name,
        tier: traits.tier,
        created_at: traits.createdAt?.toISOString(),
        ...Object.fromEntries(
          Object.entries(traits).filter(([key]) => 
            !['userId', 'email', 'name', 'tier', 'createdAt'].includes(key)
          )
        ),
      };

      // Use the official Mixpanel SDK
      this.mixpanelClient.people.set(traits.userId, profile);
      
      logger.debug('Mixpanel user identified', { 
        userId: traits.userId, 
        tier: traits.tier,
        email: traits.email ? '***@***' : undefined 
      });
    } catch (error) {
      logger.error('Failed to identify in Mixpanel', { error });
    }
  }

  /**
   * Get analytics summary (for admin dashboard)
   */
  public async getAnalyticsSummary(): Promise<any> {
    try {
      // Get basic analytics data
      // In a real implementation, this would fetch from Mixpanel/GA4 APIs
      const summary = {
        events: {
          today: 0,
          week: 0,
          month: 0,
        },
        conversions: {
          signups: 0,
          upgrades: 0,
          revenue: 0,
        },
        activeUsers: {
          daily: 0,
          weekly: 0,
          monthly: 0,
        },
        integrations: {
          mixpanel: {
            enabled: !!this.mixpanelClient,
            status: this.mixpanelClient ? 'connected' : 'not_configured'
          },
          ga4: {
            enabled: !!(this.ga4MeasurementId && this.ga4ApiSecret),
            status: (this.ga4MeasurementId && this.ga4ApiSecret) ? 'connected' : 'not_configured'
          }
        },
        lastUpdated: new Date().toISOString()
      };

      // If Mixpanel is available, we could fetch real data like:
      // if (this.mixpanelClient) {
      //   try {
      //     const events = await this.fetchMixpanelEvents();
      //     summary.events = events;
      //   } catch (error) {
      //     logger.warn('Failed to fetch Mixpanel events', { error });
      //   }
      // }

      return summary;
    } catch (error) {
      logger.error('Failed to get analytics summary', { error });
      return {
        events: { today: 0, week: 0, month: 0 },
        conversions: { signups: 0, upgrades: 0, revenue: 0 },
        activeUsers: { daily: 0, weekly: 0, monthly: 0 },
        integrations: {
          mixpanel: { enabled: false, status: 'error' },
          ga4: { enabled: false, status: 'error' }
        },
        error: 'Failed to retrieve analytics data'
      };
    }
  }

  /**
   * Get integration status
   */
  public getIntegrationStatus(): {
    mixpanel: { enabled: boolean; configured: boolean; status: string };
    ga4: { enabled: boolean; configured: boolean; status: string };
    internal: { enabled: boolean };
  } {
    return {
      mixpanel: {
        enabled: automationConfig.analytics.mixpanel.enabled,
        configured: !!this.mixpanelClient,
        status: this.mixpanelClient ? 'connected' : 'not_configured'
      },
      ga4: {
        enabled: automationConfig.analytics.googleAnalytics.enabled,
        configured: !!(this.ga4MeasurementId && this.ga4ApiSecret),
        status: (this.ga4MeasurementId && this.ga4ApiSecret) ? 'connected' : 'not_configured'
      },
      internal: {
        enabled: automationConfig.analytics.internal.enabled
      }
    };
  }
}

// Export singleton instance
export const analyticsService = new AnalyticsIntegrationService();