import { FileProcessingService } from '../src/services/file-processing.service';
import { promises as fs } from 'fs';
import * as path from 'path';
import * as os from 'os';
import archiver from 'archiver';
import { createWriteStream } from 'fs';

describe('FileProcessingService', () => {
  let fileProcessingService: FileProcessingService;
  let tempDir: string;

  beforeEach(async () => {
    fileProcessingService = new FileProcessingService({
      maxFileSize: 1024 * 1024, // 1MB for testing
      maxTotalSize: 5 * 1024 * 1024, // 5MB for testing
      timeout: 30000 // 30 seconds for testing
    });
    
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'test-file-processing-'));
  });

  afterEach(async () => {
    await fs.rm(tempDir, { recursive: true, force: true });
  });

  describe('File Processing and Extraction', () => {
    it('should process a simple React project structure', async () => {
      // Create a mock React project
      const projectFiles = {
        'package.json': JSON.stringify({
          name: 'test-react-app',
          dependencies: {
            react: '^18.0.0',
            'react-dom': '^18.0.0'
          },
          devDependencies: {
            '@types/react': '^18.0.0'
          }
        }),
        'src/App.tsx': `
import React from 'react';
import { UserList } from './components/UserList';

function App() {
  return (
    <div className="App">
      <h1>My React App</h1>
      <UserList />
    </div>
  );
}

export default App;
        `,
        'src/components/UserList.tsx': `
import React, { useState, useEffect } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
}

export const UserList: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/users');
      const data = await response.json();
      setUsers(data.users);
    } catch (error) {
      console.error('Failed to fetch users:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <ul>
      {users.map(user => (
        <li key={user.id}>
          {user.name} - {user.email}
        </li>
      ))}
    </ul>
  );
};
        `,
        'src/api/users.ts': `
export interface User {
  id: string;
  name: string;
  email: string;
  createdAt: Date;
}

export async function getUsers(): Promise<User[]> {
  // Mock implementation
  return [
    {
      id: '1',
      name: 'John Doe',
      email: 'john@example.com',
      createdAt: new Date()
    },
    {
      id: '2', 
      name: 'Jane Smith',
      email: 'jane@example.com',
      createdAt: new Date()
    }
  ];
}

export async function createUser(userData: Omit<User, 'id' | 'createdAt'>): Promise<User> {
  const newUser: User = {
    ...userData,
    id: Math.random().toString(36),
    createdAt: new Date()
  };
  
  // Mock save to database
  return newUser;
}
        `,
        'README.md': `# Test React App

This is a test React application for documentation generation.

## Features
- User listing
- User creation
- Responsive design
        `,
        'tsconfig.json': JSON.stringify({
          compilerOptions: {
            target: 'es5',
            lib: ['dom', 'dom.iterable', 'es6'],
            strict: true,
            jsx: 'react-jsx'
          }
        })
      };

      // Create ZIP file
      const zipPath = await createTestZip(projectFiles, tempDir);

      // Test file processing
      const result = await fileProcessingService.downloadAndExtractFiles(`file://${zipPath}`);

      // Verify extraction results
      expect(result.files.size).toBe(6); // package.json, App.tsx, UserList.tsx, users.ts, README.md, tsconfig.json
      expect(result.metadata.totalFiles).toBe(6);
      expect(result.metadata.languages).toContain('typescript');
      expect(result.metadata.languages).toContain('json');
      expect(result.metadata.languages).toContain('markdown');
      expect(result.metadata.projectType).toBe('webapp');
      expect(result.metadata.framework).toBe('react');

      // Verify file contents
      expect(result.files.get('package.json')).toContain('react');
      expect(result.files.get('src/App.tsx')).toContain('function App()');
      expect(result.files.get('src/components/UserList.tsx')).toContain('interface User');
      expect(result.files.get('src/api/users.ts')).toContain('export async function getUsers()');
    });

    it('should process a Node.js Express API project', async () => {
      const projectFiles = {
        'package.json': JSON.stringify({
          name: 'test-api',
          dependencies: {
            express: '^4.18.0',
            cors: '^2.8.5'
          }
        }),
        'server.js': `
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

app.get('/api/users', async (req, res) => {
  try {
    const users = await getUsersFromDatabase();
    res.json({ success: true, data: users });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/users', async (req, res) => {
  try {
    const { name, email } = req.body;
    const user = await createUser({ name, email });
    res.status(201).json({ success: true, data: user });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});
        `,
        'src/models/User.js': `
class User {
  constructor(id, name, email) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.createdAt = new Date();
  }

  static async findAll() {
    // Mock database query
    return [
      new User(1, 'John Doe', 'john@example.com'),
      new User(2, 'Jane Smith', 'jane@example.com')
    ];
  }

  static async create(userData) {
    const id = Math.floor(Math.random() * 1000);
    return new User(id, userData.name, userData.email);
  }
}

module.exports = User;
        `
      };

      const zipPath = await createTestZip(projectFiles, tempDir);
      const result = await fileProcessingService.downloadAndExtractFiles(`file://${zipPath}`);

      expect(result.metadata.languages).toContain('javascript');
      expect(result.metadata.projectType).toBe('api');
      expect(result.metadata.framework).toBe('express');
      expect(result.files.get('server.js')).toContain('app.get(\'/api/users\'');
    });

    it('should process a Python Flask project', async () => {
      const projectFiles = {
        'requirements.txt': `
flask==2.3.0
flask-cors==4.0.0
python-dotenv==1.0.0
        `,
        'app.py': `
from flask import Flask, request, jsonify
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

@app.route('/api/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'version': '1.0.0'
    })

@app.route('/api/users', methods=['GET'])
def get_users():
    try:
        users = get_all_users()
        return jsonify({'success': True, 'data': users})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/users', methods=['POST'])
def create_user():
    try:
        data = request.get_json()
        user = create_new_user(data)
        return jsonify({'success': True, 'data': user}), 201
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000)
        `,
        'models/user.py': `
from datetime import datetime
from typing import List, Dict, Optional

class User:
    def __init__(self, id: int, name: str, email: str):
        self.id = id
        self.name = name
        self.email = email
        self.created_at = datetime.now()
    
    @staticmethod
    def get_all() -> List['User']:
        """Get all users from database"""
        # Mock database query
        return [
            User(1, 'John Doe', 'john@example.com'),
            User(2, 'Jane Smith', 'jane@example.com')
        ]
    
    @staticmethod
    def create(user_data: Dict[str, str]) -> 'User':
        """Create a new user"""
        import random
        user_id = random.randint(1, 1000)
        return User(user_id, user_data['name'], user_data['email'])
    
    def to_dict(self) -> Dict:
        """Convert user to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'created_at': self.created_at.isoformat()
        }
        `
      };

      const zipPath = await createTestZip(projectFiles, tempDir);
      const result = await fileProcessingService.downloadAndExtractFiles(`file://${zipPath}`);

      expect(result.metadata.languages).toContain('python');
      expect(result.metadata.projectType).toBe('api');
      expect(result.metadata.framework).toBe('flask');
      expect(result.files.get('app.py')).toContain('@app.route(\'/api/users\'');
    });

    it('should exclude files based on patterns', async () => {
      const projectFiles = {
        'package.json': JSON.stringify({ name: 'test' }),
        'src/index.js': 'console.log("hello");',
        'node_modules/react/index.js': 'module.exports = require("./lib/React");',
        'dist/bundle.js': '(function(){})();',
        '.git/config': '[core]',
        'coverage/lcov.info': 'TN:',
        'src/utils.min.js': 'function minified(){}',
        'yarn.lock': '# THIS IS AN AUTOGENERATED FILE',
        'build/static/js/main.js': 'built file content'
      };

      const zipPath = await createTestZip(projectFiles, tempDir);
      const result = await fileProcessingService.downloadAndExtractFiles(`file://${zipPath}`);

      // Should only include package.json and src/index.js
      expect(result.files.size).toBe(2);
      expect(result.files.has('package.json')).toBe(true);
      expect(result.files.has('src/index.js')).toBe(true);
      expect(result.files.has('node_modules/react/index.js')).toBe(false);
      expect(result.files.has('dist/bundle.js')).toBe(false);
      expect(result.files.has('.git/config')).toBe(false);
    });

    it('should handle file size limits', async () => {
      const smallFileService = new FileProcessingService({
        maxFileSize: 100, // 100 bytes
        maxTotalSize: 1000
      });

      const projectFiles = {
        'small.js': 'console.log("small");',
        'large.js': 'console.log("' + 'x'.repeat(200) + '");' // Over 100 bytes
      };

      const zipPath = await createTestZip(projectFiles, tempDir);
      const result = await smallFileService.downloadAndExtractFiles(`file://${zipPath}`);

      expect(result.files.size).toBe(1);
      expect(result.files.has('small.js')).toBe(true);
      expect(result.files.has('large.js')).toBe(false);
    });
  });

  describe('Documentation Packaging', () => {
    it('should create a comprehensive documentation package', async () => {
      const mockDocResult = {
        jobId: 'test-job-123',
        templates: [
          {
            templateId: 'executive-summary',
            templateName: 'Executive Summary',
            content: '# Executive Summary\n\nThis project is awesome.',
            sections: [
              {
                id: 'overview',
                title: 'Overview',
                content: '## Overview\n\nProject overview here.',
                dataUsed: ['projectInfo'],
                aiGenerated: false
              }
            ]
          },
          {
            templateId: 'api-contract',
            templateName: 'API Contract',
            content: '# API Documentation\n\n## Endpoints\n\n- GET /api/users',
            sections: []
          }
        ],
        metadata: {
          generatedAt: new Date('2023-12-01T00:00:00Z'),
          templatesUsed: ['executive-summary', 'api-contract'],
          aiTokensUsed: 1500,
          quality: {
            overall: 85,
            completeness: 90,
            accuracy: 80,
            readability: 85
          }
        }
      };

      const packageBuffer = await fileProcessingService.packageDocumentation(
        mockDocResult,
        'test-job-123',
        true
      );

      expect(packageBuffer).toBeInstanceOf(Buffer);
      expect(packageBuffer.length).toBeGreaterThan(0);

      // TODO: Add ZIP extraction test to verify contents
      // This would require additional test utilities to extract and verify ZIP contents
    });
  });

  describe('Project Type Detection', () => {
    it('should detect various project types correctly', async () => {
      const testCases = [
        {
          files: { 'package.json': JSON.stringify({ dependencies: { react: '^18.0.0' } }) },
          expectedType: 'webapp',
          expectedFramework: 'react'
        },
        {
          files: { 'package.json': JSON.stringify({ dependencies: { express: '^4.18.0' } }) },
          expectedType: 'api',
          expectedFramework: 'express'
        },
        {
          files: { 'requirements.txt': 'django==4.0.0' },
          expectedType: 'webapp',
          expectedFramework: 'django'
        },
        {
          files: { 'go.mod': 'module example.com/myapp' },
          expectedType: 'application',
          expectedFramework: 'go'
        },
        {
          files: { 'Cargo.toml': '[package]\nname = "myapp"' },
          expectedType: 'application',
          expectedFramework: 'rust'
        }
      ];

      for (const testCase of testCases) {
        const zipPath = await createTestZip(testCase.files, tempDir);
        const result = await fileProcessingService.downloadAndExtractFiles(`file://${zipPath}`);

        expect(result.metadata.projectType).toBe(testCase.expectedType);
        expect(result.metadata.framework).toBe(testCase.expectedFramework);
      }
    });
  });
});

// Helper function to create test ZIP files
async function createTestZip(files: Record<string, string>, tempDir: string): Promise<string> {
  const zipPath = path.join(tempDir, `test-${Date.now()}.zip`);
  
  return new Promise((resolve, reject) => {
    const output = createWriteStream(zipPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => resolve(zipPath));
    archive.on('error', reject);

    archive.pipe(output);

    // Add files to archive
    for (const [filePath, content] of Object.entries(files)) {
      archive.append(content, { name: filePath });
    }

    archive.finalize();
  });
}