import request from 'supertest';
import { app } from '../../src/server';
import { testDb } from '../utils/test-database';
import { ZipManager } from '../utils/zip-manager';
import { promises as fs } from 'fs';
import * as path from 'path';
import * as os from 'os';

describe('Self-Testing: FinishThisIdea Dogfooding', () => {
  let tempDir: string;
  let finishThisIdeaZip: string;

  beforeAll(async () => {
    // Set up test database
    await testDb.setup({ seedData: true });
    
    // Create temporary directory
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'finishthisidea-self-test-'));
    
    // Create ZIP of our own codebase for testing
    console.log('🚀 Creating ZIP of FinishThisIdea codebase...');
    
    const projectRoot = path.resolve(__dirname, '../..');
    finishThisIdeaZip = path.join(tempDir, 'finishthisidea-self-test.zip');
    
    try {
      await ZipManager.createZipFromDirectory(projectRoot, finishThisIdeaZip, {
        level: 6,
        comment: 'FinishThisIdea self-test ZIP created for dogfooding'
      });
      
      // Verify the ZIP was created and has content
      const zipInfo = await ZipManager.getZipInfo(finishThisIdeaZip);
      console.log(`✅ Created FinishThisIdea ZIP: ${zipInfo.fileCount} files, ${(zipInfo.totalSize / 1024 / 1024).toFixed(2)}MB`);
      
      // Validate that we have the expected project structure
      expect(zipInfo.files.some(f => f.name === 'package.json')).toBe(true);
      expect(zipInfo.files.some(f => f.name.includes('src/'))).toBe(true);
      expect(zipInfo.files.some(f => f.name === 'README.md')).toBe(true);
      
    } catch (error) {
      console.error('❌ Failed to create FinishThisIdea ZIP:', error);
      throw error;
    }
  });

  afterAll(async () => {
    // Clean up
    await fs.rm(tempDir, { recursive: true, force: true });
    await testDb.cleanup();
    await testDb.teardown();
  });

  afterEach(async () => {
    await testDb.reset();
    await testDb.seedDatabase();
  });

  describe('Processing Our Own Codebase', () => {
    it('should successfully upload and process FinishThisIdea codebase', async () => {
      console.log('📤 Testing upload of FinishThisIdea codebase...');

      // Step 1: Upload our own codebase
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', finishThisIdeaZip)
        .field('profileId', 'typescript-strict')
        .expect(200);

      expect(uploadResponse.body.success).toBe(true);
      expect(uploadResponse.body.data.jobId).toBeDefined();
      expect(uploadResponse.body.data.originalFileName).toContain('finishthisidea');

      const jobId = uploadResponse.body.data.jobId;
      const fileSize = uploadResponse.body.data.fileSize;

      console.log(`✅ Upload successful!`);
      console.log(`   Job ID: ${jobId}`);
      console.log(`   File size: ${(fileSize / 1024 / 1024).toFixed(2)}MB`);

      // Verify job was created in database
      const prisma = testDb.getPrisma();
      const job = await prisma.job.findUnique({ where: { id: jobId } });
      
      expect(job).toBeDefined();
      expect(job!.originalFileName).toContain('finishthisidea');
      expect(job!.fileSizeBytes).toBe(fileSize);
      expect(job!.status).toBe('PENDING');

      console.log('✅ Job record verified in database');
    });

    it('should simulate file processing and extraction of our codebase', async () => {
      console.log('⚙️ Testing file processing simulation...');

      // Upload our codebase
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', finishThisIdeaZip)
        .field('profileId', 'typescript-strict')
        .expect(200);

      const jobId = uploadResponse.body.data.jobId;

      // Simulate the file processing that would normally happen in a background job
      console.log('🔄 Simulating file processing...');
      
      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'PROCESSING'
        }
      });

      // Simulate processing completion
      await new Promise(resolve => setTimeout(resolve, 100)); // Brief delay to simulate processing

      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: `https://test-bucket.s3.amazonaws.com/processed-finishthisidea-${jobId}.zip`,
          processedAt: new Date(),
          metadata: {
            extractedFiles: 150,
            codeAnalysis: {
              language: 'typescript',
              framework: 'express',
              linesOfCode: 8500,
              functions: 85,
              classes: 25
            }
          }
        }
      });

      // Verify processing completed
      const completedJob = await prisma.job.findUnique({ where: { id: jobId } });
      expect(completedJob!.status).toBe('COMPLETED');
      expect(completedJob!.outputFileUrl).toBeDefined();

      console.log('✅ File processing simulation completed');
    });

    it('should generate comprehensive documentation for FinishThisIdea', async () => {
      console.log('📚 Testing documentation generation for our own codebase...');

      // Upload and process our codebase
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', finishThisIdeaZip)
        .field('profileId', 'typescript-strict')
        .expect(200);

      const jobId = uploadResponse.body.data.jobId;

      // Simulate completed processing
      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: `https://test-bucket.s3.amazonaws.com/processed-finishthisidea-${jobId}.zip`
        }
      });

      // Generate comprehensive documentation
      console.log('📝 Generating comprehensive documentation...');
      
      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId,
          templates: [
            'executive-summary',
            'api-contract', 
            'data-models',
            'technical-requirements',
            'user-stories'
          ],
          includeInOutput: true
        })
        .expect(200);

      expect(docResponse.body.success).toBe(true);
      expect(docResponse.body.data.documentationId).toBeDefined();
      expect(docResponse.body.data.url).toBeDefined();
      expect(docResponse.body.data.quality).toBeDefined();

      const quality = docResponse.body.data.quality;
      const documentationId = docResponse.body.data.documentationId;

      console.log(`✅ Documentation generated successfully!`);
      console.log(`   Documentation ID: ${documentationId}`);
      console.log(`   Quality Score: ${quality.overall}%`);
      console.log(`   Completeness: ${quality.completeness}%`);
      console.log(`   Accuracy: ${quality.accuracy}%`);
      console.log(`   Readability: ${quality.readability}%`);

      // Verify quality expectations for our own codebase
      expect(quality.overall).toBeGreaterThan(70); // Should be high quality since it's our own code
      expect(quality.completeness).toBeGreaterThan(60);
      expect(quality.accuracy).toBeGreaterThan(60);
      expect(quality.readability).toBeGreaterThan(70);

      // Verify documentation exists in database with correct data
      const documentation = await prisma.documentation.findUnique({
        where: { id: documentationId },
        include: { job: true }
      });

      expect(documentation).toBeDefined();
      expect(documentation!.jobId).toBe(jobId);
      expect(documentation!.templates).toEqual([
        'executive-summary',
        'api-contract', 
        'data-models',
        'technical-requirements',
        'user-stories'
      ]);
      expect(documentation!.metadata).toBeDefined();
      expect(documentation!.metadata.generatedAt).toBeDefined();

      console.log('✅ Documentation metadata verified');
    });

    it('should extract meaningful requirements from FinishThisIdea README and docs', async () => {
      console.log('📋 Testing requirements extraction from our own documentation...');

      // Create a simulated chat log based on our project documentation
      const projectChatLog = {
        messages: [
          {
            role: 'user' as const,
            content: `I want to build a $1 AI-powered code cleanup service called FinishThisIdea. Users should be able to upload their codebases as ZIP files and get back professionally documented modules. The system needs to handle file processing, code analysis, and documentation generation with multiple templates.`,
            timestamp: new Date().toISOString()
          },
          {
            role: 'assistant' as const,
            content: `I'll help you build FinishThisIdea! This will need: 1) File upload system with ZIP processing 2) Code analysis engine for multiple languages 3) AI-powered documentation generation 4) Template system for different doc types 5) User management and payment processing 6) Queue system for background processing. The architecture should use Node.js/Express backend, React frontend, PostgreSQL database, and Redis for caching.`,
            timestamp: new Date().toISOString()
          },
          {
            role: 'user' as const,
            content: `Excellent! The system must support TypeScript, JavaScript, Python, Java, and other languages. Documentation templates should include executive summaries, API contracts, data models, and user stories. The service needs to be production-ready with comprehensive error handling, logging, and monitoring.`,
            timestamp: new Date().toISOString()
          },
          {
            role: 'assistant' as const,
            content: `Perfect! I'll implement multi-language support with AST parsing, comprehensive template system, production-grade error handling with circuit breakers, structured logging, health checks, and monitoring. The system will use Prisma for database management, Bull for job queues, and JWT for authentication.`,
            timestamp: new Date().toISOString()
          }
        ],
        platform: 'claude' as const
      };

      // Extract requirements from our project description
      const chatImportResponse = await request(app)
        .post('/api/documentation/chat-import')
        .send(projectChatLog)
        .expect(200);

      expect(chatImportResponse.body.success).toBe(true);
      
      const requirements = chatImportResponse.body.data.requirements;
      
      console.log('📊 Requirements extraction results:');
      console.log(`   Features: ${requirements.features.length}`);
      console.log(`   User Stories: ${requirements.userStories.length}`);
      console.log(`   Technical Requirements: ${requirements.technicalRequirements.length}`);
      console.log(`   Business Rules: ${requirements.businessRules.length}`);
      console.log(`   Constraints: ${requirements.constraints.length}`);

      // Verify that key FinishThisIdea features were extracted
      const hasUploadFeature = requirements.features.some((f: any) => 
        f.description.toLowerCase().includes('upload') || 
        f.description.toLowerCase().includes('file')
      );
      expect(hasUploadFeature).toBe(true);

      const hasDocumentationFeature = requirements.features.some((f: any) => 
        f.description.toLowerCase().includes('documentation') ||
        f.description.toLowerCase().includes('template')
      );
      expect(hasDocumentationFeature).toBe(true);

      // Verify technical requirements extraction
      const hasNodeRequirement = requirements.technicalRequirements.some((r: any) => 
        r.description.toLowerCase().includes('node') || 
        r.description.toLowerCase().includes('express')
      );
      expect(hasNodeRequirement).toBe(true);

      const hasReactRequirement = requirements.technicalRequirements.some((r: any) => 
        r.description.toLowerCase().includes('react')
      );
      expect(hasReactRequirement).toBe(true);

      const hasPostgresRequirement = requirements.technicalRequirements.some((r: any) => 
        r.description.toLowerCase().includes('postgresql') ||
        r.description.toLowerCase().includes('prisma')
      );
      expect(hasPostgresRequirement).toBe(true);

      console.log('✅ Requirements extraction validated against FinishThisIdea specs');
    });
  });

  describe('Quality and Performance Validation', () => {
    it('should meet performance benchmarks when processing our codebase', async () => {
      console.log('⚡ Testing performance benchmarks...');

      const startTime = Date.now();

      // Upload our codebase
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', finishThisIdeaZip)
        .expect(200);

      const uploadTime = Date.now();
      const jobId = uploadResponse.body.data.jobId;

      // Simulate processing
      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: `https://test-bucket.s3.amazonaws.com/perf-test-${jobId}.zip`
        }
      });

      // Generate documentation
      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId,
          templates: ['executive-summary', 'api-contract']
        })
        .expect(200);

      const endTime = Date.now();

      const totalTime = endTime - startTime;
      const uploadDuration = uploadTime - startTime;
      const docGenerationDuration = endTime - uploadTime;

      console.log(`📈 Performance Results:`);
      console.log(`   Total Time: ${totalTime}ms`);
      console.log(`   Upload Time: ${uploadDuration}ms`);
      console.log(`   Doc Generation Time: ${docGenerationDuration}ms`);

      // Performance expectations
      expect(uploadDuration).toBeLessThan(30000); // Upload should complete within 30 seconds
      expect(docGenerationDuration).toBeLessThan(60000); // Doc generation within 60 seconds
      expect(totalTime).toBeLessThan(90000); // Total process within 90 seconds

      expect(docResponse.body.success).toBe(true);

      console.log('✅ Performance benchmarks met');
    });

    it('should validate documentation quality for production readiness', async () => {
      console.log('🔍 Validating documentation quality for production...');

      // Process our codebase with all templates
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', finishThisIdeaZip)
        .expect(200);

      const jobId = uploadResponse.body.data.jobId;

      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: `https://test-bucket.s3.amazonaws.com/quality-test-${jobId}.zip`
        }
      });

      // Generate comprehensive documentation
      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId,
          templates: [
            'executive-summary',
            'api-contract',
            'data-models',
            'technical-requirements',
            'user-stories',
            'test-plan'
          ]
        })
        .expect(200);

      const quality = docResponse.body.data.quality;

      console.log(`🎯 Quality Assessment:`);
      console.log(`   Overall: ${quality.overall}%`);
      console.log(`   Completeness: ${quality.completeness}%`);
      console.log(`   Accuracy: ${quality.accuracy}%`);
      console.log(`   Readability: ${quality.readability}%`);

      // Production quality standards
      expect(quality.overall).toBeGreaterThan(75); // High overall quality
      expect(quality.completeness).toBeGreaterThan(70); // Comprehensive coverage
      expect(quality.accuracy).toBeGreaterThan(70); // Accurate analysis
      expect(quality.readability).toBeGreaterThan(75); // Well-formatted output

      // Verify all templates were generated
      const documentation = await prisma.documentation.findFirst({
        where: { jobId }
      });

      expect(documentation!.templates).toHaveLength(6);
      expect(documentation!.metadata.templatesUsed).toEqual([
        'executive-summary',
        'api-contract',
        'data-models',
        'technical-requirements',
        'user-stories',
        'test-plan'
      ]);

      console.log('✅ Production quality standards validated');
    });
  });

  describe('Regression Testing', () => {
    it('should produce consistent results across multiple runs', async () => {
      console.log('🔄 Testing consistency across multiple documentation generations...');

      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', finishThisIdeaZip)
        .expect(200);

      const jobId = uploadResponse.body.data.jobId;

      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: `https://test-bucket.s3.amazonaws.com/consistency-test-${jobId}.zip`
        }
      });

      // Generate documentation multiple times
      const templates = ['executive-summary', 'api-contract'];
      const results: any[] = [];

      for (let i = 0; i < 3; i++) {
        const docResponse = await request(app)
          .post('/api/documentation/generate')
          .send({ jobId, templates })
          .expect(200);

        results.push(docResponse.body.data);
        
        // Small delay between requests
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      // Verify consistency
      const firstResult = results[0];
      for (let i = 1; i < results.length; i++) {
        const result = results[i];
        
        // Quality scores should be similar (within 10% variance)
        const qualityDiff = Math.abs(result.quality.overall - firstResult.quality.overall);
        expect(qualityDiff).toBeLessThan(10);
        
        // Templates should be identical
        expect(result.templates).toEqual(firstResult.templates);
      }

      console.log('✅ Consistency validated across multiple runs');
      console.log(`   Quality variance: ${Math.max(...results.map(r => r.quality.overall)) - Math.min(...results.map(r => r.quality.overall))}%`);
    });
  });

  describe('Integration with Real Services', () => {
    it('should handle database operations correctly', async () => {
      console.log('💾 Testing database integration...');

      // Check database stats before test
      const statsBefore = await testDb.getStats();
      
      // Process our codebase
      const uploadResponse = await request(app)
        .post('/api/upload')
        .attach('file', finishThisIdeaZip)
        .expect(200);

      const jobId = uploadResponse.body.data.jobId;

      const prisma = testDb.getPrisma();
      await prisma.job.update({
        where: { id: jobId },
        data: { 
          status: 'COMPLETED',
          outputFileUrl: `https://test-bucket.s3.amazonaws.com/db-test-${jobId}.zip`
        }
      });

      const docResponse = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId,
          templates: ['executive-summary']
        })
        .expect(200);

      // Check database stats after test
      const statsAfter = await testDb.getStats();

      // Verify database operations
      expect(statsAfter.jobCount).toBe(statsBefore.jobCount + 1);
      expect(statsAfter.documentationCount).toBe(statsBefore.documentationCount + 1);

      // Verify data integrity
      const job = await prisma.job.findUnique({ where: { id: jobId } });
      const documentation = await prisma.documentation.findFirst({ where: { jobId } });

      expect(job).toBeDefined();
      expect(documentation).toBeDefined();
      expect(documentation!.jobId).toBe(job!.id);

      console.log('✅ Database integration validated');
    });
  });
});