---
title: "Developer Onboarding Guide"
description: "Comprehensive guide for new developers joining the FinishThisIdea team, covering setup, codebase, and automation systems"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Developer Onboarding Guide

Welcome to the FinishThisIdea development team! This guide will help you get up and running quickly and understand our codebase, processes, and automation systems.

## 📋 Prerequisites

Before you start, make sure you have:

- **Node.js 18+** - [Download](https://nodejs.org/)
- **Docker & Docker Compose** - [Download](https://www.docker.com/products/docker-desktop)
- **Git** - [Download](https://git-scm.com/)
- **VS Code** (recommended) - [Download](https://code.visualstudio.com/)

### Recommended VS Code Extensions

Install these extensions for the best development experience:

```bash
# Essential extensions
code --install-extension ms-vscode.vscode-typescript-next
code --install-extension esbenp.prettier-vscode
code --install-extension ms-vscode.vscode-eslint
code --install-extension bradlc.vscode-tailwindcss
code --install-extension ms-vscode.vscode-json

# Database and testing
code --install-extension ms-vscode.vscode-jest
code --install-extension ms-vscode.vscode-postgresql

# Optional but helpful
code --install-extension ms-vscode.vscode-docker
code --install-extension ms-vscode.vscode-yaml
```

## 🚀 Day 1: Setup & First Run

### Step 1: Clone and Install

```bash
# Clone the repository
git clone <repository-url>
cd FinishThisIdea

# Install dependencies
npm ci

# Install frontend dependencies
cd frontend && npm ci && cd ..
```

### Step 2: Environment Setup

```bash
# Copy environment template
cp .env.example .env

# Start all services
docker-compose up -d

# Wait for services to be ready (30-60 seconds)
docker-compose ps
```

### Step 3: Database Setup

```bash
# Run database migrations
npx prisma migrate deploy

# Generate Prisma client
npx prisma generate

# (Optional) Seed with sample data
npx prisma db seed
```

### Step 4: Verify Installation

```bash
# Run type checking
npm run type-check

# Run linting
npm run lint

# Run unit tests
npm run test:unit

# Start development servers
npm run dev  # Backend on :3001
cd frontend && npm run dev  # Frontend on :3000
```

### Step 5: First Success ✅

Visit http://localhost:3000 and you should see the FinishThisIdea interface!

## 📚 Day 2-3: Understanding the Codebase

### Project Structure

```
FinishThisIdea/
├── src/                          # Backend source code
│   ├── api/routes/              # API endpoints
│   ├── automation/              # Automation services (NEW!)
│   │   ├── config/             # Automation configuration
│   │   └── services/           # Email, analytics, monitoring
│   ├── jobs/                   # Background job definitions
│   ├── llm/                    # AI integration (Ollama, Claude)
│   ├── middleware/             # Express middleware
│   ├── parsers/                # Language-specific parsers
│   ├── services/               # Business logic services
│   └── utils/                  # Utility functions
├── frontend/                    # React frontend
│   ├── src/components/         # React components
│   │   ├── Premium/           # Premium feature components
│   │   ├── Onboarding/        # User onboarding
│   │   └── Support/           # Help and support
│   └── src/pages/             # Main application pages
├── tests/                      # Test suite
│   ├── e2e/                   # End-to-end tests
│   ├── integration/           # Integration tests
│   └── performance/           # Performance & load tests
├── docs/                       # Documentation
├── .github/workflows/          # CI/CD pipelines
└── docker-compose.yml         # Local development services
```

### Key Technologies

**Backend:**
- **Express.js + TypeScript**: API server
- **Prisma + PostgreSQL**: Database ORM and storage
- **Bull + Redis**: Job queue for background processing
- **Stripe**: Payment processing
- **Sentry**: Error monitoring
- **Nodemailer**: Email automation

**Frontend:**
- **React 18 + TypeScript**: User interface
- **Vite**: Build tool and development server
- **Tailwind CSS**: Styling framework
- **Framer Motion**: Animations

**AI & Processing:**
- **Ollama**: Local AI model serving
- **Anthropic Claude**: Fallback AI service
- **Custom Parsers**: Multi-language code analysis

### Key Concepts

1. **Context Profiles**: User-defined parsing configurations
2. **Job Queue**: Async processing for file uploads and AI analysis
3. **Premium Tiers**: FREE vs PREMIUM feature gating
4. **Automation System**: Email, analytics, and monitoring automation

## 🔧 Day 4-5: Development Workflow

### Git Workflow

We use a feature branch workflow:

```bash
# Create feature branch
git checkout -b feature/your-feature-name

# Make changes and commit
git add .
git commit -m "feat: add new feature description"

# Push and create PR
git push origin feature/your-feature-name
```

**Commit Message Format:**
- `feat:` - New feature
- `fix:` - Bug fix
- `docs:` - Documentation changes
- `test:` - Adding or updating tests
- `refactor:` - Code refactoring
- `chore:` - Maintenance tasks

### Development Commands

```bash
# Development
npm run dev              # Start backend dev server
npm run dev:frontend     # Start frontend dev server

# Testing
npm run test            # Run all tests
npm run test:unit       # Unit tests only
npm run test:e2e        # End-to-end tests
npm run test:watch      # Watch mode for TDD

# Code Quality
npm run lint            # Check code style
npm run format          # Auto-format code
npm run type-check      # TypeScript validation

# Database
npx prisma studio       # Database GUI
npx prisma migrate dev  # Create new migration
npx prisma db push      # Push schema changes
```

### Debugging

**Backend Debugging:**
```bash
# Enable debug logging
export LOG_LEVEL=debug
npm run dev

# Use VS Code debugger
# - Set breakpoints in TypeScript files
# - F5 to start debugging session
```

**Frontend Debugging:**
- Use React DevTools browser extension
- Set breakpoints in browser DevTools
- Use `console.log()` for quick debugging

### Testing Best Practices

1. **Write tests first** (TDD approach)
2. **Test behavior, not implementation**
3. **Use descriptive test names**
4. **Mock external dependencies**

Example test structure:
```typescript
describe('UserService', () => {
  describe('createUser', () => {
    it('should create user with valid data', async () => {
      // Arrange
      const userData = { email: 'test@example.com' };
      
      // Act
      const user = await userService.createUser(userData);
      
      // Assert
      expect(user.email).toBe('test@example.com');
    });
  });
});
```

## 🤖 Understanding the Automation System

### Email Automation

Located in `src/automation/services/email.service.ts`:

```typescript
// Send welcome email
await emailService.sendWelcomeEmail(user.email, {
  name: user.name,
  upgradeUrl: 'https://app.com/upgrade'
});

// Send job notification
await jobNotificationService.sendJobNotification({
  jobId,
  userId,
  status: 'COMPLETED',
  downloadUrl
});
```

### Analytics & Conversion Tracking

Located in `src/automation/services/conversion-tracking.service.ts`:

```typescript
// Track signup funnel
await conversionTracking.trackSignupFunnel(userId, 'completed');

// Track upgrade funnel
await conversionTracking.trackUpgradeFunnel(userId, 'checkout', {
  amount: 2999, // $29.99 in cents
  contextProfileId
});

// Track custom events
await conversionTracking.trackConversion(userId, 'feature_used', {
  featureName: 'advanced_parser'
});
```

### Queue Health Monitoring

Located in `src/automation/services/queue-health-monitor.service.ts`:

```typescript
// Start monitoring
queueHealthMonitor.startMonitoring(5); // Check every 5 minutes

// Manual health check
const stats = await queueHealthMonitor.getQueueStats();
console.log(stats);

// Cleanup old jobs
await queueHealthMonitor.cleanupQueues(7); // Older than 7 days
```

## 🎯 Week 2: Contributing Your First Feature

### Choose a Good First Issue

Look for issues labeled:
- `good-first-issue`
- `help-wanted`
- `frontend` or `backend` based on your preference

### Feature Development Process

1. **Understand the Requirements**
   - Read the issue description thoroughly
   - Ask questions in comments if unclear
   - Review related code areas

2. **Plan Your Implementation**
   - Identify affected files
   - Consider testing strategy
   - Think about edge cases

3. **Implement with Tests**
   ```bash
   # Create feature branch
   git checkout -b feature/issue-123-description
   
   # Write failing test first
   npm run test:watch
   
   # Implement feature
   # Make tests pass
   
   # Add integration/E2E tests if needed
   npm run test:e2e
   ```

4. **Code Review Checklist**
   - [ ] All tests pass
   - [ ] Code follows style guidelines
   - [ ] Documentation updated if needed
   - [ ] No TypeScript errors
   - [ ] Performance impact considered

### Example: Adding a New API Endpoint

1. **Define the route** (`src/api/routes/example.route.ts`):
```typescript
import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../../utils/async-handler';

const router = Router();

const exampleSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
});

router.post('/example', asyncHandler(async (req, res) => {
  const data = exampleSchema.parse(req.body);
  
  // Business logic here
  const result = await exampleService.create(data);
  
  res.json({ success: true, data: result });
}));

export { router as exampleRouter };
```

2. **Write tests** (`tests/api/example.test.ts`):
```typescript
import request from 'supertest';
import { app } from '../../src/server';

describe('POST /api/example', () => {
  it('should create example with valid data', async () => {
    const response = await request(app)
      .post('/api/example')
      .send({
        name: 'Test',
        email: 'test@example.com'
      })
      .expect(200);
      
    expect(response.body.success).toBe(true);
  });
});
```

3. **Add to main app** (`src/server.ts`):
```typescript
import { exampleRouter } from './api/routes/example.route';

app.use('/api/example', exampleRouter);
```

## 🔍 Debugging Common Issues

### Database Connection Issues

```bash
# Check if PostgreSQL is running
docker-compose ps

# Reset database
docker-compose down
docker-compose up -d
npx prisma migrate reset
```

### Frontend Build Issues

```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm ci

# Check for TypeScript errors
npm run type-check
```

### Queue/Redis Issues

```bash
# Check Redis connection
docker-compose logs redis

# Clear all queues
npm run dev
# In another terminal:
curl http://localhost:3001/health/queues
```

### AI/Ollama Issues

```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Pull required model
docker exec -it finishthisidea-ollama-1 ollama pull codellama:latest
```

## 📖 Learning Resources

### Internal Documentation
- [API Documentation](API.md) - Complete API reference
- [Automation Guide](AUTOMATION_IMPLEMENTATION.md) - Automation system details
- [Database Schema](DATABASE.md) - Database structure and migrations
- [Production Deployment](PRODUCTION_DEPLOYMENT.md) - Deployment process

### External Resources
- [Express.js Guide](https://expressjs.com/en/guide/)
- [React Documentation](https://react.dev/)
- [Prisma Documentation](https://www.prisma.io/docs)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Jest Testing Framework](https://jestjs.io/docs/getting-started)

## 🤝 Getting Help

### Development Support
- **Code Questions**: Ask in team chat or GitHub discussions
- **Bugs**: Create GitHub issue with reproduction steps
- **Architecture Decisions**: Schedule team discussion

### Quick Reference Commands

```bash
# Health checks
curl http://localhost:3001/health
curl http://localhost:3001/health/detailed

# Database operations
npx prisma studio
npx prisma db push
npx prisma migrate dev

# Testing
npm run test:unit -- --watch
npm run test:e2e -- --verbose
npm run test:coverage

# Production commands
npm run build
npm run start
npm run test:full
```

## 🎉 Welcome to the Team!

You're now ready to contribute to FinishThisIdea! Remember:

- **Ask questions** - The team is here to help
- **Start small** - Build confidence with smaller features first
- **Test everything** - We maintain high quality standards
- **Document changes** - Help future developers (including yourself)
- **Have fun** - We're building something amazing together!

### Your First Week Goals

- [ ] Complete local setup
- [ ] Run all tests successfully
- [ ] Understand the automation system
- [ ] Complete first code review
- [ ] Ask at least 3 questions (seriously!)

### Next Steps

1. Join the team chat/Slack
2. Review open issues and pick your first task
3. Set up your development environment
4. Make your first contribution

Welcome aboard! 🚀