/**
 * Database Seeding Script
 * 
 * Seeds the database with initial data including:
 * - Default context profiles
 * - System configuration
 * - Test data (in development only)
 */

const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();

async function main() {
  const isProduction = process.env.NODE_ENV === 'production';
  
  console.log('🌱 Starting database seeding...');
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);

  try {
    // Seed default context profiles
    await seedContextProfiles();
    
    // Only seed test data in development
    if (!isProduction) {
      await seedTestData();
    }
    
    console.log('✅ Database seeding completed successfully');
  } catch (error) {
    console.error('❌ Database seeding failed:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

/**
 * Seed default context profiles from JSON files
 */
async function seedContextProfiles() {
  console.log('📋 Seeding context profiles...');
  
  const profilesDir = path.join(__dirname, '../src/profiles/defaults');
  
  if (!fs.existsSync(profilesDir)) {
    console.warn('⚠️  Profiles directory not found, skipping profile seeding');
    return;
  }

  const profileFiles = fs.readdirSync(profilesDir).filter(file => file.endsWith('.json'));
  
  for (const file of profileFiles) {
    try {
      const filePath = path.join(profilesDir, file);
      const profileData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      
      // Check if profile already exists
      const existingProfile = await prisma.contextProfile.findFirst({
        where: { 
          name: profileData.name,
          userId: null // System profiles have null userId
        }
      });
      
      if (existingProfile) {
        console.log(`⏭️  Profile "${profileData.name}" already exists, skipping...`);
        continue;
      }
      
      // Create the profile
      await prisma.contextProfile.create({
        data: {
          id: profileData.id,
          name: profileData.name,
          description: profileData.description,
          userId: null, // System profile
          data: profileData,
          language: profileData.language,
          framework: profileData.framework,
          version: profileData.version || '1.0.0',
          isDefault: profileData.isDefault || false,
          isPublic: true, // System profiles are public
          usageCount: 0
        }
      });
      
      console.log(`✅ Created profile: ${profileData.name}`);
    } catch (error) {
      console.error(`❌ Failed to seed profile from ${file}:`, error);
    }
  }
}

/**
 * Seed test data for development environment
 */
async function seedTestData() {
  console.log('🧪 Seeding test data for development...');
  
  // Create test user
  const testUser = await prisma.user.upsert({
    where: { email: 'test@finishthisidea.com' },
    update: {},
    create: {
      id: 'test-user-id',
      email: 'test@finishthisidea.com',
      username: 'testuser',
      tier: 'FREE'
    }
  });
  
  console.log('✅ Created test user');
  
  // Create test upload
  const testUpload = await prisma.upload.upsert({
    where: { id: 'test-upload-id' },
    update: {},
    create: {
      id: 'test-upload-id',
      originalName: 'test-project.zip',
      filename: 'test-project-123456.zip',
      mimeType: 'application/zip',
      size: 1024000, // 1MB
      path: '/uploads/test-project-123456.zip',
      url: 'https://s3.amazonaws.com/test-bucket/test-project-123456.zip',
      userId: testUser.id,
      status: 'UPLOADED'
    }
  });
  
  console.log('✅ Created test upload');
  
  // Create test job
  const testJob = await prisma.job.upsert({
    where: { id: 'test-job-id' },
    update: {},
    create: {
      id: 'test-job-id',
      type: 'cleanup',
      status: 'COMPLETED',
      inputFileUrl: testUpload.url,
      outputFileUrl: 'https://s3.amazonaws.com/test-bucket/cleaned-project-123456.zip',
      originalFileName: 'test-project.zip',
      fileSizeBytes: 1024000,
      fileCount: 15,
      cost: 1.0,
      totalCost: 1.0,
      tokensUsed: 1500,
      llmProvider: 'ollama',
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      userId: testUser.id,
      uploadId: testUpload.id,
      completedAt: new Date(),
      metadata: {
        processingTime: 30000,
        filesProcessed: 15,
        changesApplied: 42
      }
    }
  });
  
  console.log('✅ Created test job');
  
  // Create test payment
  await prisma.payment.upsert({
    where: { jobId: testJob.id },
    update: {},
    create: {
      jobId: testJob.id,
      userId: testUser.id,
      amount: 100, // $1.00 in cents
      currency: 'usd',
      status: 'SUCCEEDED',
      paidAt: new Date(),
      metadata: {
        testPayment: true
      }
    }
  });
  
  console.log('✅ Created test payment');
  
  // Create test analysis result
  await prisma.analysisResult.upsert({
    where: { jobId: testJob.id },
    update: {},
    create: {
      jobId: testJob.id,
      totalFiles: 15,
      linesOfCode: 2500,
      languages: {
        javascript: 60,
        typescript: 30,
        css: 10
      },
      issues: [
        {
          type: 'missing-semicolon',
          count: 12,
          severity: 'low'
        },
        {
          type: 'unused-variable',
          count: 5,
          severity: 'medium'
        }
      ],
      improvements: [
        {
          type: 'code-formatting',
          count: 42,
          description: 'Applied consistent formatting'
        },
        {
          type: 'import-organization',
          count: 8,
          description: 'Organized import statements'
        }
      ],
      ollamaConfidence: 0.92,
      claudeUsed: false,
      processingCostUsd: 0.01
    }
  });
  
  console.log('✅ Created test analysis result');
}

// Handle script execution
if (require.main === module) {
  main().catch(error => {
    console.error('❌ Seed script failed:', error);
    process.exit(1);
  });
}

module.exports = { main, seedContextProfiles, seedTestData };