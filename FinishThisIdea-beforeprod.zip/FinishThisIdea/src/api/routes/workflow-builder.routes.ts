/**
 * Workflow Builder API Routes
 * Endpoints for the workflow builder UI
 */

import { Router, Request, Response } from 'express';
import { authenticate } from '../../middleware/auth.middleware';
import { workflowEngine } from '../../automation/services/workflow-engine.service';
import { logger } from '../../utils/logger';
import * as yaml from 'js-yaml';

const router = Router();

/**
 * Get available step types with metadata
 */
router.get('/step-types', authenticate, async (req: Request, res: Response) => {
  try {
    const stepTypes = workflowEngine.getAvailableStepTypes();
    
    res.json({
      success: true,
      data: stepTypes
    });
  } catch (error) {
    logger.error('Failed to get step types:', error);
    res.status(500).json({
      success: false,
      error: {
        message: 'Failed to retrieve step types',
        code: 'STEP_TYPES_ERROR'
      }
    });
  }
});

/**
 * Get available workflow templates
 */
router.get('/templates', authenticate, async (req: Request, res: Response) => {
  try {
    const templates = workflowEngine.getAvailableTemplates();
    const templateDetails = templates.map(name => {
      const template = workflowEngine.getTemplate(name);
      return {
        name,
        description: template?.description || '',
        stepCount: template?.steps.length || 0
      };
    });
    
    res.json({
      success: true,
      data: templateDetails
    });
  } catch (error) {
    logger.error('Failed to get templates:', error);
    res.status(500).json({
      success: false,
      error: {
        message: 'Failed to retrieve templates',
        code: 'TEMPLATES_ERROR'
      }
    });
  }
});

/**
 * Save a new workflow
 */
router.post('/workflows', authenticate, async (req: Request, res: Response) => {
  try {
    const { name, description, nodes, connections, variables, triggers } = req.body;
    
    if (!name || !nodes || !Array.isArray(nodes)) {
      return res.status(400).json({
        success: false,
        error: {
          message: 'Invalid workflow data',
          code: 'INVALID_WORKFLOW'
        }
      });
    }
    
    // Convert nodes and connections to workflow steps
    const steps = nodes.map((node: any) => ({
      name: node.data.name || node.id,
      type: node.data.type,
      ...node.data
    }));
    
    const workflow = {
      name,
      description,
      variables: variables || {},
      triggers: triggers || [],
      steps
    };
    
    // Generate YAML
    const yamlContent = yaml.dump(workflow, { 
      indent: 2,
      lineWidth: 80,
      noRefs: true
    });
    
    // Register the workflow
    workflowEngine.registerTemplate(name.toLowerCase().replace(/[^a-z0-9]/g, '-'), workflow);
    
    res.json({
      success: true,
      data: {
        id: name.toLowerCase().replace(/[^a-z0-9]/g, '-'),
        name,
        nodeCount: nodes.length,
        yaml: yamlContent
      }
    });
  } catch (error) {
    logger.error('Failed to save workflow:', error);
    res.status(500).json({
      success: false,
      error: {
        message: 'Failed to save workflow',
        code: 'SAVE_ERROR'
      }
    });
  }
});

/**
 * Execute a workflow
 */
router.post('/workflows/:id/execute', authenticate, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { variables = {} } = req.body;
    
    const result = await workflowEngine.executeWorkflow(id, {
      variables,
      userId: req.user!.id
    });
    
    res.json({
      success: true,
      data: result
    });
  } catch (error) {
    logger.error('Failed to execute workflow:', error);
    res.status(500).json({
      success: false,
      error: {
        message: error instanceof Error ? error.message : 'Failed to execute workflow',
        code: 'EXECUTION_ERROR'
      }
    });
  }
});

/**
 * Reload plugins
 */
router.post('/plugins/reload', authenticate, async (req: Request, res: Response) => {
  try {
    // Check if user has admin role
    if (req.user?.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: {
          message: 'Admin access required',
          code: 'FORBIDDEN'
        }
      });
    }
    
    await workflowEngine.reloadPlugins();
    const stepTypes = workflowEngine.getAvailableStepTypes();
    
    res.json({
      success: true,
      data: {
        message: 'Plugins reloaded successfully',
        pluginCount: stepTypes.length
      }
    });
  } catch (error) {
    logger.error('Failed to reload plugins:', error);
    res.status(500).json({
      success: false,
      error: {
        message: 'Failed to reload plugins',
        code: 'RELOAD_ERROR'
      }
    });
  }
});

export default router;