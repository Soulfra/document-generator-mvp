import { documentationService } from '../src/services/documentation.service';

describe('DocumentationService Integration', () => {
  describe('analyzeCodeForDocumentation', () => {
    it('should analyze a simple codebase and extract metadata', async () => {
      // Mock a simple React codebase
      const mockFiles = new Map([
        ['package.json', JSON.stringify({
          name: 'my-react-app',
          description: 'A simple React application for testing',
          dependencies: {
            'react': '^18.0.0',
            'express': '^4.18.0'
          },
          devDependencies: {
            'jest': '^29.0.0',
            '@types/node': '^18.0.0'
          }
        })],
        ['src/App.tsx', `
import React from 'react';
import { UserList } from './components/UserList';

function App() {
  return (
    <div className="App">
      <h1>My React App</h1>
      <UserList />
    </div>
  );
}

export default App;
        `],
        ['src/api/routes/users.ts', `
import express from 'express';

const router = express.Router();

// GET /api/users - Get all users
router.get('/users', async (req, res) => {
  try {
    const users = await getUsersFromDatabase();
    res.json({ success: true, data: users });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch users' });
  }
});

// POST /api/users - Create new user
router.post('/users', async (req, res) => {
  try {
    const { name, email } = req.body;
    const user = await createUser({ name, email });
    res.status(201).json({ success: true, data: user });
  } catch (error) {
    res.status(400).json({ success: false, error: 'Failed to create user' });
  }
});

export default router;
        `],
        ['src/components/UserList.test.tsx', `
import { render, screen } from '@testing-library/react';
import { UserList } from './UserList';

describe('UserList', () => {
  it('renders user list', () => {
    render(<UserList />);
    expect(screen.getByText('Users')).toBeInTheDocument();
  });
});
        `],
        ['README.md', `
# My React App

This is a simple React application for managing users.

## Features
- User listing
- User creation
- Responsive design
        `]
      ]);

      const result = await documentationService.analyzeCodeForDocumentation(mockFiles, '/test-project');

      // Test project info extraction
      expect(result.projectInfo.name).toBe('my-react-app');
      expect(result.projectInfo.description).toBe('A simple React application for testing');
      expect(result.projectInfo.language).toBe('typescript');
      expect(result.projectInfo.framework).toBe('react');
      expect(result.projectInfo.type).toBe('application');

      // Test dependencies extraction
      expect(result.dependencies).toHaveLength(4);
      expect(result.dependencies.find(d => d.name === 'react')).toEqual({
        name: 'react',
        version: '^18.0.0',
        type: 'production'
      });
      expect(result.dependencies.find(d => d.name === 'jest')).toEqual({
        name: 'jest',
        version: '^29.0.0',
        type: 'development'
      });

      // Test test coverage extraction
      expect(result.testCoverage.testFiles).toBe(1); // UserList.test.tsx
      
      // Test file structure
      expect(result.fileStructure.totalFiles).toBe(5);
      expect(result.fileStructure.linesOfCode).toBeGreaterThan(0);
    });

    it('should handle empty codebase gracefully', async () => {
      const emptyFiles = new Map<string, string>();
      
      const result = await documentationService.analyzeCodeForDocumentation(emptyFiles, '/empty-project');

      expect(result.projectInfo.name).toBe('empty-project');
      expect(result.projectInfo.language).toBe('javascript');
      expect(result.apis).toHaveLength(0);
      expect(result.dataModels).toHaveLength(0);
      expect(result.functions).toHaveLength(0);
      expect(result.dependencies).toHaveLength(0);
    });
  });

  describe('generateDocumentation', () => {
    it('should generate documentation from code analysis', async () => {
      const mockAnalysis = {
        projectInfo: {
          name: 'Test App',
          description: 'A test application',
          type: 'webapp',
          language: 'typescript',
          framework: 'react'
        },
        apis: [
          {
            method: 'GET',
            path: '/api/users',
            description: 'Get all users',
            parameters: [],
            responses: { '200': { description: 'Success' } }
          }
        ],
        dataModels: [
          {
            name: 'User',
            type: 'table',
            fields: [
              { name: 'id', type: 'string', required: true, description: 'User ID' },
              { name: 'name', type: 'string', required: true, description: 'User name' }
            ],
            relationships: []
          }
        ],
        functions: [],
        dependencies: [
          { name: 'react', version: '^18.0.0', type: 'production' }
        ],
        testCoverage: {
          coverage: 80,
          testFiles: 5,
          testCases: 20,
          passingTests: 18,
          failingTests: 2
        },
        architecture: {
          pattern: 'MVC',
          layers: ['presentation', 'business', 'data'],
          components: []
        },
        businessLogic: [
          {
            id: 'br-001',
            description: 'Users must have unique emails',
            implementation: 'Database constraint'
          }
        ],
        fileStructure: {
          totalFiles: 15,
          linesOfCode: 500,
          directories: ['src', 'tests'],
          mainFiles: ['src/app.ts']
        }
      };

      const result = await documentationService.generateDocumentation(
        'test-job-123',
        mockAnalysis as any,
        ['executive-summary', 'api-contract']
      );

      expect(result.jobId).toBe('test-job-123');
      expect(result.templates).toHaveLength(2);
      
      // Check that templates were processed
      const execSummary = result.templates.find(t => t.templateId === 'executive-summary');
      expect(execSummary).toBeDefined();
      expect(execSummary?.content).toContain('Test App');

      const apiContract = result.templates.find(t => t.templateId === 'api-contract');
      expect(apiContract).toBeDefined();
      expect(apiContract?.content).toContain('/api/users');

      // Check metadata
      expect(result.metadata.templatesUsed).toEqual(['executive-summary', 'api-contract']);
      expect(result.metadata.quality.overall).toBeGreaterThanOrEqual(0);
      expect(result.metadata.quality.overall).toBeLessThanOrEqual(100);
    });

    it('should handle missing templates gracefully', async () => {
      const mockAnalysis = {
        projectInfo: { name: 'Test', description: 'Test', type: 'app', language: 'js' },
        apis: [], dataModels: [], functions: [], dependencies: [],
        testCoverage: { coverage: 0, testFiles: 0, testCases: 0, passingTests: 0, failingTests: 0 },
        architecture: { pattern: 'MVC', layers: [], components: [] },
        businessLogic: [],
        fileStructure: { totalFiles: 0, linesOfCode: 0, directories: [], mainFiles: [] }
      };

      const result = await documentationService.generateDocumentation(
        'test-job-456',
        mockAnalysis as any,
        ['non-existent-template']
      );

      expect(result.templates).toHaveLength(0);
    });
  });

  describe('parseChatlogs', () => {
    it('should parse chat logs and extract requirements', async () => {
      const mockChatLog = {
        messages: [
          {
            role: 'user' as const,
            content: 'I need a user management system with login and registration',
            timestamp: new Date()
          },
          {
            role: 'assistant' as const,
            content: 'I can help you build that. We\'ll need user authentication, a database for storing users, and forms for login/registration.',
            timestamp: new Date()
          },
          {
            role: 'user' as const,
            content: 'Great! Also, users should be able to update their profiles and reset passwords.',
            timestamp: new Date()
          }
        ],
        platform: 'claude' as const,
        exportDate: new Date()
      };

      const result = await documentationService.parseChatlogs(mockChatLog);

      expect(result).toBeDefined();
      expect(result.features).toBeDefined();
      expect(result.userStories).toBeDefined();
      expect(result.technicalRequirements).toBeDefined();
      expect(result.businessRules).toBeDefined();
      expect(result.constraints).toBeDefined();
    });
  });

  describe('Template Loading', () => {
    it('should load YAML templates successfully', async () => {
      // This test verifies that the service can load templates
      // Since loadDefaultTemplates is called in constructor, we can test by generating docs
      const mockAnalysis = {
        projectInfo: { name: 'Test', description: 'Test', type: 'app', language: 'js' },
        apis: [], dataModels: [], functions: [], dependencies: [],
        testCoverage: { coverage: 0, testFiles: 0, testCases: 0, passingTests: 0, failingTests: 0 },
        architecture: { pattern: 'MVC', layers: [], components: [] },
        businessLogic: [],
        fileStructure: { totalFiles: 0, linesOfCode: 0, directories: [], mainFiles: [] }
      };

      // If templates are loaded, this should work without throwing
      await expect(
        documentationService.generateDocumentation('test', mockAnalysis as any, ['executive-summary'])
      ).resolves.toBeDefined();
    });
  });
});