
/**
 * Production Readiness Validation Script
 * 
 * Validates all consultant recommendations and production requirements
 */

const fs = require('fs');
const path = require('path');

class ProductionValidator {
  constructor() {
    this.errors = [];
    this.warnings = [];
    this.passed = [];
    this.projectRoot = process.cwd();
  }

  /**
   * Run all validation checks
   */
  async validate() {
    console.log('🔍 Running Production Readiness Validation...\n');

    this.validateBuildSystem();
    this.validateDockerConfiguration();
    this.validateSecurityImplementation();
    this.validateDocumentationCompliance();
    this.validateCICDPipeline();
    this.validateObservability();

    this.generateReport();
    return this.errors.length === 0;
  }

  validateBuildSystem() {
    console.log('📦 Validating Build System...');

    const packageJson = this.readJsonFile('package.json');
    if (packageJson) {
      if (packageJson.scripts?.['build:prod']) {
        this.passed.push('✅ Production build script exists');
      } else {
        this.errors.push('❌ Missing npm run build:prod script');
      }
    }

    if (fs.existsSync('tsconfig.prod.json')) {
      this.passed.push('✅ Production TypeScript config exists');
    } else {
      this.errors.push('❌ Missing tsconfig.prod.json');
    }
  }

  validateDockerConfiguration() {
    console.log('🐳 Validating Docker Configuration...');

    if (fs.existsSync('docker-compose.prod.yml')) {
      this.passed.push('✅ Production Docker Compose exists');
    } else {
      this.errors.push('❌ Missing docker-compose.prod.yml');
    }
  }

  validateSecurityImplementation() {
    console.log('🛡️ Validating Security Implementation...');

    if (fs.existsSync('docs/AUTHENTICATION_STRATEGY.md')) {
      this.passed.push('✅ Authentication strategy documented');
    } else {
      this.errors.push('❌ Missing authentication strategy documentation');
    }

    if (fs.existsSync('src/middleware/security-headers.middleware.ts')) {
      this.passed.push('✅ Security headers middleware implemented');
    } else {
      this.errors.push('❌ Missing security headers middleware');
    }
  }

  validateDocumentationCompliance() {
    console.log('📚 Validating Documentation Compliance...');

    const docsDir = 'docs';
    if (fs.existsSync(docsDir)) {
      const docFiles = fs.readdirSync(docsDir).filter(f => f.endsWith('.md'));
      let frontMatterCount = 0;

      docFiles.forEach(file => {
        const content = this.readFile(path.join(docsDir, file));
        if (content && content.startsWith('---')) {
          frontMatterCount++;
        }
      });

      if (frontMatterCount >= docFiles.length * 0.8) {
        this.passed.push(`✅ Most docs have YAML front-matter`);
      } else {
        this.warnings.push(`⚠️  Some docs missing YAML front-matter`);
      }
    }
  }

  validateCICDPipeline() {
    console.log('🚀 Validating CI/CD Pipeline...');

    if (fs.existsSync('.github/workflows/ci.yml')) {
      this.passed.push('✅ GitHub Actions CI/CD workflow exists');
    } else {
      this.errors.push('❌ Missing GitHub Actions CI/CD workflow');
    }
  }

  validateObservability() {
    console.log('📊 Validating Observability...');

    if (fs.existsSync('src/utils/telemetry.ts')) {
      this.passed.push('✅ OpenTelemetry integration implemented');
    } else {
      this.errors.push('❌ Missing OpenTelemetry integration');
    }
  }

  readJsonFile(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(content);
    } catch (error) {
      return null;
    }
  }

  readFile(filePath) {
    try {
      return fs.readFileSync(filePath, 'utf8');
    } catch (error) {
      return null;
    }
  }

  generateReport() {
    console.log('\n📋 Production Readiness Report');
    console.log('================================\n');

    if (this.passed.length > 0) {
      console.log('✅ PASSED CHECKS:');
      this.passed.forEach(check => console.log(`  ${check}`));
      console.log('');
    }

    if (this.warnings.length > 0) {
      console.log('⚠️  WARNINGS:');
      this.warnings.forEach(warning => console.log(`  ${warning}`));
      console.log('');
    }

    if (this.errors.length > 0) {
      console.log('❌ FAILED CHECKS:');
      this.errors.forEach(error => console.log(`  ${error}`));
      console.log('');
    }

    const total = this.passed.length + this.warnings.length + this.errors.length;
    const passRate = Math.round((this.passed.length / total) * 100);

    console.log('📊 SUMMARY:');
    console.log(`  Total Checks: ${total}`);
    console.log(`  Passed: ${this.passed.length} (${passRate}%)`);
    console.log(`  Warnings: ${this.warnings.length}`);
    console.log(`  Errors: ${this.errors.length}`);

    if (this.errors.length === 0) {
      console.log('\n🎉 PRODUCTION READY\! All critical checks passed.');
    } else {
      console.log('\n⚠️  NOT PRODUCTION READY. Please address the failed checks above.');
    }
  }
}

if (require.main === module) {
  const validator = new ProductionValidator();
  validator.validate().catch(error => {
    console.error('❌ Validation failed with error:', error);
    process.exit(1);
  });
}

module.exports = ProductionValidator;
EOF < /dev/null