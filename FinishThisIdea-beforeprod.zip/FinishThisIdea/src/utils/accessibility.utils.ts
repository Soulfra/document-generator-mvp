/**
 * Accessibility Utilities
 * Provides helper functions for managing accessibility features across the application
 */

export class AccessibilityUtils {
  private static announcerElement: HTMLElement | null = null;
  private static focusTrapStack: HTMLElement[] = [];
  
  /**
   * Initialize accessibility utilities
   */
  static initialize(): void {
    // Create live region for screen reader announcements
    if (typeof document !== 'undefined' && !this.announcerElement) {
      this.announcerElement = document.createElement('div');
      this.announcerElement.setAttribute('role', 'status');
      this.announcerElement.setAttribute('aria-live', 'polite');
      this.announcerElement.setAttribute('aria-atomic', 'true');
      this.announcerElement.className = 'sr-only';
      this.announcerElement.style.cssText = `
        position: absolute;
        left: -10000px;
        width: 1px;
        height: 1px;
        overflow: hidden;
      `;
      document.body.appendChild(this.announcerElement);
    }

    // Add keyboard navigation helpers
    this.setupKeyboardNavigation();
  }

  /**
   * Announce message to screen readers
   */
  static announce(message: string, priority: 'polite' | 'assertive' = 'polite'): void {
    if (!this.announcerElement) {
      this.initialize();
    }
    
    if (this.announcerElement) {
      this.announcerElement.setAttribute('aria-live', priority);
      this.announcerElement.textContent = message;
      
      // Clear after announcement
      setTimeout(() => {
        if (this.announcerElement) {
          this.announcerElement.textContent = '';
        }
      }, 1000);
    }
  }

  /**
   * Set up global keyboard navigation
   */
  private static setupKeyboardNavigation(): void {
    if (typeof document === 'undefined') return;

    // Skip to main content
    document.addEventListener('keydown', (e: KeyboardEvent) => {
      // Alt + M to skip to main content
      if (e.altKey && e.key === 'm') {
        e.preventDefault();
        const main = document.querySelector('main') || document.querySelector('[role="main"]');
        if (main instanceof HTMLElement) {
          main.tabIndex = -1;
          main.focus();
          this.announce('Navigated to main content');
        }
      }

      // Alt + N to skip to navigation
      if (e.altKey && e.key === 'n') {
        e.preventDefault();
        const nav = document.querySelector('nav') || document.querySelector('[role="navigation"]');
        if (nav instanceof HTMLElement) {
          nav.tabIndex = -1;
          nav.focus();
          this.announce('Navigated to navigation');
        }
      }

      // Escape to close modals/dialogs
      if (e.key === 'Escape') {
        const modal = document.querySelector('.modal.visible') || document.querySelector('[role="dialog"][aria-hidden="false"]');
        if (modal) {
          const closeBtn = modal.querySelector('.close-btn') || modal.querySelector('[aria-label*="close"]');
          if (closeBtn instanceof HTMLElement) {
            closeBtn.click();
          }
        }
      }
    });
  }

  /**
   * Trap focus within an element (for modals, etc)
   */
  static trapFocus(element: HTMLElement): void {
    const focusableElements = element.querySelectorAll(
      'a[href], button, textarea, input[type="text"], input[type="radio"], input[type="checkbox"], select, [tabindex]:not([tabindex="-1"])'
    );
    
    const focusableArray = Array.from(focusableElements) as HTMLElement[];
    if (focusableArray.length === 0) return;

    const firstFocusable = focusableArray[0];
    const lastFocusable = focusableArray[focusableArray.length - 1];

    // Store current focus to restore later
    const previouslyFocused = document.activeElement as HTMLElement;
    this.focusTrapStack.push(previouslyFocused);

    // Focus first element
    firstFocusable.focus();

    const trapHandler = (e: KeyboardEvent) => {
      if (e.key !== 'Tab') return;

      if (e.shiftKey) {
        // Shift + Tab
        if (document.activeElement === firstFocusable) {
          e.preventDefault();
          lastFocusable.focus();
        }
      } else {
        // Tab
        if (document.activeElement === lastFocusable) {
          e.preventDefault();
          firstFocusable.focus();
        }
      }
    };

    element.addEventListener('keydown', trapHandler);
    element.setAttribute('data-focus-trap', 'true');
  }

  /**
   * Release focus trap
   */
  static releaseFocusTrap(element: HTMLElement): void {
    element.removeAttribute('data-focus-trap');
    
    // Restore previous focus
    const previousFocus = this.focusTrapStack.pop();
    if (previousFocus) {
      previousFocus.focus();
    }
  }

  /**
   * Get appropriate ARIA label for interactive elements
   */
  static getAriaLabel(element: HTMLElement): string {
    // Check for existing aria-label
    if (element.getAttribute('aria-label')) {
      return element.getAttribute('aria-label') || '';
    }

    // Check for aria-labelledby
    const labelledBy = element.getAttribute('aria-labelledby');
    if (labelledBy) {
      const labelElement = document.getElementById(labelledBy);
      if (labelElement) {
        return labelElement.textContent || '';
      }
    }

    // Check for associated label
    if (element instanceof HTMLInputElement || element instanceof HTMLSelectElement || element instanceof HTMLTextAreaElement) {
      const label = element.labels?.[0];
      if (label) {
        return label.textContent || '';
      }
    }

    // Use text content as fallback
    return element.textContent?.trim() || '';
  }

  /**
   * Set up live region for dynamic content
   */
  static createLiveRegion(
    containerId: string, 
    ariaLive: 'polite' | 'assertive' = 'polite',
    ariaRelevant: string = 'additions text'
  ): void {
    const container = document.getElementById(containerId);
    if (container) {
      container.setAttribute('role', 'region');
      container.setAttribute('aria-live', ariaLive);
      container.setAttribute('aria-relevant', ariaRelevant);
      container.setAttribute('aria-atomic', 'false');
    }
  }

  /**
   * Add keyboard shortcut with visual indicator
   */
  static addKeyboardShortcut(
    key: string,
    modifiers: { ctrl?: boolean; alt?: boolean; shift?: boolean; meta?: boolean },
    action: () => void,
    description: string
  ): void {
    document.addEventListener('keydown', (e: KeyboardEvent) => {
      const matchesModifiers = 
        (!modifiers.ctrl || e.ctrlKey) &&
        (!modifiers.alt || e.altKey) &&
        (!modifiers.shift || e.shiftKey) &&
        (!modifiers.meta || e.metaKey);

      if (e.key.toLowerCase() === key.toLowerCase() && matchesModifiers) {
        e.preventDefault();
        action();
        this.announce(`Activated: ${description}`);
      }
    });
  }

  /**
   * Enhance form validation messages for screen readers
   */
  static announceFormError(fieldId: string, errorMessage: string): void {
    const field = document.getElementById(fieldId);
    if (field) {
      // Set aria-invalid
      field.setAttribute('aria-invalid', 'true');
      
      // Create or update error message element
      let errorId = `${fieldId}-error`;
      let errorElement = document.getElementById(errorId);
      
      if (!errorElement) {
        errorElement = document.createElement('span');
        errorElement.id = errorId;
        errorElement.className = 'error-message';
        errorElement.setAttribute('role', 'alert');
        field.parentNode?.insertBefore(errorElement, field.nextSibling);
      }
      
      errorElement.textContent = errorMessage;
      field.setAttribute('aria-describedby', errorId);
      
      // Announce error
      this.announce(errorMessage, 'assertive');
    }
  }

  /**
   * Clear form error
   */
  static clearFormError(fieldId: string): void {
    const field = document.getElementById(fieldId);
    if (field) {
      field.setAttribute('aria-invalid', 'false');
      const errorElement = document.getElementById(`${fieldId}-error`);
      if (errorElement) {
        errorElement.textContent = '';
      }
    }
  }

  /**
   * Make table sortable with keyboard
   */
  static makeTableSortable(tableId: string): void {
    const table = document.getElementById(tableId);
    if (!table) return;

    const headers = table.querySelectorAll('th[data-sortable="true"]');
    headers.forEach((header, index) => {
      if (header instanceof HTMLElement) {
        // Make header focusable and add role
        header.tabIndex = 0;
        header.setAttribute('role', 'button');
        header.setAttribute('aria-sort', 'none');
        
        // Add keyboard handler
        header.addEventListener('keydown', (e: KeyboardEvent) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            header.click();
          }
        });

        // Update aria-sort on click
        header.addEventListener('click', () => {
          const currentSort = header.getAttribute('aria-sort');
          
          // Reset all other headers
          headers.forEach(h => {
            if (h !== header) {
              h.setAttribute('aria-sort', 'none');
            }
          });

          // Toggle sort direction
          const newSort = currentSort === 'ascending' ? 'descending' : 'ascending';
          header.setAttribute('aria-sort', newSort);
          
          this.announce(`Table sorted by ${header.textContent} ${newSort}`);
        });
      }
    });
  }

  /**
   * Enhance progress indicators for screen readers
   */
  static updateProgress(progressId: string, value: number, max: number = 100): void {
    const progressElement = document.getElementById(progressId);
    if (progressElement) {
      progressElement.setAttribute('role', 'progressbar');
      progressElement.setAttribute('aria-valuenow', value.toString());
      progressElement.setAttribute('aria-valuemin', '0');
      progressElement.setAttribute('aria-valuemax', max.toString());
      
      // Announce significant progress updates
      if (value === 0) {
        this.announce('Process started');
      } else if (value === max) {
        this.announce('Process completed');
      } else if (value % 25 === 0) {
        this.announce(`Progress: ${value}%`);
      }
    }
  }

  /**
   * Add skip links for keyboard navigation
   */
  static addSkipLinks(): void {
    if (typeof document === 'undefined') return;

    const skipLinksHtml = `
      <div class="skip-links" role="navigation" aria-label="Skip links">
        <a href="#main-content" class="skip-link">Skip to main content</a>
        <a href="#navigation" class="skip-link">Skip to navigation</a>
        <a href="#search" class="skip-link">Skip to search</a>
      </div>
    `;

    const skipLinksContainer = document.createElement('div');
    skipLinksContainer.innerHTML = skipLinksHtml;
    document.body.insertBefore(skipLinksContainer.firstElementChild!, document.body.firstChild);

    // Add CSS for skip links
    const style = document.createElement('style');
    style.textContent = `
      .skip-links {
        position: absolute;
        top: -40px;
        left: 0;
        background: #000;
        color: #fff;
        padding: 8px;
        z-index: 100000;
      }
      
      .skip-link {
        color: #fff;
        text-decoration: none;
        padding: 8px;
        display: inline-block;
      }
      
      .skip-link:focus {
        position: absolute;
        top: 40px;
        left: 0;
        background: #000;
        color: #fff;
        padding: 8px;
        text-decoration: underline;
        z-index: 100000;
      }
      
      .sr-only {
        position: absolute;
        left: -10000px;
        width: 1px;
        height: 1px;
        overflow: hidden;
      }
      
      *:focus {
        outline: 2px solid #3b82f6;
        outline-offset: 2px;
      }
      
      .focus-visible:focus {
        outline: 2px solid #3b82f6;
        outline-offset: 2px;
      }
    `;
    document.head.appendChild(style);
  }
}

// Initialize on load
if (typeof window !== 'undefined') {
  window.addEventListener('DOMContentLoaded', () => {
    AccessibilityUtils.initialize();
    AccessibilityUtils.addSkipLinks();
  });
}