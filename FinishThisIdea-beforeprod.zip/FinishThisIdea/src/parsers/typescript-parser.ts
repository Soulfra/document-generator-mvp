import { BaseParser, ParseResult, Dependency, ImportStatement, Comment, ParserOptions } from './base-parser';
import { APIEndpoint, DataModel, FunctionSignature, Parameter } from '../types/code-analysis';
import { logger } from '../utils/logger';
import * as ts from 'typescript';
// import * as path from 'path'; // Unused

export class TypeScriptParser extends BaseParser {
  private program?: ts.Program;
  private checker?: ts.TypeChecker;

  constructor(options: ParserOptions = {}) {
    super(options);
  }

  getLanguage(): string {
    return 'typescript';
  }

  getSupportedExtensions(): string[] {
    return ['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs'];
  }

  async parse(files: Map<string, string>): Promise<ParseResult> {
    // Create a virtual TypeScript program for analysis
    this.createProgram(files);

    const [apis, functions, dataModels, dependencies, imports, comments] = await Promise.all([
      this.extractAPIs(files),
      this.extractFunctions(files),
      this.extractDataModels(files),
      this.extractDependencies(files),
      this.extractImports(files),
      this.extractComments(files)
    ]);

    return this.mergeResults({
      apis,
      functions,
      dataModels,
      dependencies,
      imports,
      comments
    });
  }

  private createProgram(files: Map<string, string>): void {
    // Create a virtual file system
    const fileContents = new Map<string, string>();
    const fileNames: string[] = [];

    for (const [filename, content] of files.entries()) {
      if (this.shouldParseFile(filename)) {
        fileContents.set(filename, content);
        fileNames.push(filename);
      }
    }

    // Create compiler options
    const options: ts.CompilerOptions = {
      target: ts.ScriptTarget.ES2020,
      module: ts.ModuleKind.CommonJS,
      lib: ['es2020'],
      allowJs: true,
      checkJs: false,
      jsx: ts.JsxEmit.React,
      skipLibCheck: true,
      skipDefaultLibCheck: true,
      allowSyntheticDefaultImports: true,
      esModuleInterop: true
    };

    // Create a custom compiler host
    const host: ts.CompilerHost = {
      getSourceFile: (fileName: string, languageVersion: ts.ScriptTarget) => {
        const content = fileContents.get(fileName);
        if (content !== undefined) {
          return ts.createSourceFile(fileName, content, languageVersion, true);
        }
        return undefined;
      },
      writeFile: () => {},
      getCurrentDirectory: () => '/',
      getDirectories: () => [],
      fileExists: (fileName: string) => fileContents.has(fileName),
      readFile: (fileName: string) => fileContents.get(fileName),
      getCanonicalFileName: (fileName: string) => fileName,
      useCaseSensitiveFileNames: () => true,
      getNewLine: () => '\n',
      getDefaultLibFileName: () => 'lib.d.ts'
    };

    this.program = ts.createProgram(fileNames, options, host);
    this.checker = this.program.getTypeChecker();
  }

  async extractAPIs(files: Map<string, string>): Promise<APIEndpoint[]> {
    const apis: APIEndpoint[] = [];

    for (const [filename, content] of files.entries()) {
      if (!this.shouldParseFile(filename)) continue;

      // Express routes
      const expressRoutes = this.extractExpressRoutes(content, filename);
      apis.push(...expressRoutes);

      // Fastify routes
      const fastifyRoutes = this.extractFastifyRoutes(content, filename);
      apis.push(...fastifyRoutes);

      // Next.js API routes (based on file path)
      if (filename.includes('/api/') || filename.includes('\\api\\')) {
        const nextRoutes = this.extractNextJSRoutes(content, filename);
        apis.push(...nextRoutes);
      }

      // NestJS decorators
      const nestRoutes = this.extractNestJSRoutes(content, filename);
      apis.push(...nestRoutes);
    }

    return this.deduplicate(apis, api => `${api.method}:${api.path}`);
  }

  private extractExpressRoutes(content: string, _filename: string): APIEndpoint[] {
    const apis: APIEndpoint[] = [];
    
    // Express route patterns: app.get(), router.post(), etc.
    const routePattern = /(?:app|router|route)\.(get|post|put|delete|patch|head|options|all)\s*\(\s*['"`]([^'"`]+)['"`]/gi;
    
    let match;
    while ((match = routePattern.exec(content)) !== null) {
      const [, method, path] = match;
      
      // Try to find the handler function
      const afterRoute = content.substring(match.index);
      const handlerMatch = afterRoute.match(/,\s*(?:async\s+)?(?:function\s*)?(\w*)\s*\([^)]*\)\s*(?:=>)?\s*{/);
      const handlerName = handlerMatch?.[1] || 'anonymous';
      
      apis.push({
        method: method?.toUpperCase() || 'GET',
        path: path || '/',
        description: `Express ${method} route${handlerName ? `: ${handlerName}` : ''}`,
        parameters: this.extractExpressParams(path || '/', afterRoute),
        responses: {},
        authentication: this.detectAuthentication(afterRoute) ? 'required' : 'optional'
      });
    }

    // Express use() middleware that might be routes
    const usePattern = /(?:app|router)\.use\s*\(\s*['"`]([^'"`]+)['"`]/gi;
    while ((match = usePattern.exec(content)) !== null) {
      const [, path] = match;
      if (path && path !== '/' && !path.startsWith('*')) {
        apis.push({
          method: 'USE',
          path,
          description: 'Express middleware/sub-router',
          parameters: [],
          responses: {},
          authentication: 'optional'
        });
      }
    }

    return apis;
  }

  private extractFastifyRoutes(content: string, _filename: string): APIEndpoint[] {
    const apis: APIEndpoint[] = [];
    
    // Fastify route patterns
    const routePattern = /fastify\.(get|post|put|delete|patch|head|options)\s*\(\s*['"`]([^'"`]+)['"`]/gi;
    
    let match;
    while ((match = routePattern.exec(content)) !== null) {
      const [, method, path] = match;
      
      apis.push({
        method: method?.toUpperCase() || 'GET',
        path: path || '',
        description: `Fastify ${method || 'GET'} route`,
        parameters: this.extractRouteParams(path || ''),
        responses: {},
        authentication: 'optional'
      });
    }

    return apis;
  }

  private extractNextJSRoutes(content: string, _filename: string): APIEndpoint[] {
    const apis: APIEndpoint[] = [];
    
    // Extract path from filename
    const apiPath = this.filePathToRoute(_filename);
    
    // Look for exported handler functions
    const methods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'];
    
    for (const method of methods) {
      // Check for named exports: export async function GET
      const namedExportPattern = new RegExp(`export\\s+(?:async\\s+)?function\\s+${method}\\s*\\(`, 'i');
      // Check for const exports: export const GET = 
      const constExportPattern = new RegExp(`export\\s+const\\s+${method}\\s*=`, 'i');
      
      if (namedExportPattern.test(content) || constExportPattern.test(content)) {
        apis.push({
          method,
          path: apiPath,
          description: `Next.js API route: ${method}`,
          parameters: [],
          responses: {},
          authentication: (content.includes('getServerSession') || content.includes('getSession')) ? 'required' : 'optional'
        });
      }
    }

    // For pages/api style (Next.js 12 and below)
    if (content.includes('export default') && (_filename.includes('pages/api') || _filename.includes('pages\\api'))) {
      apis.push({
        method: 'ALL',
        path: apiPath,
        description: 'Next.js API route (legacy)',
        parameters: [],
        responses: {},
        authentication: content.includes('getSession') ? 'required' : 'optional'
      });
    }

    return apis;
  }

  private extractNestJSRoutes(content: string, _filename: string): APIEndpoint[] {
    const apis: APIEndpoint[] = [];
    
    // Controller decorator
    const controllerMatch = content.match(/@Controller\s*\(\s*['"`]?([^'"`\)]*)/);
    const basePath = controllerMatch?.[1] || '';
    
    // Method decorators
    const methodPattern = /@(Get|Post|Put|Delete|Patch|Head|Options|All)\s*\(\s*['"`]?([^'"`\)]*)/gi;
    
    let match;
    while ((match = methodPattern.exec(content)) !== null) {
      const [, method, subPath] = match;
      const fullPath = this.joinPaths(basePath, subPath || '');
      
      // Find the method name
      const afterDecorator = content.substring(match.index);
      const methodMatch = afterDecorator.match(/\s+(?:async\s+)?(\w+)\s*\(/);
      const methodName = methodMatch?.[1] || 'unknown';
      
      apis.push({
        method: method?.toUpperCase() || 'GET',
        path: fullPath,
        description: `NestJS ${method}: ${methodName}`,
        parameters: this.extractNestParams(afterDecorator),
        responses: {},
        authentication: (content.includes('@UseGuards') || content.includes('AuthGuard')) ? 'required' : 'optional'
      });
    }

    return apis;
  }

  private extractExpressParams(path: string, content: string): Parameter[] {
    const params: Parameter[] = [];
    
    // URL parameters like :id
    const urlParamPattern = /:(\w+)/g;
    let match;
    while ((match = urlParamPattern.exec(path)) !== null) {
      params.push({
        name: match[1] || 'param',
        type: 'string',
        required: true,
        description: `URL parameter: ${match[1] || 'param'}`
      });
    }

    // Check for body parsing
    if (content.includes('req.body') || content.includes('request.body')) {
      params.push({
        name: 'body',
        type: 'object',
        required: true,
        description: 'Request body'
      });
    }

    // Check for query parameters
    if (content.includes('req.query') || content.includes('request.query')) {
      params.push({
        name: 'query',
        type: 'object',
        required: false,
        description: 'Query parameters'
      });
    }

    return params;
  }

  private extractRouteParams(path: string): Parameter[] {
    const params: Parameter[] = [];
    
    // URL parameters like :id or {id}
    const patterns = [/:(\w+)/g, /{(\w+)}/g];
    
    for (const pattern of patterns) {
      let match;
      while ((match = pattern.exec(path)) !== null) {
        params.push({
          name: match[1] || 'param',
          type: 'string',
          required: true,
          description: `URL parameter: ${match[1] || 'param'}`
        });
      }
    }

    return params;
  }

  private extractNestParams(content: string): Parameter[] {
    const params: Parameter[] = [];
    
    // @Param decorator
    const paramPattern = /@Param\s*\(\s*['"`](\w+)['"`]\)/g;
    let match;
    while ((match = paramPattern.exec(content)) !== null) {
      params.push({
        name: match[1] || 'param',
        type: 'string',
        required: true,
        description: `Path parameter: ${match[1] || 'param'}`
      });
    }

    // @Body decorator
    if (/@Body\s*\(/.test(content)) {
      params.push({
        name: 'body',
        type: 'object',
        required: true,
        description: 'Request body'
      });
    }

    // @Query decorator
    if (/@Query\s*\(/.test(content)) {
      params.push({
        name: 'query',
        type: 'object',
        required: false,
        description: 'Query parameters'
      });
    }

    return params;
  }

  private detectAuthentication(content: string): boolean {
    const authPatterns = [
      'authenticate',
      'isAuthenticated',
      'requireAuth',
      'verifyToken',
      'passport',
      'jwt',
      'session',
      'auth'
    ];

    return authPatterns.some(pattern => 
      content.toLowerCase().includes(pattern)
    );
  }

  private filePathToRoute(filename: string): string {
    // Convert file path to route path
    let route = filename
      .replace(/\\/g, '/') // Windows path separators
      .replace(/.*\/(pages|app)\/api/, '') // Remove prefix
      .replace(/\.(ts|tsx|js|jsx)$/, '') // Remove extension
      .replace(/\/index$/, '') // Remove index
      .replace(/\[([^\]]+)\]/g, ':$1'); // Convert [param] to :param

    // Ensure route starts with /
    if (!route.startsWith('/')) {
      route = '/' + route;
    }

    return route || '/';
  }

  private joinPaths(base: string, sub: string): string {
    if (!base) return sub || '/';
    if (!sub) return base;
    
    const cleanBase = base.endsWith('/') ? base.slice(0, -1) : base;
    const cleanSub = sub.startsWith('/') ? sub.slice(1) : sub;
    
    return `${cleanBase}/${cleanSub}`;
  }

  async extractFunctions(_files: Map<string, string>): Promise<FunctionSignature[]> {
    const functions: FunctionSignature[] = [];

    if (!this.program || !this.checker) {
      return functions;
    }

    for (const sourceFile of this.program.getSourceFiles()) {
      if (!this.shouldParseFile(sourceFile.fileName)) continue;

      ts.forEachChild(sourceFile, (node) => {
        this.visitNode(node, functions, sourceFile);
      });
    }

    return functions;
  }

  private visitNode(
    node: ts.Node,
    functions: FunctionSignature[],
    sourceFile: ts.SourceFile
  ): void {
    // Function declarations
    if (ts.isFunctionDeclaration(node) && node.name) {
      const func = this.extractFunctionSignature(node, sourceFile);
      if (func && (!this.isPrivate(func.name) || this.options.includePrivate)) {
        functions.push(func);
      }
    }

    // Method declarations in classes
    if (ts.isClassDeclaration(node)) {
      const className = node.name?.getText() || 'AnonymousClass';
      
      node.members.forEach(member => {
        if (ts.isMethodDeclaration(member) && member.name) {
          const methodName = member.name.getText();
          const func = this.extractMethodSignature(member, className, sourceFile);
          
          if (func && (!this.isPrivate(methodName) || this.options.includePrivate)) {
            functions.push(func);
          }
        }
      });
    }

    // Arrow functions and function expressions assigned to variables
    if (ts.isVariableStatement(node)) {
      node.declarationList.declarations.forEach(decl => {
        if (decl.initializer && 
            (ts.isArrowFunction(decl.initializer) || ts.isFunctionExpression(decl.initializer))) {
          const name = decl.name.getText();
          const func = this.extractFunctionExpression(decl, sourceFile);
          
          if (func && (!this.isPrivate(name) || this.options.includePrivate)) {
            functions.push(func);
          }
        }
      });
    }

    // Recursively visit child nodes
    ts.forEachChild(node, (child) => {
      this.visitNode(child, functions, sourceFile);
    });
  }

  private extractFunctionSignature(
    node: ts.FunctionDeclaration,
    sourceFile: ts.SourceFile
  ): FunctionSignature | null {
    if (!node.name || !this.checker) return null;

    const symbol = this.checker.getSymbolAtLocation(node.name);
    if (!symbol) return null;

    const signature = this.checker.getSignatureFromDeclaration(node);
    if (!signature) return null;

    // const type = this.checker.getTypeOfSymbolAtLocation(symbol, node); // Unused
    // const _typeString = this.checker.typeToString(type); // Unused

    return {
      name: node.name?.getText() || 'anonymous',
      description: this.extractJSDoc(node) || '',
      parameters: this.extractParameters(node),
      returnType: this.getReturnType(signature),
      complexity: 1, // Basic complexity - can be enhanced later
      linesOfCode: this.countFunctionLines(node.getText()),
      visibility: this.getVisibility(node),
      async: !!node.modifiers?.some(m => m.kind === ts.SyntaxKind.AsyncKeyword),
      line: sourceFile.getLineAndCharacterOfPosition(node.getStart()).line + 1,
      file: sourceFile.fileName
    };
  }

  private extractMethodSignature(
    node: ts.MethodDeclaration,
    className: string,
    sourceFile: ts.SourceFile
  ): FunctionSignature | null {
    if (!node.name || !this.checker) return null;

    const signature = this.checker.getSignatureFromDeclaration(node);
    if (!signature) return null;

    const methodName = node.name.getText();
    // const decorators = node.modifiers?.filter(m => 
    //   m.kind === ts.SyntaxKind.Decorator
    // ).map(d => d.getText()) || []; // Not used in FunctionSignature interface

    return {
      name: `${className}.${methodName}`,
      description: this.extractJSDoc(node) || '',
      parameters: this.extractParameters(node),
      returnType: this.getReturnType(signature),
      complexity: 1, // Basic complexity - can be enhanced later
      linesOfCode: this.countFunctionLines(node.getText()),
      visibility: this.getVisibility(node),
      async: !!node.modifiers?.some(m => m.kind === ts.SyntaxKind.AsyncKeyword),
      line: sourceFile.getLineAndCharacterOfPosition(node.getStart()).line + 1,
      file: sourceFile.fileName
    };
  }

  private extractFunctionExpression(
    node: ts.VariableDeclaration,
    sourceFile: ts.SourceFile
  ): FunctionSignature | null {
    if (!node.initializer || !this.checker) return null;

    const funcNode = node.initializer as ts.ArrowFunction | ts.FunctionExpression;
    const name = node.name.getText();

    return {
      name,
      description: this.extractJSDoc(node.parent.parent) || '',
      parameters: this.extractParameters(funcNode),
      returnType: this.inferReturnType(funcNode),
      complexity: 1, // Basic complexity - can be enhanced later
      linesOfCode: this.countFunctionLines(funcNode.getText()),
      visibility: 'public',
      async: !!funcNode.modifiers?.some(m => m.kind === ts.SyntaxKind.AsyncKeyword),
      line: sourceFile.getLineAndCharacterOfPosition(node.getStart()).line + 1,
      file: sourceFile.fileName
    };
  }

  private extractParameters(
    node: ts.FunctionLikeDeclaration
  ): Parameter[] {
    return node.parameters.map(param => {
      const name = param.name.getText();
      const type = param.type ? param.type.getText() : 'any';
      const required = !param.questionToken && !param.initializer;
      const defaultValue = param.initializer?.getText();

      return {
        name,
        type: this.normalizeType(type),
        required,
        defaultValue,
        description: ''
      };
    });
  }

  private getReturnType(signature: ts.Signature): string {
    if (!this.checker) return 'any';
    
    const returnType = signature.getReturnType();
    return this.normalizeType(this.checker.typeToString(returnType));
  }

  private inferReturnType(node: ts.ArrowFunction | ts.FunctionExpression): string {
    if (node.type) {
      return this.normalizeType(node.type.getText());
    }
    
    // Try to infer from return statements
    let returnType = 'any';
    
    const visit = (child: ts.Node) => {
      if (ts.isReturnStatement(child) && child.expression) {
        // Simple type inference
        if (ts.isStringLiteral(child.expression)) {
          returnType = 'string';
        } else if (ts.isNumericLiteral(child.expression)) {
          returnType = 'number';
        } else if (child.expression.kind === ts.SyntaxKind.TrueKeyword ||
                   child.expression.kind === ts.SyntaxKind.FalseKeyword) {
          returnType = 'boolean';
        } else if (ts.isObjectLiteralExpression(child.expression)) {
          returnType = 'object';
        } else if (ts.isArrayLiteralExpression(child.expression)) {
          returnType = 'array';
        }
      }
      ts.forEachChild(child, visit);
    };
    
    ts.forEachChild(node.body, visit);
    
    return returnType;
  }

  private getVisibility(node: ts.Node): 'public' | 'private' | 'protected' {
    const nodeWithModifiers = node as any;
    if (!nodeWithModifiers.modifiers) return 'public';
    
    if (nodeWithModifiers.modifiers.some((m: any) => m.kind === ts.SyntaxKind.PrivateKeyword)) {
      return 'private';
    }
    if (nodeWithModifiers.modifiers.some((m: any) => m.kind === ts.SyntaxKind.ProtectedKeyword)) {
      return 'protected';
    }
    
    return 'public';
  }

  private extractJSDoc(node: ts.Node): string {
    const jsDocs = ts.getJSDocCommentsAndTags(node);
    if (jsDocs.length === 0) return '';
    
    const comments: string[] = [];
    
    for (const jsDoc of jsDocs) {
      if (ts.isJSDoc(jsDoc) && jsDoc.comment) {
        if (typeof jsDoc.comment === 'string') {
          comments.push(jsDoc.comment);
        } else {
          // Handle JSDoc comment nodes
          comments.push(jsDoc.comment.map(c => 
            typeof c === 'string' ? c : c.text
          ).join(''));
        }
      }
    }
    
    return comments.join('\n').trim();
  }

  async extractDataModels(_files: Map<string, string>): Promise<DataModel[]> {
    const models: DataModel[] = [];

    if (!this.program || !this.checker) {
      return models;
    }

    for (const sourceFile of this.program.getSourceFiles()) {
      if (!this.shouldParseFile(sourceFile.fileName)) continue;

      ts.forEachChild(sourceFile, (node) => {
        this.visitNodeForModels(node, models, sourceFile);
      });
    }

    return models;
  }

  private visitNodeForModels(
    node: ts.Node,
    models: DataModel[],
    sourceFile: ts.SourceFile
  ): void {
    // Class declarations
    if (ts.isClassDeclaration(node) && node.name) {
      const model = this.extractClassModel(node, sourceFile);
      if (model && (!this.isPrivate(model.name) || this.options.includePrivate)) {
        models.push(model);
      }
    }

    // Interface declarations
    if (ts.isInterfaceDeclaration(node)) {
      const model = this.extractInterfaceModel(node, sourceFile);
      if (model && (!this.isPrivate(model.name) || this.options.includePrivate)) {
        models.push(model);
      }
    }

    // Type alias declarations
    if (ts.isTypeAliasDeclaration(node)) {
      const model = this.extractTypeAliasModel(node, sourceFile);
      if (model && (!this.isPrivate(model.name) || this.options.includePrivate)) {
        models.push(model);
      }
    }

    // Enum declarations
    if (ts.isEnumDeclaration(node)) {
      const model = this.extractEnumModel(node, sourceFile);
      if (model && (!this.isPrivate(model.name) || this.options.includePrivate)) {
        models.push(model);
      }
    }

    // Recursively visit child nodes
    ts.forEachChild(node, (child) => {
      this.visitNodeForModels(child, models, sourceFile);
    });
  }

  private extractClassModel(
    node: ts.ClassDeclaration,
    _sourceFile: ts.SourceFile
  ): DataModel | null {
    if (!node.name) return null;

    const className = node.name.getText();
    const properties = this.extractClassProperties(node);
    // const methods: string[] = []; // Not used in DataModel interface
    
    // Extract method names (not full signatures)
    // node.members.forEach(member => {
    //   if (ts.isMethodDeclaration(member) && member.name) {
    //     methods.push(member.name.getText());
    //   }
    // });

    // Extract decorators
    // const decorators = node.modifiers?.filter(m => 
    //   m.kind === ts.SyntaxKind.Decorator
    // ).map(d => d.getText()) || []; // Not used in DataModel interface

    // Extract heritage
    const extends_: string[] = [];
    if (node.heritageClauses) {
      node.heritageClauses.forEach(clause => {
        if (clause.token === ts.SyntaxKind.ExtendsKeyword) {
          clause.types.forEach(type => {
            extends_.push(type.expression.getText());
          });
        }
      });
    }

    return {
      name: className,
      type: 'class',
      fields: properties?.map(p => ({ name: p.name || 'unknown', type: p.type || 'any', required: p.required || false, description: p.description })) || [],
      relationships: []
    };
  }

  private extractInterfaceModel(
    node: ts.InterfaceDeclaration,
    _sourceFile: ts.SourceFile
  ): DataModel {
    const properties = node.members.map(member => {
      if (ts.isPropertySignature(member) && member.name) {
        return {
          name: member.name.getText(),
          type: member.type ? this.normalizeType(member.type.getText()) : 'any',
          required: !member.questionToken,
          description: this.extractJSDoc(member) || ''
        };
      }
      return null;
    }).filter((p): p is any => p !== null);

    // Extract heritage
    const extends_: string[] = [];
    if (node.heritageClauses) {
      node.heritageClauses.forEach(clause => {
        clause.types.forEach(type => {
          extends_.push(type.expression.getText());
        });
      });
    }

    return {
      name: node.name.getText(),
      type: 'interface',
      fields: properties?.map(p => ({ name: p.name || 'unknown', type: p.type || 'any', required: p.required || false, description: p.description })) || [],
      relationships: []
    };
  }

  private extractTypeAliasModel(
    node: ts.TypeAliasDeclaration,
    _sourceFile: ts.SourceFile
  ): DataModel | null {
    const name = node.name.getText();
    
    // Only extract object-like type aliases
    if (ts.isTypeLiteralNode(node.type)) {
      const properties = node.type.members.map(member => {
        if (ts.isPropertySignature(member) && member.name) {
          return {
            name: member.name.getText(),
            type: member.type ? this.normalizeType(member.type.getText()) : 'any',
            required: !member.questionToken,
            description: ''
          };
        }
        return null;
      }).filter((p): p is any => p !== null);

      return {
        name,
        type: 'interface',
        fields: properties?.map(p => ({ name: p.name || 'unknown', type: p.type || 'any', required: p.required || false, description: p.description })) || [],
        relationships: []
      };
    }

    return null;
  }

  private extractEnumModel(
    node: ts.EnumDeclaration,
    _sourceFile: ts.SourceFile
  ): DataModel {
    const members = node.members.map(member => ({
      name: member.name?.getText() || '',
      type: 'enum-value',
      required: true,
      description: this.extractJSDoc(member) || '',
      defaultValue: member.initializer?.getText()
    }));

    return {
      name: node.name.getText(),
      type: 'enum',
      fields: members?.map(m => ({ name: m.name || 'unknown', type: m.type || 'enum-value', required: m.required || false, description: m.description })) || [],
      relationships: []
    };
  }

  private extractClassProperties(node: ts.ClassDeclaration): any[] {
    const properties: any[] = [];

    node.members.forEach(member => {
      if (ts.isPropertyDeclaration(member) && member.name) {
        const name = member.name.getText();
        const type = member.type ? member.type.getText() : 'any';
        const required = !member.questionToken && !member.initializer;
        const defaultValue = member.initializer?.getText();
        const visibility = this.getVisibility(member);

        properties.push({
          name,
          type: this.normalizeType(type),
          required,
          defaultValue,
          description: this.extractJSDoc(member) || '',
          visibility
        });
      }
    });

    return properties;
  }

  async extractDependencies(_files: Map<string, string>): Promise<Dependency[]> {
    const dependencies: Dependency[] = [];

    // Check package.json (handle subdirectories)
    let packageJson: string | undefined;
    let packagePath: string | undefined;
    
    for (const [path, content] of _files.entries()) {
      if (path.endsWith('package.json')) {
        packageJson = content;
        packagePath = path;
        break;
      }
    }
    
    if (packageJson) {
      try {
        const pkg = JSON.parse(packageJson);
        
        // Runtime dependencies
        if (pkg.dependencies) {
          for (const [name, version] of Object.entries(pkg.dependencies)) {
            dependencies.push({
              name,
              version: version as string,
              type: 'runtime',
              source: packagePath || 'package.json'
            });
          }
        }

        // Dev dependencies
        if (pkg.devDependencies) {
          for (const [name, version] of Object.entries(pkg.devDependencies)) {
            dependencies.push({
              name,
              version: version as string,
              type: 'dev',
              source: packagePath || 'package.json'
            });
          }
        }

        // Peer dependencies
        if (pkg.peerDependencies) {
          for (const [name, version] of Object.entries(pkg.peerDependencies)) {
            dependencies.push({
              name,
              version: version as string,
              type: 'peer',
              source: packagePath || 'package.json'
            });
          }
        }

        // Optional dependencies
        if (pkg.optionalDependencies) {
          for (const [name, version] of Object.entries(pkg.optionalDependencies)) {
            dependencies.push({
              name,
              version: version as string,
              type: 'optional',
              source: packagePath || 'package.json'
            });
          }
        }
      } catch (error) {
        logger.warn('Failed to parse package.json for dependencies');
      }
    }

    return dependencies;
  }

  async extractImports(_files: Map<string, string>): Promise<ImportStatement[]> {
    const imports: ImportStatement[] = [];

    if (!this.program) {
      return imports;
    }

    for (const sourceFile of this.program.getSourceFiles()) {
      if (!this.shouldParseFile(sourceFile.fileName)) continue;

      ts.forEachChild(sourceFile, (node) => {
        if (ts.isImportDeclaration(node)) {
          const importStmt = this.extractImportStatement(node, sourceFile);
          if (importStmt) {
            imports.push(importStmt);
          }
        }
      });
    }

    return imports;
  }

  private extractImportStatement(
    node: ts.ImportDeclaration,
    sourceFile: ts.SourceFile
  ): ImportStatement | null {
    const moduleSpecifier = node.moduleSpecifier;
    if (!ts.isStringLiteral(moduleSpecifier)) return null;

    const source = moduleSpecifier.text;
    const importedItems: string[] = [];
    let isWildcard = false;
    let alias: string | undefined;

    if (node.importClause) {
      // Default import
      if (node.importClause.name) {
        importedItems.push('default');
        alias = node.importClause.name.getText();
      }

      // Named imports
      if (node.importClause.namedBindings) {
        if (ts.isNamespaceImport(node.importClause.namedBindings)) {
          // import * as name
          isWildcard = true;
          alias = node.importClause.namedBindings.name.getText();
        } else if (ts.isNamedImports(node.importClause.namedBindings)) {
          // import { a, b, c }
          node.importClause.namedBindings.elements.forEach(element => {
            importedItems.push(element.name.getText());
          });
        }
      }
    }

    return {
      source,
      imports: importedItems,
      isRelative: source.startsWith('.') || source.startsWith('..'),
      isWildcard,
      alias,
      line: sourceFile.getLineAndCharacterOfPosition(node.getStart()).line + 1,
      file: sourceFile.fileName
    };
  }

  async extractComments(_files: Map<string, string>): Promise<Comment[]> {
    const comments: Comment[] = [];

    if (!this.program) {
      return comments;
    }

    for (const sourceFile of this.program.getSourceFiles()) {
      if (!this.shouldParseFile(sourceFile.fileName)) continue;

      // Get all comments from the source file
      const sourceText = sourceFile.getFullText();
      const commentRanges = ts.getLeadingCommentRanges(sourceText, 0) || [];
      
      for (const range of commentRanges) {
        const commentText = sourceText.substring(range.pos, range.end);
        const line = sourceFile.getLineAndCharacterOfPosition(range.pos).line + 1;
        
        if (range.kind === ts.SyntaxKind.SingleLineCommentTrivia) {
          // Single-line comment
          const content = commentText.replace(/^\/\/\s*/, '').trim();
          comments.push({
            type: 'single',
            content,
            line,
            file: sourceFile.fileName
          });
        } else if (range.kind === ts.SyntaxKind.MultiLineCommentTrivia) {
          // Multi-line comment
          const content = commentText
            .replace(/^\/\*\*?/, '')
            .replace(/\*\/$/, '')
            .replace(/^\s*\* ?/gm, '')
            .trim();
          
          const isJSDoc = commentText.startsWith('/**');
          comments.push({
            type: isJSDoc ? 'doc' : 'multi',
            content,
            line,
            file: sourceFile.fileName
          });
        }
      }

      // Also extract inline comments
      ts.forEachChild(sourceFile, function visit(node) {
        // const nodeStart = node.getFullStart(); // Unused
        const nodeEnd = node.getEnd();
        
        // Check for trailing comments
        const trailingComments = ts.getTrailingCommentRanges(sourceText, nodeEnd) || [];
        for (const range of trailingComments) {
          const commentText = sourceText.substring(range.pos, range.end);
          const line = sourceFile.getLineAndCharacterOfPosition(range.pos).line + 1;
          
          if (range.kind === ts.SyntaxKind.SingleLineCommentTrivia) {
            const content = commentText.replace(/^\/\/\s*/, '').trim();
            comments.push({
              type: 'single',
              content,
              line,
              file: sourceFile.fileName
            });
          }
        }
        
        ts.forEachChild(node, visit);
      });
    }

    return comments;
  }

  private countFunctionLines(functionBody: string): number {
    if (!functionBody) return 1;
    return functionBody.split('\n').length;
  }

  private normalizeType(type: string): string {
    // Normalize TypeScript types to more generic types
    const typeMap: Record<string, string> = {
      'String': 'string',
      'Number': 'number',
      'Boolean': 'boolean',
      'Object': 'object',
      'Array': 'array',
      'Function': 'function',
      'Date': 'date',
      'RegExp': 'regex',
      'Promise': 'promise',
      'void': 'void',
      'undefined': 'undefined',
      'null': 'null',
      'any': 'any',
      'unknown': 'unknown',
      'never': 'never'
    };

    // Handle generic types
    const genericMatch = type.match(/^(\w+)<(.+)>$/);
    if (genericMatch) {
      const [, container, inner] = genericMatch;
      const normalizedContainer = typeMap[container || ''] || container?.toLowerCase() || 'unknown';
      return `${normalizedContainer}<${this.normalizeType(inner || 'any')}>`;
    }

    // Handle union types
    if (type.includes('|')) {
      return type.split('|').map(t => this.normalizeType(t.trim())).join(' | ');
    }

    // Handle array notation
    if (type.endsWith('[]')) {
      const innerType = type.slice(0, -2);
      return `array<${this.normalizeType(innerType)}>`;
    }

    return typeMap[type] || type;
  }
}