import { Request, Response, NextFunction } from 'express';
import { GatewayService } from '../gateway/gateway.service';
import { logger } from '../utils/logger';

/**
 * Optional Gateway Middleware Integration
 * 
 * This middleware integrates the existing gateway service into the Express chain.
 * It's completely optional and controlled by environment variables.
 */

interface GatewayConfig {
  enabled: boolean;
  projectContextRequired: boolean;
  rateLimitingEnabled: boolean;
  cachingEnabled: boolean;
}

export class GatewayMiddleware {
  private config: GatewayConfig;
  private gatewayService: GatewayService | null = null;

  constructor() {
    this.config = {
      enabled: process.env.ENABLE_GATEWAY_SERVICE === 'true',
      projectContextRequired: process.env.GATEWAY_REQUIRE_PROJECT_CONTEXT === 'true',
      rateLimitingEnabled: process.env.GATEWAY_RATE_LIMITING !== 'false',
      cachingEnabled: process.env.GATEWAY_CACHING !== 'false'
    };

    if (this.config.enabled) {
      try {
        this.gatewayService = GatewayService.getInstance();
        logger.info('Gateway middleware enabled', { config: this.config });
      } catch (error) {
        logger.error('Failed to initialize gateway service', { error });
        this.config.enabled = false;
      }
    } else {
      logger.info('Gateway middleware disabled via ENABLE_GATEWAY_SERVICE environment variable');
    }
  }

  /**
   * Project context extraction middleware
   * Attempts to extract project context from various sources
   */
  extractProjectContext() {
    return async (req: Request, res: Response, next: NextFunction) => {
      if (!this.config.enabled || !this.gatewayService) {
        return next();
      }

      try {
        // Extract project ID from various sources
        const projectId = this.extractProjectId(req);
        
        if (projectId) {
          // Load and validate project
          const project = await this.gatewayService.getProject(projectId);
          
          if (project) {
            // Add project to request object
            (req as any).project = project;
            (req as any).projectId = projectId;
            
            logger.debug('Project context extracted', { 
              projectId, 
              projectName: project.name 
            });
          } else if (this.config.projectContextRequired) {
            return res.status(404).json({
              success: false,
              error: {
                message: 'Project not found',
                code: 'PROJECT_NOT_FOUND'
              }
            });
          }
        } else if (this.config.projectContextRequired) {
          return res.status(400).json({
            success: false,
            error: {
              message: 'Project ID required',
              code: 'PROJECT_ID_REQUIRED'
            }
          });
        }

        next();
      } catch (error) {
        logger.error('Gateway project context extraction failed', { error });
        
        // Fail gracefully - don't break the request
        if (this.config.projectContextRequired) {
          return res.status(500).json({
            success: false,
            error: {
              message: 'Project context extraction failed',
              code: 'GATEWAY_ERROR'
            }
          });
        }
        
        next();
      }
    };
  }

  /**
   * Project-based rate limiting middleware
   */
  projectRateLimit() {
    return async (req: Request, res: Response, next: NextFunction) => {
      if (!this.config.enabled || !this.config.rateLimitingEnabled || !this.gatewayService) {
        return next();
      }

      try {
        const project = (req as any).project;
        const rateLimitKey = this.generateRateLimitKey(req, project);
        
        const rateLimitResult = await this.gatewayService.checkRateLimit(
          rateLimitKey,
          project?.plan || 'free'
        );

        if (rateLimitResult.blocked) {
          // Add rate limit headers
          res.setHeader('X-RateLimit-Limit', rateLimitResult.limit);
          res.setHeader('X-RateLimit-Remaining', rateLimitResult.remaining);
          res.setHeader('X-RateLimit-Reset', rateLimitResult.resetTime);

          return res.status(429).json({
            success: false,
            error: {
              message: 'Rate limit exceeded',
              code: 'RATE_LIMIT_EXCEEDED',
              retryAfter: rateLimitResult.resetTime
            }
          });
        }

        // Add rate limit info to headers
        res.setHeader('X-RateLimit-Limit', rateLimitResult.limit);
        res.setHeader('X-RateLimit-Remaining', rateLimitResult.remaining);

        next();
      } catch (error) {
        logger.error('Gateway rate limiting failed', { error });
        // Don't block the request on rate limiting errors
        next();
      }
    };
  }

  /**
   * Project member authentication middleware
   */
  requireProjectMember(permission?: string) {
    return async (req: Request, res: Response, next: NextFunction) => {
      if (!this.config.enabled || !this.gatewayService) {
        return next();
      }

      try {
        const project = (req as any).project;
        const user = (req as any).user;

        if (!project || !user) {
          return res.status(401).json({
            success: false,
            error: {
              message: 'Project and user context required',
              code: 'CONTEXT_REQUIRED'
            }
          });
        }

        // Check project membership
        const member = await this.gatewayService.getProjectMember(project.id, user.id);
        
        if (!member) {
          return res.status(403).json({
            success: false,
            error: {
              message: 'Not a member of this project',
              code: 'NOT_PROJECT_MEMBER'
            }
          });
        }

        // Check specific permission if required
        if (permission && !member.hasPermission(permission)) {
          return res.status(403).json({
            success: false,
            error: {
              message: `Permission required: ${permission}`,
              code: 'INSUFFICIENT_PERMISSIONS'
            }
          });
        }

        // Add member to request
        (req as any).projectMember = member;

        next();
      } catch (error) {
        logger.error('Gateway project member check failed', { error });
        next(); // Fail gracefully
      }
    };
  }

  /**
   * Extract project ID from request
   */
  private extractProjectId(req: Request): string | null {
    // Try multiple sources in order of preference
    
    // 1. URL path parameter
    if (req.params.projectId) {
      return req.params.projectId;
    }

    // 2. Query parameter
    if (req.query.projectId) {
      return req.query.projectId as string;
    }

    // 3. Custom header
    const headerProjectId = req.get('X-Project-ID');
    if (headerProjectId) {
      return headerProjectId;
    }

    // 4. JWT token claim (if available)
    const user = (req as any).user;
    if (user && user.activeProjectId) {
      return user.activeProjectId;
    }

    // 5. Subdomain (e.g., project-slug.app.com)
    const host = req.get('Host');
    if (host && host.includes('.')) {
      const subdomain = host.split('.')[0];
      if (subdomain && subdomain !== 'www' && subdomain !== 'api') {
        return subdomain;
      }
    }

    return null;
  }

  /**
   * Generate rate limit key
   */
  private generateRateLimitKey(req: Request, project: any): string {
    const parts = [
      project?.id || 'no-project',
      req.ip,
      req.path
    ];
    
    return parts.join(':');
  }

  /**
   * Get gateway status
   */
  getStatus() {
    return {
      enabled: this.config.enabled,
      config: this.config,
      serviceAvailable: !!this.gatewayService
    };
  }
}

// Create singleton instance
const gatewayMiddleware = new GatewayMiddleware();

// Export middleware functions
export const extractProjectContext = gatewayMiddleware.extractProjectContext();
export const projectRateLimit = gatewayMiddleware.projectRateLimit();
export const requireProjectMember = (permission?: string) => gatewayMiddleware.requireProjectMember(permission);
export const getGatewayStatus = () => gatewayMiddleware.getStatus();

// Export class for testing
export { GatewayMiddleware };