/**
 * Delay Plugin
 * Adds delays/waits in workflows
 */

import { BasePlugin } from '../base-plugin';
import { PluginMetadata, PluginField, PluginExecutionResult } from '../interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../../interfaces/workflow.interface';

export default class DelayPlugin extends BasePlugin {
  metadata: PluginMetadata = {
    id: 'delay',
    name: 'Delay',
    version: '1.0.0',
    description: 'Wait for a specified duration',
    author: 'FinishThisIdea',
    icon: '⏱️',
    category: 'utility',
    tags: ['delay', 'wait', 'pause', 'sleep']
  };
  
  fields: PluginField[] = [
    {
      name: 'duration',
      label: 'Duration (seconds)',
      type: 'number',
      required: true,
      default: 5,
      placeholder: '10',
      description: 'How long to wait in seconds',
      validation: {
        min: 0.1,
        max: 3600
      }
    },
    {
      name: 'jitter',
      label: 'Jitter (seconds)',
      type: 'number',
      required: false,
      default: 0,
      placeholder: '2',
      description: 'Random jitter to add (0 to this value)',
      validation: {
        min: 0,
        max: 60
      }
    },
    {
      name: 'message',
      label: 'Wait Message',
      type: 'text',
      required: false,
      placeholder: 'Waiting for external process...',
      description: 'Optional message to log during wait'
    }
  ];
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    const { duration, jitter = 0, message } = step;
    
    if (!duration || duration <= 0) {
      return this.failure('Invalid duration specified');
    }
    
    try {
      // Calculate actual delay with jitter
      let actualDelay = duration;
      if (jitter > 0) {
        actualDelay = duration + (Math.random() * jitter);
      }
      
      this.logger.info(`Delaying for ${actualDelay.toFixed(2)} seconds${message ? `: ${message}` : ''}`);
      
      const startTime = Date.now();
      
      // Use setTimeout wrapped in Promise
      await new Promise<void>((resolve) => {
        setTimeout(resolve, actualDelay * 1000);
      });
      
      const actualDuration = Date.now() - startTime;
      
      return this.success(
        { 
          requestedDelay: duration,
          actualDelay: actualDelay,
          actualDuration: actualDuration / 1000
        }, 
        actualDuration,
        [
          `Delayed for ${(actualDuration / 1000).toFixed(2)} seconds`,
          jitter > 0 ? `Applied jitter of up to ${jitter} seconds` : null,
          message || null
        ].filter(Boolean)
      );
      
    } catch (error) {
      this.logger.error('Delay failed:', error);
      return this.failure(`Delay failed: ${error.message}`);
    }
  }
  
  async testConnection(): Promise<{ success: boolean; message?: string }> {
    // Delay plugin doesn't need connection testing
    return {
      success: true,
      message: 'Delay plugin is ready'
    };
  }
}