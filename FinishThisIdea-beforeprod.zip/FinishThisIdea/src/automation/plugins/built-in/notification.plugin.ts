/**
 * Notification Plugin
 * Generic notification system for multiple channels
 */

import { BasePlugin } from '../base-plugin';
import { PluginMetadata, PluginField, PluginExecutionResult } from '../interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../../interfaces/workflow.interface';
import { container } from '../../../inversify.config';
import { NotificationService } from '../../../services/notification.service';
import { TYPES } from '../../../types';

export default class NotificationPlugin extends BasePlugin {
  private notificationService: NotificationService;
  
  metadata: PluginMetadata = {
    id: 'notification',
    name: 'Multi-Channel Notification',
    version: '1.0.0',
    description: 'Send notifications to multiple channels (email, in-app, push)',
    author: 'FinishThisIdea',
    icon: '🔔',
    category: 'notification',
    tags: ['notification', 'alert', 'push', 'multi-channel']
  };
  
  fields: PluginField[] = [
    {
      name: 'userId',
      label: 'User ID',
      type: 'text',
      required: false,
      placeholder: 'user123 or {{userId}}',
      description: 'Target user ID (leave empty for broadcast)'
    },
    {
      name: 'type',
      label: 'Notification Type',
      type: 'select',
      required: true,
      default: 'info',
      options: [
        { value: 'info', label: 'Information' },
        { value: 'success', label: 'Success' },
        { value: 'warning', label: 'Warning' },
        { value: 'error', label: 'Error' }
      ],
      description: 'Type of notification'
    },
    {
      name: 'title',
      label: 'Title',
      type: 'text',
      required: true,
      placeholder: 'Workflow Update',
      description: 'Notification title'
    },
    {
      name: 'message',
      label: 'Message',
      type: 'textarea',
      required: true,
      placeholder: 'Your workflow has completed successfully',
      description: 'Notification message'
    },
    {
      name: 'channels',
      label: 'Channels',
      type: 'json',
      required: false,
      default: ['in-app'],
      placeholder: '["in-app", "email", "push"]',
      description: 'Delivery channels'
    },
    {
      name: 'data',
      label: 'Additional Data',
      type: 'json',
      required: false,
      placeholder: '{"workflowId": "123", "link": "/workflows/123"}',
      description: 'Extra data to include'
    },
    {
      name: 'priority',
      label: 'Priority',
      type: 'select',
      required: false,
      default: 'normal',
      options: [
        { value: 'low', label: 'Low' },
        { value: 'normal', label: 'Normal' },
        { value: 'high', label: 'High' },
        { value: 'urgent', label: 'Urgent' }
      ],
      description: 'Notification priority'
    }
  ];
  
  constructor(config?: Record<string, any>) {
    super(config);
    this.notificationService = container.get<NotificationService>(TYPES.NotificationService);
  }
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    const { 
      userId, 
      type = 'info', 
      title, 
      message, 
      channels = ['in-app'], 
      data = {},
      priority = 'normal'
    } = step;
    
    if (!title || !message) {
      return this.failure('Missing required fields: title, message');
    }
    
    try {
      const { result, duration } = await this.measureExecution(async () => {
        const notificationData = {
          userId: userId || context.variables.userId,
          type,
          title,
          message,
          data: { ...data, workflowId: context.workflowId },
          metadata: {
            source: 'workflow',
            workflowId: context.workflowId,
            workflowName: context.workflowName,
            priority
          }
        };
        
        // Send to specified channels
        const results = await Promise.all(
          channels.map(async (channel: string) => {
            try {
              const result = await this.notificationService.send(notificationData, channel);
              return { channel, success: true, result };
            } catch (error) {
              return { channel, success: false, error: error.message };
            }
          })
        );
        
        return {
          sent: results.filter(r => r.success).length,
          failed: results.filter(r => !r.success).length,
          details: results
        };
      });
      
      this.logger.info(`Sent notifications to ${result.sent} channels in ${duration}ms`);
      
      if (result.failed > 0) {
        this.logger.warn(`Failed to send to ${result.failed} channels`);
      }
      
      return this.success(result, duration, [
        `Sent to ${result.sent} channel(s)`,
        result.failed > 0 ? `Failed: ${result.failed} channel(s)` : null,
        `Priority: ${priority}`
      ].filter(Boolean));
      
    } catch (error) {
      this.logger.error('Notification failed:', error);
      return this.failure(`Failed to send notification: ${error.message}`);
    }
  }
  
  async testConnection(): Promise<{ success: boolean; message?: string }> {
    try {
      // Test notification service is available
      const channels = await this.notificationService.getAvailableChannels();
      return {
        success: true,
        message: `Notification service ready with channels: ${channels.join(', ')}`
      };
    } catch (error) {
      return {
        success: false,
        message: `Notification service test failed: ${error.message}`
      };
    }
  }
}