import { ZipManager } from '../utils/zip-manager';
import { promises as fs } from 'fs';
import * as path from 'path';
import * as os from 'os';

describe('Self-Testing: FinishThisIdea Dogfooding', () => {
  let tempDir: string;
  let finishThisIdeaZip: string;

  beforeAll(async () => {
    // Create temporary directory
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'finishthisidea-self-test-'));
    console.log('🚀 Starting self-test in:', tempDir);
    
    // Create ZIP of our own codebase for testing
    console.log('🔄 Creating ZIP of FinishThisIdea codebase...');
    
    const projectRoot = path.resolve(__dirname, '../..');
    finishThisIdeaZip = path.join(tempDir, 'finishthisidea-self-test.zip');
    
    // Create ZIP from directory (not using ZipManager.createZipFromDirectory since it may not exist)
    await createProjectZip(projectRoot, finishThisIdeaZip);
    
    // Verify the ZIP was created and has content
    const zipInfo = await ZipManager.getZipInfo(finishThisIdeaZip);
    console.log(`✅ Created FinishThisIdea ZIP: ${zipInfo.fileCount} files, ${(zipInfo.totalSize / 1024 / 1024).toFixed(2)}MB`);
    
    // Validate that we have the expected project structure
    expect(zipInfo.files.some(f => f.name === 'package.json')).toBe(true);
    expect(zipInfo.files.some(f => f.name.includes('src/'))).toBe(true);
    expect(zipInfo.files.some(f => f.name === 'README.md')).toBe(true);
  });

  afterAll(async () => {
    // Clean up
    await fs.rm(tempDir, { recursive: true, force: true });
    console.log('✅ Self-test cleanup completed');
  });

  describe('Processing Our Own Codebase', () => {
    it('should extract and analyze FinishThisIdea project structure', async () => {
      console.log('📂 Testing FinishThisIdea project extraction...');

      // Extract our codebase with higher limits for self-testing
      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip, {
        maxFiles: 15000, // Allow more files for self-testing
        maxSizeBytes: 200 * 1024 * 1024 // 200MB limit
      });
      
      console.log(`📊 Extracted ${extractedFiles.size} files from FinishThisIdea`);
      
      // Verify we have key files
      expect(extractedFiles.has('package.json')).toBe(true);
      expect(extractedFiles.has('README.md')).toBe(true);
      
      // Parse package.json to understand the project
      const packageJsonContent = extractedFiles.get('package.json');
      expect(packageJsonContent).toBeDefined();
      
      const packageJson = JSON.parse(packageJsonContent!);
      console.log(`📦 Project: ${packageJson.name} v${packageJson.version}`);
      console.log(`📝 Description: ${packageJson.description}`);
      
      // Verify it's our project
      expect(packageJson.name).toBe('finishthisidea-mvp');
      expect(packageJson.description).toContain('AI-powered codebase cleanup service');
      
      console.log('✅ Project structure validation passed');
    });

    it('should analyze FinishThisIdea codebase quality and complexity', async () => {
      console.log('🔍 Analyzing FinishThisIdea codebase quality...');

      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip, {
        maxFiles: 15000,
        maxSizeBytes: 200 * 1024 * 1024
      });
      
      // Analyze codebase metrics
      const analysis = {
        totalFiles: extractedFiles.size,
        codeFiles: 0,
        testFiles: 0,
        configFiles: 0,
        documentationFiles: 0,
        languages: new Set<string>(),
        directories: new Set<string>(),
        totalLinesOfCode: 0,
        sourceFileTypes: {} as Record<string, number>
      };

      // Analyze each file
      for (const [fileName, content] of extractedFiles) {
        const ext = path.extname(fileName).toLowerCase();
        const dir = path.dirname(fileName);
        
        // Track directories
        if (dir !== '.') {
          analysis.directories.add(dir.split('/')[0]);
        }
        
        // Classify files by type
        if (['.ts', '.tsx', '.js', '.jsx', '.py', '.java', '.go', '.rs'].includes(ext)) {
          analysis.codeFiles++;
          analysis.totalLinesOfCode += content.split('\\n').length;
          
          // Track file types
          analysis.sourceFileTypes[ext] = (analysis.sourceFileTypes[ext] || 0) + 1;
          
          // Detect languages
          if (['.ts', '.tsx'].includes(ext)) analysis.languages.add('typescript');
          if (['.js', '.jsx'].includes(ext)) analysis.languages.add('javascript');
          if (ext === '.py') analysis.languages.add('python');
          if (ext === '.java') analysis.languages.add('java');
          if (ext === '.go') analysis.languages.add('go');
          if (ext === '.rs') analysis.languages.add('rust');
        } else if (fileName.includes('test') || fileName.includes('spec')) {
          analysis.testFiles++;
        } else if (['.json', '.yml', '.yaml', '.toml', '.ini', '.env'].includes(ext)) {
          analysis.configFiles++;
        } else if (['.md', '.txt', '.rst'].includes(ext)) {
          analysis.documentationFiles++;
        }
      }

      console.log('📈 FinishThisIdea Codebase Analysis:');
      console.log(`   Total Files: ${analysis.totalFiles}`);
      console.log(`   Code Files: ${analysis.codeFiles}`);
      console.log(`   Test Files: ${analysis.testFiles}`);
      console.log(`   Config Files: ${analysis.configFiles}`);
      console.log(`   Documentation Files: ${analysis.documentationFiles}`);
      console.log(`   Languages: ${Array.from(analysis.languages).join(', ')}`);
      console.log(`   Directories: ${Array.from(analysis.directories).join(', ')}`);
      console.log(`   Lines of Code: ${analysis.totalLinesOfCode}`);
      console.log(`   File Types:`, analysis.sourceFileTypes);

      // Quality expectations for our own codebase
      expect(analysis.totalFiles).toBeGreaterThan(20); // Should have substantial content
      expect(analysis.codeFiles).toBeGreaterThan(10); // Should have multiple source files
      expect(analysis.testFiles).toBeGreaterThan(5); // Should have comprehensive tests
      expect(analysis.languages.has('typescript')).toBe(true); // Primary language
      expect(analysis.directories.has('src')).toBe(true); // Should have src directory
      expect(analysis.directories.has('tests')).toBe(true); // Should have tests directory
      expect(analysis.totalLinesOfCode).toBeGreaterThan(1000); // Should be substantial codebase

      console.log('✅ Quality analysis passed - FinishThisIdea is production-ready!');
    });

    it('should extract key architectural components from FinishThisIdea', async () => {
      console.log('🏗️ Analyzing FinishThisIdea architecture...');

      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip, {
        maxFiles: 15000,
        maxSizeBytes: 200 * 1024 * 1024
      });
      
      const architecture = {
        apiRoutes: [] as string[],
        services: [] as string[],
        middleware: [] as string[],
        utilities: [] as string[],
        types: [] as string[],
        tests: [] as string[],
        hasDatabase: false,
        hasQueue: false,
        hasAuth: false,
        hasLogging: false,
        hasDocumentation: false
      };

      // Analyze file structure for architectural patterns
      for (const [fileName, content] of extractedFiles) {
        if (fileName.includes('api/routes/')) {
          architecture.apiRoutes.push(fileName);
        } else if (fileName.includes('services/')) {
          architecture.services.push(fileName);
        } else if (fileName.includes('middleware/')) {
          architecture.middleware.push(fileName);
        } else if (fileName.includes('utils/')) {
          architecture.utilities.push(fileName);
        } else if (fileName.includes('types/')) {
          architecture.types.push(fileName);
        } else if (fileName.includes('test')) {
          architecture.tests.push(fileName);
        }

        // Check for key architectural components
        if (content.includes('prisma') || content.includes('database')) {
          architecture.hasDatabase = true;
        }
        if (content.includes('bull') || content.includes('queue')) {
          architecture.hasQueue = true;
        }
        if (content.includes('auth') || content.includes('jwt')) {
          architecture.hasAuth = true;
        }
        if (content.includes('logger') || content.includes('winston')) {
          architecture.hasLogging = true;
        }
        if (fileName === 'README.md' || fileName.includes('docs/')) {
          architecture.hasDocumentation = true;
        }
      }

      console.log('🏛️ FinishThisIdea Architecture Analysis:');
      console.log(`   API Routes: ${architecture.apiRoutes.length}`);
      console.log(`   Services: ${architecture.services.length}`);
      console.log(`   Middleware: ${architecture.middleware.length}`);
      console.log(`   Utilities: ${architecture.utilities.length}`);
      console.log(`   Types: ${architecture.types.length}`);
      console.log(`   Tests: ${architecture.tests.length}`);
      console.log(`   Database: ${architecture.hasDatabase ? '✅' : '❌'}`);
      console.log(`   Queue System: ${architecture.hasQueue ? '✅' : '❌'}`);
      console.log(`   Authentication: ${architecture.hasAuth ? '✅' : '❌'}`);
      console.log(`   Logging: ${architecture.hasLogging ? '✅' : '❌'}`);
      console.log(`   Documentation: ${architecture.hasDocumentation ? '✅' : '❌'}`);

      // Architectural quality expectations
      expect(architecture.apiRoutes.length).toBeGreaterThan(2); // Should have multiple API routes
      expect(architecture.services.length).toBeGreaterThan(2); // Should have service layer
      expect(architecture.hasDatabase).toBe(true); // Should have database integration
      expect(architecture.hasAuth).toBe(true); // Should have authentication
      expect(architecture.hasLogging).toBe(true); // Should have logging
      expect(architecture.hasDocumentation).toBe(true); // Should be documented

      console.log('✅ Architecture analysis passed - Well-structured codebase!');
    });

    it('should validate FinishThisIdea can process its own requirements', async () => {
      console.log('🎯 Testing requirements extraction from FinishThisIdea...');

      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip, {
        maxFiles: 15000,
        maxSizeBytes: 200 * 1024 * 1024
      });
      
      // Get README content to extract requirements
      const readmeContent = extractedFiles.get('README.md');
      expect(readmeContent).toBeDefined();
      
      const packageJsonContent = extractedFiles.get('package.json');
      const packageJson = JSON.parse(packageJsonContent!);
      
      // Extract requirements from project documentation
      const extractedRequirements = {
        projectName: packageJson.name,
        description: packageJson.description,
        keywords: packageJson.keywords || [],
        dependencies: Object.keys(packageJson.dependencies || {}),
        devDependencies: Object.keys(packageJson.devDependencies || {}),
        scripts: Object.keys(packageJson.scripts || {}),
        features: [] as string[],
        techStack: [] as string[]
      };

      // Identify tech stack from dependencies
      const depAnalysis = extractedRequirements.dependencies;
      if (depAnalysis.includes('express')) extractedRequirements.techStack.push('Express.js');
      if (depAnalysis.includes('@prisma/client')) extractedRequirements.techStack.push('Prisma ORM');
      if (depAnalysis.includes('jsonwebtoken')) extractedRequirements.techStack.push('JWT Authentication');
      if (depAnalysis.includes('bull')) extractedRequirements.techStack.push('Bull Queue');
      if (depAnalysis.includes('winston')) extractedRequirements.techStack.push('Winston Logging');
      if (depAnalysis.includes('stripe')) extractedRequirements.techStack.push('Stripe Payments');

      // Extract features from README content
      if (readmeContent!.toLowerCase().includes('upload')) extractedRequirements.features.push('File Upload');
      if (readmeContent!.toLowerCase().includes('documentation')) extractedRequirements.features.push('Documentation Generation');
      if (readmeContent!.toLowerCase().includes('ai')) extractedRequirements.features.push('AI Processing');
      if (readmeContent!.toLowerCase().includes('payment')) extractedRequirements.features.push('Payment Processing');

      console.log('📋 Extracted Requirements:');
      console.log(`   Project: ${extractedRequirements.projectName}`);
      console.log(`   Description: ${extractedRequirements.description}`);
      console.log(`   Features: ${extractedRequirements.features.join(', ')}`);
      console.log(`   Tech Stack: ${extractedRequirements.techStack.join(', ')}`);
      console.log(`   Dependencies: ${extractedRequirements.dependencies.length}`);
      console.log(`   Scripts: ${extractedRequirements.scripts.join(', ')}`);

      // Validate extracted requirements match our expectations
      expect(extractedRequirements.projectName).toBe('finishthisidea-mvp');
      expect(extractedRequirements.description).toContain('AI-powered');
      expect(extractedRequirements.features.length).toBeGreaterThan(1);
      expect(extractedRequirements.techStack.length).toBeGreaterThan(3);
      expect(extractedRequirements.dependencies.length).toBeGreaterThan(10);

      console.log('✅ Requirements extraction validated - FinishThisIdea self-awareness confirmed!');
    });
  });

  describe('Performance and Scale Validation', () => {
    it('should process FinishThisIdea codebase within performance bounds', async () => {
      console.log('⚡ Testing FinishThisIdea processing performance...');

      const startTime = Date.now();

      // Time the extraction process
      const extractionStart = Date.now();
      const extractedFiles = await ZipManager.extractZip(finishThisIdeaZip, {
        maxFiles: 15000,
        maxSizeBytes: 200 * 1024 * 1024
      });
      const extractionTime = Date.now() - extractionStart;

      // Time basic analysis
      const analysisStart = Date.now();
      let totalLines = 0;
      let codeFiles = 0;
      
      for (const [fileName, content] of extractedFiles) {
        const ext = path.extname(fileName).toLowerCase();
        if (['.ts', '.tsx', '.js', '.jsx'].includes(ext)) {
          codeFiles++;
          totalLines += content.split('\\n').length;
        }
      }
      const analysisTime = Date.now() - analysisStart;

      const totalTime = Date.now() - startTime;

      console.log('📈 Performance Results:');
      console.log(`   Extraction Time: ${extractionTime}ms`);
      console.log(`   Analysis Time: ${analysisTime}ms`);
      console.log(`   Total Time: ${totalTime}ms`);
      console.log(`   Files Processed: ${extractedFiles.size}`);
      console.log(`   Code Files: ${codeFiles}`);
      console.log(`   Total Lines: ${totalLines}`);
      console.log(`   Lines/Second: ${Math.round(totalLines / (totalTime / 1000))}`);

      // Performance expectations (generous for test environment)
      expect(extractionTime).toBeLessThan(5000); // Extraction within 5 seconds
      expect(analysisTime).toBeLessThan(2000); // Analysis within 2 seconds
      expect(totalTime).toBeLessThan(10000); // Total processing within 10 seconds

      console.log('✅ Performance validation passed - Ready for production scale!');
    });
  });
});

// Helper function to create ZIP from directory
async function createProjectZip(sourceDir: string, outputPath: string): Promise<void> {
  const archiver = require('archiver');
  const output = require('fs').createWriteStream(outputPath);
  const archive = archiver('zip', { zlib: { level: 9 } });

  return new Promise((resolve, reject) => {
    output.on('close', resolve);
    output.on('error', reject);
    archive.on('error', reject);

    archive.pipe(output);

    // Add files while excluding certain directories and large files
    archive.glob('**/*', {
      cwd: sourceDir,
      ignore: [
        'node_modules/**',
        'dist/**',
        'coverage/**',
        '.git/**',
        '.next/**',
        'build/**',
        'out/**',
        '*.log',
        'tmp/**',
        'temp/**',
        '**/*.map',
        '**/*.chunk.js',
        '**/.DS_Store',
        '**/Thumbs.db',
        'jest.config.js' // Don't self-reference test config
      ]
    });

    archive.finalize();
  });
}