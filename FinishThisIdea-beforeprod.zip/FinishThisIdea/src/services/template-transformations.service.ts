import { CodeAnalysis, APIEndpoint, DataModel, FunctionSignature, BusinessRule } from '../types/code-analysis';
import { logger } from '../utils/logger';

/**
 * Template transformation service for auto-populating documentation templates
 * from code analysis data
 */
export class TemplateTransformationService {
  
  /**
   * Transform code analysis data using the specified transformation function
   */
  async transform(
    transformName: string,
    sourceData: any,
    context: CodeAnalysis
  ): Promise<string> {
    try {
      switch (transformName) {
        // Executive Summary transformations
        case 'expandToVision':
          return this.expandToVision(sourceData);
        case 'extractPrimaryGoals':
          return this.extractPrimaryGoals(sourceData);
        case 'extractTechnicalGoals':
          return this.extractTechnicalGoals(sourceData);
        case 'generateTechStack':
          return this.generateTechStack(sourceData);
        case 'formatLanguages':
          return this.formatLanguages(sourceData);
        case 'extractKeyFeatures':
          return this.extractKeyFeatures(sourceData);
        case 'formatBusinessRules':
          return this.formatBusinessRules(sourceData);

        // API Contract transformations
        case 'generateEndpointTable':
          return this.generateEndpointTable(sourceData);
        case 'generateEndpointDetails':
          return this.generateEndpointDetails(sourceData);
        case 'generateOpenAPISpec':
          return this.generateOpenAPISpec(sourceData, context);
        case 'extractAuthDetails':
          return this.extractAuthDetails(sourceData);
        case 'generateRateLimits':
          return this.generateRateLimits(sourceData);
        case 'extractErrorCodes':
          return this.extractErrorCodes(sourceData);

        // Data Models transformations
        case 'listPrimaryEntities':
          return this.listPrimaryEntities(sourceData);
        case 'generateERDiagram':
          return this.generateERDiagram(sourceData);
        case 'summarizeRelationships':
          return this.summarizeRelationships(sourceData);
        case 'generateSchemaDetails':
          return this.generateSchemaDetails(sourceData);
        case 'generateFieldTables':
          return this.generateFieldTables(sourceData);
        case 'extractValidationRules':
          return this.extractValidationRules(sourceData);
        case 'listIndexes':
          return this.listIndexes(sourceData);
        case 'generateOptimizationNotes':
          return this.generateOptimizationNotes(sourceData);

        // Test Plan transformations
        case 'generateTestableFunction':
          return this.generateTestableFunction(sourceData);
        case 'generateBusinessLogicTests':
          return this.generateBusinessLogicTests(sourceData);
        case 'generateAPITests':
          return this.generateAPITests(sourceData);
        case 'generateDatabaseTests':
          return this.generateDatabaseTests(sourceData);
        case 'generateTestDataRequirements':
          return this.generateTestDataRequirements(sourceData);
        case 'generateMockDataExamples':
          return this.generateMockDataExamples(sourceData);

        default:
          logger.warn(`Unknown transformation: ${transformName}`);
          return String(sourceData || '');
      }
    } catch (error) {
      logger.error('Template transformation failed', { transformName, error });
      return String(sourceData || '');
    }
  }

  // Executive Summary transformations
  private expandToVision(description: string): string {
    if (!description) return 'Project vision to be defined.';
    
    return `${description}\n\nThis project aims to deliver high-quality software that meets user needs while maintaining excellent code standards and architectural principles.`;
  }

  private extractPrimaryGoals(businessLogic: BusinessRule[]): string {
    if (!businessLogic || businessLogic.length === 0) {
      return '- Deliver functional software solution\n- Meet user requirements\n- Maintain code quality';
    }

    return businessLogic
      .slice(0, 5) // Top 5 goals
      .map(rule => `- ${rule.description}`)
      .join('\n');
  }

  private extractTechnicalGoals(architecture: any): string {
    const defaultGoals = [
      'Maintain scalable architecture',
      'Ensure code maintainability',
      'Implement proper error handling',
      'Follow security best practices'
    ];

    if (!architecture || !architecture.components) {
      return defaultGoals.map(goal => `- ${goal}`).join('\n');
    }

    const technicalGoals = [
      `- Implement ${architecture.pattern} architecture pattern`,
      '- Ensure proper separation of concerns',
      '- Maintain high code quality standards',
      '- Implement comprehensive testing strategy'
    ];

    return technicalGoals.join('\n');
  }

  private generateTechStack(dependencies: any[]): string {
    if (!dependencies || dependencies.length === 0) {
      return 'Technology stack to be documented.';
    }

    const prodDeps = dependencies.filter(dep => dep.type === 'production');
    const devDeps = dependencies.filter(dep => dep.type === 'development');

    let stack = '### Production Dependencies\n';
    stack += prodDeps.slice(0, 10).map(dep => `- **${dep.name}**: ${dep.version}`).join('\n');
    
    if (devDeps.length > 0) {
      stack += '\n\n### Development Dependencies\n';
      stack += devDeps.slice(0, 5).map(dep => `- **${dep.name}**: ${dep.version}`).join('\n');
    }

    return stack;
  }

  private formatLanguages(language: string): string {
    return language ? language.charAt(0).toUpperCase() + language.slice(1) : 'Not specified';
  }

  private extractKeyFeatures(apis: APIEndpoint[]): string {
    if (!apis || apis.length === 0) {
      return '- Core application functionality\n- User interface\n- Data management';
    }

    const features = apis
      .slice(0, 8)
      .map(api => `- **${api.method} ${api.path}**: ${api.description}`)
      .join('\n');

    return features;
  }

  private formatBusinessRules(businessLogic: BusinessRule[]): string {
    if (!businessLogic || businessLogic.length === 0) {
      return 'Business rules to be documented.';
    }

    return businessLogic
      .slice(0, 6)
      .map(rule => `- ${rule.description}`)
      .join('\n');
  }

  // API Contract transformations
  private generateEndpointTable(apis: APIEndpoint[]): string {
    if (!apis || apis.length === 0) {
      return '| Method | Endpoint | Description |\n|--------|----------|-------------|\n| - | - | No endpoints found |';
    }

    let table = '| Method | Endpoint | Description |\n|--------|----------|-------------|\n';
    
    apis.forEach(api => {
      table += `| ${api.method} | ${api.path} | ${api.description} |\n`;
    });

    return table;
  }

  private generateEndpointDetails(apis: APIEndpoint[]): string {
    if (!apis || apis.length === 0) {
      return 'No API endpoints found in the codebase.';
    }

    return apis.map(api => {
      let details = `### ${api.method} ${api.path}\n\n`;
      details += `${api.description}\n\n`;
      
      if (api.parameters && api.parameters.length > 0) {
        details += '**Parameters:**\n';
        api.parameters.forEach(param => {
          details += `- \`${param.name}\` (${param.type}): ${param.description || 'Parameter description'}\n`;
        });
        details += '\n';
      }

      if (api.authentication) {
        details += `**Authentication:** ${api.authentication}\n\n`;
      }

      return details;
    }).join('\n');
  }

  private generateOpenAPISpec(apis: APIEndpoint[], context: CodeAnalysis): string {
    const spec: any = {
      openapi: '3.0.0',
      info: {
        title: context.projectInfo.name,
        version: '1.0.0',
        description: context.projectInfo.description
      },
      paths: {}
    };

    apis.forEach(api => {
      if (!spec.paths[api.path]) {
        spec.paths[api.path] = {};
      }
      
      spec.paths[api.path][api.method.toLowerCase()] = {
        summary: api.description,
        parameters: api.parameters?.map(param => ({
          name: param.name,
          in: param.type === 'query' ? 'query' : 'path',
          required: param.required,
          schema: { type: 'string' }
        })) || [],
        responses: api.responses || {
          '200': { description: 'Success' }
        }
      };
    });

    try {
      const yaml = require('js-yaml');
      return yaml.dump(spec);
    } catch (error) {
      // Fallback to JSON if YAML conversion fails
      return JSON.stringify(spec, null, 2);
    }
  }

  private extractAuthDetails(apis: APIEndpoint[]): string {
    const authMethods = [...new Set(apis.map(api => api.authentication).filter(Boolean))];
    
    if (authMethods.length === 0) {
      return 'Authentication mechanism to be implemented.';
    }

    let details = '### Authentication Methods\n\n';
    authMethods.forEach(method => {
      details += `- **${method}**: Authentication details to be documented.\n`;
    });

    return details;
  }

  private generateRateLimits(_apis: APIEndpoint[]): string {
    return `### Rate Limiting\n\n- **Default**: 100 requests per minute\n- **Authenticated**: 1000 requests per minute\n- **Admin**: No rate limiting\n\n### Headers\n\n- \`X-RateLimit-Limit\`: Number of requests allowed per window\n- \`X-RateLimit-Remaining\`: Number of requests remaining in current window`;
  }

  private extractErrorCodes(_apis: APIEndpoint[]): string {
    return `| Code | Description |\n|------|-------------|\n| 400 | Bad Request - Invalid parameters |\n| 401 | Unauthorized - Authentication required |\n| 403 | Forbidden - Insufficient permissions |\n| 404 | Not Found - Resource not found |\n| 422 | Unprocessable Entity - Validation failed |\n| 429 | Too Many Requests - Rate limit exceeded |\n| 500 | Internal Server Error - Server error |`;
  }

  // Data Model transformations
  private listPrimaryEntities(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No data models found';
    }

    return dataModels.slice(0, 5).map(model => model.name).join(', ');
  }

  private generateERDiagram(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No entity relationships found.';
    }

    let diagram = '```\n';
    dataModels.forEach(model => {
      diagram += `[${model.name}]\n`;
      model.relationships?.forEach(rel => {
        diagram += `  ${rel.type} -> [${rel.target}]\n`;
      });
      diagram += '\n';
    });
    diagram += '```';

    return diagram;
  }

  private summarizeRelationships(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No relationships found.';
    }

    const relationships = dataModels.flatMap(model => 
      model.relationships?.map(rel => `- **${model.name}** has ${rel.type} relationship with **${rel.target}**`) || []
    );

    return relationships.join('\n') || 'No relationships defined.';
  }

  private generateSchemaDetails(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No schema details available.';
    }

    return dataModels.map(model => {
      let details = `### ${model.name}\n\n`;
      details += `**Type**: ${model.type}\n\n`;
      
      if (model.fields && model.fields.length > 0) {
        details += '**Fields**:\n';
        model.fields.forEach(field => {
          details += `- \`${field.name}\` (${field.type})${field.required ? ' *required*' : ''}: ${field.description || 'Field description'}\n`;
        });
        details += '\n';
      }

      return details;
    }).join('\n');
  }

  private generateFieldTables(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No field definitions available.';
    }

    return dataModels.map(model => {
      let table = `### ${model.name}\n\n`;
      table += '| Field | Type | Required | Description |\n';
      table += '|-------|------|----------|-------------|\n';
      
      model.fields?.forEach(field => {
        table += `| ${field.name} | ${field.type} | ${field.required ? 'Yes' : 'No'} | ${field.description || '-'} |\n`;
      });
      
      return table + '\n';
    }).join('\n');
  }

  private extractValidationRules(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No validation rules found.';
    }

    const rules = dataModels.flatMap(model =>
      model.fields?.filter(field => field.constraints?.length).map(field =>
        `- **${model.name}.${field.name}**: ${field.constraints?.join(', ')}`
      ) || []
    );

    return rules.join('\n') || 'No validation rules defined.';
  }

  private listIndexes(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No indexes found.';
    }

    const indexes = dataModels.flatMap(model =>
      model.indexes?.map(index => `- **${model.name}**: ${index}`) || []
    );

    return indexes.join('\n') || 'No indexes defined.';
  }

  private generateOptimizationNotes(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No optimization recommendations available.';
    }

    return `### Query Optimization Recommendations\n\n- Consider adding indexes on frequently queried fields\n- Use appropriate data types for better performance\n- Implement database connection pooling\n- Monitor query performance and optimize slow queries\n\n### Specific Recommendations\n\n${dataModels.map(model => `- **${model.name}**: Consider indexing primary lookup fields`).join('\n')}`;
  }

  // Test Plan transformations
  private generateTestableFunction(functions: FunctionSignature[]): string {
    if (!functions || functions.length === 0) {
      return 'No functions found for testing.';
    }

    return functions.slice(0, 10).map(func => {
      let test = `### ${func.name}\n`;
      test += `- **Description**: ${func.description}\n`;
      test += `- **Complexity**: ${func.complexity}/10\n`;
      test += `- **Test Priority**: ${func.complexity > 5 ? 'High' : 'Medium'}\n`;
      if (func.testCoverage !== undefined) {
        test += `- **Current Coverage**: ${func.testCoverage}%\n`;
      }
      return test;
    }).join('\n\n');
  }

  private generateBusinessLogicTests(businessLogic: BusinessRule[]): string {
    if (!businessLogic || businessLogic.length === 0) {
      return 'No business logic tests required.';
    }

    return businessLogic.map(rule => `- Test: ${rule.description}`).join('\n');
  }

  private generateAPITests(apis: APIEndpoint[]): string {
    if (!apis || apis.length === 0) {
      return 'No API tests required.';
    }

    return apis.map(api => {
      return `#### ${api.method} ${api.path}\n- Test successful response\n- Test error handling\n- Test parameter validation${api.authentication ? '\n- Test authentication' : ''}`;
    }).join('\n\n');
  }

  private generateDatabaseTests(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No database tests required.';
    }

    return dataModels.map(model => {
      return `#### ${model.name} Model\n- Test CRUD operations\n- Test field validation\n- Test relationship integrity${model.indexes ? '\n- Test index performance' : ''}`;
    }).join('\n\n');
  }

  private generateTestDataRequirements(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No test data requirements.';
    }

    return dataModels.map(model => {
      return `### ${model.name}\n- Valid test records with all required fields\n- Invalid test records for validation testing\n- Edge case data for boundary testing`;
    }).join('\n\n');
  }

  private generateMockDataExamples(dataModels: DataModel[]): string {
    if (!dataModels || dataModels.length === 0) {
      return 'No mock data examples available.';
    }

    return dataModels.slice(0, 3).map(model => {
      let example = `### ${model.name} Example\n\n\`\`\`json\n{\n`;
      model.fields?.slice(0, 5).forEach((field, index) => {
        const isLast = index === Math.min(4, model.fields.length - 1);
        example += `  "${field.name}": "${this.generateSampleValue(field.type, field.name)}"${isLast ? '' : ','}\n`;
      });
      example += '}\n```\n';
      return example;
    }).join('\n');
  }

  private generateSampleValue(type: string, fieldName?: string): string {
    // Check field name for hints about the data type
    const lowerFieldName = fieldName?.toLowerCase() || '';
    
    if (lowerFieldName.includes('email')) {
      return 'user@example.com';
    }
    
    switch (type.toLowerCase()) {
      case 'string':
      case 'text':
        return 'Sample text';
      case 'number':
      case 'integer':
      case 'int':
        return '123';
      case 'boolean':
      case 'bool':
        return 'true';
      case 'date':
      case 'datetime':
        return '2023-12-01T00:00:00Z';
      case 'email':
        return 'user@example.com';
      default:
        return 'sample_value';
    }
  }
}

// Export singleton instance
export const templateTransformationService = new TemplateTransformationService();