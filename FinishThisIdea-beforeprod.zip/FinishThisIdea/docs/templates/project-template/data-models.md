---
title: "Data Models & Schemas"
description: "Template for defining all data models, database schemas, data structures, and data relationships"
author: "Database Team"
lastUpdated: "2024-06-28"
version: "1.0"
template: true
status: "ready"
---

# Data Models & Schemas

## Overview
This document defines all data models, database schemas, data structures, and data relationships for the project.

## Entity Relationship Overview

### Core Entities
- **Entity 1**: _[Brief description]_
- **Entity 2**: _[Brief description]_
- **Entity 3**: _[Brief description]_

### Relationships Summary
- **Entity 1** → **Entity 2**: _[Relationship type and description]_
- **Entity 2** → **Entity 3**: _[Relationship type and description]_

## Database Schema

### Entity 1: [Entity Name]
**Purpose**: _[What this entity represents]_
**Primary Use Cases**: _[How this entity is used]_

#### Table Structure
```sql
CREATE TABLE entity_name (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name              VARCHAR(255) NOT NULL,
  description       TEXT,
  status            VARCHAR(50) NOT NULL DEFAULT 'active',
  metadata          JSONB,
  created_at        TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  created_by        UUID REFERENCES users(id),
  updated_by        UUID REFERENCES users(id)
);

-- Indexes
CREATE INDEX idx_entity_name_status ON entity_name(status);
CREATE INDEX idx_entity_name_created_at ON entity_name(created_at);
CREATE INDEX idx_entity_name_created_by ON entity_name(created_by);

-- Constraints
ALTER TABLE entity_name ADD CONSTRAINT check_status 
  CHECK (status IN ('active', 'inactive', 'pending', 'archived'));
```

#### Field Definitions
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| `id` | UUID | PRIMARY KEY, NOT NULL | Unique identifier |
| `name` | VARCHAR(255) | NOT NULL | Human-readable name |
| `description` | TEXT | NULLABLE | Detailed description |
| `status` | VARCHAR(50) | NOT NULL, DEFAULT 'active' | Current status |
| `metadata` | JSONB | NULLABLE | Additional flexible data |
| `created_at` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Creation timestamp |
| `updated_at` | TIMESTAMP | NOT NULL, DEFAULT NOW() | Last update timestamp |
| `created_by` | UUID | FOREIGN KEY users(id) | User who created the record |
| `updated_by` | UUID | FOREIGN KEY users(id) | User who last updated the record |

#### Business Rules
- [ ] **Name Uniqueness**: Names must be unique within the same status
- [ ] **Status Transitions**: Only specific status transitions are allowed
- [ ] **Metadata Validation**: Metadata must conform to defined JSON schema
- [ ] **Audit Trail**: All changes must be tracked with user and timestamp

### Entity 2: [Entity Name]
**Purpose**: _[What this entity represents]_
**Primary Use Cases**: _[How this entity is used]_

#### Table Structure
```sql
CREATE TABLE entity_two (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_one_id     UUID NOT NULL REFERENCES entity_name(id) ON DELETE CASCADE,
  title             VARCHAR(500) NOT NULL,
  content           TEXT,
  priority          INTEGER NOT NULL DEFAULT 0,
  tags              TEXT[],
  settings          JSONB DEFAULT '{}',
  is_active         BOOLEAN NOT NULL DEFAULT true,
  expires_at        TIMESTAMP WITH TIME ZONE,
  created_at        TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX idx_entity_two_entity_one_id ON entity_two(entity_one_id);
CREATE INDEX idx_entity_two_priority ON entity_two(priority DESC);
CREATE INDEX idx_entity_two_is_active ON entity_two(is_active);
CREATE INDEX idx_entity_two_expires_at ON entity_two(expires_at);
CREATE INDEX idx_entity_two_tags ON entity_two USING GIN(tags);

-- Partial index for active records
CREATE INDEX idx_entity_two_active_priority ON entity_two(priority DESC) 
  WHERE is_active = true;
```

#### Field Definitions
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| `id` | UUID | PRIMARY KEY | Unique identifier |
| `entity_one_id` | UUID | FOREIGN KEY, NOT NULL | Reference to parent entity |
| `title` | VARCHAR(500) | NOT NULL | Display title |
| `content` | TEXT | NULLABLE | Main content |
| `priority` | INTEGER | NOT NULL, DEFAULT 0 | Priority ordering (higher = more important) |
| `tags` | TEXT[] | NULLABLE | Searchable tags array |
| `settings` | JSONB | DEFAULT '{}' | Configuration settings |
| `is_active` | BOOLEAN | NOT NULL, DEFAULT true | Active status flag |
| `expires_at` | TIMESTAMP | NULLABLE | Expiration timestamp |

## Data Transfer Objects (DTOs)

### API Request/Response Models

#### Entity Creation Request
```typescript
interface CreateEntityRequest {
  name: string;                    // 1-255 characters
  description?: string;            // Optional description
  metadata?: Record<string, any>;  // Optional metadata
  status?: 'active' | 'inactive';  // Optional, defaults to 'active'
}
```

#### Entity Response
```typescript
interface EntityResponse {
  id: string;                      // UUID
  name: string;
  description: string | null;
  status: 'active' | 'inactive' | 'pending' | 'archived';
  metadata: Record<string, any> | null;
  createdAt: string;               // ISO 8601 timestamp
  updatedAt: string;               // ISO 8601 timestamp
  createdBy: UserSummary;
  updatedBy: UserSummary;
}
```

#### Entity Update Request
```typescript
interface UpdateEntityRequest {
  name?: string;                   // Optional name update
  description?: string;            // Optional description update
  metadata?: Record<string, any>;  // Optional metadata update
  status?: 'active' | 'inactive' | 'pending' | 'archived';
}
```

#### Paginated Entity List Response
```typescript
interface EntityListResponse {
  data: EntityResponse[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrevious: boolean;
  };
  filters: {
    status?: string;
    search?: string;
    createdAfter?: string;
    createdBefore?: string;
  };
}
```

## JSON Schemas

### Metadata Schema Validation
```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "category": {
      "type": "string",
      "enum": ["type1", "type2", "type3"]
    },
    "settings": {
      "type": "object",
      "properties": {
        "enabled": {"type": "boolean"},
        "threshold": {"type": "number", "minimum": 0, "maximum": 100},
        "options": {
          "type": "array",
          "items": {"type": "string"}
        }
      },
      "required": ["enabled"]
    },
    "tags": {
      "type": "array",
      "items": {"type": "string"},
      "maxItems": 10
    }
  },
  "additionalProperties": false
}
```

### Settings Configuration Schema
```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "notifications": {
      "type": "object",
      "properties": {
        "email": {"type": "boolean", "default": true},
        "push": {"type": "boolean", "default": false},
        "frequency": {
          "type": "string",
          "enum": ["immediate", "daily", "weekly"],
          "default": "daily"
        }
      }
    },
    "preferences": {
      "type": "object",
      "properties": {
        "theme": {
          "type": "string",
          "enum": ["light", "dark", "auto"],
          "default": "auto"
        },
        "language": {
          "type": "string",
          "pattern": "^[a-z]{2}(-[A-Z]{2})?$",
          "default": "en"
        }
      }
    }
  }
}
```

## Data Relationships

### Entity Relationship Diagram (ERD)
```mermaid
erDiagram
    USERS {
        uuid id PK
        string username
        string email
        timestamp created_at
    }
    
    ENTITY_NAME {
        uuid id PK
        string name
        text description
        string status
        jsonb metadata
        timestamp created_at
        timestamp updated_at
        uuid created_by FK
        uuid updated_by FK
    }
    
    ENTITY_TWO {
        uuid id PK
        uuid entity_one_id FK
        string title
        text content
        integer priority
        text[] tags
        jsonb settings
        boolean is_active
        timestamp expires_at
        timestamp created_at
        timestamp updated_at
    }
    
    USERS ||--o{ ENTITY_NAME : creates
    USERS ||--o{ ENTITY_NAME : updates
    ENTITY_NAME ||--o{ ENTITY_TWO : contains
```

### Relationship Details

#### Users → Entity Name (1:Many)
- **Type**: One-to-Many
- **Foreign Key**: `entity_name.created_by` → `users.id`
- **Constraint**: CASCADE on user deletion not allowed (preserve audit trail)
- **Business Rule**: User must exist when creating/updating entities

#### Entity Name → Entity Two (1:Many)
- **Type**: One-to-Many
- **Foreign Key**: `entity_two.entity_one_id` → `entity_name.id`
- **Constraint**: CASCADE on delete (remove child entities when parent is deleted)
- **Business Rule**: Child entities inherit some properties from parent

## Data Validation Rules

### Input Validation
- **String Fields**: Trim whitespace, validate length
- **Email Fields**: Valid email format, domain verification
- **Enum Fields**: Must match allowed values exactly
- **Numeric Fields**: Range validation, type checking
- **Date Fields**: Valid ISO 8601 format, logical date ranges

### Business Logic Validation
- **Name Uniqueness**: Case-insensitive unique names within scope
- **Status Transitions**: Only allow valid status changes
- **Parent-Child Consistency**: Child records must align with parent rules
- **Data Integrity**: Cross-field validation for related data

### Security Validation
- **SQL Injection Prevention**: Parameterized queries only
- **XSS Prevention**: HTML sanitization for user content
- **Data Sanitization**: Remove dangerous characters/patterns
- **Access Control**: User permissions for data access/modification

## Data Migration Strategy

### Database Migrations
```sql
-- Migration: 001_create_entity_name_table.sql
CREATE TABLE entity_name (
  -- table definition here
);

-- Migration: 002_add_entity_two_table.sql
CREATE TABLE entity_two (
  -- table definition here
);

-- Migration: 003_add_indexes.sql
CREATE INDEX idx_entity_name_status ON entity_name(status);
-- additional indexes
```

### Data Migration Scripts
- **Rollback Strategy**: Each migration includes rollback script
- **Data Preservation**: Backup before major schema changes
- **Performance Considerations**: Large table migrations during maintenance windows
- **Validation**: Post-migration data integrity checks

## Performance Considerations

### Query Optimization
- **Indexing Strategy**: Indexes on frequently queried columns
- **Composite Indexes**: Multi-column indexes for complex queries
- **Partial Indexes**: Conditional indexes for filtered queries
- **Query Planning**: EXPLAIN ANALYZE for performance monitoring

### Caching Strategy
- **Application Cache**: Frequently accessed data caching
- **Query Cache**: Database query result caching
- **CDN Caching**: Static data distribution
- **Cache Invalidation**: Automatic cache updates on data changes

### Scaling Considerations
- **Read Replicas**: Separate read/write database instances
- **Partitioning**: Table partitioning for large datasets
- **Archival Strategy**: Historical data archival process
- **Connection Pooling**: Database connection management

## Data Backup & Recovery

### Backup Strategy
- **Daily Backups**: Automated daily full backups
- **Point-in-Time Recovery**: Transaction log backups
- **Cross-Region Backups**: Geographic redundancy
- **Backup Validation**: Regular restore testing

### Recovery Procedures
- **Recovery Time Objective (RTO)**: Maximum 4 hours downtime
- **Recovery Point Objective (RPO)**: Maximum 1 hour data loss
- **Disaster Recovery**: Step-by-step recovery procedures
- **Data Validation**: Post-recovery data integrity verification

---

**Document Owner**: _[Database architect name and role]_
**Database Administrator**: _[DBA name]_
**Development Lead**: _[Engineering lead]_
**Last Updated**: _[Date]_
**Schema Version**: _[Current version]_