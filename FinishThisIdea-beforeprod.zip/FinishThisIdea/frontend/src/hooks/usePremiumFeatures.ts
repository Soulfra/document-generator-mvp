import { useState, useCallback } from 'react';
import { usePremium } from '../contexts/PremiumContext';

export interface PremiumFeatureCheck {
  isAllowed: boolean;
  showPaywall: () => void;
  feature: string;
  featureName: string;
}

export interface PaywallState {
  isOpen: boolean;
  feature: string;
  featureName: string;
  contextProfileId?: string;
}

const FEATURE_NAMES: Record<string, string> = {
  'file-size': 'Large File Upload',
  'batch-processing': 'Batch Processing',
  'advanced-templates': 'Advanced Templates',
  'export-formats': 'Multiple Export Formats',
  'priority-processing': 'Priority Processing',
  'profiles': 'Custom Profiles',
};

export const usePremiumFeatures = () => {
  const { user, activeProfile, checkPremiumFeature, upgradeUser } = usePremium();
  const [paywallState, setPaywallState] = useState<PaywallState>({
    isOpen: false,
    feature: '',
    featureName: '',
  });

  const checkFeature = useCallback((feature: string): PremiumFeatureCheck => {
    const isAllowed = checkPremiumFeature(feature);
    const featureName = FEATURE_NAMES[feature] || feature;

    return {
      isAllowed,
      feature,
      featureName,
      showPaywall: () => {
        if (!isAllowed) {
          setPaywallState({
            isOpen: true,
            feature,
            featureName,
            contextProfileId: activeProfile?.id,
          });
        }
      },
    };
  }, [checkPremiumFeature, activeProfile?.id]);

  const closePaywall = useCallback(() => {
    setPaywallState(prev => ({ ...prev, isOpen: false }));
  }, []);

  const handleUpgrade = useCallback(async (contextProfileId?: string) => {
    try {
      await upgradeUser(contextProfileId);
      closePaywall();
    } catch (error) {
      console.error('Upgrade failed:', error);
      throw error;
    }
  }, [upgradeUser, closePaywall]);

  // Specific feature checks
  const fileSize = useCallback((sizeInMB: number): PremiumFeatureCheck => {
    const maxSize = user?.tier === 'PREMIUM' ? 500 : 50;
    const feature = checkFeature('file-size');
    
    return {
      ...feature,
      isAllowed: sizeInMB <= maxSize,
    };
  }, [user?.tier, checkFeature]);

  const batchProcessing = useCallback((batchSize: number): PremiumFeatureCheck => {
    const maxBatch = user?.tier === 'PREMIUM' ? 10 : 1;
    const feature = checkFeature('batch-processing');
    
    return {
      ...feature,
      isAllowed: batchSize <= maxBatch,
    };
  }, [user?.tier, checkFeature]);

  const profileLimit = useCallback((currentCount: number): PremiumFeatureCheck => {
    const maxProfiles = user?.tier === 'PREMIUM' ? 10 : 2;
    const feature = checkFeature('profiles');
    
    return {
      ...feature,
      isAllowed: currentCount < maxProfiles,
    };
  }, [user?.tier, checkFeature]);

  const exportFormat = useCallback((format: string): PremiumFeatureCheck => {
    const allowedFormats = user?.tier === 'PREMIUM' 
      ? ['zip', 'pdf', 'html', 'md'] 
      : ['zip'];
    const feature = checkFeature('export-formats');
    
    return {
      ...feature,
      isAllowed: allowedFormats.includes(format.toLowerCase()),
    };
  }, [user?.tier, checkFeature]);

  return {
    // State
    paywallState,
    user,
    activeProfile,
    
    // General feature checking
    checkFeature,
    
    // Specific feature checks
    fileSize,
    batchProcessing,
    profileLimit,
    exportFormat,
    advancedTemplates: useCallback(() => checkFeature('advanced-templates'), [checkFeature]),
    priorityProcessing: useCallback(() => checkFeature('priority-processing'), [checkFeature]),
    
    // Actions
    closePaywall,
    handleUpgrade,
  };
};