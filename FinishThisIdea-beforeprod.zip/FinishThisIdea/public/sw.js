// FinishThisIdea Service Worker
// Provides offline functionality, caching, and background sync

const CACHE_NAME = 'finishthisidea-v1.2.0';
const STATIC_CACHE = 'finishthisidea-static-v1.2.0';
const DYNAMIC_CACHE = 'finishthisidea-dynamic-v1.2.0';

// Files to cache immediately on install
const STATIC_ASSETS = [
  '/',
  '/manifest.json',
  '/admin/analytics.html',
  '/admin/workflow-builder.html',
  '/admin/template-marketplace.html',
  // Add other critical assets
];

// API endpoints to cache
const API_CACHE_PATTERNS = [
  /^\/api\/profiles/,
  /^\/api\/jobs/,
  /^\/api\/health/,
  /^\/api\/analytics\/dashboard/,
  /^\/api\/template-marketplace\/featured/,
];

// Network-first patterns (always try network first)
const NETWORK_FIRST_PATTERNS = [
  /^\/api\/upload/,
  /^\/api\/payment/,
  /^\/api\/webhook/,
  /^\/api\/workflow-builder\/workflows\/.*\/execute/,
];

// Cache-first patterns (try cache first)
const CACHE_FIRST_PATTERNS = [
  /\.(css|js|png|jpg|jpeg|gif|svg|woff|woff2|ttf|eot)$/,
  /^\/icons\//,
  /^\/images\//,
];

// Install event - cache static assets
self.addEventListener('install', event => {
  console.log('[SW] Installing service worker...');
  
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then(cache => {
        console.log('[SW] Caching static assets');
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => {
        console.log('[SW] Service worker installed successfully');
        return self.skipWaiting();
      })
      .catch(error => {
        console.error('[SW] Failed to install service worker:', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  console.log('[SW] Activating service worker...');
  
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => {
            if (cacheName !== STATIC_CACHE && 
                cacheName !== DYNAMIC_CACHE && 
                cacheName !== CACHE_NAME) {
              console.log('[SW] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('[SW] Service worker activated');
        return self.clients.claim();
      })
  );
});

// Fetch event - handle all network requests
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);
  
  // Skip non-GET requests and different origins
  if (request.method !== 'GET' || url.origin !== location.origin) {
    return;
  }

  // Handle different caching strategies
  event.respondWith(handleRequest(request));
});

async function handleRequest(request) {
  const url = new URL(request.url);
  const pathname = url.pathname;

  try {
    // Network-first strategy for critical APIs
    if (NETWORK_FIRST_PATTERNS.some(pattern => pattern.test(pathname))) {
      return await networkFirst(request);
    }

    // Cache-first strategy for static assets
    if (CACHE_FIRST_PATTERNS.some(pattern => pattern.test(pathname))) {
      return await cacheFirst(request);
    }

    // API endpoints - cache with network fallback
    if (pathname.startsWith('/api/')) {
      return await apiCacheStrategy(request);
    }

    // Default strategy - cache first with network fallback
    return await cacheFirst(request);

  } catch (error) {
    console.error('[SW] Request failed:', error);
    return await getOfflineFallback(request);
  }
}

// Network-first strategy
async function networkFirst(request) {
  try {
    const response = await fetch(request);
    
    if (response.ok) {
      // Cache successful responses
      const cache = await caches.open(DYNAMIC_CACHE);
      cache.put(request, response.clone());
    }
    
    return response;
  } catch (error) {
    console.log('[SW] Network failed, trying cache:', request.url);
    const cachedResponse = await caches.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    throw error;
  }
}

// Cache-first strategy
async function cacheFirst(request) {
  const cachedResponse = await caches.match(request);
  
  if (cachedResponse) {
    // Update cache in background
    updateCacheInBackground(request);
    return cachedResponse;
  }
  
  // Not in cache, fetch from network
  const response = await fetch(request);
  
  if (response.ok) {
    const cache = await caches.open(DYNAMIC_CACHE);
    cache.put(request, response.clone());
  }
  
  return response;
}

// API cache strategy with TTL
async function apiCacheStrategy(request) {
  const url = new URL(request.url);
  const pathname = url.pathname;
  
  // Check if this API should be cached
  const shouldCache = API_CACHE_PATTERNS.some(pattern => pattern.test(pathname));
  
  if (!shouldCache) {
    return fetch(request);
  }
  
  const cachedResponse = await caches.match(request);
  
  if (cachedResponse) {
    const cacheDate = new Date(cachedResponse.headers.get('sw-cache-date') || 0);
    const now = new Date();
    const maxAge = 5 * 60 * 1000; // 5 minutes TTL
    
    if (now - cacheDate < maxAge) {
      // Update cache in background
      updateCacheInBackground(request);
      return cachedResponse;
    }
  }
  
  // Fetch from network
  try {
    const response = await fetch(request);
    
    if (response.ok) {
      const responseToCache = response.clone();
      responseToCache.headers.set('sw-cache-date', new Date().toISOString());
      
      const cache = await caches.open(DYNAMIC_CACHE);
      cache.put(request, responseToCache);
    }
    
    return response;
  } catch (error) {
    if (cachedResponse) {
      return cachedResponse;
    }
    throw error;
  }
}

// Update cache in background
function updateCacheInBackground(request) {
  // Don't await this - let it run in background
  fetch(request)
    .then(response => {
      if (response.ok) {
        return caches.open(DYNAMIC_CACHE)
          .then(cache => cache.put(request, response));
      }
    })
    .catch(error => {
      console.log('[SW] Background cache update failed:', error);
    });
}

// Offline fallback
async function getOfflineFallback(request) {
  const url = new URL(request.url);
  
  // Try to return cached version
  const cachedResponse = await caches.match(request);
  if (cachedResponse) {
    return cachedResponse;
  }
  
  // Return offline page for navigation requests
  if (request.mode === 'navigate') {
    return caches.match('/offline.html') || 
           new Response('You are offline. Please check your connection.', {
             status: 503,
             statusText: 'Service Unavailable',
             headers: { 'Content-Type': 'text/plain' }
           });
  }
  
  // Return empty response for other requests
  return new Response('Offline', {
    status: 503,
    statusText: 'Service Unavailable'
  });
}

// Background sync for failed uploads
self.addEventListener('sync', event => {
  console.log('[SW] Background sync triggered:', event.tag);
  
  if (event.tag === 'upload-retry') {
    event.waitUntil(retryFailedUploads());
  }
  
  if (event.tag === 'analytics-sync') {
    event.waitUntil(syncAnalytics());
  }
});

// Push notifications
self.addEventListener('push', event => {
  console.log('[SW] Push notification received');
  
  const options = {
    body: 'Your job has been completed!',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/badge-72x72.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 'job-completion'
    },
    actions: [
      {
        action: 'view',
        title: 'View Results',
        icon: '/icons/view-icon.png'
      },
      {
        action: 'dismiss',
        title: 'Dismiss',
        icon: '/icons/dismiss-icon.png'
      }
    ]
  };
  
  event.waitUntil(
    self.registration.showNotification('FinishThisIdea', options)
  );
});

// Notification click handling
self.addEventListener('notificationclick', event => {
  console.log('[SW] Notification clicked:', event.action);
  
  event.notification.close();
  
  if (event.action === 'view') {
    event.waitUntil(
      clients.openWindow('/jobs')
    );
  }
});

// Share target handling
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SHARE_TARGET') {
    console.log('[SW] Share target received:', event.data);
    
    // Handle shared content
    event.waitUntil(
      handleSharedContent(event.data.payload)
    );
  }
});

// Helper functions
async function retryFailedUploads() {
  try {
    const requests = await getStoredRequests('failed-uploads');
    
    for (const storedRequest of requests) {
      try {
        const response = await fetch(storedRequest.url, storedRequest.options);
        
        if (response.ok) {
          // Remove from failed uploads
          await removeStoredRequest('failed-uploads', storedRequest.id);
          console.log('[SW] Successfully retried upload:', storedRequest.id);
        }
      } catch (error) {
        console.log('[SW] Retry failed for upload:', storedRequest.id, error);
      }
    }
  } catch (error) {
    console.error('[SW] Failed to retry uploads:', error);
  }
}

async function syncAnalytics() {
  try {
    const events = await getStoredData('offline-analytics');
    
    if (events && events.length > 0) {
      const response = await fetch('/api/analytics/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ events })
      });
      
      if (response.ok) {
        await clearStoredData('offline-analytics');
        console.log('[SW] Analytics synced successfully');
      }
    }
  } catch (error) {
    console.error('[SW] Failed to sync analytics:', error);
  }
}

async function handleSharedContent(payload) {
  // Store shared content for processing when app opens
  await storeData('shared-content', payload);
  
  // Open the app
  const clients = await self.clients.matchAll();
  if (clients.length > 0) {
    clients[0].postMessage({
      type: 'SHARED_CONTENT',
      payload
    });
  } else {
    await self.clients.openWindow('/share');
  }
}

// IndexedDB helpers for storing data offline
async function storeData(storeName, data) {
  // Simple localStorage fallback - in production use IndexedDB
  try {
    const existing = JSON.parse(localStorage.getItem(storeName) || '[]');
    existing.push({ ...data, timestamp: Date.now() });
    localStorage.setItem(storeName, JSON.stringify(existing));
  } catch (error) {
    console.error('[SW] Failed to store data:', error);
  }
}

async function getStoredData(storeName) {
  try {
    return JSON.parse(localStorage.getItem(storeName) || '[]');
  } catch (error) {
    console.error('[SW] Failed to get stored data:', error);
    return [];
  }
}

async function clearStoredData(storeName) {
  try {
    localStorage.removeItem(storeName);
  } catch (error) {
    console.error('[SW] Failed to clear stored data:', error);
  }
}

async function getStoredRequests(storeName) {
  return getStoredData(storeName);
}

async function removeStoredRequest(storeName, id) {
  try {
    const requests = await getStoredData(storeName);
    const filtered = requests.filter(req => req.id !== id);
    localStorage.setItem(storeName, JSON.stringify(filtered));
  } catch (error) {
    console.error('[SW] Failed to remove stored request:', error);
  }
}

console.log('[SW] Service worker script loaded');