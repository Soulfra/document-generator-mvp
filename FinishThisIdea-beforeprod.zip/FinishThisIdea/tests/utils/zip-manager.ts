import * as fs from 'fs/promises';
import * as path from 'path';
import archiver from 'archiver';
import { createWriteStream, createReadStream } from 'fs';
import yauzl from 'yauzl';

export interface ZipEntry {
  fileName: string;
  content: string;
  isDirectory: boolean;
  uncompressedSize: number;
}

export interface ZipCreationOptions {
  compression?: 'store' | 'deflate';
  level?: number; // 0-9, where 9 is maximum compression
  comment?: string;
}

export interface ZipExtractionOptions {
  maxFiles?: number;
  maxTotalSize?: number;
  allowedExtensions?: string[];
  excludePatterns?: RegExp[];
}

/**
 * Utility class for creating and managing ZIP files in tests
 */
export class ZipManager {
  
  /**
   * Create a ZIP file from a collection of files
   */
  static async createZip(
    files: Record<string, string>,
    outputPath: string,
    options: ZipCreationOptions = {}
  ): Promise<string> {
    const {
      compression = 'deflate',
      level = 6,
      comment
    } = options;

    return new Promise((resolve, reject) => {
      const output = createWriteStream(outputPath);
      const archive = archiver('zip', {
        zlib: { level },
        comment
      });

      output.on('close', () => {
        resolve(outputPath);
      });

      output.on('error', reject);
      archive.on('error', reject);

      archive.pipe(output);

      // Add files to archive
      for (const [filePath, content] of Object.entries(files)) {
        archive.append(content, { 
          name: filePath,
          store: compression === 'store'
        });
      }

      archive.finalize();
    });
  }

  /**
   * Create a ZIP file from a directory structure
   */
  static async createZipFromDirectory(
    sourceDir: string,
    outputPath: string,
    options: ZipCreationOptions = {}
  ): Promise<string> {
    const {
      compression = 'deflate',
      level = 6,
      comment
    } = options;

    return new Promise((resolve, reject) => {
      const output = createWriteStream(outputPath);
      const archive = archiver('zip', {
        zlib: { level },
        comment
      });

      output.on('close', () => resolve(outputPath));
      output.on('error', reject);
      archive.on('error', reject);

      archive.pipe(output);
      archive.directory(sourceDir, false);
      archive.finalize();
    });
  }

  /**
   * Extract and read contents of a ZIP file
   */
  static async extractZip(
    zipPath: string,
    options: ZipExtractionOptions = {}
  ): Promise<Map<string, string>> {
    const {
      maxFiles = 1000,
      maxTotalSize = 100 * 1024 * 1024, // 100MB
      allowedExtensions,
      excludePatterns = []
    } = options;

    return new Promise((resolve, reject) => {
      yauzl.open(zipPath, { lazyEntries: true }, (err, zipfile) => {
        if (err) {
          reject(err);
          return;
        }

        const files = new Map<string, string>();
        let fileCount = 0;
        let totalSize = 0;

        zipfile.readEntry();

        zipfile.on('entry', (entry) => {
          // Check file count limit
          if (fileCount >= maxFiles) {
            zipfile.close();
            reject(new Error(`Too many files in ZIP (max: ${maxFiles})`));
            return;
          }

          // Skip directories
          if (/\/$/.test(entry.fileName)) {
            zipfile.readEntry();
            return;
          }

          // Check file extension if restricted
          if (allowedExtensions) {
            const ext = path.extname(entry.fileName).toLowerCase();
            if (!allowedExtensions.includes(ext)) {
              zipfile.readEntry();
              return;
            }
          }

          // Check exclude patterns
          if (excludePatterns.some(pattern => pattern.test(entry.fileName))) {
            zipfile.readEntry();
            return;
          }

          // Check size limits
          if (totalSize + entry.uncompressedSize > maxTotalSize) {
            zipfile.close();
            reject(new Error(`ZIP contents too large (max: ${maxTotalSize} bytes)`));
            return;
          }

          // Extract file content
          zipfile.openReadStream(entry, (err, readStream) => {
            if (err) {
              reject(err);
              return;
            }

            const chunks: Buffer[] = [];
            
            readStream.on('data', (chunk) => {
              chunks.push(chunk);
            });

            readStream.on('end', () => {
              const content = Buffer.concat(chunks).toString('utf8');
              files.set(entry.fileName, content);
              
              fileCount++;
              totalSize += entry.uncompressedSize;
              
              zipfile.readEntry();
            });

            readStream.on('error', reject);
          });
        });

        zipfile.on('end', () => {
          resolve(files);
        });

        zipfile.on('error', reject);
      });
    });
  }

  /**
   * Get ZIP file information without extracting
   */
  static async getZipInfo(zipPath: string): Promise<{
    fileCount: number;
    totalSize: number;
    files: Array<{
      name: string;
      size: number;
      compressedSize: number;
      isDirectory: boolean;
    }>;
  }> {
    return new Promise((resolve, reject) => {
      yauzl.open(zipPath, { lazyEntries: true }, (err, zipfile) => {
        if (err) {
          reject(err);
          return;
        }

        const files: Array<{
          name: string;
          size: number;
          compressedSize: number;
          isDirectory: boolean;
        }> = [];
        
        let totalSize = 0;

        zipfile.readEntry();

        zipfile.on('entry', (entry) => {
          const isDirectory = /\/$/.test(entry.fileName);
          
          files.push({
            name: entry.fileName,
            size: entry.uncompressedSize,
            compressedSize: entry.compressedSize,
            isDirectory
          });

          if (!isDirectory) {
            totalSize += entry.uncompressedSize;
          }

          zipfile.readEntry();
        });

        zipfile.on('end', () => {
          resolve({
            fileCount: files.filter(f => !f.isDirectory).length,
            totalSize,
            files
          });
        });

        zipfile.on('error', reject);
      });
    });
  }

  /**
   * Validate ZIP file structure and contents
   */
  static async validateZip(
    zipPath: string,
    validation: {
      expectedFiles?: string[];
      requiredFiles?: string[];
      maxSize?: number;
      allowedExtensions?: string[];
      forbiddenPatterns?: RegExp[];
    }
  ): Promise<{
    isValid: boolean;
    errors: string[];
    warnings: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];

    try {
      const zipInfo = await this.getZipInfo(zipPath);
      const fileNames = zipInfo.files.map(f => f.name);

      // Check maximum size
      if (validation.maxSize && zipInfo.totalSize > validation.maxSize) {
        errors.push(`ZIP too large: ${zipInfo.totalSize} bytes (max: ${validation.maxSize})`);
      }

      // Check required files
      if (validation.requiredFiles) {
        for (const requiredFile of validation.requiredFiles) {
          if (!fileNames.includes(requiredFile)) {
            errors.push(`Required file missing: ${requiredFile}`);
          }
        }
      }

      // Check expected files
      if (validation.expectedFiles) {
        for (const fileName of fileNames) {
          if (!validation.expectedFiles.includes(fileName)) {
            warnings.push(`Unexpected file: ${fileName}`);
          }
        }
      }

      // Check file extensions
      if (validation.allowedExtensions) {
        for (const file of zipInfo.files) {
          if (!file.isDirectory) {
            const ext = path.extname(file.name).toLowerCase();
            if (ext && !validation.allowedExtensions.includes(ext)) {
              warnings.push(`File with disallowed extension: ${file.name}`);
            }
          }
        }
      }

      // Check forbidden patterns
      if (validation.forbiddenPatterns) {
        for (const file of zipInfo.files) {
          for (const pattern of validation.forbiddenPatterns) {
            if (pattern.test(file.name)) {
              errors.push(`File matches forbidden pattern: ${file.name}`);
            }
          }
        }
      }

      return {
        isValid: errors.length === 0,
        errors,
        warnings
      };

    } catch (error) {
      return {
        isValid: false,
        errors: [`Failed to validate ZIP: ${error.message}`],
        warnings: []
      };
    }
  }

  /**
   * Create a test ZIP with specific characteristics for testing edge cases
   */
  static async createTestZip(
    config: {
      type: 'empty' | 'large' | 'malformed' | 'nested' | 'mixed-content';
      outputPath: string;
      options?: {
        fileCount?: number;
        fileSize?: number;
        nestingLevel?: number;
      };
    }
  ): Promise<string> {
    const { type, outputPath, options = {} } = config;
    const { fileCount = 10, fileSize = 1024, nestingLevel = 3 } = options;

    const files: Record<string, string> = {};

    switch (type) {
      case 'empty':
        // Create empty ZIP
        break;

      case 'large':
        // Create ZIP with many files
        for (let i = 0; i < fileCount; i++) {
          const content = 'x'.repeat(fileSize);
          files[`file${i}.txt`] = content;
        }
        break;

      case 'nested':
        // Create deeply nested directory structure
        let currentPath = '';
        for (let level = 0; level < nestingLevel; level++) {
          currentPath += `level${level}/`;
          files[`${currentPath}file.txt`] = `Content at level ${level}`;
        }
        break;

      case 'mixed-content':
        // Create ZIP with various file types
        files['package.json'] = JSON.stringify({ name: 'test-project' });
        files['README.md'] = '# Test Project\\n\\nThis is a test.';
        files['src/index.js'] = 'console.log("Hello, world!");';
        files['src/styles.css'] = 'body { margin: 0; }';
        files['assets/image.txt'] = 'fake image content';
        files['node_modules/lib/index.js'] = 'module.exports = {};';
        files['.git/config'] = '[core]\\nfilemode = true';
        files['dist/bundle.js'] = '(function(){})();';
        break;

      case 'malformed':
        // Create files that might cause issues
        files[''] = 'file with empty name';
        files['file with spaces.txt'] = 'content';
        files['file\\nwith\\nnewlines.txt'] = 'content';
        files['very-long-filename-' + 'x'.repeat(200) + '.txt'] = 'content';
        files['../../../etc/passwd'] = 'malicious content';
        files['file.txt'] = '\\x00\\x01\\x02'; // Binary content
        break;
    }

    return this.createZip(files, outputPath);
  }

  /**
   * Compare two ZIP files for testing
   */
  static async compareZips(
    zipPath1: string,
    zipPath2: string
  ): Promise<{
    areEqual: boolean;
    differences: Array<{
      type: 'missing' | 'extra' | 'different';
      file: string;
      details?: string;
    }>;
  }> {
    const [files1, files2] = await Promise.all([
      this.extractZip(zipPath1),
      this.extractZip(zipPath2)
    ]);

    const differences: Array<{
      type: 'missing' | 'extra' | 'different';
      file: string;
      details?: string;
    }> = [];

    // Check for missing files in zip2
    for (const [fileName, content1] of files1) {
      if (!files2.has(fileName)) {
        differences.push({
          type: 'missing',
          file: fileName
        });
      } else {
        const content2 = files2.get(fileName)!;
        if (content1 !== content2) {
          differences.push({
            type: 'different',
            file: fileName,
            details: `Size: ${content1.length} vs ${content2.length}`
          });
        }
      }
    }

    // Check for extra files in zip2
    for (const fileName of files2.keys()) {
      if (!files1.has(fileName)) {
        differences.push({
          type: 'extra',
          file: fileName
        });
      }
    }

    return {
      areEqual: differences.length === 0,
      differences
    };
  }

  /**
   * Clean up test ZIP files
   */
  static async cleanupZips(zipPaths: string[]): Promise<void> {
    await Promise.all(
      zipPaths.map(async (zipPath) => {
        try {
          await fs.unlink(zipPath);
        } catch (error) {
          // Ignore errors when cleaning up
        }
      })
    );
  }
}