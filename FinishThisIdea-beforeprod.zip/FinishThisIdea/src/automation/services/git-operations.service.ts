import { exec } from 'child_process';
import { promisify } from 'util';
import { logger } from '../../utils/logger';
import * as path from 'path';

const execAsync = promisify(exec);

export interface GitStatus {
  branch: string;
  ahead: number;
  behind: number;
  staged: string[];
  unstaged: string[];
  untracked: string[];
  conflicted: string[];
  clean: boolean;
}

export interface GitCommitResult {
  hash: string;
  message: string;
  author: string;
  timestamp: Date;
}

export interface GitOperationResult {
  success: boolean;
  output: string;
  error?: string;
}

export class GitOperationsService {
  private readonly workingDirectory: string;

  constructor() {
    this.workingDirectory = process.cwd();
  }

  /**
   * Get git status
   */
  public async getStatus(): Promise<GitOperationResult & { status?: GitStatus }> {
    try {
      // Check if this is a git repository
      await this.execGit('rev-parse --git-dir');

      // Get branch info
      const branchResult = await this.execGit('branch --show-current');
      const branch = branchResult.stdout.trim() || 'HEAD';

      // Get tracking info
      let ahead = 0;
      let behind = 0;
      try {
        const trackingResult = await this.execGit('rev-list --count --left-right @{upstream}...HEAD');
        const [behindStr, aheadStr] = trackingResult.stdout.trim().split('\t');
        behind = parseInt(behindStr) || 0;
        ahead = parseInt(aheadStr) || 0;
      } catch (error) {
        // No upstream branch or other tracking issues
      }

      // Get file status
      const statusResult = await this.execGit('status --porcelain=v1');
      const statusLines = statusResult.stdout.trim().split('\n').filter(Boolean);

      const staged: string[] = [];
      const unstaged: string[] = [];
      const untracked: string[] = [];
      const conflicted: string[] = [];

      for (const line of statusLines) {
        const status = line.substring(0, 2);
        const filename = line.substring(3);

        if (status.includes('U') || status.includes('A') && status.includes('A')) {
          conflicted.push(filename);
        } else if (status[0] !== ' ' && status[0] !== '?') {
          staged.push(filename);
        }
        
        if (status[1] !== ' ' && status[1] !== '?') {
          unstaged.push(filename);
        }
        
        if (status === '??') {
          untracked.push(filename);
        }
      }

      const gitStatus: GitStatus = {
        branch,
        ahead,
        behind,
        staged,
        unstaged,
        untracked,
        conflicted,
        clean: statusLines.length === 0,
      };

      const output = this.formatStatusOutput(gitStatus);

      return {
        success: true,
        output,
        status: gitStatus,
      };

    } catch (error) {
      logger.error('Git status failed', { error });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Unknown git error',
      };
    }
  }

  /**
   * Add all changes to staging area
   */
  public async addAll(): Promise<GitOperationResult> {
    try {
      const result = await this.execGit('add -A');
      
      logger.info('Git add all completed');
      return {
        success: true,
        output: 'All changes added to staging area',
      };

    } catch (error) {
      logger.error('Git add failed', { error });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Git add failed',
      };
    }
  }

  /**
   * Add specific file to staging area
   */
  public async addFile(filename: string): Promise<GitOperationResult> {
    try {
      // Validate filename for security
      const safePath = path.normalize(filename);
      if (safePath.includes('..') || path.isAbsolute(safePath)) {
        throw new Error('Invalid file path');
      }

      const result = await this.execGit(`add "${safePath}"`);
      
      logger.info('Git add file completed', { filename });
      return {
        success: true,
        output: `Added: ${filename}`,
      };

    } catch (error) {
      logger.error('Git add file failed', { error, filename });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Git add failed',
      };
    }
  }

  /**
   * Commit changes
   */
  public async commit(message: string): Promise<GitOperationResult & { commit?: GitCommitResult }> {
    try {
      if (!message || message.trim().length === 0) {
        throw new Error('Commit message is required');
      }

      // Escape the commit message
      const safeMessage = message.replace(/"/g, '\\"');
      
      const result = await this.execGit(`commit -m "${safeMessage}"`);
      
      // Get the commit hash
      const hashResult = await this.execGit('rev-parse HEAD');
      const hash = hashResult.stdout.trim();

      // Get commit details
      const detailsResult = await this.execGit(`show --format="%an|%ai" --no-patch ${hash}`);
      const [author, timestamp] = detailsResult.stdout.trim().split('|');

      const commit: GitCommitResult = {
        hash: hash.substring(0, 8), // Short hash
        message: message.trim(),
        author,
        timestamp: new Date(timestamp),
      };

      logger.info('Git commit completed', { hash: commit.hash, message });
      return {
        success: true,
        output: `Committed: ${commit.hash} - ${message}`,
        commit,
      };

    } catch (error) {
      logger.error('Git commit failed', { error, message });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Git commit failed',
      };
    }
  }

  /**
   * Push changes to remote
   */
  public async push(remote: string = 'origin', branch?: string): Promise<GitOperationResult> {
    try {
      let command = `push ${remote}`;
      
      if (branch) {
        command += ` ${branch}`;
      }

      const result = await this.execGit(command);
      
      logger.info('Git push completed', { remote, branch });
      return {
        success: true,
        output: `Pushed to ${remote}${branch ? ` (${branch})` : ''}`,
      };

    } catch (error) {
      logger.error('Git push failed', { error, remote, branch });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Git push failed',
      };
    }
  }

  /**
   * Pull changes from remote
   */
  public async pull(remote: string = 'origin', branch?: string): Promise<GitOperationResult> {
    try {
      let command = `pull ${remote}`;
      
      if (branch) {
        command += ` ${branch}`;
      }

      const result = await this.execGit(command);
      
      logger.info('Git pull completed', { remote, branch });
      return {
        success: true,
        output: result.stdout || `Pulled from ${remote}`,
      };

    } catch (error) {
      logger.error('Git pull failed', { error, remote, branch });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Git pull failed',
      };
    }
  }

  /**
   * Get recent commits
   */
  public async getRecentCommits(limit: number = 10): Promise<GitOperationResult & { commits?: GitCommitResult[] }> {
    try {
      const result = await this.execGit(`log --oneline --format="%H|%s|%an|%ai" -n ${limit}`);
      
      const commits: GitCommitResult[] = result.stdout
        .trim()
        .split('\n')
        .filter(Boolean)
        .map(line => {
          const [hash, message, author, timestamp] = line.split('|');
          return {
            hash: hash.substring(0, 8),
            message,
            author,
            timestamp: new Date(timestamp),
          };
        });

      return {
        success: true,
        output: commits.map(c => `${c.hash} - ${c.message}`).join('\n'),
        commits,
      };

    } catch (error) {
      logger.error('Git log failed', { error });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Git log failed',
      };
    }
  }

  /**
   * Create and switch to new branch
   */
  public async createBranch(branchName: string): Promise<GitOperationResult> {
    try {
      // Validate branch name
      if (!/^[a-zA-Z0-9/_-]+$/.test(branchName)) {
        throw new Error('Invalid branch name');
      }

      const result = await this.execGit(`checkout -b ${branchName}`);
      
      logger.info('Git branch created', { branchName });
      return {
        success: true,
        output: `Created and switched to branch: ${branchName}`,
      };

    } catch (error) {
      logger.error('Git branch creation failed', { error, branchName });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Branch creation failed',
      };
    }
  }

  /**
   * Switch to existing branch
   */
  public async switchBranch(branchName: string): Promise<GitOperationResult> {
    try {
      // Validate branch name
      if (!/^[a-zA-Z0-9/_-]+$/.test(branchName)) {
        throw new Error('Invalid branch name');
      }

      const result = await this.execGit(`checkout ${branchName}`);
      
      logger.info('Git branch switched', { branchName });
      return {
        success: true,
        output: `Switched to branch: ${branchName}`,
      };

    } catch (error) {
      logger.error('Git branch switch failed', { error, branchName });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Branch switch failed',
      };
    }
  }

  /**
   * Get remote information
   */
  public async getRemotes(): Promise<GitOperationResult & { remotes?: Array<{ name: string; url: string }> }> {
    try {
      const result = await this.execGit('remote -v');
      
      const remotes = result.stdout
        .trim()
        .split('\n')
        .filter(Boolean)
        .filter(line => line.includes('(fetch)')) // Only fetch URLs
        .map(line => {
          const [name, url] = line.split('\t')[0].split(/\s+/);
          return { name, url: url || '' };
        });

      return {
        success: true,
        output: remotes.map(r => `${r.name}: ${r.url}`).join('\n'),
        remotes,
      };

    } catch (error) {
      logger.error('Git remotes failed', { error });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Git remotes failed',
      };
    }
  }

  /**
   * Execute git command safely
   */
  private async execGit(command: string): Promise<{ stdout: string; stderr: string }> {
    const fullCommand = `git ${command}`;
    
    try {
      const result = await execAsync(fullCommand, {
        cwd: this.workingDirectory,
        timeout: 30000, // 30 second timeout
        maxBuffer: 1024 * 1024, // 1MB buffer
      });

      return result;
    } catch (error: any) {
      // Enhance error message with git-specific context
      if (error.code === 128) {
        throw new Error(`Git error: ${error.stderr || error.message}`);
      }
      throw error;
    }
  }

  /**
   * Format git status for display
   */
  private formatStatusOutput(status: GitStatus): string {
    let output = `Branch: ${status.branch}\n`;

    if (status.ahead > 0 || status.behind > 0) {
      output += `Tracking: `;
      if (status.ahead > 0) output += `+${status.ahead} ahead `;
      if (status.behind > 0) output += `-${status.behind} behind `;
      output += '\n';
    }

    if (status.clean) {
      output += 'Working tree clean ✅';
      return output;
    }

    if (status.staged.length > 0) {
      output += `\nStaged (${status.staged.length}):\n`;
      output += status.staged.map(f => `  ✓ ${f}`).join('\n');
    }

    if (status.unstaged.length > 0) {
      output += `\nUnstaged (${status.unstaged.length}):\n`;
      output += status.unstaged.map(f => `  ⚠️ ${f}`).join('\n');
    }

    if (status.untracked.length > 0) {
      output += `\nUntracked (${status.untracked.length}):\n`;
      output += status.untracked.map(f => `  ❓ ${f}`).join('\n');
    }

    if (status.conflicted.length > 0) {
      output += `\nConflicted (${status.conflicted.length}):\n`;
      output += status.conflicted.map(f => `  ❌ ${f}`).join('\n');
    }

    return output;
  }

  /**
   * Check if directory is a git repository
   */
  public async isGitRepository(): Promise<boolean> {
    try {
      await this.execGit('rev-parse --git-dir');
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * Initialize git repository
   */
  public async initRepository(): Promise<GitOperationResult> {
    try {
      const result = await this.execGit('init');
      
      logger.info('Git repository initialized');
      return {
        success: true,
        output: 'Git repository initialized',
      };

    } catch (error) {
      logger.error('Git init failed', { error });
      return {
        success: false,
        output: '',
        error: error instanceof Error ? error.message : 'Git init failed',
      };
    }
  }
}

// Export singleton instance
export const gitOperations = new GitOperationsService();