---
title: "Environment Setup Guide"
description: "Comprehensive guide for configuring environment variables and settings for the Document Generator"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Environment Setup Guide

Comprehensive guide for configuring environment variables and settings for the Document Generator.

## 🔧 Environment Variables Overview

The application uses environment variables for configuration across development, staging, and production environments.

## 📋 Required Variables

### Database Configuration
```bash
# PostgreSQL connection string
DATABASE_URL=postgresql://username:password@host:port/database

# Example for local development
DATABASE_URL=postgresql://postgres:password@localhost:5434/finishthisidea

# Production example
DATABASE_URL=postgresql://user:pass@prod-db.amazonaws.com:5432/finishthisidea
```

### Redis Configuration
```bash
# Redis connection for job queue and caching
REDIS_URL=redis://[username:password@]host:port[/database]

# Local development
REDIS_URL=redis://localhost:6379

# Production with auth
REDIS_URL=redis://user:password@prod-redis.com:6379/0
```

### Server Configuration
```bash
# Server port (default: 3001)
PORT=3001

# Runtime environment
NODE_ENV=development|staging|production

# Frontend URL for CORS
FRONTEND_URL=http://localhost:3000

# Logging level
LOG_LEVEL=debug|info|warn|error
```

## 🔐 Security Variables

### JWT & Encryption
```bash
# JWT secret for token signing (min 32 characters)
JWT_SECRET=your_jwt_secret_at_least_32_chars_long

# Encryption key for sensitive data (exactly 32 characters)
ENCRYPTION_KEY=your_encryption_key_32_chars_long
```

### API Keys
```bash
# Stripe payment processing
STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret

# Anthropic Claude API (optional fallback)
ANTHROPIC_API_KEY=sk-ant-your_api_key
ANTHROPIC_MODEL=claude-3-sonnet-20240229
```

## ☁️ Storage Configuration

### AWS S3 / MinIO
```bash
# AWS credentials
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_REGION=us-east-1

# S3 bucket for file storage
S3_BUCKET=finishthisidea-uploads

# S3 endpoint (for MinIO or custom S3-compatible storage)
S3_ENDPOINT=http://localhost:9000
```

## 🤖 AI Service Configuration

### Ollama (Local AI)
```bash
# Ollama service URL
OLLAMA_BASE_URL=http://localhost:11434

# Model to use
OLLAMA_MODEL=codellama:latest
```

## ⚙️ Application Settings

### File Processing
```bash
# Maximum file size in MB
MAX_FILE_SIZE_MB=50

# Allowed file types (comma-separated)
ALLOWED_FILE_TYPES=.zip,.tar,.tar.gz

# Job timeout in minutes
JOB_TIMEOUT_MINUTES=30

# Job retention in hours
JOB_RETENTION_HOURS=24

# Maximum concurrent jobs
MAX_CONCURRENT_JOBS=5
```

### Feature Flags
```bash
# Enable Claude API fallback
ENABLE_CLAUDE_FALLBACK=false

# Enable documentation generation
ENABLE_DOCUMENTATION_GENERATION=true

# Enable API generation
ENABLE_API_GENERATION=false
```

## 📁 Environment Files

### `.env` (Development)
```bash
# Server Configuration
PORT=3001
NODE_ENV=development
LOG_LEVEL=info

# Frontend URL (for CORS)
FRONTEND_URL=http://localhost:3000

# Database
DATABASE_URL=postgresql://postgres:password@localhost:5434/finishthisidea

# Redis (for job queue)
REDIS_URL=redis://localhost:6379

# AWS S3 (using MinIO for local development)
AWS_ACCESS_KEY_ID=minioadmin
AWS_SECRET_ACCESS_KEY=minioadmin123
AWS_REGION=us-east-1
S3_BUCKET=finishthisidea-uploads
S3_ENDPOINT=http://localhost:9000

# Stripe (test keys)
STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret

# Ollama (local AI)
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=codellama:latest

# Claude API (optional fallback)
ANTHROPIC_API_KEY=sk-ant-your_api_key
ANTHROPIC_MODEL=claude-3-sonnet-20240229

# Security
JWT_SECRET=your_jwt_secret_at_least_32_chars_long
ENCRYPTION_KEY=your_encryption_key_32_chars_long

# File Limits
MAX_FILE_SIZE_MB=50
ALLOWED_FILE_TYPES=.zip,.tar,.tar.gz

# Job Processing
JOB_TIMEOUT_MINUTES=30
JOB_RETENTION_HOURS=24
MAX_CONCURRENT_JOBS=5

# Feature Flags
ENABLE_CLAUDE_FALLBACK=false
ENABLE_DOCUMENTATION_GENERATION=true
ENABLE_API_GENERATION=false
```

### `.env.staging` (Staging)
```bash
NODE_ENV=staging
PORT=3001
LOG_LEVEL=info

FRONTEND_URL=https://staging.finishthisidea.com

# Use staging database and Redis
DATABASE_URL=postgresql://user:pass@staging-db:5432/finishthisidea
REDIS_URL=redis://staging-redis:6379

# Production S3 bucket with staging prefix
S3_BUCKET=finishthisidea-staging
AWS_REGION=us-east-1

# Stripe test keys
STRIPE_SECRET_KEY=sk_test_staging_key
STRIPE_WEBHOOK_SECRET=whsec_staging_secret

# Production-like security
JWT_SECRET=staging_jwt_secret_32_chars_long
ENCRYPTION_KEY=staging_encryption_key_32_chars

# Relaxed limits for testing
MAX_FILE_SIZE_MB=100
JOB_TIMEOUT_MINUTES=45

# Enable more features for testing
ENABLE_CLAUDE_FALLBACK=true
ENABLE_DOCUMENTATION_GENERATION=true
ENABLE_API_GENERATION=true
```

### `.env.production` (Production)
```bash
NODE_ENV=production
PORT=3001
LOG_LEVEL=warn

FRONTEND_URL=https://finishthisidea.com

# Production database with connection pooling
DATABASE_URL=postgresql://user:pass@prod-db:5432/finishthisidea?connection_limit=10

# Production Redis with auth
REDIS_URL=redis://:password@prod-redis:6379

# Production S3
S3_BUCKET=finishthisidea-production
AWS_REGION=us-east-1

# Live Stripe keys
STRIPE_SECRET_KEY=sk_live_production_key
STRIPE_WEBHOOK_SECRET=whsec_production_secret

# Strong production secrets
JWT_SECRET=production_jwt_secret_32_chars_long
ENCRYPTION_KEY=production_encryption_key_32_chars

# Production limits
MAX_FILE_SIZE_MB=50
JOB_TIMEOUT_MINUTES=30
MAX_CONCURRENT_JOBS=10

# Production features
ENABLE_CLAUDE_FALLBACK=true
ENABLE_DOCUMENTATION_GENERATION=true
ENABLE_API_GENERATION=false

# Monitoring
SENTRY_DSN=https://your-sentry-dsn@sentry.io/project
```

## 🔄 Environment Loading

### Node.js (Backend)
```typescript
// src/config/environment.ts
import dotenv from 'dotenv';
import { z } from 'zod';

// Load environment file based on NODE_ENV
const envFile = process.env.NODE_ENV === 'production' 
  ? '.env.production'
  : process.env.NODE_ENV === 'staging'
  ? '.env.staging'
  : '.env';

dotenv.config({ path: envFile });

// Environment schema validation
const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'staging', 'production']),
  PORT: z.string().transform(Number),
  DATABASE_URL: z.string().url(),
  REDIS_URL: z.string().url(),
  JWT_SECRET: z.string().min(32),
  STRIPE_SECRET_KEY: z.string(),
  AWS_ACCESS_KEY_ID: z.string(),
  AWS_SECRET_ACCESS_KEY: z.string(),
  S3_BUCKET: z.string(),
  MAX_FILE_SIZE_MB: z.string().transform(Number).default('50'),
});

// Validate and export environment
export const env = envSchema.parse(process.env);
```

### Frontend (Vite)
```typescript
// frontend/src/config/env.ts
interface Environment {
  apiUrl: string;
  stripePublishableKey: string;
  enableDevTools: boolean;
}

export const env: Environment = {
  apiUrl: import.meta.env.VITE_API_URL || '/api',
  stripePublishableKey: import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || '',
  enableDevTools: import.meta.env.VITE_ENABLE_DEV_TOOLS === 'true',
};
```

## 🔧 Configuration Management

### Docker Environment
```yaml
# docker-compose.yml
services:
  api:
    environment:
      - NODE_ENV=${NODE_ENV}
      - DATABASE_URL=${DATABASE_URL}
      - REDIS_URL=${REDIS_URL}
    env_file:
      - .env
```

### Kubernetes ConfigMap
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
data:
  NODE_ENV: "production"
  PORT: "3001"
  FRONTEND_URL: "https://finishthisidea.com"
  MAX_FILE_SIZE_MB: "50"
  JOB_TIMEOUT_MINUTES: "30"
```

### Kubernetes Secrets
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: app-secrets
type: Opaque
stringData:
  DATABASE_URL: "postgresql://user:pass@host:5432/db"
  REDIS_URL: "redis://host:6379"
  JWT_SECRET: "your-jwt-secret"
  STRIPE_SECRET_KEY: "sk_live_..."
  ANTHROPIC_API_KEY: "sk-ant-..."
```

## 🏗️ Environment-Specific Settings

### Development
- **Database**: Local PostgreSQL (port 5434)
- **Redis**: Local Redis (port 6379)
- **Storage**: MinIO (ports 9000-9001)
- **AI**: Local Ollama (port 11434)
- **Logging**: Debug level with console output
- **Hot Reload**: Enabled
- **CORS**: Permissive for localhost

### Staging
- **Database**: Staging PostgreSQL with production-like data
- **Redis**: Staging Redis instance
- **Storage**: S3 with staging bucket
- **AI**: Production Ollama + Claude fallback
- **Logging**: Info level
- **Testing**: Extended timeouts and limits
- **Monitoring**: Basic health checks

### Production
- **Database**: Production PostgreSQL with connection pooling
- **Redis**: Production Redis with authentication
- **Storage**: Production S3 with backup/CDN
- **AI**: Ollama + Claude with proper fallback
- **Logging**: Warn/Error level with structured logs
- **Security**: Strict CORS, rate limiting, encryption
- **Monitoring**: Full observability stack

## 🔒 Security Best Practices

### Secret Management
```bash
# Use strong, unique secrets
JWT_SECRET=$(openssl rand -base64 32)
ENCRYPTION_KEY=$(openssl rand -base64 32)

# Rotate secrets regularly
# Store secrets in secure vault (AWS Secrets Manager, HashiCorp Vault)
```

### Environment Isolation
```bash
# Different databases per environment
DEV_DATABASE_URL=postgresql://localhost:5432/finishthisidea_dev
STAGING_DATABASE_URL=postgresql://staging:5432/finishthisidea_staging
PROD_DATABASE_URL=postgresql://prod:5432/finishthisidea_prod

# Separate S3 buckets
DEV_S3_BUCKET=finishthisidea-dev
STAGING_S3_BUCKET=finishthisidea-staging
PROD_S3_BUCKET=finishthisidea-production
```

### Access Control
```bash
# Use IAM roles in production
# Principle of least privilege
# No hardcoded credentials in code
# Regular access audits
```

## 🔍 Validation & Testing

### Environment Validation
```typescript
// src/utils/validateEnv.ts
export function validateEnvironment() {
  const required = [
    'DATABASE_URL',
    'REDIS_URL',
    'JWT_SECRET',
    'STRIPE_SECRET_KEY'
  ];

  const missing = required.filter(key => !process.env[key]);
  
  if (missing.length > 0) {
    throw new Error(`Missing environment variables: ${missing.join(', ')}`);
  }

  // Test database connection
  // Test Redis connection
  // Validate API keys
}
```

### Health Checks
```typescript
// Environment-specific health checks
export async function healthCheck() {
  return {
    environment: process.env.NODE_ENV,
    database: await testDatabaseConnection(),
    redis: await testRedisConnection(),
    storage: await testStorageConnection(),
    ai: await testAIConnection(),
  };
}
```

## 🐛 Troubleshooting

### Common Issues

**Environment not loading:**
```bash
# Check file exists
ls -la .env*

# Check file permissions
chmod 644 .env

# Verify syntax (no spaces around =)
cat .env | grep -E '^[A-Z_]+=.*'
```

**Database connection failed:**
```bash
# Test connection manually
psql $DATABASE_URL -c "SELECT 1;"

# Check encoding
echo $DATABASE_URL | base64 -d  # if base64 encoded
```

**Redis connection failed:**
```bash
# Test Redis connection
redis-cli -u $REDIS_URL ping
```

**S3 access denied:**
```bash
# Test AWS credentials
aws s3 ls s3://$S3_BUCKET

# Check IAM permissions
aws iam get-user
```

### Environment Debugging

```typescript
// Debug environment loading
console.log('NODE_ENV:', process.env.NODE_ENV);
console.log('Environment variables loaded:', Object.keys(process.env).filter(key => 
  key.startsWith('DATABASE_') || 
  key.startsWith('REDIS_') ||
  key.startsWith('STRIPE_')
));
```

## 📚 Additional Resources

- [Node.js Environment Variables Best Practices](https://nodejs.org/en/learn/command-line/how-to-read-environment-variables-from-nodejs)
- [Docker Environment Variables](https://docs.docker.com/compose/environment-variables/)
- [Kubernetes ConfigMaps and Secrets](https://kubernetes.io/docs/concepts/configuration/)
- [Twelve-Factor App Config](https://12factor.net/config)

---

**Last Updated**: 2024-01-15  
**Config Version**: 1.0.0