import Bull from 'bull';
import { prisma } from '../../utils/database';
import { logger } from '../../utils/logger';
import { analyticsService } from './analytics-integration.service';
import { emailService } from './email.service';
import * as Sentry from '@sentry/node';

interface QueueHealthMetrics {
  queueName: string;
  waiting: number;
  active: number;
  completed: number;
  failed: number;
  delayed: number;
  paused: boolean;
  processingRate: number;
  errorRate: number;
  avgProcessingTime: number;
  oldestJobAge: number;
}

interface HealthThresholds {
  maxWaitingJobs: number;
  maxFailedJobs: number;
  maxJobAge: number; // in milliseconds
  minProcessingRate: number; // jobs per minute
  maxErrorRate: number; // percentage
}

export class QueueHealthMonitor {
  private queues: Map<string, Bull.Queue> = new Map();
  private healthCheckInterval: NodeJS.Timeout | null = null;
  private readonly DEFAULT_THRESHOLDS: HealthThresholds = {
    maxWaitingJobs: 100,
    maxFailedJobs: 10,
    maxJobAge: 30 * 60 * 1000, // 30 minutes
    minProcessingRate: 1, // 1 job per minute minimum
    maxErrorRate: 5, // 5% error rate
  };

  constructor() {
    this.initializeQueues();
  }

  /**
   * Initialize queue connections
   */
  private initializeQueues(): void {
    // Add your queue names here
    const queueNames = ['documentation-queue', 'api-generation-queue', 'email-queue'];
    
    queueNames.forEach(name => {
      const queue = new Bull(name, process.env.REDIS_URL || 'redis://localhost:6379');
      this.queues.set(name, queue);
    });
  }

  /**
   * Start health monitoring
   */
  public startMonitoring(intervalMinutes: number = 5): void {
    // Clear existing interval if any
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
    }

    // Run initial check
    this.checkHealth();

    // Set up recurring checks
    this.healthCheckInterval = setInterval(
      () => this.checkHealth(),
      intervalMinutes * 60 * 1000
    );

    logger.info('Queue health monitoring started', { intervalMinutes });
  }

  /**
   * Stop health monitoring
   */
  public stopMonitoring(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
      logger.info('Queue health monitoring stopped');
    }
  }

  /**
   * Check health of all queues
   */
  public async checkHealth(): Promise<void> {
    try {
      const metrics: QueueHealthMetrics[] = [];
      const issues: string[] = [];

      // Collect metrics for each queue
      for (const [name, queue] of this.queues) {
        const queueMetrics = await this.getQueueMetrics(name, queue);
        metrics.push(queueMetrics);

        // Check for issues
        const queueIssues = this.checkQueueThresholds(queueMetrics);
        issues.push(...queueIssues);
      }

      // Track metrics
      await this.trackMetrics(metrics);

      // Alert if issues found
      if (issues.length > 0) {
        await this.alertOnIssues(issues);
      }

      // Log summary
      logger.info('Queue health check completed', {
        queuesChecked: metrics.length,
        issuesFound: issues.length,
      });
    } catch (error) {
      logger.error('Queue health check failed', { error });
      Sentry.captureException(error, {
        tags: { component: 'queue-health-monitor' },
      });
    }
  }

  /**
   * Get metrics for a specific queue
   */
  private async getQueueMetrics(
    name: string,
    queue: Bull.Queue
  ): Promise<QueueHealthMetrics> {
    const [waiting, active, completed, failed, delayed, paused] = await Promise.all([
      queue.getWaitingCount(),
      queue.getActiveCount(),
      queue.getCompletedCount(),
      queue.getFailedCount(),
      queue.getDelayedCount(),
      queue.isPaused(),
    ]);

    // Calculate processing rate (jobs per minute)
    const recentCompleted = await this.getRecentJobCount(name, 'completed', 5);
    const processingRate = recentCompleted / 5;

    // Calculate error rate
    const totalProcessed = completed + failed;
    const errorRate = totalProcessed > 0 ? (failed / totalProcessed) * 100 : 0;

    // Get average processing time
    const avgProcessingTime = await this.getAverageProcessingTime(name);

    // Get oldest waiting job age
    const oldestJobAge = await this.getOldestJobAge(queue);

    return {
      queueName: name,
      waiting,
      active,
      completed,
      failed,
      delayed,
      paused,
      processingRate,
      errorRate,
      avgProcessingTime,
      oldestJobAge,
    };
  }

  /**
   * Check if queue metrics exceed thresholds
   */
  private checkQueueThresholds(
    metrics: QueueHealthMetrics,
    thresholds: HealthThresholds = this.DEFAULT_THRESHOLDS
  ): string[] {
    const issues: string[] = [];

    if (metrics.waiting > thresholds.maxWaitingJobs) {
      issues.push(
        `Queue ${metrics.queueName}: ${metrics.waiting} waiting jobs exceeds threshold of ${thresholds.maxWaitingJobs}`
      );
    }

    if (metrics.failed > thresholds.maxFailedJobs) {
      issues.push(
        `Queue ${metrics.queueName}: ${metrics.failed} failed jobs exceeds threshold of ${thresholds.maxFailedJobs}`
      );
    }

    if (metrics.oldestJobAge > thresholds.maxJobAge) {
      const ageMinutes = Math.round(metrics.oldestJobAge / 60000);
      issues.push(
        `Queue ${metrics.queueName}: Oldest job is ${ageMinutes} minutes old`
      );
    }

    if (metrics.processingRate < thresholds.minProcessingRate && metrics.waiting > 0) {
      issues.push(
        `Queue ${metrics.queueName}: Processing rate of ${metrics.processingRate.toFixed(2)} jobs/min is below threshold`
      );
    }

    if (metrics.errorRate > thresholds.maxErrorRate) {
      issues.push(
        `Queue ${metrics.queueName}: Error rate of ${metrics.errorRate.toFixed(2)}% exceeds threshold`
      );
    }

    if (metrics.paused) {
      issues.push(`Queue ${metrics.queueName}: Queue is paused`);
    }

    return issues;
  }

  /**
   * Get count of recent jobs by status
   */
  private async getRecentJobCount(
    queueName: string,
    status: string,
    minutes: number
  ): Promise<number> {
    const since = new Date(Date.now() - minutes * 60 * 1000);
    
    // This would query your job tracking database
    // For now, returning placeholder
    return 0;
  }

  /**
   * Get average processing time for recent jobs
   */
  private async getAverageProcessingTime(queueName: string): Promise<number> {
    // Query recent completed jobs and calculate average
    // For now, returning placeholder
    return 0;
  }

  /**
   * Get age of oldest waiting job
   */
  private async getOldestJobAge(queue: Bull.Queue): Promise<number> {
    const waitingJobs = await queue.getWaiting(0, 1);
    if (waitingJobs.length === 0) {
      return 0;
    }

    const oldestJob = waitingJobs[0];
    const createdAt = new Date(oldestJob.timestamp);
    return Date.now() - createdAt.getTime();
  }

  /**
   * Track metrics to analytics
   */
  private async trackMetrics(metrics: QueueHealthMetrics[]): Promise<void> {
    for (const metric of metrics) {
      await analyticsService.track({
        event: 'queue_health_check',
        userId: 'system',
        properties: {
          queue_name: metric.queueName,
          waiting_jobs: metric.waiting,
          active_jobs: metric.active,
          failed_jobs: metric.failed,
          processing_rate: metric.processingRate,
          error_rate: metric.errorRate,
          avg_processing_time: metric.avgProcessingTime,
          oldest_job_age_minutes: Math.round(metric.oldestJobAge / 60000),
        },
      });
    }
  }

  /**
   * Send alerts for issues
   */
  private async alertOnIssues(issues: string[]): Promise<void> {
    // Log to Sentry
    Sentry.captureMessage('Queue health issues detected', {
      level: 'warning',
      extra: { issues },
      tags: { component: 'queue-health-monitor' },
    });

    // Send email alert to admin
    const adminEmail = process.env.ADMIN_EMAIL;
    if (adminEmail) {
      await emailService.sendEmail({
        to: adminEmail,
        subject: 'Queue Health Alert - FinishThisIdea',
        html: this.generateAlertEmail(issues),
      });
    }

    logger.warn('Queue health issues detected', { issues });
  }

  /**
   * Generate alert email HTML
   */
  private generateAlertEmail(issues: string[]): string {
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #ef4444; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background-color: #f8f9fa; }
        .issue { background-color: #fee; padding: 10px; margin: 10px 0; border-left: 4px solid #ef4444; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Queue Health Alert</h1>
        </div>
        <div class="content">
          <p>The following queue health issues have been detected:</p>
          ${issues.map(issue => `<div class="issue">${issue}</div>`).join('')}
          <p>Please investigate and take appropriate action.</p>
        </div>
        <div class="footer">
          <p>© 2024 FinishThisIdea. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
    `;
  }

  /**
   * Get current queue statistics
   */
  public async getQueueStats(): Promise<Record<string, QueueHealthMetrics>> {
    const stats: Record<string, QueueHealthMetrics> = {};

    for (const [name, queue] of this.queues) {
      stats[name] = await this.getQueueMetrics(name, queue);
    }

    return stats;
  }

  /**
   * Manually trigger queue cleanup
   */
  public async cleanupQueues(olderThanDays: number = 7): Promise<void> {
    const cutoffDate = new Date(Date.now() - olderThanDays * 24 * 60 * 60 * 1000);

    for (const [name, queue] of this.queues) {
      try {
        // Clean completed jobs
        await queue.clean(olderThanDays * 24 * 60 * 60 * 1000, 'completed');
        
        // Clean failed jobs
        await queue.clean(olderThanDays * 24 * 60 * 60 * 1000, 'failed');

        logger.info('Queue cleanup completed', { 
          queueName: name, 
          olderThanDays 
        });
      } catch (error) {
        logger.error('Queue cleanup failed', { 
          queueName: name, 
          error 
        });
      }
    }
  }
}

// Export singleton instance
export const queueHealthMonitor = new QueueHealthMonitor();