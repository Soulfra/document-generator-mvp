import { logger } from '../../utils/logger';
import { queueHealthMonitor } from './queue-health-monitor.service';
import { emailService } from './email.service';
import { analyticsService } from './analytics-integration.service';
import automationConfig from '../config/automation-config.json';

export class StartupService {
  private isInitialized = false;

  /**
   * Initialize all automation services
   */
  public async initialize(): Promise<void> {
    if (this.isInitialized) {
      logger.warn('Startup service already initialized');
      return;
    }

    try {
      logger.info('Initializing automation services...');

      // Initialize services based on configuration
      await this.initializeServices();

      this.isInitialized = true;
      logger.info('All automation services initialized successfully');

      // Send startup notification if configured
      await this.sendStartupNotification();
    } catch (error) {
      logger.error('Failed to initialize automation services', { error });
      throw error;
    }
  }

  /**
   * Initialize individual services
   */
  private async initializeServices(): Promise<void> {
    // Start queue health monitoring
    if (automationConfig.features.queueHealthMonitoring) {
      queueHealthMonitor.startMonitoring(automationConfig.queueHealthMonitoring.intervalMinutes);
      logger.info('Queue health monitoring started', {
        interval: automationConfig.queueHealthMonitoring.intervalMinutes,
      });
    }

    // Test email service connection
    if (automationConfig.features.emailNotifications) {
      try {
        await emailService.testConnection();
        logger.info('Email service connection verified');
      } catch (error) {
        logger.warn('Email service connection failed', { error });
      }
    }

    // Test analytics service
    if (automationConfig.features.externalAnalytics) {
      try {
        await analyticsService.track({
          event: 'service_startup',
          userId: 'system',
          properties: {
            environment: process.env.NODE_ENV || 'development',
            version: process.env.npm_package_version || 'unknown',
          },
        });
        logger.info('Analytics service connection verified');
      } catch (error) {
        logger.warn('Analytics service connection failed', { error });
      }
    }
  }

  /**
   * Send startup notification to admin
   */
  private async sendStartupNotification(): Promise<void> {
    const adminEmail = process.env.ADMIN_EMAIL;
    
    if (!adminEmail || !automationConfig.features.emailNotifications) {
      return;
    }

    try {
      const environment = process.env.NODE_ENV || 'development';
      const version = process.env.npm_package_version || 'unknown';
      
      await emailService.sendEmail({
        to: adminEmail,
        subject: `FinishThisIdea Service Started - ${environment}`,
        html: this.generateStartupEmail(environment, version),
      });

      logger.info('Startup notification sent', { adminEmail });
    } catch (error) {
      logger.warn('Failed to send startup notification', { error });
    }
  }

  /**
   * Generate startup notification email
   */
  private generateStartupEmail(environment: string, version: string): string {
    const enabledFeatures = Object.entries(automationConfig.features)
      .filter(([_, enabled]) => enabled)
      .map(([feature, _]) => feature);

    return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #10b981; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background-color: #f8f9fa; }
        .info-box { background-color: #e0f2fe; padding: 15px; margin: 10px 0; border-left: 4px solid #0284c7; }
        .feature-list { list-style-type: none; padding: 0; }
        .feature-list li { background-color: #f0f9ff; padding: 8px; margin: 5px 0; border-radius: 4px; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🚀 Service Started Successfully</h1>
        </div>
        <div class="content">
          <h2>FinishThisIdea Backend Service</h2>
          <div class="info-box">
            <strong>Environment:</strong> ${environment}<br>
            <strong>Version:</strong> ${version}<br>
            <strong>Started:</strong> ${new Date().toISOString()}<br>
            <strong>Server:</strong> ${process.env.SERVER_NAME || 'Unknown'}
          </div>
          
          <h3>Enabled Features:</h3>
          <ul class="feature-list">
            ${enabledFeatures.map(feature => `<li>✅ ${feature}</li>`).join('')}
          </ul>
          
          <h3>Health Check Endpoints:</h3>
          <ul>
            <li><a href="${process.env.API_URL || 'http://localhost:3001'}/health">/health</a> - Basic health check</li>
            <li><a href="${process.env.API_URL || 'http://localhost:3001'}/health/detailed">/health/detailed</a> - Detailed system health</li>
            <li><a href="${process.env.API_URL || 'http://localhost:3001'}/health/queues">/health/queues</a> - Queue health monitoring</li>
          </ul>
          
          <p>All automation services are running and monitoring your application.</p>
        </div>
        <div class="footer">
          <p>© 2024 FinishThisIdea. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
    `;
  }

  /**
   * Graceful shutdown
   */
  public async shutdown(): Promise<void> {
    logger.info('Shutting down automation services...');

    try {
      // Stop queue health monitoring
      queueHealthMonitor.stopMonitoring();

      // Send shutdown notification if configured
      await this.sendShutdownNotification();

      logger.info('Automation services shut down successfully');
    } catch (error) {
      logger.error('Error during shutdown', { error });
    }
  }

  /**
   * Send shutdown notification
   */
  private async sendShutdownNotification(): Promise<void> {
    const adminEmail = process.env.ADMIN_EMAIL;
    
    if (!adminEmail || !automationConfig.features.emailNotifications) {
      return;
    }

    try {
      await emailService.sendEmail({
        to: adminEmail,
        subject: `FinishThisIdea Service Shutdown - ${process.env.NODE_ENV || 'development'}`,
        html: `
        <h2>Service Shutdown</h2>
        <p>The FinishThisIdea backend service has been shut down.</p>
        <p><strong>Time:</strong> ${new Date().toISOString()}</p>
        <p><strong>Environment:</strong> ${process.env.NODE_ENV || 'development'}</p>
        `,
      });
    } catch (error) {
      logger.warn('Failed to send shutdown notification', { error });
    }
  }
}

// Export singleton instance
export const startupService = new StartupService();