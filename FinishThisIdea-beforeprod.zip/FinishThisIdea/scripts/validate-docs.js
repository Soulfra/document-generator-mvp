/**
 * Documentation Validation Script
 * 
 * Validates documentation files for:
 * - YAML front-matter compliance
 * - Required metadata fields
 * - Duplicate document checking
 * - Content quality standards
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

// Required YAML front-matter fields
const REQUIRED_FIELDS = ['title', 'description', 'lastUpdated', 'version'];

// Optional but recommended fields
const RECOMMENDED_FIELDS = ['author', 'tags', 'status'];

// Validation rules
const VALIDATION_RULES = {
  requireFrontMatter: true,
  disallowDuplicateDocs: true,
  maxTitleLength: 100,
  maxDescriptionLength: 300,
  minDescriptionLength: 20,
  requireDateFormat: /^\d{4}-\d{2}-\d{2}$/,
  requireVersionFormat: /^\d+\.\d+(\.\d+)?$/
};

class DocumentationValidator {
  constructor() {
    this.errors = [];
    this.warnings = [];
    this.processedFiles = new Set();
    this.titleMap = new Map(); // Track duplicate titles
  }

  /**
   * Validate all documentation files
   */
  async validateAll() {
    const docsDir = path.join(__dirname, '../docs');
    
    if (!fs.existsSync(docsDir)) {
      this.addError('Documentation directory not found: docs/');
      return this.getResults();
    }

    console.log('🔍 Validating documentation files...\n');

    // Recursively find all .md files
    const markdownFiles = this.findMarkdownFiles(docsDir);
    
    console.log(`Found ${markdownFiles.length} markdown files to validate\n`);

    // Validate each file
    for (const filePath of markdownFiles) {
      await this.validateFile(filePath);
    }

    // Check for duplicate titles
    this.checkDuplicateTitles();

    return this.getResults();
  }

  /**
   * Validate a single file (used by lint-staged)
   */
  async validateFile(filePath) {
    const relativePath = path.relative(process.cwd(), filePath);
    
    if (this.processedFiles.has(relativePath)) {
      return; // Already processed
    }

    this.processedFiles.add(relativePath);

    try {
      if (!fs.existsSync(filePath)) {
        this.addError(`File not found: ${relativePath}`);
        return;
      }

      const content = fs.readFileSync(filePath, 'utf-8');
      
      // Parse front-matter and content
      const { frontMatter, bodyContent } = this.parseFrontMatter(content, relativePath);
      
      // Validate front-matter
      this.validateFrontMatter(frontMatter, relativePath);
      
      // Validate content
      this.validateContent(bodyContent, relativePath);
      
      // Track title for duplicate checking
      if (frontMatter.title) {
        this.trackTitle(frontMatter.title, relativePath);
      }

      console.log(`✅ ${relativePath}`);
      
    } catch (error) {
      this.addError(`Error validating ${relativePath}: ${error.message}`);
      console.log(`❌ ${relativePath}: ${error.message}`);
    }
  }

  /**
   * Find all markdown files recursively
   */
  findMarkdownFiles(dir, files = []) {
    const entries = fs.readdirSync(dir);
    
    for (const entry of entries) {
      const fullPath = path.join(dir, entry);
      const stat = fs.statSync(fullPath);
      
      if (stat.isDirectory()) {
        this.findMarkdownFiles(fullPath, files);
      } else if (entry.endsWith('.md')) {
        files.push(fullPath);
      }
    }
    
    return files;
  }

  /**
   * Parse YAML front-matter from markdown content
   */
  parseFrontMatter(content, filePath) {
    const frontMatterRegex = /^---\s*\n([\s\S]*?)\n---\s*\n([\s\S]*)$/;
    const match = content.match(frontMatterRegex);
    
    if (!match) {
      if (VALIDATION_RULES.requireFrontMatter) {
        this.addError(`Missing YAML front-matter: ${filePath}`);
      }
      return { frontMatter: {}, bodyContent: content };
    }

    try {
      const frontMatter = yaml.load(match[1]) || {};
      const bodyContent = match[2];
      return { frontMatter, bodyContent };
    } catch (error) {
      this.addError(`Invalid YAML front-matter in ${filePath}: ${error.message}`);
      return { frontMatter: {}, bodyContent: match[2] || content };
    }
  }

  /**
   * Validate YAML front-matter
   */
  validateFrontMatter(frontMatter, filePath) {
    // Check required fields
    for (const field of REQUIRED_FIELDS) {
      if (!frontMatter[field]) {
        this.addError(`Missing required field '${field}' in ${filePath}`);
      }
    }

    // Validate field formats
    if (frontMatter.title) {
      if (frontMatter.title.length > VALIDATION_RULES.maxTitleLength) {
        this.addWarning(`Title too long (${frontMatter.title.length} chars) in ${filePath}`);
      }
    }

    if (frontMatter.description) {
      const descLength = frontMatter.description.length;
      if (descLength < VALIDATION_RULES.minDescriptionLength) {
        this.addWarning(`Description too short (${descLength} chars) in ${filePath}`);
      }
      if (descLength > VALIDATION_RULES.maxDescriptionLength) {
        this.addWarning(`Description too long (${descLength} chars) in ${filePath}`);
      }
    }

    if (frontMatter.lastUpdated) {
      if (!VALIDATION_RULES.requireDateFormat.test(frontMatter.lastUpdated)) {
        this.addError(`Invalid date format in lastUpdated field: ${filePath} (expected YYYY-MM-DD)`);
      }
    }

    if (frontMatter.version) {
      if (!VALIDATION_RULES.requireVersionFormat.test(frontMatter.version)) {
        this.addError(`Invalid version format in ${filePath} (expected X.Y or X.Y.Z)`);
      }
    }

    // Check recommended fields
    for (const field of RECOMMENDED_FIELDS) {
      if (!frontMatter[field]) {
        this.addWarning(`Missing recommended field '${field}' in ${filePath}`);
      }
    }
  }

  /**
   * Validate document content
   */
  validateContent(content, filePath) {
    // Check for empty content
    if (!content.trim()) {
      this.addWarning(`Empty document content: ${filePath}`);
      return;
    }

    // Check for proper heading structure
    const lines = content.split('\n');
    let hasH1 = false;
    
    for (const line of lines) {
      if (line.startsWith('# ')) {
        if (hasH1) {
          this.addWarning(`Multiple H1 headings found in ${filePath}`);
        }
        hasH1 = true;
      }
    }

    if (!hasH1) {
      this.addWarning(`No H1 heading found in ${filePath}`);
    }

    // Check for common issues
    if (content.includes('TODO') || content.includes('FIXME')) {
      this.addWarning(`TODO/FIXME comments found in ${filePath}`);
    }

    // Check for broken internal links (simple check)
    const linkRegex = /\[([^\]]+)\]\(([^)]+)\)/g;
    let match;
    while ((match = linkRegex.exec(content)) !== null) {
      const linkPath = match[2];
      if (linkPath.startsWith('./') || linkPath.startsWith('../')) {
        const resolvedPath = path.resolve(path.dirname(filePath), linkPath);
        if (!fs.existsSync(resolvedPath)) {
          this.addWarning(`Broken internal link in ${filePath}: ${linkPath}`);
        }
      }
    }
  }

  /**
   * Track titles for duplicate checking
   */
  trackTitle(title, filePath) {
    const normalizedTitle = title.toLowerCase().trim();
    
    if (this.titleMap.has(normalizedTitle)) {
      const existingPath = this.titleMap.get(normalizedTitle);
      this.addError(`Duplicate title "${title}" found in ${filePath} and ${existingPath}`);
    } else {
      this.titleMap.set(normalizedTitle, filePath);
    }
  }

  /**
   * Check for duplicate titles across all files
   */
  checkDuplicateTitles() {
    if (!VALIDATION_RULES.disallowDuplicateDocs) {
      return;
    }

    // Additional duplicate checking logic if needed
    // (basic duplicate checking is already done in trackTitle)
  }

  /**
   * Add validation error
   */
  addError(message) {
    this.errors.push(message);
  }

  /**
   * Add validation warning
   */
  addWarning(message) {
    this.warnings.push(message);
  }

  /**
   * Get validation results
   */
  getResults() {
    return {
      success: this.errors.length === 0,
      filesProcessed: this.processedFiles.size,
      errors: this.errors,
      warnings: this.warnings,
      summary: {
        totalFiles: this.processedFiles.size,
        errorCount: this.errors.length,
        warningCount: this.warnings.length
      }
    };
  }
}

/**
 * Main function for CLI usage
 */
async function main() {
  const validator = new DocumentationValidator();
  
  // Get files from command line args or validate all
  const args = process.argv.slice(2);
  
  let results;
  if (args.length > 0) {
    // Validate specific files (used by lint-staged)
    console.log(`🔍 Validating ${args.length} file(s)...\n`);
    for (const filePath of args) {
      await validator.validateFile(path.resolve(filePath));
    }
    results = validator.getResults();
  } else {
    // Validate all files
    results = await validator.validateAll();
  }

  // Print results
  console.log('\n📊 Validation Results:');
  console.log('─'.repeat(50));
  console.log(`Files processed: ${results.filesProcessed}`);
  console.log(`Errors: ${results.errors.length}`);
  console.log(`Warnings: ${results.warnings.length}`);

  if (results.errors.length > 0) {
    console.log('\n❌ Errors:');
    results.errors.forEach(error => console.log(`  • ${error}`));
  }

  if (results.warnings.length > 0) {
    console.log('\n⚠️  Warnings:');
    results.warnings.forEach(warning => console.log(`  • ${warning}`));
  }

  if (results.success) {
    console.log('\n✅ All validations passed!');
    process.exit(0);
  } else {
    console.log('\n❌ Validation failed');
    process.exit(1);
  }
}

// Handle script execution
if (require.main === module) {
  main().catch(error => {
    console.error('❌ Documentation validation failed:', error);
    process.exit(1);
  });
}

module.exports = { DocumentationValidator, VALIDATION_RULES };