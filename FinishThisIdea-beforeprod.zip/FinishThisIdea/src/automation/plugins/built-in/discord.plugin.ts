/**
 * Discord Plugin
 * Send messages to Discord channels
 */

import { BasePlugin } from '../base-plugin';
import { PluginMetadata, PluginField, PluginExecutionResult } from '../interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../../interfaces/workflow.interface';
import { DiscordTeamsIntegrationService } from '../../services/discord-teams-integration.service';

export default class DiscordPlugin extends BasePlugin {
  private discordService: DiscordTeamsIntegrationService;
  
  metadata: PluginMetadata = {
    id: 'discord',
    name: 'Discord Message',
    version: '1.0.0',
    description: 'Send messages to Discord channels via webhooks',
    author: 'FinishThisIdea',
    icon: '💬',
    category: 'notification',
    tags: ['discord', 'chat', 'webhook', 'notification']
  };
  
  fields: PluginField[] = [
    {
      name: 'channel',
      label: 'Channel Name',
      type: 'text',
      required: true,
      placeholder: 'general',
      description: 'Discord channel name (configured in automation config)'
    },
    {
      name: 'content',
      label: 'Message Content',
      type: 'textarea',
      required: true,
      placeholder: 'Your message here...',
      description: 'Message text content'
    },
    {
      name: 'username',
      label: 'Bot Username',
      type: 'text',
      required: false,
      placeholder: 'Workflow Bot',
      description: 'Override webhook username'
    },
    {
      name: 'avatar_url',
      label: 'Avatar URL',
      type: 'text',
      required: false,
      placeholder: 'https://example.com/avatar.png',
      description: 'Override webhook avatar'
    },
    {
      name: 'embeds',
      label: 'Rich Embeds',
      type: 'json',
      required: false,
      placeholder: '[{"title": "Status", "description": "Success", "color": 65280}]',
      description: 'Discord rich embeds'
    }
  ];
  
  constructor(config?: Record<string, any>) {
    super(config);
    this.discordService = DiscordTeamsIntegrationService.getInstance();
  }
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    const { channel, content, username, avatar_url, embeds } = step;
    
    if (!channel || !content) {
      return this.failure('Missing required fields: channel, content');
    }
    
    try {
      await this.discordService.initialize();
      
      const { result, duration } = await this.measureExecution(async () => {
        return await this.discordService.sendDiscordMessage(channel, {
          content,
          username,
          avatar_url,
          embeds
        });
      });
      
      return this.success(result, duration, [`Message sent to Discord channel: ${channel}`]);
    } catch (error) {
      return this.failure(`Discord message failed: ${error.message}`);
    }
  }
}