---
title: "API Documentation"
description: "Comprehensive REST API documentation for the Document Generator service"
lastUpdated: "2024-06-28"
version: "1.0"
---

# API Documentation

Comprehensive REST API documentation for the Document Generator service.

## 📚 Overview

The Document Generator API provides endpoints for AI-powered codebase analysis, documentation generation, and project management. All endpoints return JSON responses and support standard HTTP status codes.

**Base URL**: `http://localhost:3001/api`  
**Content-Type**: `application/json`  
**Rate Limiting**: 100 requests/minute per IP

## 🔐 Authentication

Currently, the API operates without authentication for MVP. Future versions will include JWT-based authentication.

```javascript
// Future authentication header
{
  "Authorization": "Bearer <jwt_token>"
}
```

## 📋 Response Format

### Success Response
```json
{
  "success": true,
  "data": { /* response data */ },
  "message": "Operation completed successfully"
}
```

### Error Response
```json
{
  "success": false,
  "error": "Error description",
  "code": "ERROR_CODE",
  "requestId": "unique-request-id"
}
```

### Status Codes
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `404` - Not Found
- `422` - Validation Error
- `429` - Rate Limited
- `500` - Internal Server Error

## 🚀 Core Endpoints

### Health Check

#### GET `/health`
System health and status check.

**Response:**
```json
{
  "status": "ok",
  "timestamp": "2024-01-15T10:30:00Z",
  "version": "1.0.0",
  "services": {
    "database": "healthy",
    "redis": "healthy",
    "ollama": "healthy",
    "storage": "healthy"
  }
}
```

---

## 📁 Upload Management

### Upload File

#### POST `/upload`
Upload a codebase archive for processing.

**Request:**
```bash
curl -X POST http://localhost:3001/api/upload \
  -F "file=@codebase.zip" \
  -F "contextProfileId=ts-strict" \
  -F "options[generateDocs]=true"
```

**Form Data:**
- `file` (required): ZIP/TAR archive of codebase
- `contextProfileId` (optional): Context profile ID
- `options` (optional): Processing options object

**Response (201):**
```json
{
  "success": true,
  "data": {
    "jobId": "job_123456789",
    "uploadId": "upload_987654321",
    "status": "PENDING",
    "estimatedProcessingTime": 300,
    "cost": 1.00,
    "paymentUrl": "https://checkout.stripe.com/..."
  }
}
```

**Error Examples:**
```json
// File too large
{
  "success": false,
  "error": "File size exceeds 50MB limit",
  "code": "FILE_TOO_LARGE"
}

// Invalid file type
{
  "success": false,
  "error": "Only .zip, .tar, .tar.gz files allowed",
  "code": "INVALID_FILE_TYPE"
}
```

---

## 💼 Job Management

### Get Job Status

#### GET `/jobs/:id`
Retrieve current job status and progress.

**Parameters:**
- `id` (required): Job ID

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "job_123456789",
    "status": "PROCESSING",
    "progress": 45,
    "currentStep": "analyzing_code_structure",
    "estimatedTimeRemaining": 180,
    "createdAt": "2024-01-15T10:00:00Z",
    "startedAt": "2024-01-15T10:01:00Z",
    "fileInfo": {
      "originalFileName": "my-project.zip",
      "fileSizeBytes": 2048576,
      "fileCount": 42,
      "languages": ["typescript", "javascript", "css"]
    },
    "cost": 1.00,
    "tokensUsed": 1250,
    "llmProvider": "ollama"
  }
}
```

**Job Statuses:**
- `PENDING` - Waiting for payment
- `PROCESSING` - AI analysis in progress
- `REVIEW` - Ready for user review
- `APPLYING` - Applying approved changes
- `COMPLETED` - Job finished successfully
- `FAILED` - Job failed with errors
- `CANCELLED` - Job cancelled by user

### List Jobs

#### GET `/jobs`
List all jobs for the current session.

**Query Parameters:**
- `status` (optional): Filter by job status
- `limit` (optional): Number of results (default: 20)
- `offset` (optional): Pagination offset

**Response:**
```json
{
  "success": true,
  "data": {
    "jobs": [
      {
        "id": "job_123456789",
        "status": "COMPLETED",
        "originalFileName": "project.zip",
        "createdAt": "2024-01-15T10:00:00Z",
        "completedAt": "2024-01-15T10:05:00Z"
      }
    ],
    "total": 5,
    "hasMore": false
  }
}
```

### Download Results

#### GET `/jobs/:id/download`
Download processed results as a ZIP archive.

**Parameters:**
- `id` (required): Job ID

**Response:**
- Content-Type: `application/zip`
- Content-Disposition: `attachment; filename="project-processed.zip"`

**Example:**
```bash
curl -X GET http://localhost:3001/api/jobs/job_123456789/download \
  --output processed-project.zip
```

---

## 📊 Context Profiles

### List Profiles

#### GET `/profiles`
Get available context profiles for code analysis.

**Response:**
```json
{
  "success": true,
  "data": {
    "profiles": [
      {
        "id": "ts-strict",
        "name": "TypeScript Strict",
        "description": "Strict TypeScript with modern React patterns",
        "language": "typescript",
        "framework": "react",
        "isDefault": true,
        "usageCount": 1250
      },
      {
        "id": "python-pep8",
        "name": "Python PEP 8",
        "description": "PEP 8 compliant Python with Django support",
        "language": "python",
        "framework": "django",
        "isDefault": false,
        "usageCount": 800
      }
    ]
  }
}
```

### Get Profile Details

#### GET `/profiles/:id`
Get detailed configuration for a specific profile.

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "ts-strict",
    "name": "TypeScript Strict",
    "description": "Strict TypeScript with modern React patterns",
    "language": "typescript",
    "framework": "react",
    "version": "1.2.0",
    "data": {
      "parsingRules": {
        "extractFunctions": true,
        "extractTypes": true,
        "extractInterfaces": true
      },
      "codeStandards": {
        "strictMode": true,
        "noImplicitAny": true,
        "preferFunctionalComponents": true
      },
      "documentationTemplates": [
        "api-contract",
        "component-docs",
        "type-definitions"
      ]
    },
    "createdAt": "2024-01-01T00:00:00Z",
    "updatedAt": "2024-01-10T15:30:00Z"
  }
}
```

### Create Custom Profile

#### POST `/profiles`
Create a new custom context profile.

**Request Body:**
```json
{
  "name": "My Custom Profile",
  "description": "Custom profile for Next.js projects",
  "language": "typescript",
  "framework": "nextjs",
  "data": {
    "parsingRules": {
      "extractFunctions": true,
      "extractComponents": true,
      "extractApiRoutes": true
    },
    "codeStandards": {
      "useAppRouter": true,
      "preferServerComponents": true
    }
  }
}
```

**Response (201):**
```json
{
  "success": true,
  "data": {
    "id": "profile_custom_123",
    "name": "My Custom Profile",
    "message": "Profile created successfully"
  }
}
```

---

## 💳 Payment Integration

### Create Checkout Session

#### POST `/payment/checkout`
Create a Stripe checkout session for job payment.

**Request Body:**
```json
{
  "jobId": "job_123456789",
  "successUrl": "http://localhost:3000/success",
  "cancelUrl": "http://localhost:3000/cancel"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "sessionId": "cs_test_123456789",
    "url": "https://checkout.stripe.com/pay/cs_test_123456789",
    "expiresAt": "2024-01-15T11:00:00Z"
  }
}
```

### Payment Webhook

#### POST `/webhook/stripe`
Stripe webhook endpoint for payment status updates.

**Headers:**
- `stripe-signature`: Webhook signature for verification

**Internal endpoint** - not for direct API consumption.

---

## 📄 Documentation Generation

### Generate Documentation

#### POST `/documentation/generate`
Generate documentation for a completed job.

**Request Body:**
```json
{
  "jobId": "job_123456789",
  "templates": ["api-contract", "readme", "data-models"],
  "options": {
    "includeExamples": true,
    "outputFormat": "markdown"
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "documentationId": "doc_123456789",
    "status": "GENERATING",
    "estimatedTime": 60,
    "templates": ["api-contract", "readme", "data-models"]
  }
}
```

### Get Documentation Status

#### GET `/documentation/:id`
Check documentation generation progress.

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "doc_123456789",
    "status": "COMPLETED",
    "downloadUrl": "/api/documentation/doc_123456789/download",
    "generatedFiles": [
      "README.md",
      "API_DOCUMENTATION.md",
      "DATA_MODELS.md"
    ],
    "metadata": {
      "tokensUsed": 2500,
      "qualityScore": 0.92,
      "processingTime": 45
    }
  }
}
```

---

## 🔄 Real-time Updates (WebSocket)

### Connection
```javascript
const socket = io('http://localhost:3001');

// Join job updates room
socket.emit('join', { jobId: 'job_123456789' });
```

### Events

#### Job Progress
```javascript
socket.on('job:progress', (data) => {
  console.log(data);
  // {
  //   jobId: "job_123456789",
  //   progress: 75,
  //   currentStep: "generating_documentation",
  //   message: "Creating API documentation..."
  // }
});
```

#### Job Completed
```javascript
socket.on('job:completed', (data) => {
  console.log(data);
  // {
  //   jobId: "job_123456789",
  //   status: "COMPLETED",
  //   downloadUrl: "/api/jobs/job_123456789/download"
  // }
});
```

#### Job Failed
```javascript
socket.on('job:failed', (data) => {
  console.log(data);
  // {
  //   jobId: "job_123456789",
  //   status: "FAILED",
  //   error: "Failed to parse codebase structure"
  // }
});
```

---

## 📊 Admin Endpoints

### Queue Dashboard

#### GET `/admin/queues`
Access Bull queue dashboard (development only).

**Response:** HTML dashboard interface

### System Stats

#### GET `/admin/stats`
Get system statistics and metrics.

**Response:**
```json
{
  "success": true,
  "data": {
    "jobsProcessed": 1250,
    "activeJobs": 3,
    "queueSize": 8,
    "averageProcessingTime": 285,
    "systemHealth": {
      "cpu": 45.2,
      "memory": 67.8,
      "disk": 23.1
    }
  }
}
```

---

## 🔧 Development & Testing

### API Client Example

```javascript
class DocumentGeneratorAPI {
  constructor(baseURL = 'http://localhost:3001/api') {
    this.baseURL = baseURL;
  }

  async uploadFile(file, options = {}) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('options', JSON.stringify(options));

    const response = await fetch(`${this.baseURL}/upload`, {
      method: 'POST',
      body: formData,
    });

    return response.json();
  }

  async getJobStatus(jobId) {
    const response = await fetch(`${this.baseURL}/jobs/${jobId}`);
    return response.json();
  }

  async downloadResults(jobId) {
    const response = await fetch(`${this.baseURL}/jobs/${jobId}/download`);
    return response.blob();
  }
}

// Usage
const api = new DocumentGeneratorAPI();
const result = await api.uploadFile(file, { generateDocs: true });
```

### Error Handling

```javascript
try {
  const response = await api.uploadFile(file);
  if (!response.success) {
    throw new Error(response.error);
  }
  // Handle success
} catch (error) {
  switch (error.code) {
    case 'FILE_TOO_LARGE':
      alert('File is too large. Maximum size is 50MB.');
      break;
    case 'INVALID_FILE_TYPE':
      alert('Please upload a ZIP or TAR archive.');
      break;
    default:
      alert('An error occurred. Please try again.');
  }
}
```

## 📝 Testing the API

### Using cURL

```bash
# Upload a file
curl -X POST http://localhost:3001/api/upload \
  -F "file=@test-project.zip" \
  -F "contextProfileId=ts-strict"

# Check job status
curl -X GET http://localhost:3001/api/jobs/job_123456789

# Download results
curl -X GET http://localhost:3001/api/jobs/job_123456789/download \
  --output results.zip
```

### Using Postman

Import the API collection: [Download Postman Collection](./postman-collection.json)

---

## 🚀 API Versioning

Current version: `v1` (implicit)  
Future versions will use URL versioning: `/api/v2/upload`

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/your-repo/issues)
- **Discord**: [Developer Community](https://discord.gg/your-server)
- **Email**: api-support@finishthisidea.com

---

**Last Updated**: 2024-01-15  
**API Version**: 1.0.0