/**
 * Script Plugin
 * Executes shell scripts as workflow steps
 */

import { BasePlugin } from '../base-plugin';
import { PluginMetadata, PluginField, PluginExecutionResult } from '../interfaces/plugin.interface';
import { WorkflowStep, WorkflowContext } from '../../interfaces/workflow.interface';
import { exec } from 'child_process';
import { promisify } from 'util';
import * as path from 'path';
import * as fs from 'fs/promises';
import { v4 as uuidv4 } from 'uuid';

const execAsync = promisify(exec);

export default class ScriptPlugin extends BasePlugin {
  metadata: PluginMetadata = {
    id: 'script',
    name: 'Shell Script',
    version: '1.0.0',
    description: 'Execute shell scripts with optional environment variables',
    author: 'FinishThisIdea',
    icon: '📜',
    category: 'utility',
    tags: ['bash', 'shell', 'script', 'command']
  };
  
  fields: PluginField[] = [
    {
      name: 'script',
      label: 'Script',
      type: 'textarea',
      required: true,
      placeholder: '#!/bin/bash\necho "Hello, World!"',
      description: 'Shell script to execute'
    },
    {
      name: 'interpreter',
      label: 'Interpreter',
      type: 'select',
      required: false,
      default: '/bin/bash',
      options: [
        { value: '/bin/bash', label: 'Bash' },
        { value: '/bin/sh', label: 'Shell' },
        { value: '/usr/bin/python3', label: 'Python 3' },
        { value: '/usr/bin/node', label: 'Node.js' }
      ],
      description: 'Script interpreter to use'
    },
    {
      name: 'workingDir',
      label: 'Working Directory',
      type: 'text',
      required: false,
      placeholder: '/tmp',
      description: 'Directory to execute the script in'
    },
    {
      name: 'env',
      label: 'Environment Variables',
      type: 'json',
      required: false,
      placeholder: '{"KEY": "value"}',
      description: 'Additional environment variables'
    },
    {
      name: 'captureOutput',
      label: 'Capture Output',
      type: 'boolean',
      required: false,
      default: true,
      description: 'Whether to capture script output'
    },
    {
      name: 'timeout',
      label: 'Timeout (seconds)',
      type: 'number',
      required: false,
      default: 300,
      validation: {
        min: 1,
        max: 3600
      },
      description: 'Maximum execution time in seconds'
    }
  ];
  
  async execute(step: WorkflowStep, context: WorkflowContext): Promise<PluginExecutionResult> {
    const { script, interpreter = '/bin/bash', workingDir, env = {}, captureOutput = true, timeout = 300 } = step;
    
    if (!script) {
      return this.failure('No script provided');
    }
    
    try {
      const { result: output, duration } = await this.measureExecution(async () => {
        // Create temporary script file
        const tempDir = '/tmp/workflow-scripts';
        await fs.mkdir(tempDir, { recursive: true });
        
        const scriptFile = path.join(tempDir, `script-${uuidv4()}.sh`);
        await fs.writeFile(scriptFile, script, { mode: 0o755 });
        
        try {
          // Execute script
          const { stdout, stderr } = await execAsync(`${interpreter} ${scriptFile}`, {
            cwd: workingDir || process.cwd(),
            env: { ...process.env, ...env },
            timeout: timeout * 1000
          });
          
          // Clean up
          await fs.unlink(scriptFile).catch(() => {});
          
          return captureOutput ? { stdout, stderr } : { message: 'Script executed successfully' };
          
        } catch (error) {
          // Clean up on error
          await fs.unlink(scriptFile).catch(() => {});
          throw error;
        }
      });
      
      this.logger.info(`Script executed successfully in ${duration}ms`);
      
      return this.success(output, duration, [
        `Script executed with ${interpreter}`,
        workingDir ? `Working directory: ${workingDir}` : null
      ].filter(Boolean));
      
    } catch (error) {
      this.logger.error('Script execution failed:', error);
      
      if (error.code === 'ETIMEDOUT') {
        return this.failure(`Script execution timed out after ${timeout} seconds`);
      }
      
      return this.failure(`Script execution failed: ${error.message}`);
    }
  }
  
  async testConnection(): Promise<{ success: boolean; message?: string }> {
    try {
      const { stdout } = await execAsync('echo "Test successful"');
      return {
        success: true,
        message: 'Shell execution is available'
      };
    } catch (error) {
      return {
        success: false,
        message: `Shell execution test failed: ${error.message}`
      };
    }
  }
}