import { templateTransformationService } from '../src/services/template-transformations.service';
import { CodeAnalysis, APIEndpoint, DataModel, FunctionSignature, BusinessRule } from '../src/services/documentation.service';

describe('TemplateTransformationService', () => {
  const mockCodeAnalysis: CodeAnalysis = {
    projectInfo: {
      name: 'Test Project',
      description: 'A test project for documentation generation',
      type: 'webapp',
      language: 'typescript',
      framework: 'react',
    },
    apis: [
      {
        method: 'GET',
        path: '/api/users',
        description: 'Get all users',
        parameters: [
          { name: 'limit', type: 'number', required: false, description: 'Maximum number of users to return' }
        ],
        responses: { '200': { description: 'List of users' } },
        authentication: 'Bearer token',
      },
      {
        method: 'POST',
        path: '/api/users',
        description: 'Create a new user',
        parameters: [
          { name: 'name', type: 'string', required: true, description: 'User name' }
        ],
        responses: { '201': { description: 'User created' } },
      },
    ] as APIEndpoint[],
    dataModels: [
      {
        name: 'User',
        type: 'table',
        fields: [
          { name: 'id', type: 'string', required: true, description: 'User ID' },
          { name: 'name', type: 'string', required: true, description: 'User name' },
          { name: 'email', type: 'string', required: true, description: 'User email' },
        ],
        relationships: [
          { type: 'one-to-many', target: 'Post', field: 'userId' }
        ],
        indexes: ['email'],
      },
    ] as DataModel[],
    functions: [
      {
        name: 'validateUser',
        description: 'Validates user input data',
        parameters: [
          { name: 'userData', type: 'UserData', required: true, description: 'User data to validate' }
        ],
        returnType: 'boolean',
        complexity: 3,
        linesOfCode: 25,
        testCoverage: 85,
      },
    ] as FunctionSignature[],
    dependencies: [
      { name: 'react', version: '^18.0.0', type: 'production' },
      { name: 'express', version: '^4.18.0', type: 'production' },
      { name: 'jest', version: '^29.0.0', type: 'development' },
    ],
    testCoverage: {
      coverage: 75,
      testFiles: 12,
      testCases: 45,
      passingTests: 43,
      failingTests: 2,
    },
    architecture: {
      pattern: 'MVC',
      layers: ['presentation', 'business', 'data'],
      components: [
        { name: 'UserController', type: 'controller' },
        { name: 'UserService', type: 'service' },
        { name: 'UserRepository', type: 'repository' },
      ],
    },
    businessLogic: [
      {
        id: 'br-001',
        description: 'Users must have unique email addresses',
        implementation: 'Database unique constraint + validation',
      },
      {
        id: 'br-002',
        description: 'User passwords must be at least 8 characters',
        implementation: 'Frontend and backend validation',
      },
    ] as BusinessRule[],
    fileStructure: {
      totalFiles: 45,
      linesOfCode: 2350,
      directories: ['src', 'tests', 'docs'],
      mainFiles: ['src/app.ts', 'src/server.ts'],
    },
  };

  describe('Executive Summary Transformations', () => {
    it('should expand description to vision', async () => {
      const result = await templateTransformationService.transform(
        'expandToVision',
        'A test project for documentation generation',
        mockCodeAnalysis
      );

      expect(result).toContain('A test project for documentation generation');
      expect(result).toContain('high-quality software');
      expect(result).toContain('user needs');
    });

    it('should extract primary goals from business logic', async () => {
      const result = await templateTransformationService.transform(
        'extractPrimaryGoals',
        mockCodeAnalysis.businessLogic,
        mockCodeAnalysis
      );

      expect(result).toContain('Users must have unique email addresses');
      expect(result).toContain('User passwords must be at least 8 characters');
      expect(result).toMatch(/^- /m); // Should start lines with bullet points
    });

    it('should generate tech stack from dependencies', async () => {
      const result = await templateTransformationService.transform(
        'generateTechStack',
        mockCodeAnalysis.dependencies,
        mockCodeAnalysis
      );

      expect(result).toContain('Production Dependencies');
      expect(result).toContain('react');
      expect(result).toContain('express');
      expect(result).toContain('Development Dependencies');
      expect(result).toContain('jest');
    });

    it('should format languages properly', async () => {
      const result = await templateTransformationService.transform(
        'formatLanguages',
        'typescript',
        mockCodeAnalysis
      );

      expect(result).toBe('Typescript');
    });

    it('should extract key features from APIs', async () => {
      const result = await templateTransformationService.transform(
        'extractKeyFeatures',
        mockCodeAnalysis.apis,
        mockCodeAnalysis
      );

      expect(result).toContain('GET /api/users');
      expect(result).toContain('POST /api/users');
      expect(result).toContain('Get all users');
      expect(result).toContain('Create a new user');
    });
  });

  describe('API Contract Transformations', () => {
    it('should generate endpoint table', async () => {
      const result = await templateTransformationService.transform(
        'generateEndpointTable',
        mockCodeAnalysis.apis,
        mockCodeAnalysis
      );

      expect(result).toContain('| Method | Endpoint | Description |');
      expect(result).toContain('| GET | /api/users | Get all users |');
      expect(result).toContain('| POST | /api/users | Create a new user |');
    });

    it('should generate endpoint details', async () => {
      const result = await templateTransformationService.transform(
        'generateEndpointDetails',
        mockCodeAnalysis.apis,
        mockCodeAnalysis
      );

      expect(result).toContain('### GET /api/users');
      expect(result).toContain('Get all users');
      expect(result).toContain('**Parameters:**');
      expect(result).toContain('limit');
      expect(result).toContain('**Authentication:**');
    });

    it('should generate OpenAPI specification', async () => {
      const result = await templateTransformationService.transform(
        'generateOpenAPISpec',
        mockCodeAnalysis.apis,
        mockCodeAnalysis
      );

      expect(result).toContain('openapi: 3.0.0');
      expect(result).toContain('Test Project');
      expect(result).toContain('/api/users');
      expect(result).toContain('get:');
      expect(result).toContain('post:');
    });

    it('should extract authentication details', async () => {
      const result = await templateTransformationService.transform(
        'extractAuthDetails',
        mockCodeAnalysis.apis,
        mockCodeAnalysis
      );

      expect(result).toContain('Authentication Methods');
      expect(result).toContain('Bearer token');
    });

    it('should generate rate limits', async () => {
      const result = await templateTransformationService.transform(
        'generateRateLimits',
        mockCodeAnalysis.apis,
        mockCodeAnalysis
      );

      expect(result).toContain('Rate Limiting');
      expect(result).toContain('100 requests per minute');
      expect(result).toContain('X-RateLimit-Limit');
    });

    it('should extract error codes', async () => {
      const result = await templateTransformationService.transform(
        'extractErrorCodes',
        mockCodeAnalysis.apis,
        mockCodeAnalysis
      );

      expect(result).toContain('| Code | Description |');
      expect(result).toContain('| 400 | Bad Request');
      expect(result).toContain('| 401 | Unauthorized');
      expect(result).toContain('| 404 | Not Found');
    });
  });

  describe('Data Model Transformations', () => {
    it('should list primary entities', async () => {
      const result = await templateTransformationService.transform(
        'listPrimaryEntities',
        mockCodeAnalysis.dataModels,
        mockCodeAnalysis
      );

      expect(result).toBe('User');
    });

    it('should generate ER diagram', async () => {
      const result = await templateTransformationService.transform(
        'generateERDiagram',
        mockCodeAnalysis.dataModels,
        mockCodeAnalysis
      );

      expect(result).toContain('[User]');
      expect(result).toContain('one-to-many -> [Post]');
    });

    it('should summarize relationships', async () => {
      const result = await templateTransformationService.transform(
        'summarizeRelationships',
        mockCodeAnalysis.dataModels,
        mockCodeAnalysis
      );

      expect(result).toContain('**User** has one-to-many relationship with **Post**');
    });

    it('should generate schema details', async () => {
      const result = await templateTransformationService.transform(
        'generateSchemaDetails',
        mockCodeAnalysis.dataModels,
        mockCodeAnalysis
      );

      expect(result).toContain('### User');
      expect(result).toContain('**Type**: table');
      expect(result).toContain('**Fields**:');
      expect(result).toContain('`id` (string) *required*');
      expect(result).toContain('`email` (string) *required*');
    });

    it('should generate field tables', async () => {
      const result = await templateTransformationService.transform(
        'generateFieldTables',
        mockCodeAnalysis.dataModels,
        mockCodeAnalysis
      );

      expect(result).toContain('| Field | Type | Required | Description |');
      expect(result).toContain('| id | string | Yes | User ID |');
      expect(result).toContain('| name | string | Yes | User name |');
      expect(result).toContain('| email | string | Yes | User email |');
    });

    it('should extract validation rules', async () => {
      const result = await templateTransformationService.transform(
        'extractValidationRules',
        [
          {
            ...mockCodeAnalysis.dataModels[0],
            fields: [
              { name: 'email', type: 'string', required: true, constraints: ['unique', 'email-format'] }
            ]
          }
        ],
        mockCodeAnalysis
      );

      expect(result).toContain('**User.email**: unique, email-format');
    });

    it('should list indexes', async () => {
      const result = await templateTransformationService.transform(
        'listIndexes',
        mockCodeAnalysis.dataModels,
        mockCodeAnalysis
      );

      expect(result).toContain('**User**: email');
    });

    it('should generate optimization notes', async () => {
      const result = await templateTransformationService.transform(
        'generateOptimizationNotes',
        mockCodeAnalysis.dataModels,
        mockCodeAnalysis
      );

      expect(result).toContain('Query Optimization Recommendations');
      expect(result).toContain('Consider adding indexes');
      expect(result).toContain('**User**: Consider indexing primary lookup fields');
    });
  });

  describe('Test Plan Transformations', () => {
    it('should generate testable function list', async () => {
      const result = await templateTransformationService.transform(
        'generateTestableFunction',
        mockCodeAnalysis.functions,
        mockCodeAnalysis
      );

      expect(result).toContain('### validateUser');
      expect(result).toContain('Validates user input data');
      expect(result).toContain('**Complexity**: 3/10');
      expect(result).toContain('**Test Priority**: Medium');
      expect(result).toContain('**Current Coverage**: 85%');
    });

    it('should generate business logic tests', async () => {
      const result = await templateTransformationService.transform(
        'generateBusinessLogicTests',
        mockCodeAnalysis.businessLogic,
        mockCodeAnalysis
      );

      expect(result).toContain('Test: Users must have unique email addresses');
      expect(result).toContain('Test: User passwords must be at least 8 characters');
    });

    it('should generate API tests', async () => {
      const result = await templateTransformationService.transform(
        'generateAPITests',
        mockCodeAnalysis.apis,
        mockCodeAnalysis
      );

      expect(result).toContain('#### GET /api/users');
      expect(result).toContain('Test successful response');
      expect(result).toContain('Test error handling');
      expect(result).toContain('Test parameter validation');
      expect(result).toContain('Test authentication');
    });

    it('should generate database tests', async () => {
      const result = await templateTransformationService.transform(
        'generateDatabaseTests',
        mockCodeAnalysis.dataModels,
        mockCodeAnalysis
      );

      expect(result).toContain('#### User Model');
      expect(result).toContain('Test CRUD operations');
      expect(result).toContain('Test field validation');
      expect(result).toContain('Test relationship integrity');
      expect(result).toContain('Test index performance');
    });

    it('should generate test data requirements', async () => {
      const result = await templateTransformationService.transform(
        'generateTestDataRequirements',
        mockCodeAnalysis.dataModels,
        mockCodeAnalysis
      );

      expect(result).toContain('### User');
      expect(result).toContain('Valid test records with all required fields');
      expect(result).toContain('Invalid test records for validation testing');
      expect(result).toContain('Edge case data for boundary testing');
    });

    it('should generate mock data examples', async () => {
      const result = await templateTransformationService.transform(
        'generateMockDataExamples',
        mockCodeAnalysis.dataModels,
        mockCodeAnalysis
      );

      expect(result).toContain('### User Example');
      expect(result).toContain('```json');
      expect(result).toContain('"id": "Sample text"');
      expect(result).toContain('"name": "Sample text"');
      expect(result).toContain('"email": "user@example.com"');
    });
  });

  describe('Error Handling', () => {
    it('should handle unknown transformations gracefully', async () => {
      const result = await templateTransformationService.transform(
        'unknownTransformation',
        'test data',
        mockCodeAnalysis
      );

      expect(result).toBe('test data');
    });

    it('should handle null/undefined data gracefully', async () => {
      const result = await templateTransformationService.transform(
        'extractKeyFeatures',
        null,
        mockCodeAnalysis
      );

      expect(result).toContain('Core application functionality');
    });

    it('should handle empty arrays gracefully', async () => {
      const result = await templateTransformationService.transform(
        'generateEndpointTable',
        [],
        mockCodeAnalysis
      );

      expect(result).toContain('No endpoints found');
    });
  });
});