// Core code analysis types for multi-language parsing system

export interface CodeAnalysis {
  projectInfo: {
    name: string;
    description: string;
    type: string; // webapp, api, library, etc.
    language: string;
    framework?: string;
  };
  apis: APIEndpoint[];
  dataModels: DataModel[];
  functions: FunctionSignature[];
  dependencies: Dependency[];
  testCoverage: TestMetrics;
  architecture: ArchitectureInfo;
  businessLogic: BusinessRule[];
  fileStructure: FileStructure;
}

export interface APIEndpoint {
  method: string;
  path: string;
  description: string;
  parameters: Parameter[];
  requestBody?: any;
  responses: Record<string, any>;
  authentication?: string;
}

export interface DataModel {
  name: string;
  type: string; // table, document, etc.
  fields: Field[];
  relationships: Relationship[];
  indexes?: string[];
  // Additional fields that parsers populate
  description?: string;   // Model description
  size?: number;         // Number of fields/properties
}

export interface Field {
  name: string;
  type: string;
  required: boolean;
  description?: string;
  constraints?: string[];
}

export interface Relationship {
  type: string; // one-to-many, many-to-many, etc.
  target: string;
  field: string;
}

export interface FunctionSignature {
  name: string;
  description: string;
  parameters: Parameter[];
  returnType: string;
  complexity: number;
  linesOfCode: number;
  testCoverage?: number;
  // Additional fields that parsers populate
  file?: string;           // Source file path
  line?: number;          // Line number where function starts  
  visibility?: string;    // public, private, protected
  async?: boolean;        // Whether function is async
}

export interface Parameter {
  name: string;
  type: string;
  required: boolean;
  description?: string;
}

export interface Dependency {
  name: string;
  version?: string;        // Made optional - not all deps have detectable versions
  type: string; // production, development
  license?: string;
  description?: string;
  source?: string;         // Where dependency was found (package.json, requirements.txt, etc.)
}

export interface TestMetrics {
  coverage: number;
  testFiles: number;
  testCases: number;
  passingTests: number;
  failingTests: number;
}

export interface ArchitectureInfo {
  pattern: string; // MVC, microservices, etc.
  layers: string[];
  components: Component[];
  // Additional fields that parsers may populate
  style?: string;         // Architecture style information
}

export interface Component {
  name: string;
  type: string;
  responsibilities: string[];
  dependencies: string[];
}

export interface BusinessRule {
  id: string;
  description: string;
  implementation: string;
  relatedFunctions: string[];
}

export interface FileStructure {
  rootDir: string;
  structure: FileNode;
  totalFiles: number;        // Total number of files analyzed
  linesOfCode: number;       // Total lines of code across all files
  directories: string[];     // List of main directories
  mainFiles: string[];       // Main entry point files (app.ts, index.js, etc.)
}

export interface FileNode {
  name: string;
  type: 'file' | 'directory';
  path: string;
  children?: FileNode[];
  metadata?: {
    language?: string;
    purpose?: string;
    linesOfCode?: number;
  };
}

// Language detection types
export interface LanguageDetectionResult {
  primary: string;
  secondary: string[];
  confidence: number;
  framework?: string;
  packageManager?: string;
  evidence: Record<string, number>;
}

// Parser integration types
export interface ParserIntegrationOptions {
  includePrivate?: boolean;
  includeTests?: boolean;
  maxDepth?: number;
  followImports?: boolean;
  primaryLanguageOnly?: boolean;
}