import { APIEndpoint, DataModel, FunctionSignature } from '../types/code-analysis';
import { logger } from '../utils/logger';

export interface ParserOptions {
  includePrivate?: boolean;
  includeTests?: boolean;
  maxDepth?: number;
  followImports?: boolean;
}

export interface ParseResult {
  apis: APIEndpoint[];
  functions: FunctionSignature[];
  dataModels: DataModel[];
  dependencies: Dependency[];
  imports: ImportStatement[];
  comments: Comment[];
  errors: ParseError[];
}

export interface Dependency {
  name: string;
  version?: string;
  type: 'runtime' | 'dev' | 'peer' | 'optional';
  source: string; // Where it was found (package.json, requirements.txt, etc.)
}

export interface ImportStatement {
  source: string;
  imports: string[];
  isRelative: boolean;
  isWildcard: boolean;
  alias?: string;
  line: number;
  file: string;
}

export interface Comment {
  type: 'single' | 'multi' | 'doc';
  content: string;
  line: number;
  file: string;
  associatedWith?: string; // Function/class name if applicable
}

export interface ParseError {
  file: string;
  line?: number;
  message: string;
  severity: 'error' | 'warning';
}

/**
 * Abstract base class for all language parsers
 */
export abstract class BaseParser {
  protected options: ParserOptions;
  protected errors: ParseError[] = [];

  constructor(options: ParserOptions = {}) {
    this.options = {
      includePrivate: false,
      includeTests: false,
      maxDepth: 10,
      followImports: true,
      ...options
    };
  }

  /**
   * Parse all files and extract structured information
   */
  abstract parse(files: Map<string, string>): Promise<ParseResult>;

  /**
   * Extract API endpoints from files
   */
  abstract extractAPIs(files: Map<string, string>): Promise<APIEndpoint[]>;

  /**
   * Extract function signatures from files
   */
  abstract extractFunctions(files: Map<string, string>): Promise<FunctionSignature[]>;

  /**
   * Extract data models/classes/interfaces from files
   */
  abstract extractDataModels(files: Map<string, string>): Promise<DataModel[]>;

  /**
   * Extract dependencies from package files
   */
  abstract extractDependencies(files: Map<string, string>): Promise<Dependency[]>;

  /**
   * Extract import statements from files
   */
  abstract extractImports(files: Map<string, string>): Promise<ImportStatement[]>;

  /**
   * Extract comments and documentation from files
   */
  abstract extractComments(files: Map<string, string>): Promise<Comment[]>;

  /**
   * Get file extensions this parser handles
   */
  abstract getSupportedExtensions(): string[];

  /**
   * Get language identifier
   */
  abstract getLanguage(): string;

  /**
   * Check if a file should be parsed based on extension and options
   */
  protected shouldParseFile(filename: string): boolean {
    const ext = this.getFileExtension(filename);
    if (!this.getSupportedExtensions().includes(ext)) {
      return false;
    }

    // Skip test files if not included
    if (!this.options.includeTests && this.isTestFile(filename)) {
      return false;
    }

    // Skip vendor/node_modules files
    if (this.isVendorFile(filename)) {
      return false;
    }

    return true;
  }

  /**
   * Get file extension including the dot
   */
  protected getFileExtension(filename: string): string {
    const lastDot = filename.lastIndexOf('.');
    return lastDot >= 0 ? filename.slice(lastDot) : '';
  }

  /**
   * Check if file is a test file
   */
  protected isTestFile(filename: string): boolean {
    const testPatterns = [
      /\.test\./i,
      /\.spec\./i,
      /_test\./i,
      /_spec\./i,
      /\/tests?\//i,
      /\/specs?\//i,
      /\/\_\_tests\_\_\//i
    ];

    return testPatterns.some(pattern => pattern.test(filename));
  }

  /**
   * Check if file is from vendor/external dependencies
   */
  protected isVendorFile(filename: string): boolean {
    const vendorPatterns = [
      /node_modules\//,
      /vendor\//,
      /packages\//,
      /bower_components\//,
      /\.pnpm\//,
      /venv\//,
      /virtualenv\//,
      /site-packages\//,
      /target\//,
      /build\//,
      /dist\//,
      /out\//
    ];

    return vendorPatterns.some(pattern => pattern.test(filename));
  }

  /**
   * Add a parse error
   */
  protected addError(file: string, message: string, line?: number, severity: 'error' | 'warning' = 'error'): void {
    this.errors.push({ file, message, line, severity });
    logger.warn(`Parse ${severity} in ${file}${line ? `:${line}` : ''}: ${message}`);
  }

  /**
   * Extract line number from position in text
   */
  protected getLineNumber(text: string, position: number): number {
    const lines = text.substring(0, position).split('\n');
    return lines.length;
  }

  /**
   * Common method to extract string literals from various quote styles
   */
  protected extractStringLiteral(text: string, startPos: number): { value: string; endPos: number } | null {
    const quoteChars = ['"', "'", '`'];
    const char = text[startPos];
    
    if (!char || !quoteChars.includes(char)) {
      return null;
    }

    let endPos = startPos + 1;
    let escaped = false;

    while (endPos < text.length) {
      const currentChar = text[endPos];
      
      if (escaped) {
        escaped = false;
      } else if (currentChar === '\\') {
        escaped = true;
      } else if (currentChar === char) {
        return {
          value: text.substring(startPos + 1, endPos),
          endPos: endPos + 1
        };
      }
      
      endPos++;
    }

    return null; // Unterminated string
  }

  /**
   * Check if a function/variable name indicates private access
   */
  protected isPrivate(name: string): boolean {
    // Common patterns across languages
    return name.startsWith('_') || name.startsWith('private') || name.includes('Private');
  }

  /**
   * Clean and normalize documentation comments
   */
  protected cleanDocComment(comment: string): string {
    // Remove comment markers
    let cleaned = comment
      .replace(/^\/\*\*?/, '')
      .replace(/\*\/$/, '')
      .replace(/^\s*\* ?/gm, '')
      .trim();

    // Remove common doc tags for cleaner reading
    cleaned = cleaned
      .replace(/@param\s+\{[^}]+\}/g, '@param')
      .replace(/@returns?\s+\{[^}]+\}/g, '@returns')
      .replace(/@throws?\s+\{[^}]+\}/g, '@throws');

    return cleaned;
  }

  /**
   * Extract visibility/access modifier from common patterns
   */
  protected extractVisibility(text: string): 'public' | 'private' | 'protected' | undefined {
    const visibilityPattern = /\b(public|private|protected)\b/;
    const match = text.match(visibilityPattern);
    return match ? match[1] as 'public' | 'private' | 'protected' : undefined;
  }

  /**
   * Common HTTP method detection
   */
  protected detectHttpMethod(text: string): string | undefined {
    const methods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'];
    const methodPattern = new RegExp(`\\b(${methods.join('|')})\\b`, 'i');
    const match = text.match(methodPattern);
    return match && match[1] ? match[1].toUpperCase() : undefined;
  }

  /**
   * Extract route path from various patterns
   */
  protected extractRoutePath(text: string): string | undefined {
    // Common patterns: "/api/users", '/api/users', `/api/users`
    const routePattern = /["'`](\/[^"'`]*?)["'`]/;
    const match = text.match(routePattern);
    return match ? match[1] : undefined;
  }

  /**
   * Merge parse results from multiple sources
   */
  protected mergeResults(...results: Partial<ParseResult>[]): ParseResult {
    const merged: ParseResult = {
      apis: [],
      functions: [],
      dataModels: [],
      dependencies: [],
      imports: [],
      comments: [],
      errors: []
    };

    for (const result of results) {
      if (result.apis) merged.apis.push(...result.apis);
      if (result.functions) merged.functions.push(...result.functions);
      if (result.dataModels) merged.dataModels.push(...result.dataModels);
      if (result.dependencies) merged.dependencies.push(...result.dependencies);
      if (result.imports) merged.imports.push(...result.imports);
      if (result.comments) merged.comments.push(...result.comments);
      if (result.errors) merged.errors.push(...result.errors);
    }

    // Add any errors collected during parsing
    merged.errors.push(...this.errors);

    return merged;
  }

  /**
   * Deduplicate items by a key function
   */
  protected deduplicate<T>(items: T[], keyFn: (item: T) => string): T[] {
    const seen = new Map<string, T>();
    
    for (const item of items) {
      const key = keyFn(item);
      if (!seen.has(key)) {
        seen.set(key, item);
      }
    }

    return Array.from(seen.values());
  }
}