import { SampleGenerator } from '../utils/sample-generator';
import { ZipManager } from '../utils/zip-manager';
import { fileProcessingService } from '../../src/services/file-processing.service';
import { documentationService } from '../../src/services/documentation.service';
import * as fs from 'fs/promises';
import * as path from 'path';
import * as os from 'os';

describe('Production Workflow Multi-Language E2E Test', () => {
  let tempDir: string;
  
  beforeAll(async () => {
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'production-workflow-'));
    console.log('🚀 Starting production workflow test in:', tempDir);
  });

  afterAll(async () => {
    await fs.rm(tempDir, { recursive: true, force: true });
    console.log('✅ Cleanup completed');
  });

  it('should process a full-stack TypeScript/Python project through the complete workflow', async () => {
    // Generate a realistic full-stack project
    const projectFiles = {
      // Frontend - Next.js TypeScript
      'package.json': JSON.stringify({
        name: 'fullstack-ecommerce',
        description: 'Full-stack e-commerce platform with React frontend and Python backend',
        dependencies: {
          'next': '^14.0.0',
          'react': '^18.0.0',
          'react-dom': '^18.0.0',
          'axios': '^1.0.0',
          'zustand': '^4.0.0'
        },
        devDependencies: {
          'typescript': '^5.0.0',
          '@types/react': '^18.0.0',
          '@types/node': '^20.0.0'
        }
      }, null, 2),
      
      'src/pages/api/products.ts': `
import { NextApiRequest, NextApiResponse } from 'next';

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Product[] | { error: string }>
) {
  if (req.method === 'GET') {
    // Fetch products from backend
    const products = await fetch('http://localhost:5000/api/products');
    return res.status(200).json(await products.json());
  }
  
  if (req.method === 'POST') {
    const product: Product = req.body;
    // Create product via backend
    const response = await fetch('http://localhost:5000/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product)
    });
    return res.status(201).json(await response.json());
  }
  
  res.setHeader('Allow', ['GET', 'POST']);
  res.status(405).end('Method Not Allowed');
}
      `,
      
      'src/components/ProductList.tsx': `
import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
}

export const ProductList: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get('/api/products');
        setProducts(response.data);
      } catch (error) {
        console.error('Failed to fetch products:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchProducts();
  }, []);
  
  if (loading) return <div>Loading products...</div>;
  
  return (
    <div className="product-list">
      <h2>Products</h2>
      {products.map(product => (
        <div key={product.id} className="product-card">
          <h3>{product.name}</h3>
          <p>Price: \${product.price}</p>
          <p>Category: {product.category}</p>
        </div>
      ))}
    </div>
  );
};
      `,
      
      // Backend - Python Flask with SQLAlchemy
      'backend/requirements.txt': `
flask==2.3.0
flask-cors==4.0.0
flask-sqlalchemy==3.0.0
marshmallow==3.19.0
python-dotenv==1.0.0
      `,
      
      'backend/app.py': `
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from models import Product, db
import os

app = Flask(__name__)
CORS(app)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///ecommerce.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

@app.route('/api/products', methods=['GET'])
def get_products():
    """Get all products with optional filtering"""
    category = request.args.get('category')
    
    query = Product.query
    if category:
        query = query.filter_by(category=category)
    
    products = query.all()
    return jsonify([product.to_dict() for product in products])

@app.route('/api/products', methods=['POST'])
def create_product():
    """Create a new product"""
    data = request.get_json()
    
    if not data or not all(k in data for k in ['name', 'price', 'category']):
        return jsonify({'error': 'Missing required fields'}), 400
    
    product = Product(
        name=data['name'],
        price=float(data['price']),
        category=data['category'],
        description=data.get('description', '')
    )
    
    db.session.add(product)
    db.session.commit()
    
    return jsonify(product.to_dict()), 201

@app.route('/api/products/<product_id>', methods=['GET'])
def get_product(product_id):
    """Get a specific product by ID"""
    product = Product.query.get_or_404(product_id)
    return jsonify(product.to_dict())

@app.route('/api/products/<product_id>', methods=['PUT'])
def update_product(product_id):
    """Update a product"""
    product = Product.query.get_or_404(product_id)
    data = request.get_json()
    
    if 'name' in data:
        product.name = data['name']
    if 'price' in data:
        product.price = float(data['price'])
    if 'category' in data:
        product.category = data['category']
    if 'description' in data:
        product.description = data['description']
    
    db.session.commit()
    return jsonify(product.to_dict())

@app.route('/api/products/<product_id>', methods=['DELETE'])
def delete_product(product_id):
    """Delete a product"""
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    return jsonify({'message': 'Product deleted successfully'})

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)
      `,
      
      'backend/models.py': `
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import uuid

db = SQLAlchemy()

class Product(db.Model):
    """Product model for e-commerce platform"""
    __tablename__ = 'products'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, default='')
    price = db.Column(db.Numeric(10, 2), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Convert product to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'price': float(self.price),
            'category': self.category,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }
    
    def __repr__(self):
        return f'<Product {self.name}>'

class Category(db.Model):
    """Product category model"""
    __tablename__ = 'categories'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.Text, default='')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description
        }
      `,
      
      'README.md': `
# Full-Stack E-Commerce Platform

A modern e-commerce platform built with Next.js frontend and Flask backend.

## Architecture

- **Frontend**: Next.js with TypeScript, React, and Zustand for state management
- **Backend**: Python Flask with SQLAlchemy ORM
- **Database**: SQLite (development) / PostgreSQL (production)

## Features

- Product catalog with CRUD operations
- RESTful API design
- Type-safe frontend with TypeScript
- Database models with SQLAlchemy
- CORS-enabled for cross-origin requests

## API Endpoints

- \`GET /api/products\` - List all products
- \`POST /api/products\` - Create new product
- \`GET /api/products/:id\` - Get specific product
- \`PUT /api/products/:id\` - Update product
- \`DELETE /api/products/:id\` - Delete product
      `
    };

    // Create ZIP file
    const zipPath = path.join(tempDir, 'fullstack-project.zip');
    await ZipManager.createZip(projectFiles, zipPath);
    console.log('📦 Created multi-language project ZIP');

    // Step 1: Extract files directly (simulating file upload processing)
    console.log('🔄 Step 1: File extraction and processing...');
    const extractedFiles = await ZipManager.extractZip(zipPath);
    
    expect(extractedFiles.size).toBeGreaterThan(5);
    
    console.log('✅ File extraction completed:', {
      fileCount: extractedFiles.size,
      sampleFiles: Array.from(extractedFiles.keys()).slice(0, 5)
    });

    // Step 2: Multi-language code analysis
    console.log('🔍 Step 2: Multi-language code analysis...');
    const codeAnalysis = await documentationService.analyzeCodeForDocumentation(
      extractedFiles,
      'fullstack-ecommerce'
    );
    
    console.log('📊 Analysis results:', {
      projectName: codeAnalysis.projectInfo.name,
      projectType: codeAnalysis.projectInfo.type,
      primaryLanguage: codeAnalysis.projectInfo.language,
      framework: codeAnalysis.projectInfo.framework,
      apis: codeAnalysis.apis.length,
      functions: codeAnalysis.functions.length,
      dataModels: codeAnalysis.dataModels.length,
      dependencies: codeAnalysis.dependencies.length
    });

    // Verify multi-language analysis results
    expect(codeAnalysis.projectInfo.type).toBe('webapp');
    expect(codeAnalysis.apis.length).toBeGreaterThan(0); // Should find Flask routes and Next.js API routes
    expect(codeAnalysis.functions.length).toBeGreaterThan(5); // Should find functions from both languages
    expect(codeAnalysis.dataModels.length).toBeGreaterThan(1); // Should find TypeScript interfaces and Python models
    expect(codeAnalysis.dependencies.length).toBeGreaterThan(8); // Should find both npm and pip dependencies
    
    // Verify we found dependencies from both ecosystems
    const npmDeps = codeAnalysis.dependencies.filter(d => d.source.endsWith('package.json'));
    const pipDeps = codeAnalysis.dependencies.filter(d => d.source.endsWith('requirements.txt'));
    
    expect(npmDeps.length).toBeGreaterThan(0);
    expect(pipDeps.length).toBeGreaterThan(0);
    
    // Should find specific technologies
    expect(npmDeps.some(d => d.name === 'next')).toBe(true);
    expect(npmDeps.some(d => d.name === 'react')).toBe(true);
    expect(pipDeps.some(d => d.name === 'flask')).toBe(true);
    expect(pipDeps.some(d => d.name === 'flask-sqlalchemy')).toBe(true);

    // Step 3: Documentation generation
    console.log('📝 Step 3: Documentation generation...');
    const docResult = await documentationService.generateDocumentation(
      'test-job-id',
      codeAnalysis,
      ['executive-summary', 'api-contract', 'data-models']
    );
    
    expect(docResult.templates.length).toBe(3);
    expect(docResult.metadata.quality.overall).toBeGreaterThan(50);
    
    console.log('✅ Documentation generated:', {
      templates: docResult.templates.length,
      quality: docResult.metadata.quality.overall,
      templatesGenerated: docResult.templates.map(t => t.templateId)
    });

    // Step 4: Verify content quality
    console.log('🔍 Step 4: Verifying documentation quality...');
    
    // Check that documentation mentions both technologies
    const allContent = docResult.templates.map(t => t.content).join(' ').toLowerCase();
    expect(allContent).toContain('typescript');
    expect(allContent).toContain('python');
    expect(allContent).toContain('flask');
    expect(allContent).toContain('react');
    
    console.log('🎉 Production workflow test completed successfully!');
    console.log('✅ Multi-language analysis integrated into production pipeline');
  }, 60000); // 60 second timeout for full workflow
});