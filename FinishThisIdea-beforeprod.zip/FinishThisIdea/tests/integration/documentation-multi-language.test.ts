import { documentationService } from '../../src/services/documentation.service';

describe('Documentation Service Multi-Language Integration', () => {
  it('should use multi-language analysis for documentation generation', async () => {
    // Create a simple multi-language project
    const files = new Map<string, string>([
      // Frontend - TypeScript/React
      ['frontend/package.json', JSON.stringify({
        name: 'test-frontend',
        dependencies: {
          'react': '^18.0.0',
          'axios': '^1.0.0'
        }
      })],
      ['frontend/src/App.tsx', `
import React from 'react';
import { UserService } from './services/UserService';

export const App: React.FC = () => {
  return <div>Hello World</div>;
};
      `],
      
      // Backend - Python/Flask
      ['backend/requirements.txt', `
flask==2.3.0
sqlalchemy==2.0.0
      `],
      ['backend/app.py', `
from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/api/users', methods=['GET'])
def get_users():
    return jsonify([])

if __name__ == '__main__':
    app.run()
      `]
    ]);

    // Test the multi-language analysis
    console.log('🧪 Testing multi-language documentation analysis...');
    const analysis = await documentationService.analyzeCodeForDocumentation(files, 'test-project');
    
    console.log('📊 Analysis results:', {
      projectType: analysis.projectInfo.type,
      language: analysis.projectInfo.language,
      framework: analysis.projectInfo.framework,
      apis: analysis.apis.length,
      functions: analysis.functions.length,
      dependencies: analysis.dependencies.length
    });

    // Verify we got meaningful results
    expect(analysis.projectInfo.type).toBe('webapp');
    expect(analysis.dependencies.length).toBeGreaterThan(0);
    
    // Should have detected both ecosystems
    const hasReactDeps = analysis.dependencies.some(d => d.name === 'react');
    const hasFlaskDeps = analysis.dependencies.some(d => d.name === 'flask');
    
    expect(hasReactDeps).toBe(true);
    expect(hasFlaskDeps).toBe(true);
    
    console.log('✅ Multi-language documentation analysis working correctly!');
  }, 30000); // 30 second timeout for analysis
});