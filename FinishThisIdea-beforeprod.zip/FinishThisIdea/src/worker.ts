/**
 * Background Job Worker
 * 
 * Dedicated worker process for handling background jobs
 * Separates job processing from API server for better scalability
 */

import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Initialize telemetry first (before other imports for proper instrumentation)
import './utils/telemetry';

import { logger } from './utils/logger';
import { setupGlobalErrorHandlers } from './utils/error-handler';
import { getTelemetryStatus, shutdownTelemetry } from './utils/telemetry';
import { cleanupQueue } from './jobs/cleanup.queue';

// Setup global error handlers
setupGlobalErrorHandlers();

class WorkerService {
  private isShuttingDown = false;

  constructor() {
    logger.info('Starting FinishThisIdea Worker Process', {
      nodeEnv: process.env.NODE_ENV,
      version: process.env.npm_package_version || '1.0.0'
    });
  }

  /**
   * Start the worker process
   */
  async start() {
    try {
      // Initialize database connection
      await this.initializeDatabase();

      // Start job queue processing
      await this.startJobProcessing();

      // Setup graceful shutdown
      this.setupGracefulShutdown();

      logger.info('🎉 Worker process started successfully');

    } catch (error) {
      logger.error('Failed to start worker process', { error });
      process.exit(1);
    }
  }

  /**
   * Initialize database connection
   */
  private async initializeDatabase() {
    try {
      const { prisma } = await import('./utils/database');
      
      // Test database connection
      await prisma.$connect();
      logger.info('✅ Database connection established');
      
    } catch (error) {
      logger.error('❌ Database connection failed', { error });
      throw error;
    }
  }

  /**
   * Start job queue processing
   */
  private async startJobProcessing() {
    try {
      // Start cleanup queue processing
      cleanupQueue.process('cleanup-job', 5, async (job) => {
        logger.info('Processing cleanup job', { 
          jobId: job.id,
          data: job.data 
        });

        try {
          // Import cleanup service dynamically to avoid circular dependencies
          const { cleanupService } = await import('./services/cleanup.service');
          
          // Process the cleanup job
          await cleanupService.processCleanupJob(job.data);
          
          logger.info('Cleanup job completed successfully', { 
            jobId: job.id 
          });
          
        } catch (error) {
          logger.error('Cleanup job failed', { 
            jobId: job.id, 
            error 
          });
          throw error;
        }
      });

      // Handle job events
      cleanupQueue.on('completed', (job) => {
        logger.info('Job completed', { 
          jobId: job.id,
          queue: 'cleanup'
        });
      });

      cleanupQueue.on('failed', (job, err) => {
        logger.error('Job failed', { 
          jobId: job.id,
          queue: 'cleanup',
          error: err
        });
      });

      cleanupQueue.on('stalled', (job) => {
        logger.warn('Job stalled', { 
          jobId: job.id,
          queue: 'cleanup'
        });
      });

      logger.info('✅ Job queue processing started');

      // Log telemetry status
      const telemetryStatus = getTelemetryStatus();
      logger.info('📊 Worker telemetry status', telemetryStatus);

    } catch (error) {
      logger.error('❌ Failed to start job processing', { error });
      throw error;
    }
  }

  /**
   * Setup graceful shutdown handling
   */
  private setupGracefulShutdown() {
    const gracefulShutdown = async (signal: string) => {
      if (this.isShuttingDown) {
        logger.warn('Shutdown already in progress, ignoring signal', { signal });
        return;
      }

      this.isShuttingDown = true;
      logger.info('Received shutdown signal, starting graceful shutdown', { signal });

      try {
        // Stop accepting new jobs
        await cleanupQueue.pause();
        logger.info('Job queue paused');

        // Wait for active jobs to complete (with timeout)
        const activeJobs = await cleanupQueue.getActive();
        if (activeJobs.length > 0) {
          logger.info('Waiting for active jobs to complete', { 
            activeJobCount: activeJobs.length 
          });
          
          // Wait up to 30 seconds for jobs to complete
          const timeout = setTimeout(() => {
            logger.warn('Shutdown timeout reached, forcing exit');
            process.exit(1);
          }, 30000);

          // Wait for jobs to complete
          await Promise.all(activeJobs.map(job => job.finished()));
          clearTimeout(timeout);
        }

        // Close queue connections
        await cleanupQueue.close();
        logger.info('Job queue closed');

        // Disconnect from database
        const { disconnectDatabase } = await import('./utils/database');
        await disconnectDatabase();
        logger.info('Database disconnected');

        // Shutdown telemetry
        await shutdownTelemetry();
        logger.info('Worker telemetry shutdown complete');

        logger.info('✅ Graceful shutdown completed');
        process.exit(0);

      } catch (error) {
        logger.error('Error during graceful shutdown', { error });
        process.exit(1);
      }
    };

    // Handle various shutdown signals
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    process.on('SIGUSR2', () => gracefulShutdown('SIGUSR2')); // Nodemon restart

    // Handle uncaught exceptions
    process.on('uncaughtException', (error) => {
      logger.error('Uncaught exception in worker', { error });
      gracefulShutdown('uncaughtException');
    });

    process.on('unhandledRejection', (reason, promise) => {
      logger.error('Unhandled rejection in worker', { 
        reason, 
        promise: promise.toString() 
      });
      gracefulShutdown('unhandledRejection');
    });
  }

  /**
   * Health check endpoint for worker
   */
  getHealthStatus() {
    return {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      process: 'worker',
      queues: {
        cleanup: {
          active: cleanupQueue.getActive.length,
          waiting: cleanupQueue.getWaiting.length,
          completed: cleanupQueue.getCompleted.length,
          failed: cleanupQueue.getFailed.length
        }
      }
    };
  }
}

// Start the worker if this file is run directly
if (require.main === module) {
  const worker = new WorkerService();
  worker.start().catch(error => {
    logger.error('Worker startup failed', { error });
    process.exit(1);
  });
}

export { WorkerService };