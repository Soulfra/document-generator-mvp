import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import path from 'path';
import { createBullBoard } from '@bull-board/api';
import { BullAdapter } from '@bull-board/api/bullAdapter';
import { ExpressAdapter } from '@bull-board/express';
import { Server } from 'socket.io';
import { createServer } from 'http';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Initialize telemetry first (before other imports for proper instrumentation)
import './utils/telemetry';

// Setup global error handlers
import { setupGlobalErrorHandlers } from './utils/error-handler';
setupGlobalErrorHandlers();

// Import monitoring service
import { monitoringService } from './automation/services/monitoring.service';
import { automationInitialization } from './automation/services/initialization.service';

// Import routers
import { healthRouter } from './api/routes/health.route';
import { uploadRouter } from './api/routes/upload.route.simple';
import { jobRouter } from './api/routes/job.route.simple';
import { paymentRouter } from './api/routes/payment.route.simple';
import { webhookRouter } from './api/routes/webhook.route.simple';
import { profileRouter } from './api/routes/profile.route';
import { launchRouter } from './api/routes/launch.route';
import { analyticsRouter } from './api/routes/analytics.route';
import { workflowBuilderRouter } from './api/routes/workflow-builder.route';
import { templateMarketplaceRouter } from './api/routes/template-marketplace.route';
import documentationRouter from './api/routes/documentation.route';

// Import middleware
import { errorHandler } from './middleware/error.middleware';
import { rateLimiter } from './middleware/rate-limit.middleware';
import { authentication } from './middleware/auth.middleware';
import { requestLogger } from './middleware/logging.middleware';
import { csrfTokenProvider, csrfProtection, getCSRFToken } from './middleware/csrf.middleware';

// Import queue
import { cleanupQueue } from './jobs/cleanup.queue';

// Import utils
import { logger } from './utils/logger';
import { prisma, disconnectDatabase } from './utils/database';
import { getTelemetryStatus, shutdownTelemetry } from './utils/telemetry';
import { getLogShippingStatus, flushLogs } from './utils/log-shipping';
import { llmRouter } from './llm/router';
import { profileService } from './services/profile.service';

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
  },
});

const PORT = process.env.PORT || 3001;

async function startServer() {
  try {
    // Initialize database
    await prisma.$connect();
    logger.info('✅ Database connected');

    // Initialize LLM router
    await llmRouter.initialize();
    logger.info('✅ LLM router initialized');

    // Initialize profile service
    await profileService.initialize();
    logger.info('✅ Profile service initialized');

    // Log telemetry status
    const telemetryStatus = getTelemetryStatus();
    logger.info('📊 Telemetry status', telemetryStatus);

    // Log shipping status
    const logShippingStatus = getLogShippingStatus();
    logger.info('📡 Log shipping status', logShippingStatus);

    // Monitoring middleware (must be first)
    app.use(monitoringService.getRequestHandler());
    app.use(monitoringService.getTracingHandler());

    // Security middleware
    app.use(helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          scriptSrc: ["'self'"],
          imgSrc: ["'self'", "data:", "https:"],
        },
      },
    }));

    // CORS
    app.use(cors({
      origin: process.env.FRONTEND_URL || 'http://localhost:3000',
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID'],
    }));

    // Compression
    app.use(compression());

    // Body parsing - Stripe webhook needs raw body
    app.use('/api/stripe/webhook', express.raw({ type: 'application/json' }));
    
    // Regular body parsing for other routes
    app.use(express.json({ limit: '10mb' }));
    app.use(express.urlencoded({ extended: true, limit: '10mb' }));

    // Cookie parsing for CSRF
    app.use(cookieParser());

    // CSRF token provider (sets tokens in cookies)
    app.use(csrfTokenProvider);

    // Request logging
    app.use(requestLogger);

    // Rate limiting
    app.use('/api', rateLimiter);

    // Bull Dashboard
    const serverAdapter = new ExpressAdapter();
    serverAdapter.setBasePath('/admin/queues');
    
    createBullBoard({
      queues: [new BullAdapter(cleanupQueue)],
      serverAdapter,
    });
    
    app.use('/admin/queues', authentication({ role: 'admin' }), serverAdapter.getRouter());

    // Health check (no auth)
    app.use('/health', healthRouter);
    app.use('/api/health', healthRouter);

    // CSRF token endpoint (GET requests are safe)
    app.get('/api/csrf-token', getCSRFToken);

    // Public routes (no auth needed for MVP)
    app.use('/api/webhook', webhookRouter); // Webhooks skip CSRF (signature verification)
    app.use('/api/upload', csrfProtection, uploadRouter); // POST uploads need CSRF
    app.use('/api/jobs', csrfProtection, jobRouter); // Job creation/updates need CSRF
    app.use('/api/payment', csrfProtection, paymentRouter); // Payment operations need CSRF
    app.use('/api/profiles', csrfProtection, profileRouter); // Profile management needs CSRF
    app.use('/api/launch', csrfProtection, launchRouter); // Launch operations need CSRF
    app.use('/api/analytics', analyticsRouter); // Analytics (read-only) doesn't need CSRF
    app.use('/api/workflow-builder', csrfProtection, workflowBuilderRouter); // Workflow creation needs CSRF
    app.use('/api/template-marketplace', csrfProtection, templateMarketplaceRouter); // Template operations need CSRF
    app.use('/api/documentation', documentationRouter); // Documentation (read-only) doesn't need CSRF

    // Serve static files
    app.use(express.static(path.join(__dirname, '../public')));

    // Socket.io for real-time updates
    io.on('connection', (socket) => {
      logger.info('Client connected', { socketId: socket.id });

      socket.on('subscribe:job', (jobId: string) => {
        socket.join(`job:${jobId}`);
        logger.info('Client subscribed to job', { socketId: socket.id, jobId });
      });

      socket.on('disconnect', () => {
        logger.info('Client disconnected', { socketId: socket.id });
      });
    });

    // Make io accessible to other parts of the app
    app.set('io', io);

    // 404 handler
    app.use((_req, res) => {
      res.status(404).json({
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'The requested resource was not found',
        },
      });
    });

    // Error handling (must be last)
    app.use(monitoringService.getErrorHandler());
    app.use(errorHandler);

    // Start server
    httpServer.listen(PORT, async () => {
      logger.info(`🚀 Cleanup service backend running on port ${PORT}`);
      logger.info(`📊 Queue dashboard: http://localhost:${PORT}/admin/queues`);
      logger.info(`🏥 Health check: http://localhost:${PORT}/health`);
      logger.info(`🔌 WebSocket ready on port ${PORT}`);
      
      if (process.env.NODE_ENV === 'production') {
        logger.info('🏭 Running in PRODUCTION mode');
      } else {
        logger.info('🚧 Running in DEVELOPMENT mode');
      }

      // Initialize automation services
      try {
        await automationInitialization.initializeAll();
        logger.info('🤖 Automation services initialized');
      } catch (error) {
        logger.error('Failed to initialize automation services', { error });
      }
    });

    // Graceful shutdown
    const gracefulShutdown = async (signal: string) => {
      logger.info(`${signal} received, starting graceful shutdown...`);
      
      // Stop accepting new connections
      httpServer.close(() => {
        logger.info('HTTP server closed');
      });

      // Close Socket.io
      io.close(() => {
        logger.info('Socket.io server closed');
      });

      // Close queue connections
      await cleanupQueue.close();
      logger.info('Queue connections closed');

      // Close database
      await disconnectDatabase();

      // Shutdown automation services
      await automationInitialization.shutdown();
      logger.info('Automation services shut down');

      // Flush monitoring events
      await monitoringService.flush(5000);
      await monitoringService.close();

      // Shutdown telemetry
      await shutdownTelemetry();
      logger.info('Telemetry shutdown complete');

      // Flush remaining logs
      await flushLogs();
      logger.info('Log shipping flushed');

      process.exit(0);
    };

    // Handle shutdown signals
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
  // Don't exit in production, just log
  if (process.env.NODE_ENV !== 'production') {
    process.exit(1);
  }
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  // Always exit on uncaught exception
  process.exit(1);
});

// Start the server
startServer();

// Export for testing
export { app, httpServer, io };