// Re-export the comprehensive error handler from utils
export { errorHandler } from '../utils/error-handler';