import { Job, User } from '@prisma/client';
import { prisma } from '../../utils/database';
import { logger } from '../../utils/logger';
import { emailService } from './email.service';
import { analyticsService } from './analytics-integration.service';
import { conversionTracking } from './conversion-tracking.service';
import automationConfig from '../config/automation-config.json';

interface JobNotificationData {
  jobId: string;
  userId: string;
  status: 'COMPLETED' | 'FAILED' | 'CANCELLED';
  type: string;
  processingTime?: number;
  downloadUrl?: string;
  error?: string;
  templateCount?: number;
}

export class JobNotificationService {
  private isEnabled: boolean;

  constructor() {
    this.isEnabled = automationConfig.features.jobNotifications;
  }

  /**
   * Send job completion notification
   */
  public async sendJobNotification(data: JobNotificationData): Promise<void> {
    if (!this.isEnabled) {
      logger.info('Job notifications disabled', { jobId: data.jobId });
      return;
    }

    try {
      // Get user details
      const user = await prisma.user.findUnique({
        where: { id: data.userId },
      });

      if (!user || !user.email) {
        logger.warn('User not found or no email', { userId: data.userId });
        return;
      }

      // Send appropriate notification based on status
      switch (data.status) {
        case 'COMPLETED':
          await this.sendCompletionNotification(user, data);
          break;
        case 'FAILED':
          await this.sendFailureNotification(user, data);
          break;
        case 'CANCELLED':
          await this.sendCancellationNotification(user, data);
          break;
      }

      // Track notification sent
      analyticsService.track({
        event: 'job_notification_sent',
        userId: user.id,
        properties: {
          jobId: data.jobId,
          status: data.status,
          type: data.type,
        },
      });

      // Track conversion events
      if (data.status === 'COMPLETED') {
        // Track documentation generated
        await conversionTracking.trackRetention(user.id, 'generate', {
          jobId: data.jobId,
          type: data.type,
          templateCount: data.templateCount,
        });

        // Check if this is user's first completed job
        const jobCount = await prisma.job.count({
          where: {
            userId: user.id,
            status: 'COMPLETED',
          },
        });

        if (jobCount === 1) {
          await conversionTracking.trackSignupFunnel(user.id, 'first_job', {
            jobId: data.jobId,
            type: data.type,
          });
        }
      }
    } catch (error) {
      logger.error('Failed to send job notification', {
        error,
        jobId: data.jobId,
        status: data.status,
      });
    }
  }

  /**
   * Send completion notification
   */
  private async sendCompletionNotification(
    user: User,
    data: JobNotificationData
  ): Promise<void> {
    const processingTimeMinutes = data.processingTime 
      ? Math.round(data.processingTime / 60000) 
      : 0;

    await emailService.sendJobCompleteEmail(user.email!, {
      name: user.name || user.email!.split('@')[0],
      jobId: data.jobId,
      templateCount: data.templateCount || 0,
      processingTime: processingTimeMinutes > 0 
        ? `${processingTimeMinutes} minutes` 
        : 'Less than a minute',
      downloadUrl: data.downloadUrl || `${process.env.FRONTEND_URL}/job/${data.jobId}`,
    });

    logger.info('Job completion notification sent', {
      userId: user.id,
      jobId: data.jobId,
    });
  }

  /**
   * Send failure notification
   */
  private async sendFailureNotification(
    user: User,
    data: JobNotificationData
  ): Promise<void> {
    const template = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #ef4444; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background-color: #f8f9fa; }
        .button { display: inline-block; padding: 12px 24px; background-color: #6366f1; color: white; text-decoration: none; border-radius: 4px; }
        .error-box { background-color: #fee; padding: 15px; border-left: 4px solid #ef4444; margin: 20px 0; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Job Processing Failed</h1>
        </div>
        <div class="content">
          <h2>Hi ${user.name || user.email!.split('@')[0]},</h2>
          <p>Unfortunately, we encountered an error while processing your job.</p>
          <div class="error-box">
            <strong>Job ID:</strong> ${data.jobId}<br>
            <strong>Type:</strong> ${data.type}<br>
            <strong>Error:</strong> ${data.error || 'An unexpected error occurred'}
          </div>
          <p>Don't worry! Here's what you can do:</p>
          <ul>
            <li>Try uploading your files again</li>
            <li>Make sure your files are in a supported format</li>
            <li>Check that your files aren't corrupted</li>
            <li>Contact support if the problem persists</li>
          </ul>
          <p style="text-align: center; margin: 30px 0;">
            <a href="${process.env.FRONTEND_URL}/upload" class="button">Try Again</a>
          </p>
          <p>If you continue to experience issues, please reply to this email with your Job ID and we'll help you out.</p>
        </div>
        <div class="footer">
          <p>© 2024 FinishThisIdea. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
    `;

    await emailService.sendEmail({
      to: user.email!,
      subject: 'Job Processing Failed - FinishThisIdea',
      html: template,
    });

    logger.info('Job failure notification sent', {
      userId: user.id,
      jobId: data.jobId,
    });
  }

  /**
   * Send cancellation notification
   */
  private async sendCancellationNotification(
    user: User,
    data: JobNotificationData
  ): Promise<void> {
    const template = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #f59e0b; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background-color: #f8f9fa; }
        .button { display: inline-block; padding: 12px 24px; background-color: #6366f1; color: white; text-decoration: none; border-radius: 4px; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Job Cancelled</h1>
        </div>
        <div class="content">
          <h2>Hi ${user.name || user.email!.split('@')[0]},</h2>
          <p>Your job has been cancelled.</p>
          <p><strong>Job Details:</strong></p>
          <ul>
            <li>Job ID: ${data.jobId}</li>
            <li>Type: ${data.type}</li>
          </ul>
          <p>If you cancelled this job, no further action is needed. If you didn't cancel this job or need assistance, please contact our support team.</p>
          <p style="text-align: center; margin: 30px 0;">
            <a href="${process.env.FRONTEND_URL}/upload" class="button">Start a New Job</a>
          </p>
        </div>
        <div class="footer">
          <p>© 2024 FinishThisIdea. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
    `;

    await emailService.sendEmail({
      to: user.email!,
      subject: 'Job Cancelled - FinishThisIdea',
      html: template,
    });

    logger.info('Job cancellation notification sent', {
      userId: user.id,
      jobId: data.jobId,
    });
  }

  /**
   * Send batch job summary
   */
  public async sendBatchJobSummary(
    userId: string,
    jobs: Array<{ id: string; status: string; filename?: string }>
  ): Promise<void> {
    if (!this.isEnabled) return;

    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
      });

      if (!user || !user.email) return;

      const successful = jobs.filter(j => j.status === 'COMPLETED').length;
      const failed = jobs.filter(j => j.status === 'FAILED').length;

      const template = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #6366f1; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f8f9fa; }
          .stats { display: flex; justify-content: space-around; margin: 20px 0; }
          .stat { text-align: center; }
          .stat-number { font-size: 2em; font-weight: bold; }
          .button { display: inline-block; padding: 12px 24px; background-color: #6366f1; color: white; text-decoration: none; border-radius: 4px; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Batch Processing Complete</h1>
          </div>
          <div class="content">
            <h2>Hi ${user.name || user.email!.split('@')[0]},</h2>
            <p>Your batch processing job has been completed!</p>
            <div class="stats">
              <div class="stat">
                <div class="stat-number" style="color: #10b981;">${successful}</div>
                <div>Successful</div>
              </div>
              <div class="stat">
                <div class="stat-number" style="color: #ef4444;">${failed}</div>
                <div>Failed</div>
              </div>
              <div class="stat">
                <div class="stat-number">${jobs.length}</div>
                <div>Total</div>
              </div>
            </div>
            <p style="text-align: center; margin: 30px 0;">
              <a href="${process.env.FRONTEND_URL}/jobs" class="button">View All Results</a>
            </p>
          </div>
          <div class="footer">
            <p>© 2024 FinishThisIdea. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
      `;

      await emailService.sendEmail({
        to: user.email!,
        subject: `Batch Processing Complete - ${successful}/${jobs.length} Successful`,
        html: template,
      });

      logger.info('Batch summary notification sent', {
        userId: user.id,
        totalJobs: jobs.length,
        successful,
        failed,
      });
    } catch (error) {
      logger.error('Failed to send batch summary', { error, userId });
    }
  }
}

// Export singleton instance
export const jobNotificationService = new JobNotificationService();