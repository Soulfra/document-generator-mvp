/**
 * Log Shipping & Centralization Adapter
 * 
 * Configurable log shipping to various centralized logging systems:
 * - Logtail (Better Stack)
 * - AWS CloudWatch
 * - ELK Stack (Elasticsearch)
 * - Grafana Loki
 * - HTTP endpoints
 */

import winston from 'winston';
import { logger } from './logger';

// Log shipping configuration
interface LogShippingConfig {
  enabled: boolean;
  provider: 'logtail' | 'cloudwatch' | 'elasticsearch' | 'loki' | 'http' | 'datadog';
  endpoint?: string;
  token?: string;
  region?: string;
  index?: string;
  batchSize?: number;
  flushInterval?: number;
}

class LogShippingService {
  private config: LogShippingConfig;
  private transport: winston.transport | null = null;
  private isInitialized = false;

  constructor() {
    this.config = {
      enabled: process.env.LOG_SHIPPING_ENABLED === 'true',
      provider: (process.env.LOG_SHIPPING_PROVIDER as any) || 'logtail',
      endpoint: process.env.LOG_SHIPPING_ENDPOINT,
      token: process.env.LOG_SHIPPING_TOKEN,
      region: process.env.AWS_REGION || 'us-east-1',
      index: process.env.LOG_SHIPPING_INDEX || 'finishthisidea-logs',
      batchSize: parseInt(process.env.LOG_SHIPPING_BATCH_SIZE || '100'),
      flushInterval: parseInt(process.env.LOG_SHIPPING_FLUSH_INTERVAL || '5000')
    };

    if (this.config.enabled) {
      this.initialize();
    }
  }

  /**
   * Initialize log shipping based on provider
   */
  private async initialize() {
    try {
      switch (this.config.provider) {
        case 'logtail':
          await this.initializeLogtail();
          break;
        case 'cloudwatch':
          await this.initializeCloudWatch();
          break;
        case 'elasticsearch':
          await this.initializeElasticsearch();
          break;
        case 'loki':
          await this.initializeLoki();
          break;
        case 'http':
          await this.initializeHttp();
          break;
        case 'datadog':
          await this.initializeDatadog();
          break;
        default:
          throw new Error(`Unsupported log shipping provider: ${this.config.provider}`);
      }

      // Add transport to logger
      if (this.transport) {
        logger.add(this.transport);
        this.isInitialized = true;
        logger.info('✅ Log shipping initialized', {
          provider: this.config.provider,
          endpoint: this.config.endpoint ? this.maskSensitiveUrl(this.config.endpoint) : undefined
        });
      }
    } catch (error) {
      logger.error('❌ Failed to initialize log shipping', { 
        provider: this.config.provider,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  /**
   * Initialize Logtail (Better Stack) transport
   */
  private async initializeLogtail() {
    if (!this.config.token) {
      throw new Error('Logtail token is required');
    }

    // Use HTTP transport for Logtail
    const LogtailTransport = require('winston-logtail').Logtail;
    
    this.transport = new LogtailTransport({
      sourceToken: this.config.token,
      batchSize: this.config.batchSize,
      batchInterval: this.config.flushInterval,
      syncMax: 10,
      sendStreaks: true
    });
  }

  /**
   * Initialize AWS CloudWatch transport
   */
  private async initializeCloudWatch() {
    const WinstonCloudWatch = require('winston-cloudwatch');
    
    this.transport = new WinstonCloudWatch({
      logGroupName: process.env.CLOUDWATCH_LOG_GROUP || 'finishthisidea-logs',
      logStreamName: `${process.env.NODE_ENV || 'development'}-${Date.now()}`,
      awsRegion: this.config.region,
      messageFormatter: ({ level, message, additionalInfo }: any) => {
        return JSON.stringify({
          level,
          message,
          timestamp: new Date().toISOString(),
          service: 'finishthisidea-mvp',
          environment: process.env.NODE_ENV,
          ...additionalInfo
        });
      },
      uploadRate: this.config.flushInterval,
      errorHandler: (error: Error) => {
        console.error('CloudWatch logging error:', error);
      }
    });
  }

  /**
   * Initialize Elasticsearch transport
   */
  private async initializeElasticsearch() {
    if (!this.config.endpoint) {
      throw new Error('Elasticsearch endpoint is required');
    }

    const { ElasticsearchTransport } = require('winston-elasticsearch');
    
    this.transport = new ElasticsearchTransport({
      level: 'info',
      clientOpts: { 
        node: this.config.endpoint,
        auth: this.config.token ? {
          username: 'elastic',
          password: this.config.token
        } : undefined
      },
      index: this.config.index,
      transformer: (logData: any) => {
        const transformed = {
          '@timestamp': new Date().toISOString(),
          level: logData.level,
          message: logData.message,
          service: 'finishthisidea-mvp',
          environment: process.env.NODE_ENV,
          ...logData.meta
        };
        return transformed;
      },
      bufferLimit: this.config.batchSize,
      flushInterval: this.config.flushInterval
    });
  }

  /**
   * Initialize Grafana Loki transport
   */
  private async initializeLoki() {
    if (!this.config.endpoint) {
      throw new Error('Loki endpoint is required');
    }

    const LokiTransport = require('winston-loki');
    
    this.transport = new LokiTransport({
      host: this.config.endpoint,
      basicAuth: this.config.token,
      labels: {
        service: 'finishthisidea-mvp',
        environment: process.env.NODE_ENV || 'development'
      },
      json: true,
      format: winston.format.json(),
      replaceTimestamp: true,
      onConnectionError: (err: Error) => {
        console.error('Loki connection error:', err);
      },
      timeout: 30000,
      interval: this.config.flushInterval
    });
  }

  /**
   * Initialize generic HTTP transport
   */
  private async initializeHttp() {
    if (!this.config.endpoint) {
      throw new Error('HTTP endpoint is required');
    }

    const { HttpTransport } = require('winston-transport-http');
    
    this.transport = new HttpTransport({
      url: this.config.endpoint,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': this.config.token ? `Bearer ${this.config.token}` : undefined
      },
      batchCount: this.config.batchSize,
      batchInterval: this.config.flushInterval,
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json(),
        winston.format.printf(info => {
          return JSON.stringify({
            timestamp: info.timestamp,
            level: info.level,
            message: info.message,
            service: 'finishthisidea-mvp',
            environment: process.env.NODE_ENV,
            ...info
          });
        })
      )
    });
  }

  /**
   * Initialize Datadog transport
   */
  private async initializeDatadog() {
    if (!this.config.token) {
      throw new Error('Datadog API key is required');
    }

    const DatadogTransport = require('winston-datadog');
    
    this.transport = new DatadogTransport({
      apiKey: this.config.token,
      hostname: process.env.HOSTNAME || require('os').hostname(),
      service: 'finishthisidea-mvp',
      ddsource: 'nodejs',
      ddtags: `env:${process.env.NODE_ENV || 'development'}`,
      level: 'info'
    });
  }

  /**
   * Mask sensitive information in URLs
   */
  private maskSensitiveUrl(url: string): string {
    try {
      const urlObj = new URL(url);
      if (urlObj.password) {
        urlObj.password = '*****';
      }
      return urlObj.toString();
    } catch {
      return url.replace(/(:\/\/[^:]+:)[^@]+(@)/, '$1*****$2');
    }
  }

  /**
   * Check if log shipping is healthy
   */
  async healthCheck(): Promise<{ healthy: boolean; provider: string; error?: string }> {
    if (!this.config.enabled) {
      return { healthy: true, provider: 'disabled' };
    }

    if (!this.isInitialized) {
      return { 
        healthy: false, 
        provider: this.config.provider,
        error: 'Log shipping not initialized'
      };
    }

    try {
      // Test log shipping with a health check message
      logger.info('Log shipping health check', {
        timestamp: new Date().toISOString(),
        healthCheck: true
      });

      return { healthy: true, provider: this.config.provider };
    } catch (error) {
      return {
        healthy: false,
        provider: this.config.provider,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  /**
   * Get log shipping status
   */
  getStatus() {
    return {
      enabled: this.config.enabled,
      initialized: this.isInitialized,
      provider: this.config.provider,
      endpoint: this.config.endpoint ? this.maskSensitiveUrl(this.config.endpoint) : undefined,
      batchSize: this.config.batchSize,
      flushInterval: this.config.flushInterval
    };
  }

  /**
   * Manually flush logs (useful for graceful shutdown)
   */
  async flush(): Promise<void> {
    if (this.transport && typeof (this.transport as any).flush === 'function') {
      await (this.transport as any).flush();
    }
  }
}

// Create singleton instance
const logShippingService = new LogShippingService();

// Export public interface
export const getLogShippingStatus = () => logShippingService.getStatus();
export const flushLogs = () => logShippingService.flush();
export const logShippingHealthCheck = () => logShippingService.healthCheck();

export { LogShippingService };