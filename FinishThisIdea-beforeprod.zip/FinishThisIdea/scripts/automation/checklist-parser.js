#!/usr/bin/env node

/**
 * Checklist Parser - Detects completion status of modules
 * 
 * Supports:
 * - Markdown checklists: [x], [X], [ ]
 * - YAML status: status: complete, status: completed, status: pending
 * - Module completion reporting
 */

const fs = require('fs');
const path = require('path');
// Optional dependency - graceful fallback if not available
let yaml;
try {
  yaml = require('js-yaml');
} catch (e) {
  console.warn('js-yaml not found. YAML parsing will be limited. Install with: npm install js-yaml');
}

class ChecklistParser {
  constructor() {
    this.results = {
      totalItems: 0,
      completedItems: 0,
      pendingItems: 0,
      isComplete: false,
      completionPercentage: 0,
      items: []
    };
  }

  /**
   * Parse a file for completion status
   * @param {string} filePath - Path to file to parse
   * @returns {Object} Completion results
   */
  parseFile(filePath) {
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${filePath}`);
    }

    const content = fs.readFileSync(filePath, 'utf8');
    const extension = path.extname(filePath).toLowerCase();

    this.results = {
      totalItems: 0,
      completedItems: 0,
      pendingItems: 0,
      isComplete: false,
      completionPercentage: 0,
      items: [],
      filePath: filePath
    };

    if (extension === '.md') {
      this.parseMarkdown(content);
    } else if (extension === '.yaml' || extension === '.yml') {
      this.parseYaml(content);
    } else {
      // Try both formats for mixed content
      this.parseMarkdown(content);
      if (this.results.totalItems === 0) {
        this.parseYaml(content);
      }
    }

    this.calculateCompletion();
    return this.results;
  }

  /**
   * Parse Markdown checklist items
   * @param {string} content - File content
   */
  parseMarkdown(content) {
    // Patterns for markdown checklists
    const checklistPatterns = [
      /- \[(x|X)\]\s+(.+)/g,  // Completed: - [x] item
      /- \[\s\]\s+(.+)/g,     // Pending: - [ ] item
      /\[(x|X)\]\s+(.+)/g,    // Completed: [x] item  
      /\[\s\]\s+(.+)/g        // Pending: [ ] item
    ];

    const lines = content.split('\n');
    
    lines.forEach((line, index) => {
      const trimmedLine = line.trim();
      
      // Check for completed items
      const completedMatch = trimmedLine.match(/(?:- )?\[(x|X)\]\s+(.+)/);
      if (completedMatch) {
        this.results.items.push({
          line: index + 1,
          text: completedMatch[2].trim(),
          status: 'completed',
          type: 'markdown'
        });
        this.results.completedItems++;
        this.results.totalItems++;
        return;
      }

      // Check for pending items
      const pendingMatch = trimmedLine.match(/(?:- )?\[\s\]\s+(.+)/);
      if (pendingMatch) {
        this.results.items.push({
          line: index + 1,
          text: pendingMatch[1].trim(),
          status: 'pending',
          type: 'markdown'
        });
        this.results.pendingItems++;
        this.results.totalItems++;
      }
    });
  }

  /**
   * Parse YAML status fields
   * @param {string} content - File content
   */
  parseYaml(content) {
    if (!yaml) {
      // Fallback to line-by-line parsing if js-yaml not available
      this.parseYamlLines(content);
      return;
    }

    try {
      // Try to parse as YAML document
      const docs = content.split('---').filter(doc => doc.trim());
      
      docs.forEach(docContent => {
        try {
          const yamlDoc = yaml.load(docContent);
          if (yamlDoc && typeof yamlDoc === 'object') {
            this.parseYamlObject(yamlDoc);
          }
        } catch (e) {
          // Skip invalid YAML sections
        }
      });
    } catch (error) {
      // Not valid YAML, try line-by-line parsing
      this.parseYamlLines(content);
    }
  }

  /**
   * Parse YAML object for status fields
   * @param {Object} obj - Parsed YAML object
   * @param {string} path - Current object path
   */
  parseYamlObject(obj, path = '') {
    for (const [key, value] of Object.entries(obj)) {
      const currentPath = path ? `${path}.${key}` : key;
      
      if (key === 'status' && typeof value === 'string') {
        const status = value.toLowerCase();
        const isComplete = ['complete', 'completed', 'done', '✅'].includes(status);
        
        this.results.items.push({
          path: currentPath,
          text: `${path || 'item'}`,
          status: isComplete ? 'completed' : 'pending',
          type: 'yaml',
          value: value
        });
        
        if (isComplete) {
          this.results.completedItems++;
        } else {
          this.results.pendingItems++;
        }
        this.results.totalItems++;
      } else if (typeof value === 'object' && value !== null) {
        this.parseYamlObject(value, currentPath);
      }
    }
  }

  /**
   * Parse YAML-style lines
   * @param {string} content - File content
   */
  parseYamlLines(content) {
    const lines = content.split('\n');
    
    lines.forEach((line, index) => {
      const statusMatch = line.match(/^\s*(?:-\s+)?(\w+):\s*(?:status:\s+)?(complete|completed|pending|done|✅|❌|⏳)/i);
      if (statusMatch) {
        const [, itemName, status] = statusMatch;
        const isComplete = ['complete', 'completed', 'done', '✅'].includes(status.toLowerCase());
        
        this.results.items.push({
          line: index + 1,
          text: itemName.trim(),
          status: isComplete ? 'completed' : 'pending',
          type: 'yaml-line',
          value: status
        });
        
        if (isComplete) {
          this.results.completedItems++;
        } else {
          this.results.pendingItems++;
        }
        this.results.totalItems++;
      }
    });
  }

  /**
   * Calculate completion percentage and status
   */
  calculateCompletion() {
    if (this.results.totalItems === 0) {
      this.results.completionPercentage = 0;
      this.results.isComplete = false;
    } else {
      this.results.completionPercentage = Math.round(
        (this.results.completedItems / this.results.totalItems) * 100
      );
      this.results.isComplete = this.results.completedItems === this.results.totalItems;
    }
  }

  /**
   * Parse directory for all completion status
   * @param {string} dirPath - Directory to scan
   * @returns {Object} Directory completion summary
   */
  parseDirectory(dirPath) {
    const summary = {
      directory: dirPath,
      files: [],
      totalFiles: 0,
      completedFiles: 0,
      overallCompletion: 0,
      isComplete: false
    };

    if (!fs.existsSync(dirPath)) {
      throw new Error(`Directory not found: ${dirPath}`);
    }

    const files = fs.readdirSync(dirPath, { withFileTypes: true });
    
    files.forEach(file => {
      if (file.isFile() && (file.name.endsWith('.md') || file.name.endsWith('.yaml') || file.name.endsWith('.yml'))) {
        const filePath = path.join(dirPath, file.name);
        try {
          const result = this.parseFile(filePath);
          summary.files.push(result);
          summary.totalFiles++;
          
          if (result.isComplete) {
            summary.completedFiles++;
          }
        } catch (error) {
          console.error(`Error parsing ${filePath}:`, error.message);
        }
      }
    });

    if (summary.totalFiles > 0) {
      summary.overallCompletion = Math.round((summary.completedFiles / summary.totalFiles) * 100);
      summary.isComplete = summary.completedFiles === summary.totalFiles;
    }

    return summary;
  }

  /**
   * Generate completion report
   * @param {Object} results - Parse results
   * @returns {string} Formatted report
   */
  generateReport(results) {
    let report = '';
    
    if (results.directory) {
      // Directory report
      report += `📁 Directory: ${results.directory}\n`;
      report += `📊 Overall Completion: ${results.overallCompletion}% (${results.completedFiles}/${results.totalFiles} files)\n`;
      report += `${results.isComplete ? '✅' : '⏳'} Status: ${results.isComplete ? 'COMPLETE' : 'IN PROGRESS'}\n\n`;
      
      results.files.forEach(file => {
        const fileName = path.basename(file.filePath);
        report += `📄 ${fileName}: ${file.completionPercentage}% (${file.completedItems}/${file.totalItems}) ${file.isComplete ? '✅' : '⏳'}\n`;
      });
    } else {
      // Single file report
      const fileName = path.basename(results.filePath);
      report += `📄 File: ${fileName}\n`;
      report += `📊 Completion: ${results.completionPercentage}% (${results.completedItems}/${results.totalItems})\n`;
      report += `${results.isComplete ? '✅' : '⏳'} Status: ${results.isComplete ? 'COMPLETE' : 'IN PROGRESS'}\n\n`;
      
      if (results.items.length > 0) {
        report += `📋 Items:\n`;
        results.items.forEach(item => {
          const status = item.status === 'completed' ? '✅' : '⏳';
          report += `  ${status} ${item.text}\n`;
        });
      }
    }
    
    return report;
  }
}

// CLI Usage
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.log(`
Checklist Parser - Module Completion Detection

Usage:
  node checklist-parser.js <file-or-directory> [options]

Options:
  --json     Output as JSON
  --quiet    Minimal output
  --help     Show this help

Examples:
  node checklist-parser.js ./cursor/future-work-module/
  node checklist-parser.js ./cursor/future-work-module/README.md
  node checklist-parser.js ./cursor/automation-review-archival-module.md --json
`);
    process.exit(0);
  }

  const targetPath = args[0];
  const options = {
    json: args.includes('--json'),
    quiet: args.includes('--quiet')
  };

  try {
    const parser = new ChecklistParser();
    let results;
    
    if (fs.statSync(targetPath).isDirectory()) {
      results = parser.parseDirectory(targetPath);
    } else {
      results = parser.parseFile(targetPath);
    }

    if (options.json) {
      console.log(JSON.stringify(results, null, 2));
    } else if (options.quiet) {
      console.log(`${results.isComplete ? 'COMPLETE' : 'INCOMPLETE'}`);
    } else {
      console.log(parser.generateReport(results));
    }

    // Exit code: 0 if complete, 1 if incomplete
    process.exit(results.isComplete ? 0 : 1);

  } catch (error) {
    console.error('Error:', error.message);
    process.exit(2);
  }
}

module.exports = ChecklistParser;