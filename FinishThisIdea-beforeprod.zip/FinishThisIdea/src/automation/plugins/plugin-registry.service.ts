/**
 * Plugin Registry Service
 * Manages the lifecycle of workflow step plugins
 */

import { injectable } from 'inversify';
import {
  WorkflowStepPlugin,
  PluginRegistryEntry,
  PluginConstructor,
  PluginConfiguration
} from './interfaces/plugin.interface';
import { Logger } from 'winston';
import { createLogger } from '../../utils/logger';
import { ConfigService } from '../../services/config.service';

@injectable()
export class PluginRegistryService {
  private logger: Logger;
  private plugins: Map<string, PluginRegistryEntry> = new Map();
  private configService: ConfigService;
  
  constructor() {
    this.logger = createLogger('PluginRegistry');
    this.configService = new ConfigService();
  }
  
  /**
   * Initialize the registry
   */
  async initialize(): Promise<void> {
    this.logger.info('Initializing plugin registry');
    
    // Load built-in plugins
    await this.loadBuiltInPlugins();
    
    // Load external plugins
    await this.loadExternalPlugins();
    
    this.logger.info(`Plugin registry initialized with ${this.plugins.size} plugins`);
  }
  
  /**
   * Register a plugin
   */
  async registerPlugin(
    stepType: string,
    PluginClass: PluginConstructor,
    config?: PluginConfiguration
  ): Promise<void> {
    try {
      // Check if plugin is enabled
      if (config && config.enabled === false) {
        this.logger.info(`Plugin '${stepType}' is disabled, skipping registration`);
        return;
      }
      
      // Create plugin instance
      const pluginConfig = config?.config || {};
      const plugin = new PluginClass(pluginConfig);
      
      // Apply metadata overrides if any
      if (config?.overrides) {
        Object.assign(plugin.metadata, config.overrides);
      }
      
      // Validate plugin metadata
      this.validatePluginMetadata(plugin);
      
      // Call onLoad lifecycle hook
      if (plugin.onLoad) {
        await plugin.onLoad();
      }
      
      // Register the plugin
      this.plugins.set(stepType, {
        plugin,
        metadata: plugin.metadata,
        loaded: true
      });
      
      this.logger.info(`Registered plugin '${stepType}' (${plugin.metadata.name} v${plugin.metadata.version})`);
      
    } catch (error) {
      this.logger.error(`Failed to register plugin '${stepType}':`, error);
      this.plugins.set(stepType, {
        plugin: null as any,
        metadata: { id: stepType, name: stepType } as any,
        loaded: false,
        error: error.message
      });
    }
  }
  
  /**
   * Get a plugin by step type
   */
  getPlugin(stepType: string): WorkflowStepPlugin | null {
    const entry = this.plugins.get(stepType);
    if (!entry || !entry.loaded) {
      return null;
    }
    return entry.plugin;
  }
  
  /**
   * Get all registered plugins
   */
  getAllPlugins(): Map<string, PluginRegistryEntry> {
    return new Map(this.plugins);
  }
  
  /**
   * Get plugins by category
   */
  getPluginsByCategory(category: string): PluginRegistryEntry[] {
    const plugins: PluginRegistryEntry[] = [];
    this.plugins.forEach((entry) => {
      if (entry.loaded && entry.metadata.category === category) {
        plugins.push(entry);
      }
    });
    return plugins;
  }
  
  /**
   * Get plugin metadata for UI
   */
  getPluginMetadata(): Array<{ type: string; metadata: any }> {
    const metadata: Array<{ type: string; metadata: any }> = [];
    
    this.plugins.forEach((entry, type) => {
      if (entry.loaded) {
        metadata.push({
          type,
          metadata: {
            ...entry.metadata,
            fields: entry.plugin.fields
          }
        });
      }
    });
    
    return metadata;
  }
  
  /**
   * Unload a plugin
   */
  async unloadPlugin(stepType: string): Promise<void> {
    const entry = this.plugins.get(stepType);
    if (entry && entry.loaded && entry.plugin.onUnload) {
      await entry.plugin.onUnload();
    }
    this.plugins.delete(stepType);
    this.logger.info(`Unloaded plugin '${stepType}'`);
  }
  
  /**
   * Reload all plugins
   */
  async reload(): Promise<void> {
    this.logger.info('Reloading all plugins');
    
    // Unload all plugins
    for (const [type, entry] of this.plugins) {
      if (entry.loaded && entry.plugin.onUnload) {
        await entry.plugin.onUnload();
      }
    }
    
    // Clear registry
    this.plugins.clear();
    
    // Re-initialize
    await this.initialize();
  }
  
  /**
   * Load built-in plugins
   */
  private async loadBuiltInPlugins(): Promise<void> {
    try {
      // Dynamic imports for built-in plugins
      const builtInPlugins = [
        { type: 'script', module: './built-in/script.plugin' },
        { type: 'email', module: './built-in/email.plugin' },
        { type: 'slack', module: './built-in/slack.plugin' },
        { type: 'github', module: './built-in/github.plugin' },
        { type: 'analytics', module: './built-in/analytics.plugin' },
        { type: 'notification', module: './built-in/notification.plugin' },
        { type: 'delay', module: './built-in/delay.plugin' },
        { type: 'discord', module: './built-in/discord.plugin' },
        { type: 'teams', module: './built-in/teams.plugin' }
      ];
      
      for (const { type, module } of builtInPlugins) {
        try {
          const pluginModule = await import(module);
          const PluginClass = pluginModule.default || pluginModule[Object.keys(pluginModule)[0]];
          await this.registerPlugin(type, PluginClass);
        } catch (error) {
          this.logger.warn(`Failed to load built-in plugin '${type}':`, error.message);
        }
      }
    } catch (error) {
      this.logger.error('Failed to load built-in plugins:', error);
    }
  }
  
  /**
   * Load external plugins from plugins directory
   */
  private async loadExternalPlugins(): Promise<void> {
    try {
      const automationConfig = await this.configService.getAutomationConfig();
      const pluginsConfig = automationConfig.plugins || {};
      
      // Load plugins from configuration
      for (const [pluginName, config] of Object.entries(pluginsConfig)) {
        if (config.enabled) {
          try {
            // Try to load from node_modules first
            const pluginModule = await import(pluginName);
            const PluginClass = pluginModule.default || pluginModule.Plugin;
            await this.registerPlugin(pluginName, PluginClass, config);
          } catch (error) {
            this.logger.warn(`Failed to load external plugin '${pluginName}':`, error.message);
          }
        }
      }
    } catch (error) {
      this.logger.error('Failed to load external plugins:', error);
    }
  }
  
  /**
   * Validate plugin metadata
   */
  private validatePluginMetadata(plugin: WorkflowStepPlugin): void {
    const { metadata } = plugin;
    
    if (!metadata.id) {
      throw new Error('Plugin metadata must have an id');
    }
    
    if (!metadata.name) {
      throw new Error('Plugin metadata must have a name');
    }
    
    if (!metadata.version) {
      throw new Error('Plugin metadata must have a version');
    }
    
    if (!metadata.description) {
      throw new Error('Plugin metadata must have a description');
    }
    
    if (!plugin.fields || !Array.isArray(plugin.fields)) {
      throw new Error('Plugin must define fields array');
    }
  }
  
  /**
   * Get plugin configuration from automation config
   */
  async getPluginConfiguration(pluginId: string): Promise<PluginConfiguration | null> {
    const config = await this.configService.getAutomationConfig();
    return config.plugins?.[pluginId] || null;
  }
}