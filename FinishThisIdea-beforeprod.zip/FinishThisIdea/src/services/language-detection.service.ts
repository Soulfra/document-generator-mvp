import { logger } from '../utils/logger';
import * as path from 'path';

export interface LanguageDetectionResult {
  primary: string;
  confidence: number;
  secondary?: string[];
  framework?: string;
  frameworkConfidence?: number;
  packageManager?: string;
  configFiles: string[];
}

export interface LanguageSignature {
  extensions: string[];
  configFiles: string[];
  dependencies?: Record<string, string[]>;
  contentPatterns?: RegExp[];
  frameworks?: {
    [key: string]: {
      indicators: string[];
      configFiles?: string[];
      dependencies?: string[];
    };
  };
}

export class LanguageDetectionService {
  private static instance: LanguageDetectionService;
  
  private readonly languageSignatures: Record<string, LanguageSignature> = {
    typescript: {
      extensions: ['.ts', '.tsx', '.d.ts'],
      configFiles: ['tsconfig.json', 'tsconfig.*.json'],
      frameworks: {
        react: {
          indicators: ['react', 'react-dom'],
          dependencies: ['react', 'react-dom', '@types/react'],
          configFiles: ['.eslintrc', 'next.config.js']
        },
        angular: {
          indicators: ['@angular/core'],
          dependencies: ['@angular/core', '@angular/common'],
          configFiles: ['angular.json', '.angular-cli.json']
        },
        vue: {
          indicators: ['vue'],
          dependencies: ['vue', '@vue/cli'],
          configFiles: ['vue.config.js']
        },
        express: {
          indicators: ['express'],
          dependencies: ['express', '@types/express']
        },
        nestjs: {
          indicators: ['@nestjs/core'],
          dependencies: ['@nestjs/core', '@nestjs/common'],
          configFiles: ['nest-cli.json']
        }
      }
    },
    
    javascript: {
      extensions: ['.js', '.jsx', '.mjs', '.cjs'],
      configFiles: ['package.json', '.eslintrc.js', 'babel.config.js'],
      frameworks: {
        react: {
          indicators: ['react', 'react-dom'],
          dependencies: ['react', 'react-dom']
        },
        vue: {
          indicators: ['vue'],
          dependencies: ['vue']
        },
        express: {
          indicators: ['express'],
          dependencies: ['express']
        },
        nextjs: {
          indicators: ['next'],
          dependencies: ['next', 'react', 'react-dom'],
          configFiles: ['next.config.js']
        }
      }
    },
    
    python: {
      extensions: ['.py', '.pyw', '.pyx', '.pyi'],
      configFiles: ['requirements.txt', 'setup.py', 'pyproject.toml', 'Pipfile', 'poetry.lock'],
      contentPatterns: [/^#!.*python/, /^# -\*- coding:/],
      frameworks: {
        django: {
          indicators: ['django'],
          dependencies: ['django'],
          configFiles: ['manage.py', 'settings.py', 'urls.py']
        },
        flask: {
          indicators: ['flask'],
          dependencies: ['flask'],
          configFiles: ['wsgi.py', 'app.py']
        },
        fastapi: {
          indicators: ['fastapi'],
          dependencies: ['fastapi', 'uvicorn']
        },
        pytest: {
          indicators: ['pytest'],
          dependencies: ['pytest'],
          configFiles: ['pytest.ini', 'conftest.py']
        }
      }
    },
    
    java: {
      extensions: ['.java', '.class', '.jar'],
      configFiles: ['pom.xml', 'build.gradle', 'build.gradle.kts', 'settings.gradle'],
      frameworks: {
        spring: {
          indicators: ['org.springframework'],
          dependencies: ['spring-boot-starter', 'spring-core'],
          configFiles: ['application.properties', 'application.yml']
        },
        android: {
          indicators: ['android', 'androidx'],
          configFiles: ['AndroidManifest.xml', 'build.gradle']
        },
        junit: {
          indicators: ['junit', 'org.junit'],
          dependencies: ['junit', 'junit-jupiter']
        }
      }
    },
    
    go: {
      extensions: ['.go'],
      configFiles: ['go.mod', 'go.sum', 'Gopkg.toml'],
      contentPatterns: [/^package\s+\w+/m],
      frameworks: {
        gin: {
          indicators: ['github.com/gin-gonic/gin'],
          dependencies: ['github.com/gin-gonic/gin']
        },
        echo: {
          indicators: ['github.com/labstack/echo'],
          dependencies: ['github.com/labstack/echo']
        },
        fiber: {
          indicators: ['github.com/gofiber/fiber'],
          dependencies: ['github.com/gofiber/fiber']
        }
      }
    },
    
    csharp: {
      extensions: ['.cs', '.csx', '.cshtml'],
      configFiles: ['*.csproj', '*.sln', 'packages.config', 'project.json'],
      frameworks: {
        dotnet: {
          indicators: ['Microsoft.', 'System.'],
          configFiles: ['appsettings.json', 'web.config']
        },
        aspnet: {
          indicators: ['Microsoft.AspNetCore', 'Microsoft.AspNet'],
          dependencies: ['Microsoft.AspNetCore.App'],
          configFiles: ['Startup.cs', 'Program.cs']
        },
        unity: {
          indicators: ['UnityEngine', 'UnityEditor'],
          configFiles: ['ProjectSettings/', 'Assets/']
        },
        xamarin: {
          indicators: ['Xamarin.', 'Android.', 'iOS.'],
          configFiles: ['Info.plist', 'AndroidManifest.xml']
        }
      }
    },
    
    php: {
      extensions: ['.php', '.phtml', '.php3', '.php4', '.php5', '.php7', '.phps'],
      configFiles: ['composer.json', 'composer.lock', 'phpunit.xml'],
      contentPatterns: [/^<\?php/],
      frameworks: {
        laravel: {
          indicators: ['laravel/', 'illuminate/'],
          dependencies: ['laravel/framework'],
          configFiles: ['artisan', 'bootstrap/app.php']
        },
        symfony: {
          indicators: ['symfony/'],
          dependencies: ['symfony/framework-bundle'],
          configFiles: ['symfony.lock', 'config/bundles.php']
        },
        wordpress: {
          indicators: ['wp-', 'wordpress'],
          configFiles: ['wp-config.php', 'wp-content/']
        },
        codeigniter: {
          indicators: ['codeigniter'],
          configFiles: ['index.php', 'system/']
        }
      }
    },
    
    ruby: {
      extensions: ['.rb', '.rbw', '.rake', '.gemspec'],
      configFiles: ['Gemfile', 'Gemfile.lock', 'Rakefile', '.ruby-version'],
      contentPatterns: [/^#!.*ruby/],
      frameworks: {
        rails: {
          indicators: ['rails', 'activerecord'],
          dependencies: ['rails'],
          configFiles: ['config/routes.rb', 'config/application.rb']
        },
        sinatra: {
          indicators: ['sinatra'],
          dependencies: ['sinatra'],
          configFiles: ['config.ru']
        },
        rspec: {
          indicators: ['rspec'],
          dependencies: ['rspec'],
          configFiles: ['spec/', '.rspec']
        }
      }
    },
    
    rust: {
      extensions: ['.rs'],
      configFiles: ['Cargo.toml', 'Cargo.lock'],
      frameworks: {
        actix: {
          indicators: ['actix-web'],
          dependencies: ['actix-web']
        },
        rocket: {
          indicators: ['rocket'],
          dependencies: ['rocket']
        }
      }
    },
    
    swift: {
      extensions: ['.swift'],
      configFiles: ['Package.swift', '*.xcodeproj', '*.xcworkspace'],
      frameworks: {
        swiftui: {
          indicators: ['SwiftUI'],
          configFiles: ['ContentView.swift']
        },
        uikit: {
          indicators: ['UIKit'],
          configFiles: ['AppDelegate.swift', 'SceneDelegate.swift']
        }
      }
    }
  };
  
  static getInstance(): LanguageDetectionService {
    if (!LanguageDetectionService.instance) {
      LanguageDetectionService.instance = new LanguageDetectionService();
    }
    return LanguageDetectionService.instance;
  }
  
  /**
   * Detect the primary language and framework from a map of files
   */
  async detectLanguage(files: Map<string, string>): Promise<LanguageDetectionResult> {
    const fileList = Array.from(files.keys());
    const extensionCounts = this.countExtensions(fileList);
    const configFiles = this.findConfigFiles(fileList);
    
    // Score each language based on file extensions and config files
    const languageScores = new Map<string, number>();
    const detectedFrameworks = new Map<string, { framework: string; confidence: number }>();
    
    for (const [language, signature] of Object.entries(this.languageSignatures)) {
      let score = 0;
      
      // Score based on file extensions
      for (const ext of signature.extensions) {
        score += (extensionCounts.get(ext) || 0) * 10;
      }
      
      // Score based on config files
      for (const configPattern of signature.configFiles) {
        const matchingConfigs = this.matchPattern(configFiles, configPattern);
        score += matchingConfigs.length * 20;
      }
      
      // Check content patterns
      if (signature.contentPatterns && score > 0) {
        let contentMatches = 0;
        for (const [filename, content] of files) {
          if (this.hasExtension(filename, signature.extensions)) {
            for (const pattern of signature.contentPatterns) {
              if (pattern.test(content)) {
                contentMatches++;
                break;
              }
            }
          }
        }
        score += contentMatches * 5;
      }
      
      if (score > 0) {
        languageScores.set(language, score);
        
        // Detect frameworks for this language
        if (signature.frameworks) {
          const frameworkResult = await this.detectFramework(files, signature.frameworks, fileList);
          if (frameworkResult) {
            detectedFrameworks.set(language, frameworkResult);
          }
        }
      }
    }
    
    // Find primary language
    const sortedLanguages = Array.from(languageScores.entries())
      .sort(([, a], [, b]) => b - a);
    
    if (sortedLanguages.length === 0) {
      return {
        primary: 'unknown',
        confidence: 0,
        configFiles: []
      };
    }
    
    const [primaryLanguage, primaryScore] = sortedLanguages[0] || ['unknown', 0];
    const totalScore = Array.from(languageScores.values()).reduce((a, b) => a + b, 0);
    const confidence = Math.min(99, Math.round((primaryScore / totalScore) * 100));
    
    const frameworkInfo = detectedFrameworks.get(primaryLanguage);
    const packageManager = await this.detectPackageManager(files, fileList, primaryLanguage);
    
    return {
      primary: primaryLanguage,
      confidence,
      secondary: sortedLanguages.slice(1, 3).map(([lang]) => lang),
      framework: frameworkInfo?.framework,
      frameworkConfidence: frameworkInfo?.confidence,
      packageManager,
      configFiles: configFiles
    };
  }
  
  /**
   * Count occurrences of each file extension
   */
  private countExtensions(files: string[]): Map<string, number> {
    const counts = new Map<string, number>();
    
    for (const file of files) {
      const ext = path.extname(file).toLowerCase();
      if (ext) {
        counts.set(ext, (counts.get(ext) || 0) + 1);
      }
    }
    
    return counts;
  }
  
  /**
   * Find all configuration files in the project
   */
  private findConfigFiles(files: string[]): string[] {
    const configPatterns = [
      /package\.json$/,
      /tsconfig.*\.json$/,
      /\.eslintrc/,
      /webpack\.config/,
      /babel\.config/,
      /requirements\.txt$/,
      /setup\.py$/,
      /pyproject\.toml$/,
      /pom\.xml$/,
      /build\.gradle/,
      /go\.mod$/,
      /Cargo\.toml$/,
      /composer\.json$/,
      /Gemfile$/,
      /\.csproj$/,
      /\.sln$/
    ];
    
    return files.filter(file => 
      configPatterns.some(pattern => pattern.test(file))
    );
  }
  
  /**
   * Match files against a pattern (supports wildcards)
   */
  private matchPattern(files: string[], pattern: string): string[] {
    if (pattern.includes('*')) {
      const regex = new RegExp(pattern.replace(/\*/g, '.*'));
      return files.filter(file => regex.test(file));
    }
    return files.filter(file => file.endsWith(pattern) || file.includes(pattern));
  }
  
  /**
   * Check if a filename has one of the given extensions
   */
  private hasExtension(filename: string, extensions: string[]): boolean {
    const ext = path.extname(filename).toLowerCase();
    return extensions.includes(ext);
  }
  
  /**
   * Detect framework based on dependencies and indicators
   */
  private async detectFramework(
    files: Map<string, string>,
    frameworks: LanguageSignature['frameworks'],
    fileList: string[]
  ): Promise<{ framework: string; confidence: number } | null> {
    if (!frameworks) return null;
    
    const frameworkScores = new Map<string, number>();
    
    for (const [frameworkName, frameworkInfo] of Object.entries(frameworks)) {
      let score = 0;
      
      // Check for framework-specific config files
      if (frameworkInfo.configFiles) {
        for (const configPattern of frameworkInfo.configFiles) {
          const matches = this.matchPattern(fileList, configPattern);
          score += matches.length * 30;
        }
      }
      
      // Check dependencies in package.json, requirements.txt, etc.
      if (frameworkInfo.dependencies) {
        score += await this.checkDependencies(files, frameworkInfo.dependencies) * 40;
      }
      
      // Check for framework indicators in code
      if (frameworkInfo.indicators) {
        let indicatorMatches = 0;
        for (const [, content] of files) {
          for (const indicator of frameworkInfo.indicators) {
            if (content.includes(indicator)) {
              indicatorMatches++;
              break;
            }
          }
        }
        score += Math.min(indicatorMatches, 10) * 10;
      }
      
      if (score > 0) {
        frameworkScores.set(frameworkName, score);
      }
    }
    
    if (frameworkScores.size === 0) return null;
    
    const sorted = Array.from(frameworkScores.entries())
      .sort(([, a], [, b]) => b - a);
    
    const [framework, score] = sorted[0] || ['unknown', 0];
    const totalScore = Array.from(frameworkScores.values()).reduce((a, b) => a + b, 0);
    
    return {
      framework,
      confidence: Math.min(99, Math.round((score / totalScore) * 100))
    };
  }
  
  /**
   * Check if dependencies exist in dependency files
   */
  private async checkDependencies(files: Map<string, string>, dependencies: string[]): Promise<number> {
    let matches = 0;
    
    // Check package.json
    const packageJson = files.get('package.json');
    if (packageJson) {
      try {
        const pkg = JSON.parse(packageJson);
        const allDeps = {
          ...pkg.dependencies,
          ...pkg.devDependencies,
          ...pkg.peerDependencies
        };
        
        for (const dep of dependencies) {
          if (dep in allDeps) matches++;
        }
      } catch (error) {
        logger.warn('Failed to parse package.json for dependency detection');
      }
    }
    
    // Check requirements.txt
    const requirements = files.get('requirements.txt');
    if (requirements) {
      const lines = requirements.split('\n');
      for (const dep of dependencies) {
        if (lines.some(line => line.toLowerCase().includes(dep.toLowerCase()))) {
          matches++;
        }
      }
    }
    
    // Check Gemfile
    const gemfile = files.get('Gemfile');
    if (gemfile) {
      for (const dep of dependencies) {
        if (gemfile.includes(`gem '${dep}'`) || gemfile.includes(`gem "${dep}"`)) {
          matches++;
        }
      }
    }
    
    // Check go.mod
    const gomod = files.get('go.mod');
    if (gomod) {
      for (const dep of dependencies) {
        if (gomod.includes(dep)) matches++;
      }
    }
    
    // Check pom.xml
    const pomXml = files.get('pom.xml');
    if (pomXml) {
      for (const dep of dependencies) {
        if (pomXml.includes(`<artifactId>${dep}</artifactId>`)) matches++;
      }
    }
    
    return matches;
  }
  
  /**
   * Detect package manager based on lock files and config
   */
  private async detectPackageManager(
    _files: Map<string, string>,
    fileList: string[],
    _language: string
  ): Promise<string | undefined> {
    const packageManagers: Record<string, string[]> = {
      npm: ['package-lock.json', 'npm-shrinkwrap.json'],
      yarn: ['yarn.lock'],
      pnpm: ['pnpm-lock.yaml'],
      pip: ['requirements.txt', 'requirements.lock'],
      poetry: ['poetry.lock', 'pyproject.toml'],
      pipenv: ['Pipfile.lock', 'Pipfile'],
      maven: ['pom.xml'],
      gradle: ['build.gradle', 'build.gradle.kts'],
      cargo: ['Cargo.lock'],
      bundler: ['Gemfile.lock'],
      composer: ['composer.lock'],
      nuget: ['packages.config', '*.csproj'],
      go: ['go.mod']
    };
    
    for (const [manager, indicators] of Object.entries(packageManagers)) {
      for (const indicator of indicators) {
        if (this.matchPattern(fileList, indicator).length > 0) {
          return manager;
        }
      }
    }
    
    return undefined;
  }
  
  /**
   * Get language metadata including common patterns and best practices
   */
  getLanguageMetadata(language: string): {
    name: string;
    fileExtensions: string[];
    commonFrameworks: string[];
    testingFrameworks: string[];
    buildTools: string[];
    packageManagers: string[];
  } {
    const metadata: Record<string, any> = {
      typescript: {
        name: 'TypeScript',
        fileExtensions: ['.ts', '.tsx', '.d.ts'],
        commonFrameworks: ['React', 'Angular', 'Vue', 'Express', 'NestJS'],
        testingFrameworks: ['Jest', 'Mocha', 'Jasmine', 'Cypress'],
        buildTools: ['Webpack', 'Rollup', 'Parcel', 'Vite'],
        packageManagers: ['npm', 'yarn', 'pnpm']
      },
      javascript: {
        name: 'JavaScript',
        fileExtensions: ['.js', '.jsx', '.mjs', '.cjs'],
        commonFrameworks: ['React', 'Vue', 'Express', 'Next.js'],
        testingFrameworks: ['Jest', 'Mocha', 'Jasmine', 'Cypress'],
        buildTools: ['Webpack', 'Rollup', 'Parcel', 'Vite'],
        packageManagers: ['npm', 'yarn', 'pnpm']
      },
      python: {
        name: 'Python',
        fileExtensions: ['.py', '.pyw', '.pyx'],
        commonFrameworks: ['Django', 'Flask', 'FastAPI', 'Pyramid'],
        testingFrameworks: ['pytest', 'unittest', 'nose2'],
        buildTools: ['setuptools', 'poetry', 'flit'],
        packageManagers: ['pip', 'poetry', 'pipenv', 'conda']
      },
      java: {
        name: 'Java',
        fileExtensions: ['.java', '.class', '.jar'],
        commonFrameworks: ['Spring', 'Spring Boot', 'Struts', 'JSF'],
        testingFrameworks: ['JUnit', 'TestNG', 'Mockito'],
        buildTools: ['Maven', 'Gradle', 'Ant'],
        packageManagers: ['maven', 'gradle']
      },
      go: {
        name: 'Go',
        fileExtensions: ['.go'],
        commonFrameworks: ['Gin', 'Echo', 'Fiber', 'Beego'],
        testingFrameworks: ['testing', 'testify', 'ginkgo'],
        buildTools: ['go build', 'make'],
        packageManagers: ['go modules']
      },
      csharp: {
        name: 'C#',
        fileExtensions: ['.cs', '.csx'],
        commonFrameworks: ['ASP.NET Core', '.NET Framework', 'Unity', 'Xamarin'],
        testingFrameworks: ['xUnit', 'NUnit', 'MSTest'],
        buildTools: ['MSBuild', 'dotnet CLI'],
        packageManagers: ['NuGet', 'Paket']
      },
      php: {
        name: 'PHP',
        fileExtensions: ['.php', '.phtml'],
        commonFrameworks: ['Laravel', 'Symfony', 'CodeIgniter', 'Slim'],
        testingFrameworks: ['PHPUnit', 'Codeception', 'Behat'],
        buildTools: ['Composer', 'Phing'],
        packageManagers: ['composer']
      },
      ruby: {
        name: 'Ruby',
        fileExtensions: ['.rb', '.rake'],
        commonFrameworks: ['Ruby on Rails', 'Sinatra', 'Hanami'],
        testingFrameworks: ['RSpec', 'Minitest', 'Cucumber'],
        buildTools: ['Rake', 'Bundler'],
        packageManagers: ['gem', 'bundler']
      }
    };
    
    return metadata[language] || {
      name: language.charAt(0).toUpperCase() + language.slice(1),
      fileExtensions: [],
      commonFrameworks: [],
      testingFrameworks: [],
      buildTools: [],
      packageManagers: []
    };
  }
}

export const languageDetectionService = LanguageDetectionService.getInstance();