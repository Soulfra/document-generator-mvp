// Simple test file for upload
const express = require('express');
const app = express();

// A simple function that needs cleanup
function messyFunction(x, y) {
    var result = x + y;
    console.log("Result is: " + result);
    return result;
}

// TODO: Fix this function
function brokenFunction() {
    // This function has issues
    var data = [1,2,3,4,5];
    for(var i = 0; i < data.length; i++) {
        console.log(data[i]);
    }
}

module.exports = { messyFunction, brokenFunction };