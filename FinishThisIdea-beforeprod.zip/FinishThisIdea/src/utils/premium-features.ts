import { User, UserTier } from '@prisma/client';
import { trackPaywallHit } from './analytics';

/**
 * Premium Feature Utility Functions
 * Centralized logic for checking premium feature access
 */

export interface PremiumLimits {
  maxFileSize: number;        // in bytes
  maxProfiles: number;        // number of custom profiles
  maxBatchSize: number;       // number of files in batch
  allowedExportFormats: string[];
  hasAdvancedTemplates: boolean;
  hasPriorityProcessing: boolean;
}

export interface PremiumValidationOptions {
  contextProfileId?: string;
  feature?: string;
}

/**
 * Check if user has premium access
 */
export function hasPremium(user: User | null): boolean {
  return user?.tier === UserTier.PREMIUM;
}

/**
 * Check if user is free tier
 */
export function isFree(user: User | null): boolean {
  return !user || user.tier === UserTier.FREE;
}

/**
 * Get premium limits based on user tier
 */
export function getPremiumLimits(user: User | null): PremiumLimits {
  const isPremium = hasPremium(user);
  
  return {
    maxFileSize: isPremium ? 500 * 1024 * 1024 : 50 * 1024 * 1024, // 500MB vs 50MB
    maxProfiles: isPremium ? 10 : 2,
    maxBatchSize: isPremium ? 10 : 1,
    allowedExportFormats: isPremium 
      ? ['zip', 'pdf', 'html', 'md'] 
      : ['zip'],
    hasAdvancedTemplates: isPremium,
    hasPriorityProcessing: isPremium,
  };
}

/**
 * Get job queue priority based on user tier
 */
export function getJobPriority(user: User | null): number {
  return hasPremium(user) ? 2 : 1;
}

/**
 * Check if user can access a specific feature
 */
export function canAccess(user: User | null, feature: PremiumFeature): boolean {
  if (!user) return false;
  
  const limits = getPremiumLimits(user);
  
  switch (feature) {
    case 'priority-processing':
      return limits.hasPriorityProcessing;
    case 'advanced-templates':
      return limits.hasAdvancedTemplates;
    case 'batch-processing':
      return limits.maxBatchSize > 1;
    case 'large-files':
      return limits.maxFileSize > 50 * 1024 * 1024;
    case 'export-formats':
      return limits.allowedExportFormats.length > 1;
    default:
      return true; // Default to allowing access for unknown features
  }
}

/**
 * Premium feature identifiers
 */
export type PremiumFeature = 
  | 'priority-processing'
  | 'advanced-templates'
  | 'batch-processing'
  | 'large-files'
  | 'export-formats';

/**
 * Get user-friendly feature names
 */
export function getFeatureName(feature: PremiumFeature): string {
  const names: Record<PremiumFeature, string> = {
    'priority-processing': 'Priority Processing',
    'advanced-templates': 'Advanced Templates',
    'batch-processing': 'Batch Processing',
    'large-files': 'Large File Upload',
    'export-formats': 'Multiple Export Formats',
  };
  
  return names[feature];
}

/**
 * Validate file size against user tier
 */
export function validateFileSize(user: User | null, fileSize: number, options?: PremiumValidationOptions): void {
  const limits = getPremiumLimits(user);
  
  if (fileSize > limits.maxFileSize) {
    const maxSizeMB = Math.round(limits.maxFileSize / (1024 * 1024));
    const currentSizeMB = Math.round(fileSize / (1024 * 1024));
    
    // Track paywall hit for analytics
    if (user?.id) {
      trackPaywallHit(
        user.id,
        'file-size',
        user.tier || 'FREE',
        maxSizeMB,
        currentSizeMB,
        options?.contextProfileId
      );
    }
    
    const upgradeMessage = options?.contextProfileId 
      ? 'Upgrade to Premium to upload larger files for your projects.'
      : 'Upgrade to Premium for larger files.';
    
    throw new Error(
      `File size ${currentSizeMB}MB exceeds limit of ${maxSizeMB}MB. ` +
      (isFree(user) ? upgradeMessage : '')
    );
  }
}

/**
 * Validate batch size against user tier
 */
export function validateBatchSize(user: User | null, batchSize: number, options?: PremiumValidationOptions): void {
  const limits = getPremiumLimits(user);
  
  if (batchSize > limits.maxBatchSize) {
    // Track paywall hit for analytics
    if (user?.id) {
      trackPaywallHit(
        user.id,
        'batch-processing',
        user.tier || 'FREE',
        limits.maxBatchSize,
        batchSize,
        options?.contextProfileId
      );
    }
    
    const upgradeMessage = options?.contextProfileId 
      ? 'Upgrade to Premium to unlock batch processing for your projects.'
      : 'Upgrade to Premium for batch processing.';
    
    throw new Error(
      `Batch size ${batchSize} exceeds limit of ${limits.maxBatchSize}. ` +
      (isFree(user) ? upgradeMessage : '')
    );
  }
}

/**
 * Validate export format against user tier
 */
export function validateExportFormat(user: User | null, format: string): void {
  const limits = getPremiumLimits(user);
  
  if (!limits.allowedExportFormats.includes(format)) {
    throw new Error(
      `Export format '${format}' is not available. ` +
      (isFree(user) ? 'Upgrade to Premium for more export formats.' : 'Invalid format.')
    );
  }
}

/**
 * Validate profile count against user tier
 */
export function validateProfileCount(user: User | null, currentCount: number): void {
  const limits = getPremiumLimits(user);
  
  if (currentCount >= limits.maxProfiles) {
    throw new Error(
      `Profile limit of ${limits.maxProfiles} reached. ` +
      (isFree(user) ? 'Upgrade to Premium for more custom profiles.' : '')
    );
  }
}

/**
 * Get upgrade message for a specific feature
 */
export function getUpgradeMessage(feature: PremiumFeature, contextProfileId?: string): string {
  const featureName = getFeatureName(feature);
  const baseMessage = `${featureName} is a Premium feature.`;
  
  if (contextProfileId) {
    return `${baseMessage} Upgrade to unlock this functionality for your projects.`;
  }
  
  return `${baseMessage} Upgrade to unlock this functionality.`;
}

/**
 * Create premium validation error with context profile support
 */
export function createPremiumValidationError(
  feature: PremiumFeature,
  options?: PremiumValidationOptions
): Error {
  const error = new Error(getUpgradeMessage(feature, options?.contextProfileId));
  (error as any).upgradeRequired = true;
  (error as any).feature = feature;
  (error as any).contextProfileId = options?.contextProfileId;
  return error;
}

/**
 * Premium feature configuration
 */
export const PREMIUM_CONFIG = {
  FREE: {
    maxFileSize: 50 * 1024 * 1024,    // 50MB
    maxProfiles: 2,
    maxBatchSize: 1,
    exportFormats: ['zip'],
    templates: ['basic', 'standard'],
    priority: 1,
  },
  PREMIUM: {
    maxFileSize: 500 * 1024 * 1024,   // 500MB
    maxProfiles: 10,
    maxBatchSize: 10,
    exportFormats: ['zip', 'pdf', 'html', 'md'],
    templates: ['basic', 'standard', 'advanced', 'enterprise'],
    priority: 2,
  },
} as const;