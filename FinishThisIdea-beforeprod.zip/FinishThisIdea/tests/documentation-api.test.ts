import request from 'supertest';
import { app } from '../src/server';

// Mock the documentation service
jest.mock('../src/services/documentation.service', () => ({
  documentationService: {
    analyzeCodeForDocumentation: jest.fn().mockResolvedValue({
      projectInfo: { name: 'Test Project', description: 'A test project', type: 'webapp', language: 'typescript' },
      apis: [],
      dataModels: [],
      functions: [],
      dependencies: [],
      testCoverage: { coverage: 0, testFiles: 0, testCases: 0, passingTests: 0, failingTests: 0 },
      architecture: { pattern: 'MVC', layers: [], components: [] },
      businessLogic: [],
      fileStructure: { totalFiles: 0, linesOfCode: 0, directories: [], mainFiles: [] }
    }),
    generateDocumentation: jest.fn().mockResolvedValue({
      jobId: 'test-job-123',
      templates: [
        {
          templateId: 'executive-summary',
          templateName: 'Executive Summary',
          content: '# Test Project\n\nThis is a test project documentation.',
          sections: []
        }
      ],
      metadata: {
        generatedAt: new Date(),
        templatesUsed: ['executive-summary'],
        aiTokensUsed: 0,
        quality: { completeness: 80, accuracy: 75, readability: 85, overall: 80 }
      }
    }),
    parseChatlogs: jest.fn().mockResolvedValue({
      features: [],
      userStories: [],
      technicalRequirements: [],
      businessRules: [],
      constraints: []
    })
  }
}));

// Mock prisma
jest.mock('../src/utils/database', () => ({
  prisma: {
    job: {
      findFirst: jest.fn().mockResolvedValue({
        id: 'test-job-123',
        status: 'COMPLETED',
        outputFileUrl: 'https://test-bucket.s3.amazonaws.com/test-output.zip'
      })
    },
    documentation: {
      findFirst: jest.fn().mockResolvedValue(null),
      create: jest.fn().mockResolvedValue({
        id: 'doc-123',
        jobId: 'test-job-123',
        url: 'https://test-bucket.s3.amazonaws.com/docs.zip',
        templates: ['executive-summary'],
        metadata: { quality: 80 }
      })
    }
  }
}));

describe('Documentation API', () => {
  describe('GET /api/documentation/templates', () => {
    it('should return available documentation templates', async () => {
      const response = await request(app)
        .get('/api/documentation/templates')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toBeInstanceOf(Array);
      expect(response.body.data.length).toBeGreaterThan(0);
      
      const execSummary = response.body.data.find((t: any) => t.id === 'executive-summary');
      expect(execSummary).toBeDefined();
      expect(execSummary.name).toBe('Executive Summary');
      expect(execSummary.description).toContain('stakeholders');
    });
  });

  describe('POST /api/documentation/generate', () => {
    it('should generate documentation for a completed job', async () => {
      const response = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId: 'test-job-123',
          templates: ['executive-summary'],
          includeInOutput: true
        })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.documentationId).toBeDefined();
      expect(response.body.data.url).toContain('docs.zip');
      expect(response.body.data.templates).toEqual(['executive-summary']);
      expect(response.body.data.quality).toBeDefined();
    });

    it('should return 404 for non-existent job', async () => {
      // Mock job not found
      const { prisma } = require('../src/utils/database');
      prisma.job.findFirst.mockResolvedValueOnce(null);

      const response = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId: 'non-existent-job',
          templates: ['executive-summary']
        })
        .expect(404);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('not found');
    });

    it('should validate request body', async () => {
      const response = await request(app)
        .post('/api/documentation/generate')
        .send({
          // Missing required jobId
          templates: ['executive-summary']
        })
        .expect(400);

      expect(response.body.success).toBe(false);
    });
  });

  describe('POST /api/documentation/chat-import', () => {
    it('should parse chat logs and extract requirements', async () => {
      const chatLog = {
        messages: [
          {
            role: 'user',
            content: 'I need a user management system',
            timestamp: new Date().toISOString()
          },
          {
            role: 'assistant', 
            content: 'I can help you build that with authentication and CRUD operations'
          }
        ],
        platform: 'claude'
      };

      const response = await request(app)
        .post('/api/documentation/chat-import')
        .send(chatLog)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.requirements).toBeDefined();
      expect(response.body.data.documentation).toBeDefined();
    });

    it('should validate chat log format', async () => {
      const response = await request(app)
        .post('/api/documentation/chat-import')
        .send({
          // Invalid format - missing messages
          platform: 'claude'
        })
        .expect(400);

      expect(response.body.success).toBe(false);
    });
  });

  describe('GET /api/documentation/:jobId', () => {
    it('should return documentation for a job', async () => {
      const { prisma } = require('../src/utils/database');
      prisma.documentation.findFirst.mockResolvedValueOnce({
        id: 'doc-123',
        jobId: 'test-job-123',
        url: 'https://test-bucket.s3.amazonaws.com/docs.zip',
        templates: ['executive-summary'],
        metadata: { quality: 80 },
        createdAt: new Date(),
        updatedAt: new Date()
      });

      const response = await request(app)
        .get('/api/documentation/test-job-123')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.jobId).toBe('test-job-123');
      expect(response.body.data.url).toContain('docs.zip');
    });

    it('should return 404 for non-existent documentation', async () => {
      const { prisma } = require('../src/utils/database');
      prisma.documentation.findFirst.mockResolvedValueOnce(null);

      const response = await request(app)
        .get('/api/documentation/non-existent-job')
        .expect(404);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('not found');
    });
  });

  describe('GET /api/documentation/:jobId/preview', () => {
    it('should return documentation preview', async () => {
      const { prisma } = require('../src/utils/database');
      prisma.documentation.findFirst.mockResolvedValueOnce({
        id: 'doc-123',
        jobId: 'test-job-123',
        templates: ['executive-summary'],
        metadata: { quality: 80 }
      });

      const response = await request(app)
        .get('/api/documentation/test-job-123/preview')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.preview).toBeDefined();
      expect(response.body.data.templates).toEqual(['executive-summary']);
    });
  });

  describe('Error Handling', () => {
    it('should handle internal server errors gracefully', async () => {
      // Mock service to throw error
      const { documentationService } = require('../src/services/documentation.service');
      documentationService.generateDocumentation.mockRejectedValueOnce(new Error('Service error'));

      const response = await request(app)
        .post('/api/documentation/generate')
        .send({
          jobId: 'test-job-123',
          templates: ['executive-summary']
        })
        .expect(500);

      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('Failed to generate');
    });
  });
});