---
title: "Database Documentation"
description: "Comprehensive guide to the PostgreSQL database schema and operations for the Document Generator project"
lastUpdated: "2024-06-28"
version: "1.0"
---

# Database Documentation

Comprehensive guide to the PostgreSQL database schema and operations for the Document Generator project.

## 📋 Overview

The application uses **PostgreSQL 15** as the primary database with **Prisma ORM** for type-safe database operations and migrations.

**Current Configuration:**
- **Database**: PostgreSQL 15 (Alpine Docker image)
- **Port**: 5434 (to avoid local PostgreSQL conflicts)
- **Connection**: `postgresql://postgres:password@localhost:5434/finishthisidea`
- **ORM**: Prisma with TypeScript client
- **Migrations**: Prisma migrate

## 🗄️ Database Schema

### Core Models Overview

```mermaid
erDiagram
    User ||--o{ Job : creates
    User ||--o{ Upload : owns
    User ||--o{ Payment : makes
    User ||--o{ ContextProfile : creates
    Job ||--|| Payment : requires
    Job ||--o| Upload : processes
    Job ||--o| AnalysisResult : generates
    Job ||--o| Documentation : produces
    Job ||--o| ContextProfile : uses
```

### User Model
Central user entity for authentication and ownership.

```sql
CREATE TABLE users (
  id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR UNIQUE,
  username VARCHAR UNIQUE,
  stripe_customer_id VARCHAR UNIQUE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  last_login_at TIMESTAMP
);
```

**Key Features:**
- Optional email/username (supports anonymous usage)
- Stripe integration for payments
- Audit timestamps

### Job Model
Core business entity representing a code analysis job.

```sql
CREATE TABLE jobs (
  id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
  type VARCHAR,
  status job_status DEFAULT 'PENDING',
  input_file_url VARCHAR NOT NULL,
  output_file_url VARCHAR,
  output_url VARCHAR,
  download_url VARCHAR,
  stripe_session_id VARCHAR UNIQUE,
  progress INTEGER DEFAULT 0,
  error TEXT,
  metadata JSONB,
  
  -- Processing details
  current_step VARCHAR,
  input JSONB,
  changes JSONB,
  decisions JSONB,
  
  -- File information
  original_file_name VARCHAR NOT NULL,
  file_size_bytes INTEGER NOT NULL,
  file_count INTEGER,
  
  -- Timing
  processing_started_at TIMESTAMP,
  processing_ended_at TIMESTAMP,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  
  -- Cost tracking
  cost DECIMAL DEFAULT 1.0,
  total_cost DECIMAL DEFAULT 1.0,
  tokens_used INTEGER,
  llm_provider VARCHAR,
  attempts INTEGER DEFAULT 0,
  
  -- Timestamps
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  expires_at TIMESTAMP NOT NULL,
  
  -- Foreign keys
  user_id VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  context_profile_id VARCHAR REFERENCES context_profiles(id),
  upload_id VARCHAR REFERENCES uploads(id)
);
```

**Job Status Enum:**
```sql
CREATE TYPE job_status AS ENUM (
  'PENDING',      -- Waiting for payment
  'PROCESSING',   -- AI analysis in progress
  'REVIEW',       -- Ready for user review
  'APPLYING',     -- Applying approved changes
  'COMPLETED',    -- Successfully finished
  'FAILED',       -- Failed with errors
  'CANCELLED'     -- Cancelled by user
);
```

### Upload Model
File management and storage tracking.

```sql
CREATE TABLE uploads (
  id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
  original_name VARCHAR NOT NULL,
  filename VARCHAR NOT NULL,
  mime_type VARCHAR NOT NULL,
  size INTEGER NOT NULL,
  path VARCHAR NOT NULL,
  url VARCHAR,
  user_id VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  status upload_status DEFAULT 'PENDING',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Payment Model
Stripe payment integration and billing.

```sql
CREATE TABLE payments (
  id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id VARCHAR UNIQUE NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  user_id VARCHAR NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  stripe_payment_intent_id VARCHAR UNIQUE,
  stripe_customer_id VARCHAR,
  stripe_session_id VARCHAR UNIQUE,
  amount INTEGER NOT NULL, -- in cents
  currency VARCHAR DEFAULT 'usd',
  status payment_status DEFAULT 'PENDING',
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  paid_at TIMESTAMP
);
```

### Context Profile Model
Customizable analysis and documentation profiles.

```sql
CREATE TABLE context_profiles (
  id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR NOT NULL,
  description TEXT NOT NULL,
  user_id VARCHAR REFERENCES users(id) ON DELETE SET NULL,
  data JSONB NOT NULL, -- Full profile configuration
  language VARCHAR,
  framework VARCHAR,
  version VARCHAR,
  is_default BOOLEAN DEFAULT FALSE,
  is_public BOOLEAN DEFAULT FALSE,
  usage_count INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Analysis Result Model
AI analysis outputs and metrics.

```sql
CREATE TABLE analysis_results (
  id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id VARCHAR UNIQUE NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  total_files INTEGER NOT NULL,
  lines_of_code INTEGER NOT NULL,
  languages JSONB NOT NULL, -- Language distribution
  issues JSONB NOT NULL,    -- Identified issues
  improvements JSONB NOT NULL, -- Applied improvements
  ollama_confidence DECIMAL,
  claude_used BOOLEAN DEFAULT FALSE,
  processing_cost_usd DECIMAL DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### Documentation Model
Generated documentation tracking.

```sql
CREATE TABLE documentation (
  id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id VARCHAR UNIQUE NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  user_id VARCHAR NOT NULL,
  url VARCHAR NOT NULL, -- S3 URL to documentation package
  templates VARCHAR[] NOT NULL, -- Template IDs used
  metadata JSONB NOT NULL, -- Quality scores, tokens, etc.
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Swipe Pattern Model
User preference learning for UI decisions.

```sql
CREATE TABLE swipe_patterns (
  id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id VARCHAR NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  change_type VARCHAR NOT NULL,
  pattern VARCHAR NOT NULL, -- Pattern identifier
  file_pattern VARCHAR, -- File pattern for the change
  action VARCHAR, -- ACCEPT or REJECT
  usage_count INTEGER DEFAULT 1,
  last_used_at TIMESTAMP DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  
  UNIQUE(user_id, change_type, pattern)
);
```

## 🔧 Database Setup & Management

### Initial Setup

```bash
# Start PostgreSQL via Docker
docker-compose up -d postgres

# Generate Prisma client
npx prisma generate

# Apply schema to database
npx prisma db push

# Alternative: Use migrations
npx prisma migrate dev --name init
```

### Connection Configuration

**Environment Variables:**
```bash
DATABASE_URL=postgresql://postgres:password@localhost:5434/finishthisidea
```

**Prisma Client Usage:**
```typescript
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient({
  log: ['query', 'info', 'warn', 'error'],
  errorFormat: 'pretty',
});

// Example usage
const user = await prisma.user.create({
  data: {
    email: 'user@example.com',
    username: 'testuser',
  },
});
```

## 🔄 Migrations

### Creating Migrations

```bash
# Create a new migration
npx prisma migrate dev --name add_new_feature

# Apply migrations to production
npx prisma migrate deploy

# Reset database (development only)
npx prisma migrate reset
```

### Migration Best Practices

1. **Always backup** production data before migrations
2. **Test migrations** on staging environment first
3. **Use descriptive names** for migration files
4. **Review generated SQL** before applying
5. **Consider downtime** for large table alterations

### Common Migration Patterns

**Adding a new column:**
```sql
-- Migration: add_user_preferences.sql
ALTER TABLE users ADD COLUMN preferences JSONB DEFAULT '{}';
```

**Creating indexes:**
```sql
-- Migration: add_performance_indexes.sql
CREATE INDEX idx_jobs_status_created ON jobs(status, created_at);
CREATE INDEX idx_jobs_user_id ON jobs(user_id) WHERE user_id IS NOT NULL;
```

**Data transformations:**
```sql
-- Migration: normalize_job_costs.sql
UPDATE jobs SET cost = 1.0 WHERE cost IS NULL OR cost = 0;
```

## 📊 Database Queries & Operations

### Common Query Patterns

**Get user with recent jobs:**
```typescript
const userWithJobs = await prisma.user.findUnique({
  where: { id: userId },
  include: {
    jobs: {
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: {
        payment: true,
        analysisResult: true,
      },
    },
  },
});
```

**Job status aggregation:**
```typescript
const jobStats = await prisma.job.groupBy({
  by: ['status'],
  _count: {
    status: true,
  },
  where: {
    createdAt: {
      gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
    },
  },
});
```

**Complex job search:**
```typescript
const jobs = await prisma.job.findMany({
  where: {
    AND: [
      { status: { in: ['COMPLETED', 'FAILED'] } },
      { createdAt: { gte: startDate } },
      { cost: { gte: 1.0 } },
    ],
  },
  include: {
    user: { select: { id: true, email: true } },
    payment: { select: { status: true, amount: true } },
    analysisResult: { select: { totalFiles: true, linesOfCode: true } },
  },
  orderBy: { createdAt: 'desc' },
  skip: (page - 1) * limit,
  take: limit,
});
```

### Optimized Queries

**Use select to limit fields:**
```typescript
const lightweightJobs = await prisma.job.findMany({
  select: {
    id: true,
    status: true,
    originalFileName: true,
    createdAt: true,
    cost: true,
  },
  where: { userId },
});
```

**Use transactions for data consistency:**
```typescript
const result = await prisma.$transaction(async (tx) => {
  const job = await tx.job.create({
    data: { /* job data */ },
  });

  const payment = await tx.payment.create({
    data: {
      jobId: job.id,
      userId: job.userId,
      amount: 100, // $1.00
    },
  });

  return { job, payment };
});
```

## 🚀 Performance Optimization

### Database Indexes

**Existing indexes (auto-created by Prisma):**
```sql
-- Primary keys and unique constraints
CREATE UNIQUE INDEX users_email_key ON users(email);
CREATE UNIQUE INDEX jobs_stripe_session_id_key ON jobs(stripe_session_id);

-- Foreign key indexes
CREATE INDEX jobs_user_id_idx ON jobs(user_id);
CREATE INDEX payments_job_id_idx ON payments(job_id);

-- Query optimization indexes
CREATE INDEX jobs_status_idx ON jobs(status);
CREATE INDEX jobs_created_at_idx ON jobs(created_at);
CREATE INDEX uploads_status_idx ON uploads(status);
```

**Additional recommended indexes:**
```sql
-- Composite indexes for common queries
CREATE INDEX jobs_status_created_idx ON jobs(status, created_at);
CREATE INDEX jobs_user_status_idx ON jobs(user_id, status) WHERE user_id IS NOT NULL;

-- JSONB indexes for metadata queries
CREATE INDEX jobs_metadata_gin_idx ON jobs USING GIN(metadata);
CREATE INDEX analysis_results_languages_gin_idx ON analysis_results USING GIN(languages);
```

### Query Performance Tips

1. **Use `select`** to limit returned fields
2. **Add appropriate indexes** for frequent queries
3. **Use `include` carefully** - avoid deep nesting
4. **Implement pagination** for large result sets
5. **Monitor query performance** with Prisma query logs

### Connection Pooling

**Production configuration:**
```typescript
const prisma = new PrismaClient({
  datasources: {
    db: {
      url: process.env.DATABASE_URL,
    },
  },
});

// Configure connection pool
// DATABASE_URL="postgresql://user:pass@host:port/db?connection_limit=10&pool_timeout=20"
```

## 🔒 Security Considerations

### Data Protection
- **Sensitive data encryption** for user information
- **PII handling** according to privacy regulations
- **Secure connection** using SSL in production
- **Input validation** before database operations

### Access Control
```typescript
// Row-level security example
const userJobs = await prisma.job.findMany({
  where: {
    userId: currentUser.id, // Ensure users only see their data
  },
});
```

### SQL Injection Prevention
Prisma automatically handles parameterization, but for raw queries:

```typescript
// Safe raw query
const result = await prisma.$queryRaw`
  SELECT * FROM jobs 
  WHERE user_id = ${userId} 
  AND status = ${status}
`;

// Unsafe - don't do this
const unsafe = await prisma.$queryRawUnsafe(
  `SELECT * FROM jobs WHERE user_id = '${userId}'`
);
```

## 🔧 Maintenance & Monitoring

### Database Health Checks

```typescript
// Health check query
export async function checkDatabaseHealth() {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return { status: 'healthy' };
  } catch (error) {
    return { status: 'unhealthy', error: error.message };
  }
}
```

### Regular Maintenance Tasks

```bash
# Analyze table statistics
docker exec finishthisidea-db psql -U postgres -d finishthisidea -c "ANALYZE;"

# Check database size
docker exec finishthisidea-db psql -U postgres -d finishthisidea -c "
  SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
  FROM pg_tables 
  WHERE schemaname = 'public'
  ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
"
```

### Backup Strategy

**Development backup:**
```bash
# Create backup
docker exec finishthisidea-db pg_dump -U postgres finishthisidea > backup.sql

# Restore backup
docker exec -i finishthisidea-db psql -U postgres finishthisidea < backup.sql
```

**Production backup (recommended):**
- Automated daily backups to S3
- Point-in-time recovery enabled
- Cross-region backup replication
- Regular restore testing

## 🐛 Troubleshooting

### Common Issues

**Connection refused:**
```bash
# Check if PostgreSQL is running
docker ps | grep postgres

# Check logs
docker logs finishthisidea-db

# Restart container
docker-compose restart postgres
```

**Migration conflicts:**
```bash
# Reset migration state
npx prisma migrate reset

# Force apply current schema
npx prisma db push --force-reset
```

**Performance issues:**
```sql
-- Check slow queries
SELECT query, mean_time, calls 
FROM pg_stat_statements 
ORDER BY mean_time DESC 
LIMIT 10;

-- Check table sizes
SELECT schemaname, tablename, pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

### Emergency Procedures

**Database locked/corrupted:**
1. Stop all application processes
2. Restart PostgreSQL container
3. Check logs for specific errors
4. Restore from backup if necessary

**Data integrity issues:**
```sql
-- Check for orphaned records
SELECT j.id FROM jobs j 
LEFT JOIN payments p ON j.id = p.job_id 
WHERE j.status = 'COMPLETED' AND p.id IS NULL;

-- Verify foreign key constraints
SELECT * FROM information_schema.table_constraints 
WHERE constraint_type = 'FOREIGN KEY';
```

## 📚 Additional Resources

- [Prisma Documentation](https://www.prisma.io/docs/)
- [PostgreSQL Manual](https://www.postgresql.org/docs/)
- [Database Design Best Practices](https://www.postgresql.org/docs/current/ddl-best-practices.html)
- [Prisma Query Optimization](https://www.prisma.io/docs/guides/performance-and-optimization)

---

**Last Updated**: 2024-01-15  
**Schema Version**: 1.0.0