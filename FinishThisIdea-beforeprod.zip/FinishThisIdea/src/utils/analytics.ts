import { logger } from './logger';
import { analyticsService } from '../automation/services/analytics-integration.service';

/**
 * Basic Analytics for Premium Features
 * Tracks paywall hits and upgrade opportunities
 */

export interface PaywallEvent {
  userId: string;
  feature: 'file-size' | 'batch-processing' | 'templates' | 'profiles' | 'export-formats';
  action: 'blocked' | 'upgrade-shown' | 'upgrade-clicked' | 'upgrade-completed';
  metadata: {
    userTier: 'FREE' | 'PREMIUM';
    limitValue?: number;
    attemptedValue?: number;
    timestamp: Date;
  };
}

export interface FeatureUsageEvent {
  userId: string;
  feature: string;
  success: boolean;
  userTier: 'FREE' | 'PREMIUM';
  metadata?: any;
}

/**
 * Track when users hit premium feature limits
 */
export function trackPaywallHit(
  userId: string,
  feature: PaywallEvent['feature'],
  userTier: 'FREE' | 'PREMIUM',
  limitValue?: number,
  attemptedValue?: number,
  contextProfileId?: string
): void {
  const event: PaywallEvent = {
    userId,
    feature,
    action: 'blocked',
    metadata: {
      userTier,
      limitValue,
      attemptedValue,
      timestamp: new Date(),
      contextProfileId,
    },
  };

  // Log for basic analytics (can be enhanced with external services)
  logger.info('Paywall hit tracked', {
    analytics: 'paywall-hit',
    ...event,
  });

  // Send to external analytics services
  analyticsService.track({
    event: 'paywall_hit',
    userId,
    properties: {
      feature,
      userTier,
      limitValue,
      attemptedValue,
      contextProfileId,
    },
  });
}

/**
 * Track premium feature usage (successful)
 */
export function trackFeatureUsage(
  userId: string,
  feature: string,
  success: boolean,
  userTier: 'FREE' | 'PREMIUM',
  metadata?: any
): void {
  const event: FeatureUsageEvent = {
    userId,
    feature,
    success,
    userTier,
    metadata,
  };

  logger.info('Feature usage tracked', {
    analytics: 'feature-usage',
    ...event,
  });

  // Send to external analytics services
  analyticsService.trackFeatureUsage(feature, userId, success, {
    userTier,
    ...metadata,
  });
}

/**
 * Track upgrade interactions
 */
export function trackUpgradeInteraction(
  userId: string,
  action: 'upgrade-shown' | 'upgrade-clicked' | 'upgrade-completed' | 'checkout_initiated',
  userTier: 'FREE' | 'PREMIUM',
  contextProfileId?: string
): void {
  const event = {
    userId,
    action,
    userTier,
    contextProfileId,
    timestamp: new Date(),
  };

  logger.info('Upgrade interaction tracked', {
    analytics: 'upgrade-interaction',
    ...event,
  });

  // Send to external analytics services
  analyticsService.track({
    event: 'upgrade_interaction',
    userId,
    properties: {
      action,
      userTier,
      contextProfileId,
    },
  });
}

/**
 * Track user tier changes (conversions)
 */
export function trackTierChange(
  userId: string,
  fromTier: 'FREE' | 'PREMIUM',
  toTier: 'FREE' | 'PREMIUM',
  contextProfileId?: string,
  revenue?: number
): void {
  const event = {
    userId,
    fromTier,
    toTier,
    contextProfileId,
    revenue,
    timestamp: new Date(),
  };

  logger.info('Tier change tracked', {
    analytics: 'tier-change',
    ...event,
  });

  // Send to external analytics services
  analyticsService.trackConversion('upgrade', userId, revenue, {
    fromTier,
    toTier,
    contextProfileId,
  });
}

/**
 * Track profile-based feature usage patterns
 */
export function trackProfileFeatureUsage(
  userId: string,
  contextProfileId: string,
  feature: string,
  userTier: 'FREE' | 'PREMIUM',
  success: boolean
): void {
  const event = {
    userId,
    contextProfileId,
    feature,
    userTier,
    success,
    timestamp: new Date(),
  };

  logger.info('Profile feature usage tracked', {
    analytics: 'profile-feature-usage',
    ...event,
  });

  // TODO: Send to analytics service
}

/**
 * Get analytics summary for admin dashboard
 */
export async function getAnalyticsSummary() {
  // TODO: Implement analytics summary from logs or external service
  return {
    paywallHits: {
      total: 0,
      byFeature: {},
    },
    conversions: {
      total: 0,
      rate: 0,
    },
    featureUsage: {
      premium: {},
      free: {},
    },
  };
}

/**
 * Enhanced analytics wrapper for external services
 */
export class AnalyticsService {
  /**
   * Initialize analytics with external services
   */
  static init() {
    // TODO: Initialize Mixpanel, Google Analytics, etc.
    logger.info('Analytics service initialized');
  }

  /**
   * Track any event with consistent format
   */
  static track(eventName: string, properties: any) {
    const event = {
      event: eventName,
      properties: {
        ...properties,
        timestamp: new Date().toISOString(),
      },
    };

    logger.info('Analytics event tracked', {
      analytics: eventName,
      ...event,
    });

    // TODO: Send to multiple analytics platforms
    // this.sendToMixpanel(event);
    // this.sendToGoogleAnalytics(event);
    // this.sendToCustomAnalytics(event);
  }

  /**
   * Track page view (for frontend)
   */
  static trackPageView(page: string, userId?: string) {
    this.track('page_view', {
      page,
      userId,
    });
  }

  /**
   * Track conversion events
   */
  static trackConversion(userId: string, conversionType: string, value?: number) {
    this.track('conversion', {
      userId,
      conversionType,
      value,
    });
  }
}