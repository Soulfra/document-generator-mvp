import { PythonParser } from '../../src/parsers/python-parser';
import { APIEndpoint, DataModel, FunctionSignature } from '../../src/types/code-analysis';
import { ParseResult } from '../../src/parsers/base-parser';

describe('PythonParser', () => {
  let parser: PythonParser;

  beforeEach(() => {
    parser = new PythonParser();
  });

  describe('Basic Parser Properties', () => {
    it('should return correct language identifier', () => {
      expect(parser.getLanguage()).toBe('python');
    });

    it('should return correct supported extensions', () => {
      const extensions = parser.getSupportedExtensions();
      expect(extensions).toContain('.py');
      expect(extensions).toContain('.pyw');
      expect(extensions).toContain('.pyx');
      expect(extensions).toContain('.pyi');
    });
  });

  describe('API Extraction', () => {
    describe('Django URLs', () => {
      it('should extract Django path patterns', async () => {
        const files = new Map<string, string>([
          ['urls.py', `
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('users/', views.user_list, name='user-list'),
    path('users/<int:id>/', views.user_detail, name='user-detail'),
    path('api/posts/<slug:slug>/', views.PostView.as_view(), name='post-detail'),
]
          `]
        ]);

        const apis = await parser.extractAPIs(files);

        expect(apis).toHaveLength(4);
        expect(apis[0]).toMatchObject({
          method: 'GET',
          path: '',
          description: 'Django view: index (index)'
        });
        expect(apis[2]).toMatchObject({
          method: 'GET',
          path: 'users/<int:id>/',
          parameters: expect.arrayContaining([
            expect.objectContaining({
              name: 'id',
              type: 'integer',
              required: true
            })
          ])
        });
      });

      it('should extract Django ViewSet routes', async () => {
        const files = new Map<string, string>([
          ['views.py', `
from rest_framework import viewsets
from .models import Product
from .serializers import ProductSerializer

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
          `]
        ]);

        const apis = await parser.extractAPIs(files);

        expect(apis).toHaveLength(5); // List, Create, Retrieve, Update, Delete
        expect(apis).toContainEqual(expect.objectContaining({
          method: 'GET',
          path: '/products/',
          description: 'List product'
        }));
        expect(apis).toContainEqual(expect.objectContaining({
          method: 'POST',
          path: '/products/',
          description: 'Create product'
        }));
        expect(apis).toContainEqual(expect.objectContaining({
          method: 'DELETE',
          path: '/products/{id}/',
          description: 'Delete product'
        }));
      });
    });

    describe('Flask Routes', () => {
      it('should extract Flask route decorators', async () => {
        const files = new Map<string, string>([
          ['app.py', `
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return 'Hello World'

@app.route('/api/users', methods=['GET', 'POST'])
def users():
    if request.method == 'POST':
        return jsonify({'created': True})
    return jsonify({'users': []})

@app.route('/api/users/<int:user_id>', methods=['GET', 'PUT', 'DELETE'])
def user_detail(user_id):
    return jsonify({'id': user_id})
          `]
        ]);

        const apis = await parser.extractAPIs(files);

        expect(apis).toHaveLength(6); // 1 + 2 + 3 methods
        expect(apis).toContainEqual(expect.objectContaining({
          method: 'GET',
          path: '/',
          description: 'Flask route: home'
        }));
        expect(apis).toContainEqual(expect.objectContaining({
          method: 'POST',
          path: '/api/users',
          description: 'Flask route: users'
        }));
      });

      it('should detect authentication decorators', async () => {
        const files = new Map<string, string>([
          ['auth_routes.py', `
from flask import Blueprint
from flask_jwt_extended import jwt_required
from flask_login import login_required

bp = Blueprint('auth', __name__)

@bp.route('/protected')
@login_required
def protected():
    return 'Protected'

@bp.route('/api/secure')
@jwt_required()
def secure():
    return 'Secure'
          `]
        ]);

        const apis = await parser.extractAPIs(files);

        expect(apis[0].authentication).toBe(true);
        expect(apis[1].authentication).toBe(true);
      });
    });

    describe('FastAPI Routes', () => {
      it('should extract FastAPI endpoints with type hints', async () => {
        const files = new Map<string, string>([
          ['main.py', `
from fastapi import FastAPI, Query, Path
from pydantic import BaseModel
from typing import Optional, List

app = FastAPI()

class Item(BaseModel):
    name: str
    price: float
    is_offer: Optional[bool] = None

@app.get("/")
async def root():
    return {"message": "Hello World"}

@app.post("/items/", response_model=Item)
async def create_item(item: Item):
    return item

@app.get("/items/{item_id}")
async def read_item(
    item_id: int = Path(..., title="The ID of the item"),
    q: Optional[str] = Query(None, max_length=50)
):
    return {"item_id": item_id, "q": q}

@app.put("/items/{item_id}")
async def update_item(item_id: int, item: Item, current_user: User = Depends(get_current_user)):
    return {"item_id": item_id, "item": item}
          `]
        ]);

        const apis = await parser.extractAPIs(files);

        expect(apis).toHaveLength(4);
        expect(apis[1]).toMatchObject({
          method: 'POST',
          path: '/items/',
          description: 'FastAPI endpoint: create_item',
          responses: {
            '200': {
              description: 'Success',
              schema: 'Item'
            }
          }
        });
        expect(apis[3].authentication).toBe(true); // current_user parameter
      });
    });
  });

  describe('Function Extraction', () => {
    it('should extract function signatures with type hints', async () => {
      const files = new Map<string, string>([
        ['utils.py', `
def simple_function():
    """A simple function"""
    pass

async def async_function(name: str, age: int = 18) -> dict:
    """An async function with type hints"""
    return {"name": name, "age": age}

def complex_function(
    items: List[str],
    *args: Any,
    debug: bool = False,
    **kwargs: Dict[str, Any]
) -> Optional[int]:
    """Complex function with various parameter types"""
    if debug:
        print(items, args, kwargs)
    return len(items) if items else None
        `]
      ]);

      const functions = await parser.extractFunctions(files);

      expect(functions).toHaveLength(3);
      expect(functions[0]).toMatchObject({
        name: 'simple_function',
        description: 'A simple function',
        parameters: [],
        returnType: 'Any'
      });
      expect(functions[1]).toMatchObject({
        name: 'async_function',
        async: true,
        parameters: [
          { name: 'name', type: 'string', required: true },
          { name: 'age', type: 'integer', required: false, defaultValue: '18' }
        ],
        returnType: 'dict'
      });
      expect(functions[2].parameters).toContainEqual(
        expect.objectContaining({ name: '*args' })
      );
    });

    it('should extract class methods with decorators', async () => {
      const files = new Map<string, string>([
        ['models.py', `
class UserService:
    """Service for user operations"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def get_user(self, user_id: int) -> User:
        """Get user by ID"""
        return self.db.query(User).get(user_id)
    
    @staticmethod
    def validate_email(email: str) -> bool:
        """Validate email format"""
        return "@" in email
    
    @classmethod
    def from_config(cls, config: dict) -> "UserService":
        """Create service from config"""
        return cls(Database(config["db_url"]))
    
    @property
    def connection_string(self) -> str:
        """Get database connection string"""
        return self.db.url
    
    async def _private_method(self):
        """Private method"""
        pass
        `]
      ]);

      const functions = await parser.extractFunctions(files);

      expect(functions).toHaveLength(6);
      expect(functions).toContainEqual(expect.objectContaining({
        name: 'UserService.__init__',
        parameters: [{ name: 'db', type: 'Database', required: true }]
      }));
      expect(functions).toContainEqual(expect.objectContaining({
        name: 'UserService.validate_email',
        decorators: ['@staticmethod']
      }));
      expect(functions).toContainEqual(expect.objectContaining({
        name: 'UserService.connection_string',
        decorators: ['@property']
      }));
    });

    it('should respect includePrivate option', async () => {
      const files = new Map<string, string>([
        ['private.py', `
def public_function():
    pass

def _private_function():
    pass

class MyClass:
    def public_method(self):
        pass
    
    def _private_method(self):
        pass
        `]
      ]);

      // Default: exclude private
      let functions = await parser.extractFunctions(files);
      expect(functions).toHaveLength(2);
      expect(functions.every(f => !f.name.includes('_private'))).toBe(true);

      // Include private
      parser = new PythonParser({ includePrivate: true });
      functions = await parser.extractFunctions(files);
      expect(functions).toHaveLength(4);
    });
  });

  describe('Data Model Extraction', () => {
    it('should extract regular classes', async () => {
      const files = new Map<string, string>([
        ['models.py', `
class Person:
    """A person model"""
    name: str
    age: int = 0
    email: Optional[str] = None
    
    def __init__(self, name: str, age: int = 0):
        self.name = name
        self.age = age
        `]
      ]);

      const models = await parser.extractDataModels(files);

      expect(models).toHaveLength(1);
      expect(models[0]).toMatchObject({
        name: 'Person',
        type: 'class',
        description: 'A person model',
        properties: expect.arrayContaining([
          { name: 'name', type: 'string', required: true },
          { name: 'age', type: 'integer', required: false, defaultValue: '0' },
          { name: 'email', type: 'string | null', required: false, defaultValue: 'None' }
        ])
      });
    });

    it('should extract dataclasses', async () => {
      const files = new Map<string, string>([
        ['dataclasses_example.py', `
from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class Product:
    """Product information"""
    id: int
    name: str
    price: float = 0.0
    tags: List[str] = field(default_factory=list)
    description: Optional[str] = None
        `]
      ]);

      const models = await parser.extractDataModels(files);

      expect(models).toHaveLength(1);
      expect(models[0]).toMatchObject({
        name: 'Product',
        decorators: ['@dataclass'],
        metadata: { isDataclass: true }
      });
    });

    it('should extract Pydantic models', async () => {
      const files = new Map<string, string>([
        ['schemas.py', `
from pydantic import BaseModel, Field, validator
from datetime import datetime

class UserCreate(BaseModel):
    """Schema for creating a user"""
    username: str = Field(..., min_length=3, max_length=50)
    email: str
    password: str = Field(..., min_length=8)
    full_name: Optional[str] = None
    
    @validator('email')
    def email_must_be_valid(cls, v):
        if '@' not in v:
            raise ValueError('Invalid email')
        return v

class UserResponse(BaseModel):
    """Schema for user response"""
    id: int
    username: str
    email: str
    created_at: datetime
    
    class Config:
        orm_mode = True
        `]
      ]);

      const models = await parser.extractDataModels(files);

      expect(models).toHaveLength(2);
      expect(models[0]).toMatchObject({
        name: 'UserCreate',
        extends: ['BaseModel'],
        metadata: { isPydantic: true }
      });
    });

    it('should extract Django models', async () => {
      const files = new Map<string, string>([
        ['models.py', `
from django.db import models
from django.contrib.auth.models import User

class Article(models.Model):
    """Blog article model"""
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    published = models.BooleanField(default=False)
    tags = models.ManyToManyField('Tag', related_name='articles')
    
    class Meta:
        ordering = ['-created_at']
        `]
      ]);

      const models = await parser.extractDataModels(files);

      expect(models).toHaveLength(1);
      expect(models[0]).toMatchObject({
        name: 'Article',
        extends: ['models.Model'],
        metadata: { isDjangoModel: true },
        properties: expect.arrayContaining([
          { name: 'title', type: 'string', required: true },
          { name: 'published', type: 'boolean', required: false }
        ])
      });
    });

    it('should extract SQLAlchemy models', async () => {
      const files = new Map<string, string>([
        ['database.py', `
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()

class User(Base):
    """User account model"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    
    posts = relationship("Post", back_populates="author")
        `]
      ]);

      const models = await parser.extractDataModels(files);

      expect(models[0].properties).toContainEqual(
        expect.objectContaining({
          name: 'username',
          type: 'string',
          required: true
        })
      );
    });

    it('should extract TypedDict definitions', async () => {
      const files = new Map<string, string>([
        ['types.py', `
from typing import TypedDict, Optional

class UserDict(TypedDict):
    id: int
    name: str
    email: str
    age: Optional[int]

PersonDict = TypedDict('PersonDict', {
    'first_name': str,
    'last_name': str,
    'age': int
})
        `]
      ]);

      const models = await parser.extractDataModels(files);

      expect(models).toHaveLength(2);
      expect(models[0]).toMatchObject({
        name: 'UserDict',
        type: 'interface',
        extends: ['TypedDict']
      });
      expect(models[1]).toMatchObject({
        name: 'PersonDict',
        type: 'interface'
      });
    });

    it('should extract Enum classes', async () => {
      const files = new Map<string, string>([
        ['enums.py', `
from enum import Enum, auto

class Status(Enum):
    """Order status enumeration"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class Priority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    URGENT = 4
        `]
      ]);

      const models = await parser.extractDataModels(files);

      expect(models).toHaveLength(2);
      expect(models[0]).toMatchObject({
        name: 'Status',
        type: 'enum',
        extends: ['Enum']
      });
    });
  });

  describe('Dependency Extraction', () => {
    it('should extract from requirements.txt', async () => {
      const files = new Map<string, string>([
        ['requirements.txt', `
# Core dependencies
django==4.2.0
djangorestframework>=3.14.0
celery~=5.2.0
redis<5.0.0
pytest

# Database
psycopg2-binary==2.9.6
mysqlclient

# Development dependencies
black==23.3.0  # Code formatter
flake8        # Linter
        `]
      ]);

      const deps = await parser.extractDependencies(files);

      expect(deps).toContainEqual(expect.objectContaining({
        name: 'django',
        version: '4.2.0',
        type: 'runtime'
      }));
      expect(deps).toContainEqual(expect.objectContaining({
        name: 'djangorestframework',
        version: '3.14.0',
        type: 'runtime'
      }));
      expect(deps).toContainEqual(expect.objectContaining({
        name: 'pytest',
        version: 'latest',
        type: 'runtime'
      }));
    });

    it('should extract from setup.py', async () => {
      const files = new Map<string, string>([
        ['setup.py', `
from setuptools import setup, find_packages

setup(
    name="mypackage",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        'requests>=2.28.0',
        'click==8.1.3',
        'pyyaml',
    ],
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'black',
        ]
    }
)
        `]
      ]);

      const deps = await parser.extractDependencies(files);

      expect(deps).toContainEqual(expect.objectContaining({
        name: 'requests',
        version: '2.28.0',
        source: 'setup.py'
      }));
    });

    it('should extract from pyproject.toml', async () => {
      const files = new Map<string, string>([
        ['pyproject.toml', `
[tool.poetry]
name = "myproject"
version = "0.1.0"

[tool.poetry.dependencies]
python = "^3.8"
fastapi = "^0.95.0"
uvicorn = {extras = ["standard"], version = "^0.21.0"}
sqlalchemy = "~2.0.0"

[tool.poetry.dev-dependencies]
pytest = "^7.2.0"
black = "^23.0.0"
        `]
      ]);

      const deps = await parser.extractDependencies(files);

      expect(deps).toContainEqual(expect.objectContaining({
        name: 'fastapi',
        version: '0.95.0',
        source: 'pyproject.toml'
      }));
    });

    it('should extract from Pipfile', async () => {
      const files = new Map<string, string>([
        ['Pipfile', `
[[source]]
url = "https://pypi.org/simple"
verify_ssl = true
name = "pypi"

[packages]
flask = "*"
requests = "~=2.28.0"
gunicorn = "==20.1.0"

[dev-packages]
pytest = "*"
black = "*"

[requires]
python_version = "3.9"
        `]
      ]);

      const deps = await parser.extractDependencies(files);

      expect(deps).toContainEqual(expect.objectContaining({
        name: 'flask',
        version: 'latest',
        type: 'runtime'
      }));
      expect(deps).toContainEqual(expect.objectContaining({
        name: 'pytest',
        type: 'dev'
      }));
    });

    it('should deduplicate dependencies from multiple sources', async () => {
      const files = new Map<string, string>([
        ['requirements.txt', 'django==4.2.0\nrequests==2.28.0'],
        ['setup.py', `
setup(
    install_requires=['django>=4.0.0', 'requests']
)
        `]
      ]);

      const deps = await parser.extractDependencies(files);

      const djangoDeps = deps.filter(d => d.name === 'django');
      expect(djangoDeps).toHaveLength(1);
    });
  });

  describe('Import Extraction', () => {
    it('should extract standard imports', async () => {
      const files = new Map<string, string>([
        ['main.py', `
import os
import sys, json
import datetime as dt
from typing import List, Dict, Optional
from collections import defaultdict
from ..utils import helper
from . import models
from .services.user import UserService
import numpy as np
from pandas import DataFrame, Series
        `]
      ]);

      const imports = await parser.extractImports(files);

      expect(imports).toContainEqual(expect.objectContaining({
        source: 'os',
        imports: [],
        isRelative: false,
        isWildcard: false
      }));
      expect(imports).toContainEqual(expect.objectContaining({
        source: 'datetime',
        alias: 'dt'
      }));
      expect(imports).toContainEqual(expect.objectContaining({
        source: 'typing',
        imports: ['List', 'Dict', 'Optional']
      }));
      expect(imports).toContainEqual(expect.objectContaining({
        source: '..utils',
        imports: ['helper'],
        isRelative: true
      }));
    });

    it('should handle wildcard imports', async () => {
      const files = new Map<string, string>([
        ['wildcards.py', `
from math import *
from .constants import *
        `]
      ]);

      const imports = await parser.extractImports(files);

      expect(imports).toHaveLength(2);
      expect(imports[0]).toMatchObject({
        source: 'math',
        isWildcard: true,
        imports: []
      });
    });
  });

  describe('Comment Extraction', () => {
    it('should extract single-line comments', async () => {
      const files = new Map<string, string>([
        ['comments.py', `
# This is a module-level comment
import os

# TODO: Implement this function
def todo_function():
    # This is an inline comment
    x = 5  # And this is an end-of-line comment
    return x
        `]
      ]);

      const comments = await parser.extractComments(files);

      expect(comments.filter(c => c.type === 'single')).toHaveLength(4);
      expect(comments[0]).toMatchObject({
        type: 'single',
        content: 'This is a module-level comment',
        line: 1
      });
    });

    it('should extract docstrings', async () => {
      const files = new Map<string, string>([
        ['docstrings.py', `
"""Module docstring"""

def function_with_docstring():
    """
    This is a multi-line docstring.
    
    It has multiple paragraphs.
    """
    pass

class MyClass:
    """Class docstring"""
    
    def method(self):
        '''Method with single-quote docstring'''
        pass
        `]
      ]);

      const comments = await parser.extractComments(files);
      const docstrings = comments.filter(c => c.type === 'doc');

      expect(docstrings).toHaveLength(4);
      expect(docstrings[0]).toMatchObject({
        content: 'Module docstring',
        associatedWith: undefined
      });
      expect(docstrings[2]).toMatchObject({
        content: 'Class docstring',
        associatedWith: 'MyClass'
      });
    });

    it('should skip shebang lines', async () => {
      const files = new Map<string, string>([
        ['script.py', `#!/usr/bin/env python3
# This is a real comment
print("Hello")
        `]
      ]);

      const comments = await parser.extractComments(files);

      expect(comments).toHaveLength(1);
      expect(comments[0].content).toBe('This is a real comment');
    });
  });

  describe('Full Parse Integration', () => {
    it('should parse a complete Python file', async () => {
      const files = new Map<string, string>([
        ['complete.py', `
"""
Complete Python module for testing
"""
import json
from typing import List, Optional
from dataclasses import dataclass

@dataclass
class Config:
    """Application configuration"""
    api_key: str
    debug: bool = False

class APIClient:
    """Client for external API"""
    
    def __init__(self, config: Config):
        self.config = config
    
    async def fetch_data(self, endpoint: str) -> dict:
        """Fetch data from API endpoint"""
        # TODO: Implement actual API call
        return {"endpoint": endpoint}

def process_items(items: List[str]) -> Optional[dict]:
    """Process a list of items"""
    if not items:
        return None
    
    return {
        "count": len(items),
        "items": items
    }
        `],
        ['requirements.txt', 'aiohttp==3.8.0\ndataclasses==0.6']
      ]);

      const result = await parser.parse(files);

      expect(result.dataModels).toHaveLength(2);
      expect(result.functions).toHaveLength(3);
      expect(result.dependencies).toHaveLength(2);
      expect(result.imports).toHaveLength(3);
      expect(result.comments.filter(c => c.type === 'doc')).toHaveLength(4);
      expect(result.errors).toHaveLength(0);
    });

    it('should handle parsing errors gracefully', async () => {
      parser = new PythonParser();
      
      // Create a file with syntax that might cause issues
      const files = new Map<string, string>([
        ['error.py', `
def broken_function(
    # This might cause parsing issues
    param1: str = "default"
    param2: int  # Missing comma
):
    pass

class 123InvalidName:  # Invalid class name
    pass
        `]
      ]);

      // Should not throw, but might not extract everything
      const result = await parser.parse(files);
      
      // Should still extract what it can
      expect(result.functions.length).toBeGreaterThanOrEqual(0);
      expect(result.dataModels.length).toBeGreaterThanOrEqual(0);
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty files', async () => {
      const files = new Map<string, string>([
        ['empty.py', ''],
        ['whitespace.py', '   \n\n   \t\n   ']
      ]);

      const result = await parser.parse(files);

      expect(result.apis).toHaveLength(0);
      expect(result.functions).toHaveLength(0);
      expect(result.dataModels).toHaveLength(0);
    });

    it('should handle files with only comments', async () => {
      const files = new Map<string, string>([
        ['comments_only.py', `
# This file only has comments
# TODO: Add actual code
# Maybe someday...
        `]
      ]);

      const result = await parser.parse(files);

      expect(result.comments).toHaveLength(3);
      expect(result.functions).toHaveLength(0);
    });

    it('should handle Unicode in code', async () => {
      const files = new Map<string, string>([
        ['unicode.py', `
def 你好():
    """Chinese function name"""
    emoji = "🐍"
    return f"Python {emoji}"

class Ñoño:
    """Spanish class name"""
    π = 3.14159
        `]
      ]);

      const result = await parser.parse(files);

      expect(result.functions).toHaveLength(1);
      expect(result.dataModels).toHaveLength(1);
    });

    it('should handle nested classes and functions', async () => {
      const files = new Map<string, string>([
        ['nested.py', `
class Outer:
    class Inner:
        class DeepNested:
            def deep_method(self):
                def local_function():
                    return "deep"
                return local_function()
    
    def outer_method(self):
        class MethodLocalClass:
            pass
        return MethodLocalClass()
        `]
      ]);

      const result = await parser.parse(files);

      // Should at least get the outer structures
      expect(result.dataModels.length).toBeGreaterThanOrEqual(1);
      expect(result.functions.length).toBeGreaterThanOrEqual(1);
    });
  });
});